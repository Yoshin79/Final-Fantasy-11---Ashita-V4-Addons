local imgui = require('imgui')
local settings = require('settings')

local config = {}
local state = nil

function config.initialize(shared_state)
    state = shared_state
end

-- Show configuration window
function config.show_window()
    if not state.settings.show_config then return end
    
    local config_open = { true }
    if imgui.Begin('Player Bars Configuration', config_open) then
        imgui.Text('Display Options:')
        imgui.Separator()
        
        local changed = false
        
        local show_hp = { state.settings.show_hp }
        if imgui.Checkbox('Show HP Bar', show_hp) then
            state.settings.show_hp = show_hp[1]
            require('fonts').set_visibility('hp', state.settings.show_hp)
            changed = true
        end
        
        local show_mp = { state.settings.show_mp }
        if imgui.Checkbox('Show MP Bar', show_mp) then
            state.settings.show_mp = show_mp[1]
            require('fonts').set_visibility('mp', state.settings.show_mp)
            changed = true
        end
        
        local show_tp = { state.settings.show_tp }
        if imgui.Checkbox('Show TP Bar', show_tp) then
            state.settings.show_tp = show_tp[1]
            require('fonts').set_visibility('tp', state.settings.show_tp)
            changed = true
        end
        
        local show_target = { state.settings.show_target }
        if imgui.Checkbox('Show Target Bar', show_target) then
            state.settings.show_target = show_target[1]
            require('fonts').set_visibility('target', state.settings.show_target)
            changed = true
        end
        
        local show_max = { state.settings.show_max_values }
        if imgui.Checkbox('Show Maximum Values', show_max) then
            state.settings.show_max_values = show_max[1]
            changed = true
        end
        
        imgui.Separator()
        imgui.Text('Appearance:')
        
        local width = { state.settings.bar_width }
        if imgui.SliderFloat('Bar Width', width, 100.0, 400.0) then
            state.settings.bar_width = width[1]
            require('fonts').update_dimensions()
            changed = true
        end
        
        local height = { state.settings.bar_height }
        if imgui.SliderFloat('Bar Height', height, 10.0, 50.0) then
            state.settings.bar_height = height[1]
            require('fonts').update_dimensions()
            require('fonts').update_positions()
            changed = true
        end
        
        local spacing_val = { state.settings.spacing }
        if imgui.SliderFloat('Spacing', spacing_val, 0.0, 20.0) then
            state.settings.spacing = spacing_val[1]
            require('fonts').update_positions()
            changed = true
        end
        
        -- Font settings
        if imgui.CollapsingHeader('Font Settings') then
            -- Font family dropdown
            if imgui.BeginCombo('Font Family', state.settings.font_family) then
                local families = { 'Arial', 'Consolas', 'Courier New', 'Georgia', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana' }
                for _, family in ipairs(families) do
                    if imgui.Selectable(family, family == state.settings.font_family) then
                        state.settings.font_family = family
                        require('fonts').update_font_family(family)
                        changed = true
                    end
                end
                imgui.EndCombo()
            end
            
            -- Font size
            imgui.Text('Font Size: ' .. state.settings.font_size)
            imgui.SameLine()
            
            if imgui.Button('-') then
                if state.settings.font_size > 8 then
                    state.settings.font_size = state.settings.font_size - 1
                    require('fonts').update_font_size(state.settings.font_size)
                    changed = true
                end
            end
            
            imgui.SameLine()
            
            if imgui.Button('+') then
                if state.settings.font_size < 20 then
                    state.settings.font_size = state.settings.font_size + 1
                    require('fonts').update_font_size(state.settings.font_size)
                    changed = true
                end
            end
        end
        
        -- Color settings
        if imgui.CollapsingHeader('Color Settings') then
            -- Background transparency
            imgui.Text('Background Transparency:')
            local bg_alpha = bit.band(bit.rshift(state.settings.bg_color, 24), 0xFF)
            local bg_alpha_percent = { bg_alpha / 255 * 100 }
            
            if imgui.SliderFloat('##BgAlpha', bg_alpha_percent, 0, 100, '%.0f%%') then
                local new_alpha = math.floor(bg_alpha_percent[1] / 100 * 255)
                state.settings.bg_color = bit.bor(bit.band(state.settings.bg_color, 0x00FFFFFF), bit.lshift(new_alpha, 24))
                require('fonts').update_background_color(state.settings.bg_color)
                changed = true
            end
            
            -- HP color
            local r = bit.band(bit.rshift(state.settings.hp_color, 16), 0xFF) / 255
            local g = bit.band(bit.rshift(state.settings.hp_color, 8), 0xFF) / 255
            local b = bit.band(state.settings.hp_color, 0xFF) / 255
            local a = bit.band(bit.rshift(state.settings.hp_color, 24), 0xFF) / 255
            local hp_color = { r, g, b, a }
            
            if imgui.ColorEdit4('HP Color', hp_color) then
                state.settings.hp_color = bit.bor(
                    bit.lshift(bit.band(math.floor(hp_color[4] * 255), 0xFF), 24),
                    bit.lshift(bit.band(math.floor(hp_color[1] * 255), 0xFF), 16),
                    bit.lshift(bit.band(math.floor(hp_color[2] * 255), 0xFF), 8),
                    bit.band(math.floor(hp_color[3] * 255), 0xFF)
                )
                
                require('fonts').update_color('hp', state.settings.hp_color)
                changed = true
            end
            
            -- MP color
            r = bit.band(bit.rshift(state.settings.mp_color, 16), 0xFF) / 255
            g = bit.band(bit.rshift(state.settings.mp_color, 8), 0xFF) / 255
            b = bit.band(state.settings.mp_color, 0xFF) / 255
            a = bit.band(bit.rshift(state.settings.mp_color, 24), 0xFF) / 255
            local mp_color = { r, g, b, a }
            
            if imgui.ColorEdit4('MP Color', mp_color) then
                state.settings.mp_color = bit.bor(
                    bit.lshift(bit.band(math.floor(mp_color[4] * 255), 0xFF), 24),
                    bit.lshift(bit.band(math.floor(mp_color[1] * 255), 0xFF), 16),
                    bit.lshift(bit.band(math.floor(mp_color[2] * 255), 0xFF), 8),
                    bit.band(math.floor(mp_color[3] * 255), 0xFF)
                )
                
                require('fonts').update_color('mp', state.settings.mp_color)
                changed = true
            end
            
            -- TP color
            r = bit.band(bit.rshift(state.settings.tp_color, 16), 0xFF) / 255
            g = bit.band(bit.rshift(state.settings.tp_color, 8), 0xFF) / 255
            b = bit.band(state.settings.tp_color, 0xFF) / 255
            a = bit.band(bit.rshift(state.settings.tp_color, 24), 0xFF) / 255
            local tp_color = { r, g, b, a }
            
            if imgui.ColorEdit4('TP Color', tp_color) then
                state.settings.tp_color = bit.bor(
                    bit.lshift(bit.band(math.floor(tp_color[4] * 255), 0xFF), 24),
                    bit.lshift(bit.band(math.floor(tp_color[1] * 255), 0xFF), 16),
                    bit.lshift(bit.band(math.floor(tp_color[2] * 255), 0xFF), 8),
                    bit.band(math.floor(tp_color[3] * 255), 0xFF)
                )
                
                require('fonts').update_color('tp', state.settings.tp_color)
                changed = true
            end
            
            -- Target color
            r = bit.band(bit.rshift(state.settings.target_color, 16), 0xFF) / 255
            g = bit.band(bit.rshift(state.settings.target_color, 8), 0xFF) / 255
            b = bit.band(state.settings.target_color, 0xFF) / 255
            a = bit.band(bit.rshift(state.settings.target_color, 24), 0xFF) / 255
            local target_color = { r, g, b, a }
            
            if imgui.ColorEdit4('Target Color', target_color) then
                state.settings.target_color = bit.bor(
                    bit.lshift(bit.band(math.floor(target_color[4] * 255), 0xFF), 24),
                    bit.lshift(bit.band(math.floor(target_color[1] * 255), 0xFF), 16),
                    bit.lshift(bit.band(math.floor(target_color[2] * 255), 0xFF), 8),
                    bit.band(math.floor(target_color[3] * 255), 0xFF)
                )
                
                require('fonts').update_color('target', state.settings.target_color)
                changed = true
            end
        end
        
        imgui.Separator()
        
        if imgui.Button('Reset Position') then
            state.settings.position_x = 100
            state.settings.position_y = 100
            require('fonts').update_positions()
            changed = true
        end
        
        if changed then
            settings.save()
        end
        
        imgui.End()
    end
    
    -- Check if the window was closed with the X button
    if not config_open[1] then
        state.settings.show_config = false
        settings.save()
    end
end

return config
