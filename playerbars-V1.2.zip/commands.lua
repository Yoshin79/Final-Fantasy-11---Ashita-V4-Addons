local commands = {}

-- Process commands
function commands.process(e, state)
    local fonts = require('fonts')
    local settings = require('settings')
    
    local args = e.command:args()
    if (#args == 0 or args[1] ~= '/playerbars') then
        return
    end
    
    e.blocked = true
    
    if #args == 1 then
        state.settings.show_config = not state.settings.show_config
        settings.save()
        print("[Playerbars] Configuration window " .. (state.settings.show_config and "opened" or "closed"))
        return
    end
    
    local cmd = args[2]:lower()
    
    if cmd == 'config' then
        state.settings.show_config = not state.settings.show_config
        settings.save()
        print("[Playerbars] Configuration window " .. (state.settings.show_config and "opened" or "closed"))
    elseif cmd == 'hp' then
        state.settings.show_hp = not state.settings.show_hp
        fonts.set_visibility('hp', state.settings.show_hp)
        settings.save()
        print("[Playerbars] HP bar " .. (state.settings.show_hp and "enabled" or "disabled"))
    elseif cmd == 'mp' then
        state.settings.show_mp = not state.settings.show_mp
        fonts.set_visibility('mp', state.settings.show_mp)
        settings.save()
        print("[Playerbars] MP bar " .. (state.settings.show_mp and "enabled" or "disabled"))
    elseif cmd == 'tp' then
        state.settings.show_tp = not state.settings.show_tp
        fonts.set_visibility('tp', state.settings.show_tp)
        settings.save()
        print("[Playerbars] TP bar " .. (state.settings.show_tp and "enabled" or "disabled"))
    elseif cmd == 'target' then
        state.settings.show_target = not state.settings.show_target
        fonts.set_visibility('target', state.settings.show_target)
        settings.save()
        print("[Playerbars] Target bar " .. (state.settings.show_target and "enabled" or "disabled"))
    elseif cmd == 'max' then
        state.settings.show_max_values = not state.settings.show_max_values
        settings.save()
        print("[Playerbars] Maximum values " .. (state.settings.show_max_values and "enabled" or "disabled"))
    elseif cmd == 'save' then
        settings.save()
        print("[Playerbars] Settings saved")
    elseif cmd == 'reload' then
        settings.reload()
        print("[Playerbars] Settings reloaded")
    elseif cmd == 'reset' then
        settings.reset()
        print("[Playerbars] Settings reset to defaults")
    elseif cmd == 'help' then
        print("[Playerbars] Available commands:")
        print("/playerbars - Toggle config window")
        print("/playerbars config - Toggle config window")
        print("/playerbars hp - Toggle HP bar")
        print("/playerbars mp - Toggle MP bar")
        print("/playerbars tp - Toggle TP bar")
        print("/playerbars target - Toggle target bar")
        print("/playerbars max - Toggle maximum values")
        print("/playerbars save - Save current settings")
        print("/playerbars reload - Reload settings from disk")
        print("/playerbars reset - Reset settings to defaults")
        print("/playerbars help - Show this help")
    else
        print("[Playerbars] Unknown command. Use /playerbars help for available commands.")
    end
end

return commands
