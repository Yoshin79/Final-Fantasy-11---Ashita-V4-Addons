local fonts = {}

-- Font objects
fonts.objects = {
    hp = nil,
    mp = nil,
    tp = nil,
    target = nil
}

local state = nil

-- Initialize fonts
function fonts.initialize(shared_state)
    state = shared_state
    
    -- Create HP font
    fonts.objects.hp = AshitaCore:GetFontManager():Create('__playerbars_hp')
    fonts.objects.hp:SetPositionX(state.settings.position_x)
    fonts.objects.hp:SetPositionY(state.settings.position_y)
    fonts.objects.hp:SetColor(state.settings.hp_color)
    fonts.objects.hp:SetFontFamily(state.settings.font_family)
    fonts.objects.hp:SetFontHeight(state.settings.font_size)
    fonts.objects.hp:GetBackground():SetVisible(true)
    fonts.objects.hp:GetBackground():SetColor(state.settings.bg_color)
    fonts.objects.hp:SetVisible(state.settings.show_hp)
    fonts.objects.hp:SetText('HP: Loading...')
    fonts.objects.hp:GetBackground():SetWidth(state.settings.bar_width)
    fonts.objects.hp:GetBackground():SetHeight(state.settings.bar_height)
    
    -- Create MP font
    fonts.objects.mp = AshitaCore:GetFontManager():Create('__playerbars_mp')
    fonts.objects.mp:SetPositionX(state.settings.position_x)
    fonts.objects.mp:SetPositionY(state.settings.position_y + state.settings.bar_height + state.settings.spacing)
    fonts.objects.mp:SetColor(state.settings.mp_color)
    fonts.objects.mp:SetFontFamily(state.settings.font_family)
    fonts.objects.mp:SetFontHeight(state.settings.font_size)
    fonts.objects.mp:GetBackground():SetVisible(true)
    fonts.objects.mp:GetBackground():SetColor(state.settings.bg_color)
    fonts.objects.mp:SetVisible(state.settings.show_mp)
    fonts.objects.mp:SetText('MP: Loading...')
    fonts.objects.mp:GetBackground():SetWidth(state.settings.bar_width)
    fonts.objects.mp:GetBackground():SetHeight(state.settings.bar_height)
    
    -- Create TP font
    fonts.objects.tp = AshitaCore:GetFontManager():Create('__playerbars_tp')
    fonts.objects.tp:SetPositionX(state.settings.position_x)
    fonts.objects.tp:SetPositionY(state.settings.position_y + (state.settings.bar_height + state.settings.spacing) * 2)
    fonts.objects.tp:SetColor(state.settings.tp_color)
    fonts.objects.tp:SetFontFamily(state.settings.font_family)
    fonts.objects.tp:SetFontHeight(state.settings.font_size)
    fonts.objects.tp:GetBackground():SetVisible(true)
    fonts.objects.tp:GetBackground():SetColor(state.settings.bg_color)
    fonts.objects.tp:SetVisible(state.settings.show_tp)
    fonts.objects.tp:SetText('TP: Loading...')
    fonts.objects.tp:GetBackground():SetWidth(state.settings.bar_width)
    fonts.objects.tp:GetBackground():SetHeight(state.settings.bar_height)
    
    -- Create Target font
    fonts.objects.target = AshitaCore:GetFontManager():Create('__playerbars_target')
    fonts.objects.target:SetPositionX(state.settings.position_x)
    fonts.objects.target:SetPositionY(state.settings.position_y + (state.settings.bar_height + state.settings.spacing) * 3)
    fonts.objects.target:SetColor(state.settings.target_color)
    fonts.objects.target:SetFontFamily(state.settings.font_family)
    fonts.objects.target:SetFontHeight(state.settings.font_size)
    fonts.objects.target:GetBackground():SetVisible(true)
    fonts.objects.target:GetBackground():SetColor(state.settings.bg_color)
    fonts.objects.target:SetVisible(state.settings.show_target)
    fonts.objects.target:SetText('Target: None')
    fonts.objects.target:GetBackground():SetWidth(state.settings.bar_width)
    fonts.objects.target:GetBackground():SetHeight(state.settings.bar_height)
end

-- Clean up fonts
function fonts.cleanup()
    if fonts.objects.hp then
        AshitaCore:GetFontManager():Delete('__playerbars_hp')
        fonts.objects.hp = nil
    end
    if fonts.objects.mp then
        AshitaCore:GetFontManager():Delete('__playerbars_mp')
        fonts.objects.mp = nil
    end
    if fonts.objects.tp then
        AshitaCore:GetFontManager():Delete('__playerbars_tp')
        fonts.objects.tp = nil
    end
    if fonts.objects.target then
        AshitaCore:GetFontManager():Delete('__playerbars_target')
        fonts.objects.target = nil
    end
end

-- Apply settings to fonts
function fonts.apply_settings()
    if fonts.objects.hp then
        fonts.objects.hp:SetPositionX(state.settings.position_x)
        fonts.objects.hp:SetPositionY(state.settings.position_y)
        fonts.objects.hp:SetColor(state.settings.hp_color)
        fonts.objects.hp:SetFontFamily(state.settings.font_family)
        fonts.objects.hp:SetFontHeight(state.settings.font_size)
        fonts.objects.hp:GetBackground():SetColor(state.settings.bg_color)
        fonts.objects.hp:GetBackground():SetWidth(state.settings.bar_width)
        fonts.objects.hp:GetBackground():SetHeight(state.settings.bar_height)
        fonts.objects.hp:SetVisible(state.settings.show_hp)
    end
    
    if fonts.objects.mp then
        fonts.objects.mp:SetPositionX(state.settings.position_x)
        fonts.objects.mp:SetPositionY(state.settings.position_y + state.settings.bar_height + state.settings.spacing)
        fonts.objects.mp:SetColor(state.settings.mp_color)
        fonts.objects.mp:SetFontFamily(state.settings.font_family)
        fonts.objects.mp:SetFontHeight(state.settings.font_size)
        fonts.objects.mp:GetBackground():SetColor(state.settings.bg_color)
        fonts.objects.mp:GetBackground():SetWidth(state.settings.bar_width)
        fonts.objects.mp:GetBackground():SetHeight(state.settings.bar_height)
        fonts.objects.mp:SetVisible(state.settings.show_mp)
    end
    
    if fonts.objects.tp then
        fonts.objects.tp:SetPositionX(state.settings.position_x)
        fonts.objects.tp:SetPositionY(state.settings.position_y + (state.settings.bar_height + state.settings.spacing) * 2)
        fonts.objects.tp:SetColor(state.settings.tp_color)
        fonts.objects.tp:SetFontFamily(state.settings.font_family)
        fonts.objects.tp:SetFontHeight(state.settings.font_size)
        fonts.objects.tp:GetBackground():SetColor(state.settings.bg_color)
        fonts.objects.tp:GetBackground():SetWidth(state.settings.bar_width)
        fonts.objects.tp:GetBackground():SetHeight(state.settings.bar_height)
        fonts.objects.tp:SetVisible(state.settings.show_tp)
    end
    
    if fonts.objects.target then
        fonts.objects.target:SetPositionX(state.settings.position_x)
        fonts.objects.target:SetPositionY(state.settings.position_y + (state.settings.bar_height + state.settings.spacing) * 3)
        fonts.objects.target:SetColor(state.settings.target_color)
        fonts.objects.target:SetFontFamily(state.settings.font_family)
        fonts.objects.target:SetFontHeight(state.settings.font_size)
        fonts.objects.target:GetBackground():SetColor(state.settings.bg_color)
        fonts.objects.target:GetBackground():SetWidth(state.settings.bar_width)
        fonts.objects.target:GetBackground():SetHeight(state.settings.bar_height)
        fonts.objects.target:SetVisible(state.settings.show_target)
    end
end

-- Update font positions
function fonts.update_positions()
    if fonts.objects.hp then
        fonts.objects.hp:SetPositionX(state.settings.position_x)
        fonts.objects.hp:SetPositionY(state.settings.position_y)
    end
    
    if fonts.objects.mp then
        fonts.objects.mp:SetPositionX(state.settings.position_x)
        fonts.objects.mp:SetPositionY(state.settings.position_y + state.settings.bar_height + state.settings.spacing)
    end
    
    if fonts.objects.tp then
        fonts.objects.tp:SetPositionX(state.settings.position_x)
        fonts.objects.tp:SetPositionY(state.settings.position_y + (state.settings.bar_height + state.settings.spacing) * 2)
    end
    
    if fonts.objects.target then
        fonts.objects.target:SetPositionX(state.settings.position_x)
        fonts.objects.target:SetPositionY(state.settings.position_y + (state.settings.bar_height + state.settings.spacing) * 3)
    end
end

-- Update font dimensions
function fonts.update_dimensions()
    if fonts.objects.hp then
        fonts.objects.hp:GetBackground():SetWidth(state.settings.bar_width)
        fonts.objects.hp:GetBackground():SetHeight(state.settings.bar_height)
    end
    
    if fonts.objects.mp then
        fonts.objects.mp:GetBackground():SetWidth(state.settings.bar_width)
        fonts.objects.mp:GetBackground():SetHeight(state.settings.bar_height)
    end
    
    if fonts.objects.tp then
        fonts.objects.tp:GetBackground():SetWidth(state.settings.bar_width)
        fonts.objects.tp:GetBackground():SetHeight(state.settings.bar_height)
    end
    
    if fonts.objects.target then
        fonts.objects.target:GetBackground():SetWidth(state.settings.bar_width)
        fonts.objects.target:GetBackground():SetHeight(state.settings.bar_height)
    end
end

-- Update font family
function fonts.update_font_family(family)
    if fonts.objects.hp then fonts.objects.hp:SetFontFamily(family) end
    if fonts.objects.mp then fonts.objects.mp:SetFontFamily(family) end
    if fonts.objects.tp then fonts.objects.tp:SetFontFamily(family) end
    if fonts.objects.target then fonts.objects.target:SetFontFamily(family) end
end

-- Update font size
function fonts.update_font_size(size)
    if fonts.objects.hp then fonts.objects.hp:SetFontHeight(size) end
    if fonts.objects.mp then fonts.objects.mp:SetFontHeight(size) end
    if fonts.objects.tp then fonts.objects.tp:SetFontHeight(size) end
    if fonts.objects.target then fonts.objects.target:SetFontHeight(size) end
end

-- Update background color
function fonts.update_background_color(color)
    if fonts.objects.hp then fonts.objects.hp:GetBackground():SetColor(color) end
    if fonts.objects.mp then fonts.objects.mp:GetBackground():SetColor(color) end
    if fonts.objects.tp then fonts.objects.tp:GetBackground():SetColor(color) end
    if fonts.objects.target then fonts.objects.target:GetBackground():SetColor(color) end
end

-- Update font color
function fonts.update_color(type, color)
    if fonts.objects[type] then
        fonts.objects[type]:SetColor(color)
    end
end

-- Set font visibility
function fonts.set_visibility(type, visible)
    if fonts.objects[type] then
        fonts.objects[type]:SetVisible(visible)
    end
end

-- Save font positions
function fonts.save_positions()
    if fonts.objects.hp then
        state.settings.position_x = fonts.objects.hp:GetPositionX()
        state.settings.position_y = fonts.objects.hp:GetPositionY()
        require('settings').save()
    end
end

-- Check for position changes
function fonts.check_position_changes()
    if fonts.objects.hp then
        local pos_x = fonts.objects.hp:GetPositionX()
        local pos_y = fonts.objects.hp:GetPositionY()
        
        if pos_x ~= state.settings.position_x or pos_y ~= state.settings.position_y then
            -- Update stored position
            state.settings.position_x = pos_x
            state.settings.position_y = pos_y
            
            -- Update other fonts to follow
            fonts.update_positions()
            
            -- Save settings when position changes
            require('settings').save()
        end
    end
end

return fonts
