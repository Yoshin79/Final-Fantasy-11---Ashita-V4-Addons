local display = {}

-- Update display
function display.update(state)
    local fonts = require('fonts')
    local config = require('config')
    
    -- Get player entity
    local player = GetPlayerEntity()
    if player == nil then return end
    
    -- Get memory managers
    local party = AshitaCore:GetMemoryManager():GetParty()
    local playerMem = AshitaCore:GetMemoryManager():GetPlayer()
    local targetMgr = AshitaCore:GetMemoryManager():GetTarget()
    
    if not party or not playerMem then return end
    
    -- Get player stats directly from entity and memory
    local hp_current = party:GetMemberHP(0)
    local hp_max = playerMem:GetHPMax()
    local mp_current = party:GetMemberMP(0)
    local mp_max = playerMem:GetMPMax()
    local tp_current = party:GetMemberTP(0)
    
    -- Update HP text
    if fonts.objects.hp then
        if state.settings.show_max_values then
            fonts.objects.hp:SetText(string.format('HP: %d/%d', hp_current, hp_max))
        else
            fonts.objects.hp:SetText(string.format('HP: %d', hp_current))
        end
    end
    
    -- Update MP text
    if fonts.objects.mp then
        if state.settings.show_max_values then
            fonts.objects.mp:SetText(string.format('MP: %d/%d', mp_current, mp_max))
        else
            fonts.objects.mp:SetText(string.format('MP: %d', mp_current))
        end
    end
    
    -- Update TP text
    if fonts.objects.tp then
        if state.settings.show_max_values then
            fonts.objects.tp:SetText(string.format('TP: %d/1000', tp_current))
        else
            fonts.objects.tp:SetText(string.format('TP: %d', tp_current))
        end
    end
    
    -- Update Target text
    if fonts.objects.target and state.settings.show_target then
        local target_index = targetMgr:GetTargetIndex(0)
        
        if target_index ~= 0 then
            local entity = GetEntity(target_index)
            
            if entity then
                local target_name = entity.Name
                local target_hp_percent = entity.HPPercent
                
                -- Create a visual representation of the HP bar
                local bar_length = 20 -- Characters for the bar
                local filled_chars = math.floor(bar_length * target_hp_percent / 100)
                local empty_chars = bar_length - filled_chars
                local hp_bar = string.rep('█', filled_chars) .. string.rep('░', empty_chars)
                
                fonts.objects.target:SetText(string.format('%s: %s %d%%', target_name, hp_bar, target_hp_percent))
                fonts.objects.target:SetVisible(true)
            else
                fonts.objects.target:SetText('Target: None')
                fonts.objects.target:SetVisible(state.settings.show_target)
            end
        else
            fonts.objects.target:SetText('Target: None')
            fonts.objects.target:SetVisible(state.settings.show_target)
        end
    end
    
    -- Show configuration window
    config.show_window()
    
    -- Check for position changes
    fonts.check_position_changes()
end

return display
