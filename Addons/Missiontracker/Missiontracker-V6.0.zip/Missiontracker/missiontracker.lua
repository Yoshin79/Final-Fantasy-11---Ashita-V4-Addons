addon.name    = 'missiontracker';
addon.author  = 'Oneword - With Resources from FFXI game play online forums, https://www.bg-wiki.com/ and https://ffxiclopedia.fandom.com/ ';
addon.version = '5.8';
addon.desc    = 'Tracks progress through ffxi story line with detailed steps';

require('common');
local imgui = require('imgui');

------------------------------------------------------------
-- Load data files
------------------------------------------------------------
local base = AshitaCore:GetInstallPath() .. 'addons\\missiontracker\\data\\';
local MISSION_LINES = {};
local LINE_ORDER = {'bastok','sandoria','windurst','zilart','cop','toau','wotg','adoulin','rov','acp','mkd','asa'};
local files = {
    bastok='bastok.lua', sandoria='sandoria.lua', windurst='windurst.lua',
    zilart='zilart.lua', cop='cop.lua', toau='toau.lua',
    wotg='wotg.lua', adoulin='adoulin.lua', rov='rov.lua', acp='acp.lua', mkd='mkd.lua', asa='asa.lua',
};
for id, fname in pairs(files) do
    local fn, err = loadfile(base .. fname);
    if fn then
        local ok, data = pcall(fn);
        if ok and type(data)=='table' then MISSION_LINES[id]=data;
        else print('[missiontracker] Error in '..fname..': '..tostring(data)); end
    else print('[missiontracker] Cannot find: '..base..fname); end
end

------------------------------------------------------------
-- Colors
------------------------------------------------------------
local lc = {
    bastok={0.25,0.50,0.85,1}, sandoria={0.90,0.20,0.20,1}, windurst={0.45,0.65,0.38,1},
    zilart={0.60,0.35,0.90,1}, cop={0.90,0.70,0.10,1},      toau={0.85,0.50,0.10,1},
    wotg={0.85,0.35,0.70,1},   adoulin={0.15,0.75,0.75,1},  rov={0.75,0.55,0.95,1},
    acp={0.25,0.60,0.90,1},   mkd={0.85,0.40,0.40,1},   asa={0.75,0.55,0.20,1},
};
local TITLE   = {0.7,0.3,1.0,1}; local HDR  = {0.4,0.8,1.0,1};
local REQ     = {1.0,0.8,0.2,1}; local NOTE = {1.0,0.7,0.2,1};
local PREREQ  = {1.0,0.55,0.1,1};local RWD  = {0.9,0.80,0.3,1};
local SHORT   = {bastok='Bastok',sandoria="San d'Oria",windurst='Windurst',
                 zilart='Zilart',cop='CoP',toau='ToAU',wotg='WotG',adoulin='Adoulin',rov='RoV',acp='ACP',mkd='MKD',asa='ASA'};

------------------------------------------------------------
-- State
------------------------------------------------------------
local mt = { open={true}, sel=nil, char='', done={}, savepath=nil };

------------------------------------------------------------
-- Save/Load
------------------------------------------------------------
local function savepath()
    if mt.savepath then return mt.savepath end;
    local p = AshitaCore:GetInstallPath()..'config\\missiontracker\\';
    ashita.fs.create_dir(p); mt.savepath=p; return p;
end
local function save()
    if mt.char=='' then return end;
    local f=io.open(savepath()..mt.char..'.lua','w');
    if not f then return end;
    f:write('return {\n');
    for k,v in pairs(mt.done) do
        if v==true then f:write(string.format('  [%q]=true,\n',k));
        elseif v==false then f:write(string.format('  [%q]=false,\n',k)); end
    end
    f:write('}\n'); f:close();
end
local function load_char()
    if mt.char=='' then return end; mt.done={};
    local p=savepath()..mt.char..'.lua';
    if not ashita.fs.exists(p) then return end;
    local fn=loadfile(p); if fn then local ok,d=pcall(fn); if ok and type(d)=='table' then mt.done=d end end;
end
local function mk(lid,num) return lid..'|'..num end;
local function done(lid,num) return mt.done[mk(lid,num)]==true end;
-- Render a string safely: split into <=200-char chunks to prevent ImGui crashes
local function safe_text(s, color)
    -- escape % which ImGui treats as printf format specifier
    s = s:gsub('%%', '%%%%')
    local max = 200;
    if #s <= max then
        if color then imgui.TextColored(color, s) else imgui.TextWrapped(s) end
        return
    end
    local i = 1
    local first = true
    while i <= #s do
        local chunk = s:sub(i, i + max - 1)
        if i + max - 1 < #s then
            local cut = chunk:match('.*()%s') or max
            chunk = s:sub(i, i + cut - 1)
            i = i + cut
        else
            i = i + max
        end
        if not first then
            -- indent continuation lines to align under the first line (past the checkbox button)
            imgui.SetCursorPosX(imgui.GetCursorPosX() + 34)
        end
        if color then imgui.TextColored(color, chunk) else imgui.TextWrapped(chunk) end
        first = false
    end
end
local function toggle(lid,num)
    local k=mk(lid,num);
    if mt.done[k]==true then
        mt.done[k]=false;
    else
        mt.done[k]=true;
    end
    print('[mt] toggle '..k..' = '..tostring(mt.done[k]));
    save();
end;
local function mks(lid,num,si) return lid..'|'..num..'|step'..si end;
local function step_done(lid,num,si) return mt.done[mks(lid,num,si)]==true end;
local function toggle_step(lid,num,si)
    local k=mks(lid,num,si);
    mt.done[k] = mt.done[k]~=true;
    save();
end;
local function cnt(line)
    local d,t=0,0;
    for _,m in ipairs(line.missions) do t=t+1; if done(line.id,m.num) then d=d+1 end end;
    return d,t;
end

------------------------------------------------------------
-- Render one mission
------------------------------------------------------------
local function render_mission(line, m)
    local col=lc[line.id]; local dn=done(line.id,m.num);
    local r,g,b=col[1],col[2],col[3];
    local bg,hv,ac;
    if dn then
        bg={0.08,0.28,0.10,1};hv={0.12,0.38,0.14,1};ac={0.05,0.20,0.08,1};
    else
        -- pre-compute without Sugar interference
        local r26=r*0.26; local g26=g*0.26; local b26=b*0.26;
        local r38=r*0.38; local g38=g*0.38; local b38=b*0.38;
        local r18=r*0.18; local g18=g*0.18; local b18=b*0.18;
        bg={r26,g26,b26,1};hv={r38,g38,b38,1};ac={r18,g18,b18,1};
    end
    imgui.PushStyleColor(ImGuiCol_Header,bg);
    imgui.PushStyleColor(ImGuiCol_HeaderHovered,hv);
    imgui.PushStyleColor(ImGuiCol_HeaderActive,ac);
    if imgui.CollapsingHeader(m.num..'  '..m.name..'##hdr'..line.id..m.num:gsub('[^%w]','_')) then
        imgui.Indent(14);
        -- status indicator
        if dn then
            imgui.TextColored({0.3,1.0,0.4,1},'[+] Complete');
        else
            imgui.TextColored({0.5,0.5,0.5,1},'[ ] Incomplete');
        end
        -- prereqs
        if m.prereqs and #m.prereqs>0 then
            imgui.PushStyleColor(ImGuiCol_Header,{0.12,0.28,0.18,1});
            imgui.PushStyleColor(ImGuiCol_HeaderHovered,{0.16,0.36,0.24,1});
            imgui.PushStyleColor(ImGuiCol_HeaderActive,{0.08,0.20,0.12,1});
            if imgui.CollapsingHeader('  Prerequisites ('..#m.prereqs..')##p'..line.id..m.num:gsub('[^%w]','_')) then
                imgui.Indent(10);
                for _,p in ipairs(m.prereqs) do
                    imgui.TextColored(PREREQ,'>> '..p);
                end
                imgui.Unindent(10); imgui.Spacing();
            end
            imgui.PopStyleColor(3); imgui.Spacing();
        end
        -- notes
        if m.notes and #m.notes>0 then
            imgui.PushStyleColor(ImGuiCol_Header,{0.12,0.28,0.18,1});
            imgui.PushStyleColor(ImGuiCol_HeaderHovered,{0.16,0.36,0.24,1});
            imgui.PushStyleColor(ImGuiCol_HeaderActive,{0.08,0.20,0.12,1});
            if imgui.CollapsingHeader('  Notes ('..#m.notes..')##n'..line.id..m.num:gsub('[^%w]','_')) then
                imgui.Indent(10);
                for _,n in ipairs(m.notes) do
                    imgui.TextColored({0.7,0.5,0.1,1},'- '); imgui.SameLine();
                    safe_text(n);
                end
                imgui.Unindent(10); imgui.Spacing();
            end
            imgui.PopStyleColor(3); imgui.Spacing();
        end
        -- steps
        if m.steps and #m.steps>0 then
            local sdone=0;
            for si=1,#m.steps do if step_done(line.id,m.num,si) then sdone=sdone+1 end end;
            local shdr = sdone>0 and ('  Steps ('..sdone..'/'..#m.steps..' done)') or ('  Steps ('..#m.steps..')');
            local hkey = 'so_'..line.id..m.num:gsub('[^%w]','_');
            if mt.open[hkey]==nil then mt.open[hkey]=false end;
            -- draw header as a button to control open state manually
            imgui.PushStyleColor(ImGuiCol_Button,     mt.open[hkey] and {0.10,0.22,0.32,1} or {0.08,0.18,0.26,1});
            imgui.PushStyleColor(ImGuiCol_ButtonHovered, {0.14,0.30,0.44,1});
            imgui.PushStyleColor(ImGuiCol_ButtonActive,  {0.08,0.16,0.26,1});
            local arrow = mt.open[hkey] and 'v' or '>';
            if imgui.Button(arrow..' '..shdr..'##shdr_'..hkey, {-1, 0}) then
                mt.open[hkey] = not mt.open[hkey];
            end
            imgui.PopStyleColor(3);
            if mt.open[hkey] then
                imgui.Indent(10);
                for si,step in ipairs(m.steps) do
                    local checked = step_done(line.id,m.num,si);
                    -- detect section header lines and pick color
                    local is_sandy    = step:find('^=== SANDY')    ~= nil or step:find("^SAN D'ORIA:") ~= nil;
                    local is_bastok   = step:find('^=== BASTOK')   ~= nil or step:find('^BASTOK:')     ~= nil;
                    local is_windurst = step:find('^=== WINDURST') ~= nil or step:find('^WINDURST:')   ~= nil;
                    local is_header   = is_sandy or is_bastok or is_windurst;
                    local header_col;
                    if is_sandy    then header_col = {1.0, 0.35, 0.35, 1} end; -- red
                    if is_bastok   then header_col = {0.45, 0.70, 1.0, 1} end; -- blue
                    if is_windurst then header_col = {1.0, 0.85, 0.25, 1} end; -- yellow
                    imgui.PushID('step_'..line.id..'_'..m.num:gsub('[^%w]','_')..'_'..si);
                    imgui.PushStyleColor(ImGuiCol_Button,        checked and {0.10,0.36,0.10,1} or {0.18,0.18,0.26,1});
                    imgui.PushStyleColor(ImGuiCol_ButtonHovered, checked and {0.16,0.50,0.16,1} or {0.28,0.28,0.40,1});
                    imgui.PushStyleColor(ImGuiCol_ButtonActive,  checked and {0.08,0.26,0.08,1} or {0.12,0.12,0.22,1});
                    local lbl = checked and '  *  ' or '  -  ';
                    if imgui.Button(lbl, {26, 18}) then
                        toggle_step(line.id, m.num, si);
                    end
                    imgui.PopStyleColor(3);
                    imgui.PopID();
                    imgui.SameLine();
                    if is_header then
                        safe_text(step, header_col);
                    elseif checked then
                        safe_text(step, {0.35,0.65,0.35,1});
                    else
                        safe_text(step);
                    end
                end
                imgui.Unindent(10); imgui.Spacing();
            end
            imgui.Spacing();
        end
        -- rewards
        if m.rewards and #m.rewards>0 then
            imgui.PushStyleColor(ImGuiCol_Header,{0.12,0.28,0.18,1});
            imgui.PushStyleColor(ImGuiCol_HeaderHovered,{0.16,0.36,0.24,1});
            imgui.PushStyleColor(ImGuiCol_HeaderActive,{0.08,0.20,0.12,1});
            if imgui.CollapsingHeader('  Rewards ('..#m.rewards..')##r'..line.id..m.num:gsub('[^%w]','_')) then
                imgui.Indent(10);
                for _,rw in ipairs(m.rewards) do
                    imgui.TextColored({0.9,0.75,0.2,1},'+ '); imgui.SameLine();
                    imgui.TextColored(RWD,rw);
                end
                imgui.Unindent(10); imgui.Spacing();
            end
            imgui.PopStyleColor(3); imgui.Spacing();
        end
        -- button
        imgui.Spacing();
        local id=(line.id..m.num):gsub('[^%w]','_');
        if dn then
            imgui.PushStyleColor(ImGuiCol_Button,{0.14,0.36,0.14,1});
            imgui.PushStyleColor(ImGuiCol_ButtonHovered,{0.18,0.50,0.18,1});
            imgui.PushStyleColor(ImGuiCol_ButtonActive,{0.10,0.26,0.10,1});
            if imgui.Button('[ ] Mark Incomplete: '..m.num,{200,0}) then toggle(line.id,m.num) end;
            imgui.PopStyleColor(3);
        else
            imgui.PushStyleColor(ImGuiCol_Button,{0.12,0.20,0.36,1});
            imgui.PushStyleColor(ImGuiCol_ButtonHovered,{0.18,0.28,0.50,1});
            imgui.PushStyleColor(ImGuiCol_ButtonActive,{0.08,0.14,0.26,1});
            if imgui.Button('[+] Mark Complete: '..m.num,{200,0}) then toggle(line.id,m.num) end;
            imgui.PopStyleColor(3);
        end
        imgui.Unindent(14); imgui.Spacing();
    end
    imgui.PopStyleColor(3);
end

------------------------------------------------------------
-- Main render
------------------------------------------------------------
local function render_ui()
    if not mt.open[1] then return end;
    imgui.PushStyleColor(ImGuiCol_WindowBg,{0.06,0.06,0.10,0.98});
    imgui.PushStyleColor(ImGuiCol_TitleBg,{0.10,0.10,0.18,1});
    imgui.PushStyleColor(ImGuiCol_TitleBgActive,{0.14,0.14,0.24,1});
    imgui.PushStyleColor(ImGuiCol_Border,{0.55,0.48,0.22,0.90});
    imgui.PushStyleColor(ImGuiCol_Separator,{0.45,0.40,0.18,0.70});
    imgui.PushStyleColor(ImGuiCol_ScrollbarBg,{0.05,0.05,0.08,1});
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrab,{0.30,0.26,0.10,1});
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrabHovered,{0.45,0.40,0.16,1});
    imgui.PushStyleColor(ImGuiCol_Button,{0.14,0.18,0.28,1});
    imgui.PushStyleColor(ImGuiCol_ButtonHovered,{0.22,0.28,0.42,1});
    imgui.PushStyleColor(ImGuiCol_ButtonActive,{0.10,0.14,0.22,1});
    imgui.PushStyleColor(ImGuiCol_Header,{0.16,0.22,0.32,1});
    imgui.PushStyleColor(ImGuiCol_HeaderHovered,{0.22,0.30,0.44,1});
    imgui.PushStyleColor(ImGuiCol_HeaderActive,{0.12,0.16,0.26,1});

    imgui.SetNextWindowSizeConstraints({500,400},{1920,1080});
    imgui.SetNextWindowSize({860,720},ImGuiCond_FirstUseEver);

    if imgui.Begin('Mission Tracker',mt.open,ImGuiWindowFlags_None) then
        -- header
        local tp={imgui.GetCursorScreenPos()};
        imgui.SetCursorScreenPos({tp[1]+1,tp[2]+1});
        imgui.TextColored({0,0,0,0.6},'FFXI Mission Tracker  v5.8');
        imgui.SetCursorScreenPos(tp);
        imgui.TextColored(TITLE,'FFXI Mission Tracker  v5.8');
        if mt.char~='' then imgui.SameLine(); imgui.TextColored({0.5,0.5,0.5,1},' | '); imgui.SameLine(); imgui.TextColored(HDR,mt.char); end;
        imgui.Spacing(); imgui.Separator(); imgui.Spacing();

        -- overall progress with visual bar
        local gd,gt=0,0;
        for _,lid in ipairs(LINE_ORDER) do
            if MISSION_LINES[lid] then local d,t=cnt(MISSION_LINES[lid]); gd=gd+d; gt=gt+t; end;
        end
        local pct=0; if gt>0 then pct=math.floor(gd/gt*100) end;
        local frac=0; if gt>0 then frac=gd/gt end;
        imgui.TextColored(REQ,string.format('Overall Progress:  %d / %d  (%d%%)',gd,gt,pct));
        -- draw progress bar
        local bw=imgui.GetWindowWidth();
        local bw2=bw-20;
        imgui.PushStyleColor(ImGuiCol_PlotHistogram,{0.35,0.70,0.35,1.0});
        imgui.PushStyleColor(ImGuiCol_FrameBg,{0.15,0.15,0.15,1.0});
        imgui.ProgressBar(frac,{bw2,14},'');
        imgui.PopStyleColor(2);
        imgui.Spacing(); imgui.Separator(); imgui.Spacing();

        -- line buttons — auto-size width to fit label + counts
        -- use fixed width wide enough for longest label "San d'Oria 20/20"
        local BW,BH=100,28;
        local pr=9; -- show all 9 buttons in one row
        local bc=0;
        for _,lid in ipairs(LINE_ORDER) do
            if MISSION_LINES[lid] then
                local line=MISSION_LINES[lid]; local col=lc[lid];
                local d,t=cnt(line); local sel=(mt.sel==lid);
                if bc>0 and bc%pr~=0 then imgui.SameLine(0,6) end;
                local r2,g2,b2=col[1],col[2],col[3]; local dim=0.45;
                local rd,gd,bd = r2*dim, g2*dim, b2*dim;
                local bc2  = sel and {r2,g2,b2,1}           or {rd,gd,bd,1};
                local bch_r= sel and (r2*1.25 > 1 and 1 or r2*1.25) or rd*1.4;
                local bch_g= sel and (g2*1.25 > 1 and 1 or g2*1.25) or gd*1.4;
                local bch_b= sel and (b2*1.25 > 1 and 1 or b2*1.25) or bd*1.4;
                local bch  = {bch_r, bch_g, bch_b, 1};
                local bca  = sel and {r2*0.85,g2*0.85,b2*0.85,1} or {rd*0.8,gd*0.8,bd*0.8,1};
                imgui.PushStyleColor(ImGuiCol_Button,bc2);
                imgui.PushStyleColor(ImGuiCol_ButtonHovered,bch);
                imgui.PushStyleColor(ImGuiCol_ButtonActive,bca);
                local lbl=string.format('%s##sel%s',SHORT[lid],lid);
                if imgui.Button(lbl,{BW,BH}) then mt.sel=sel and nil or lid; end;
                imgui.PopStyleColor(3);
                if imgui.IsItemHovered() then
                    imgui.BeginTooltip();
                    imgui.TextColored(col,line.label);
                    imgui.Text(string.format('%d / %d complete',d,t));
                    imgui.EndTooltip();
                end
                bc=bc+1;
            end
        end

        imgui.NewLine(); imgui.Separator(); imgui.Spacing();

        -- selected line content
        if mt.sel and MISSION_LINES[mt.sel] then
            local line=MISSION_LINES[mt.sel]; local col=lc[mt.sel];
            local d,t=cnt(line);
            local lp={imgui.GetCursorScreenPos()};
            imgui.SetCursorScreenPos({lp[1]+1,lp[2]+1});
            imgui.TextColored({0,0,0,0.55},'>> '..line.label);
            imgui.SetCursorScreenPos(lp);
            imgui.TextColored(col,'>> '..line.label);
            imgui.SameLine();
            local dc=(d==t and t>0) and {0.3,1.0,0.4,1} or REQ;
            imgui.TextColored(dc,string.format('  %d / %d complete',d,t));
            imgui.Spacing(); imgui.Separator(); imgui.Spacing();
            -- entry
            imgui.TextColored(HDR,'Entry Requirement:');
            imgui.Indent(10); imgui.TextWrapped(line.entry); imgui.Unindent(10);
            imgui.Spacing(); imgui.Separator(); imgui.Spacing();
            -- missions
            for _,m in ipairs(line.missions) do
                local ok, err = pcall(render_mission, line, m)
                if not ok then
                    imgui.TextColored({1,0.2,0.2,1}, 'ERROR in '..tostring(m.num)..': '..tostring(err))
                end
            end
        else
            imgui.TextColored(HDR,'Select a mission line above.');
            imgui.Spacing();
            imgui.TextColored({0.4,0.4,0.4,1},'To update missions, edit the .lua file in the /data/ folder.');
        end
    end
    imgui.End();
    imgui.PopStyleColor(14);
end

------------------------------------------------------------
-- Events
------------------------------------------------------------
ashita.events.register('load','mt_load',function()
    local mem=AshitaCore:GetMemoryManager();
    if mem then local p=mem:GetParty(); if p then local n=p:GetMemberName(0); if n and n~='' then mt.char=n; load_char(); end end end;
    imgui.SetNextWindowPos({100,100},ImGuiCond_FirstUseEver);
    print('[missiontracker] v3.9 loaded. /mt to toggle.');
end);

ashita.events.register('unload','mt_unload',function() save(); end);

ashita.events.register('command','mt_cmd',function(e)
    local a=e.command:args(); if #a==0 then return end;
    if a[1]~='/mt' and a[1]~='/missiontracker' then return end;
    e.blocked=true;
    if #a==1 then mt.open[1]=not mt.open[1];
    elseif a[2]=='show' then mt.open[1]=true;
    elseif a[2]=='hide' then mt.open[1]=false;
    else print('[missiontracker] /mt  /mt show  /mt hide'); end;
end);

ashita.events.register('d3d_present','mt_present',function()
    local mem=AshitaCore:GetMemoryManager();
    if mem then local p=mem:GetParty(); if p then local n=p:GetMemberName(0);
        if n and n~='' and n~=mt.char then mt.char=n; load_char(); end end end;
    render_ui();
end);
