-- Rhapsodies of Vana'diel Missions (RoV)
-- Source: https://www.bg-wiki.com/ffxi/Category:Rhapsodies_of_Vanadiel_Missions

return {
    id    = 'rov',
    label = "Rhapsodies of Vana'diel",
    entry = "ALL five expansion stories must be complete: ZM17 (Zilart), CoP 8-4 (Promathia), TOAU 44 (Aht Urhgan), WotG 25 (Wings of the Goddess), SoA 10 (Adoulin).",
    missions = {
        -- Chapter 1
        { num='RoV 1-1', name="Rhapsodies of Vana'diel",
          steps={
              "Zone into any of the three starter cities (Bastok, Windurst, or San d'Oria) with a character level 3 or higher for a brief cutscene.",
              "If you chose 'watch this cutscene later' earlier, interact with a Tales' Beginning book at any of these locations: S.Sandy (H-8), N.Sandy (J-10), Port Sandy (H-9), Bastok Mines (I-9), Bastok Markets (I-8), Port Bastok (D-7), Windurst Waters (F-5), Windurst Walls (C-6), Port Windurst (B-5), Windurst Woods (J-10).",
          },
          prereqs={"All five expansion stories must be complete: ZM17, CoP 8-4, TOAU 44, WotG 25, SoA 10"},
          rewards={"Access to Escha - Zi'Tah", "Access to Escha - Ru'Aun"} },

        { num='RoV 1-2', name='Resonance',
          steps={
              "Zone into either Selbina or Mhaura for a cutscene. This determines which Crag you visit in the next mission (Selbina = Konschtat, Mhaura = Tahrongi) but is otherwise not important.",
          },
          prereqs={'RoV 1-1'},
          rewards={'None'} },

        { num='RoV 1-3', name='Emissary from the Seas',
          steps={
              "SELBINA PATH: Speak to Naillina at (F-9) in the Mayor's Residence. Choose 'You wanted an adventurer?'",
              "MHAURA PATH: Speak to Numi Adaligo at (F-9) in the Governor's House. Choose 'You're searching for adventurers?'",
          },
          notes={
              "Your choice from RoV 1-2 (Selbina or Mhaura) determines which path you take here. Either path is fine -- it only affects which Crag you visit in the next mission.",
          },
          prereqs={'RoV 1-2: Resonance'},
          rewards={'None'} },

        { num='RoV 1-4', name='Set Free',
          steps={
              "SELBINA PATH: Obtain 3 Bee Pollen from Huge Wasps in La Theine Plateau or Konschtat Highlands (or buy from AH). Best farming spot: Konschtat Highlands around the Crag of Dem -- ~12-15 spawns that repop as you lap. Trade the pollen to Abelard in Selbina.",
              "MHAURA PATH: Obtain 3 Mandragora Dewdrops from Pygmaioi in Tahrongi Canyon (or buy from AH). Trade the dewdrops to Ekokoko in Mhaura.",
          },
          notes={
              "Use Wide Scan (under Map menu) to locate Huge Wasps or Pygmaioi.",
              "Reward depends on your progress: new players who have NOT yet unlocked their Support Job receive Gilgamesh's Introductory Letter (lets you unlock subjob at level 18+ by speaking to Isacio in Selbina or Vera in Mhaura twice). Players who already have their subjob unlocked receive a Copper Voucher instead.",
          },
          prereqs={'RoV 1-3: Emissary from the Seas'},
          rewards={"Copper Voucher OR Gilgamesh's Introductory Letter (new players without subjob)"} },

        { num='RoV 1-5', name='The Beginning',
          steps={
              "SELBINA PATH: Speak to Pacomart at (H-10) in Selbina to be brought to Norg. Click the Oaken Door at (K-8) in Norg for a cutscene with Gilgamesh.",
              "MHAURA PATH: Speak to Tonasav at (H-9) in Mhaura to be brought to Norg. Click the Oaken Door at (K-8) in Norg for a cutscene with Gilgamesh.",
          },
          notes={
              "New players: unlock the Survival Guide, Proto-Waypoint, and Home Point in Norg before leaving.",
              "Pacomart (Selbina) and Tonasav (Mhaura) will take you back to Norg again if you need to return.",
              "From this point on, Pacomart and Tonasav can transport you directly to Norg at any time -- useful for ZM1 and other Zilart missions.",
          },
          prereqs={'RoV 1-4: Set Free'},
          rewards={'Key Item: Reisenjima Sanctorium Orb'} },

        { num='RoV 1-6', name='Flames of Prayer',
          steps={
              "Examine the Oaken Door at (K-8) in Norg again (a second visit after RoV 1-5) for a cutscene with Gilgamesh.",
          },
          notes={
              "Rhapsody in White is a powerful Key Item -- benefits include: 30% bonus EXP/LP, 100% increase to combat and magic skill gains, Fields of Valor tab cost reductions, +1 maximum Trust (5 total), 80% reduction in Home Point gil cost, and new items at Curio Vendor Moogles in the three nations.",
          },
          prereqs={'RoV 1-5: The Beginning'},
          rewards={"Key Item: Rhapsody in White"} },

        { num='RoV 1-7', name='The Path Untraveled',
          steps={
              "Examine the Shattered Telepoint at the Crag of Holla, Dem, or Mea for a cutscene. Select the 'Qufim Island' response to continue and complete the cutscene.",
          },
          notes={
              "Requires Rank 3+ in your home nation (complete the Rank 2-3 home nation mission first).",
              "If the Rank 2-3 mission was already completed before this RoV mission was active: speak to Halver in Chateau d'Oraguille (I-9) for Cipher: Halver, and Kupipi in Heavens Tower for Cipher: Semih. These Trusts are given by the NPCs during the mission if you had this RoV mission active at the time.",
          },
          prereqs={'RoV 1-6: Flames of Prayer', 'Rank 3+ in home nation'},
          rewards={'None'} },

        { num='RoV 1-8', name="At the Heavens' Door",
          steps={
              "Examine the Undulating Confluence at (G-8) in Qufim Island for a cutscene. It is close to the Qufim Home Point.",
          },
          notes={
              "Recommended to reach at least level 40 before proceeding to the next mission -- the fight ahead is a step more difficult than some players expect.",
          },
          prereqs={'RoV 1-7: The Path Untraveled'},
          rewards={'None'} },

        { num='RoV 1-9', name="The Lion's Roar",
          steps={
              "Examine the Undulating Confluence again (same spot as RoV 1-8) to start the battle. Make sure your Trusts are already out -- Ophiotaurus spawns and attacks immediately when you click.",
              "Defeat Ophiotaurus. Mission completes automatically on defeat.",
              "Examine the Undulating Confluence again for a cutscene.",
          },
          notes={
              "This fight is considerably more difficult than the content leading up to it. Recommended level 40-50 solo with Trusts.",
              "Calling for Help is permitted -- option is next to the Disengage button in the combat menu.",
              "Only one party can have Ophiotaurus popped at a time.",
          },
          prereqs={"RoV 1-8: At the Heavens' Door"},
          rewards={'None'} },

        { num='RoV 1-10', name='Eddies of Despair',
          steps={
              "Examine the Undulating Confluence again (same spot in Qufim Island). You will be teleported into Escha - Zi'Tah. Mission completes automatically on arrival.",
          },
          notes={
              "Consider exchanging Copper Vouchers for Escha Silt right away -- needed for Eschan Portals and to purchase maps and Key Items in Escha.",
          },
          prereqs={"RoV 1-9: The Lion's Roar"},
          rewards={"Access to Escha - Zi'Tah"} },

        { num='RoV 1-11', name='A Land After Time',
          steps={
              "Go back to the Shattered Telepoint at the Crag of Holla, Dem, or Mea for a cutscene. Any Crag works -- does not need to be the same one as before.",
          },
          notes={
              "After this mission, Coffer keys become available from the Curio Vendor Moogle -- useful for acquiring AF armor and completing The Road to Aht Urhgan.",
              "If playing solo: after Rhapsody in Umber, the next Rhapsody Key Item requires an NM battle -- consider prioritizing leveling to at least 75 before continuing RoV missions.",
          },
          prereqs={'RoV 1-10: Eddies of Despair'},
          rewards={"Key Item: Rhapsody in Umber", "Cipher: Lion II"} },

        { num='RoV 1-12', name="Fate's Call",
          steps={
              "Zone into any of the three starting nations (Bastok, Windurst, or San d'Oria) for a cutscene with Iroha. Requires completing the Shadow Lord fight in your nation's 5-2 mission first.",
          },
          prereqs={'RoV 1-11: A Land After Time', 'Nation 5-2 Shadow Lord mission completed'},
          rewards={'None'} },

        { num='RoV 1-13', name='What Lies Beyond',
          steps={
              "Zone into Norg for a cutscene. If you have not yet started Rise of the Zilart Missions, the ZM1 cutscene will play first.",
              "Examine Gilgamesh's Oaken Door in Norg.",
          },
          prereqs={"RoV 1-12: Fate's Call"},
          rewards={'None'} },

        { num='RoV 1-14', name='The Ties that Bind',
          steps={
              "Head to Sea Serpent Grotto and examine the sparkling ??? near the lake at (J-12) on Map 1 for a cutscene.",
              "OPTION 1 (Walk from Norg): Exit Norg south on foot (H-10) onto Map 1 at (F-1). Follow the tunnel south to the apparent dead end near a torch at (H-6). Interact with the hidden blank-label door to open it. Take an immediate left northeast to (J-5), then right south to the one-way drop at (K-7). Hug the left wall past the Ornamented Door at (J-10) down the tunnel to the large room (K-11). The ??? is at the edge of the water at (J-12).",
              "OPTION 2 (Unity Warp): Use Unity Warp Lv125 Sea Serpent Grotto -- lands on Map 4. Head northeast to the blank-label door at (M-5) and pass through it to reach Map 1 at (I-14). The lake is directly ahead -- go to the northeast side at (J-12) and check the ???.",
          },
          notes={
              "Mousse aggro Sound even at level 75+ -- use Sneak if taking the Unity Warp route.",
              "After the cutscene, consider walking to the next mission location instead of warping -- the Survival Guide at (M-3) on Map 1 is close and useful for future access.",
          },
          prereqs={'RoV 1-13: What Lies Beyond'},
          rewards={'None'} },

        { num='RoV 1-15', name='Impurity',
          steps={
              "Go to (F-11) in Yuhtunga Jungle and examine the sparkling ??? for a cutscene.",
          },
          notes={
              "If coming from Sea Serpent Grotto: BLM can cast Escape to reach Yuhtunga Jungle directly. Others can walk to the exit.",
              "If starting from Norg: rent a Chocobo from Marilleune (H-9) near the Sea Serpent Grotto exit and ride to the ???.",
              "If starting elsewhere: Unity Warp Lv119 to Yuhtunga Jungle is fastest.",
              "Grab the Survival Guide at the Yuhtunga Jungle zone exit on the way.",
              "Recommended level 80+ solo before proceeding to the next mission -- the fight ahead is harder than expected.",
          },
          prereqs={'RoV 1-14: The Ties that Bind'},
          rewards={'None'} },

        { num='RoV 1-16', name='The Lost Avatar',
          steps={
              "Examine the ??? to start the battle against Siren. Make sure Trusts are out before clicking -- fight starts immediately.",
              "Defeat Siren within 15 minutes -- she despawns after ~15 minutes ending the fight. Let a Trust tank her -- Charm has no effect on Trusts but will despawn them if it hits you.",
              "After the fight, examine the ??? again for a cutscene and reward.",
          },
          notes={
              "Recommended level 80+ solo with Trusts -- considerably more difficult than content leading up to it.",
              "Siren uses Massacre Elegy, Wind Threnody II, and Charm.",
              "If you Call for Help on Siren you will NOT get the cutscene -- must wait 1 minute to pop her again.",
              "If you die, rezone and you can still receive the cutscene as long as Siren is defeated.",
          },
          prereqs={'RoV 1-15: Impurity'},
          rewards={"Key Item: Rhapsody in Azure"} },

        { num='RoV 1-17', name='Volto Oscuro',
          steps={
              "Go to Norg and examine Gilgamesh's Oaken Door for a cutscene. Receive Cipher: Zeid II.",
          },
          prereqs={'RoV 1-16: The Lost Avatar'},
          rewards={"Cipher: Zeid II", "Title: The Fated"} },

        { num='RoV 1-18', name='Ring My Bell',
          steps={
              "Examine Gilgamesh's Oaken Door in Norg multiple times, then go inside and speak to Gilgamesh for a cutscene featuring Gilgamesh, Aldo, Tenzen, Zeid, Kagero, and Prishe.",
          },
          notes={
              "You CANNOT receive this cutscene if currently on: CoP 5-2 Desires of Emptiness, CoP 7-5 The Warrior's Path, CoP 8-1 Garden of Antiquity, CoP 8-3 When Angels Fall, CoP 8-4 Dawn, or other Tenzen-related missions.",
              "If you start The Warrior's Path, you must complete all remaining CoP missions through Dawn including the Lufaise Meadows epilogue cutscenes -- this includes a Japanese Midnight wait.",
          },
          prereqs={'RoV 1-17: Volto Oscuro'},
          rewards={'None'} },

        -- Chapter 2
        { num='RoV 2-1', name='Spirits Awoken',
          steps={
              "Zone into Lower Delkfutt's Tower from Qufim Island for a cutscene. Warping to the Survival Guide also triggers it -- rezone if it does not.",
          },
          notes={
              "The Qufim Island Survival Guide and Home Point are close to the tower entrance.",
              "Make sure to grab the Lower Delkfutt's Tower Survival Guide after the cutscene.",
          },
          prereqs={'RoV 1-18: Ring My Bell'},
          rewards={'None'} },

        { num='RoV 2-2', name='Crashing Waves',
          steps={
              "Go to Ru'Lude Gardens and approach the palace for a cutscene at (H-7). Requires CoP 3-2 A Vessel Without a Captain to be completed first.",
              "Receive Cipher: Tenzen II upon completing the cutscene.",
          },
          notes={
              "If your inventory was full and you did not receive the cipher, check the Mystic Retriever at the entrance to the palace in Ru'Lude Gardens.",
          },
          prereqs={'RoV 2-1: Spirits Awoken', 'CoP 3-2: A Vessel Without a Captain completed'},
          rewards={"Cipher: Tenzen II"} },

        { num='RoV 2-3', name='Call to Serve',
          steps={
              "Zone into Port Jeuno for a cutscene. Receive Cipher: Prishe II.",
          },
          notes={
              "You CANNOT receive this cutscene if currently on: CoP 3-5 Darkness Named, CoP 5-3 Three Paths, CoP 6-4 One to be Feared, or CoP 8-4 Dawn (post-battle final cutscenes).",
              "If your inventory was full and you did not receive the cipher, check the Mystic Retriever in Port Jeuno near the guide stone.",
              "Completing this mission unlocks the ability to view all Chains of Promathia mission cutscenes.",
          },
          prereqs={'RoV 2-2: Crashing Waves'},
          rewards={"Cipher: Prishe II", "Ability to view all CoP mission cutscenes"} },

        { num='RoV 2-4', name='Numbering Days',
          steps={
              "Go to Upper Jeuno and examine the Door: Marble Bridge at (F-7) for a cutscene. You do not need to be eligible to enter the Marble Bridge.",
          },
          prereqs={'RoV 2-3: Call to Serve'},
          rewards={'None'} },

        { num='RoV 2-5', name='Inescapable Binds',
          steps={
              "Zone into Aht Urhgan Whitegate for a cutscene.",
          },
          notes={
              "If you lack access to Aht Urhgan Whitegate: speak to Faursel in Lower Jeuno (J-8) inside the Tenshodo, select the 3rd invisible option twice, then select 'Where is Tenzen' to gain access.",
          },
          prereqs={'RoV 2-4: Numbering Days'},
          rewards={'None'} },

        { num='RoV 2-6', name='Desert Winds',
          steps={
              "Obtain a boarding permit from the Tenshodo for Aht Urhgan. If you already have a boarding permit, this mission auto-completes when you receive the cutscene from Tenzen in Aht Urhgan Whitegate.",
          },
          prereqs={'RoV 2-5: Inescapable Binds'},
          rewards={'None'} },

        { num='RoV 2-7', name='Ever Forward',
          steps={
              "IF TOAU COMPLETE: Return to your home nation for a cutscene, then examine the Imperial Whitegate in Aht Urhgan Whitegate for a cutscene. You will skip ahead to mission 'Reunited' and receive Cipher: Nashmeira II and the ability to view all TOAU cutscenes.",
              "IF TOAU MISSION 12+ (Royal Puppeteer): Return to your home nation for a cutscene, then go to the Imperial Whitegate. You will skip to 'Aphmau's Light'.",
              "IF TOAU NOT STARTED: You progress to the next mission 'The Endless Sky' as a placeholder until you progress TOAU. Must reach at least TOAU Mission 3 (President Salaheem) to receive the Trust Cipher.",
          },
          notes={
              "Speak to Abquhbah after receiving the home nation cutscene to obtain Cipher: Abquhbah.",
          },
          prereqs={'RoV 2-6: Desert Winds'},
          rewards={"Cipher: Abquhbah"} },

        { num='RoV 2-8', name='The Endless Sky',
          steps={
              "This is a placeholder mission -- complete up to TOAU Mission 12 (Royal Puppeteer) to advance past this point.",
          },
          prereqs={'RoV 2-7: Ever Forward'},
          rewards={'None'} },

        { num='RoV 2-9', name="Aphmau's Light",
          steps={
              "Examine the Imperial Whitegate at Aht Urhgan Whitegate (L-8/9) when Aphmau is in town for a cutscene. Receive Cipher: Nashmeira II.",
          },
          notes={
              "Aphmau must be 'in town' -- she is unavailable during certain TOAU missions. Missions where she is available include 19 (Sweets for the Soul) and 29 (Puppet in Peril). If she is not there, advance your TOAU missions until she returns.",
              "Completing this mission also unlocks the ability to view all Treasures of Aht Urhgan mission cutscenes.",
          },
          prereqs={'RoV 2-8: The Endless Sky'},
          rewards={"Cipher: Nashmeira II", "Ability to view all TOAU mission cutscenes"} },

        { num='RoV 2-10', name='Reunited',
          steps={
              "Enter Walahra Temple in Aht Urhgan Whitegate and speak to Nadeey for a cutscene.",
          },
          notes={
              "If you are automatically entered into a cutscene upon entering, it is for The Rider Cometh and is NOT part of this mission -- wait for it to finish.",
          },
          prereqs={"RoV 2-9: Aphmau's Light"},
          rewards={'None'} },

        { num='RoV 2-11', name='Take Wing',
          steps={
              "Head to Shararat Teahouse at (K-12) in Aht Urhgan Whitegate for an automatic cutscene.",
          },
          prereqs={'RoV 2-10: Reunited'},
          rewards={'None'} },

        { num='RoV 2-12', name='Prime Number',
          steps={
              "Zone into the Alzadaal Undersea Ruins for a cutscene. Access via the Chamber of Passage using the Nyzul Isle Staging Point (costs 200 Imperial Standing points). Alternatively, grab an Assault tag and select the Nyzul Isle Investigation Assault mission to port into the zone.",
          },
          notes={
              "If you lack Imperial Standing: use Copper A.M.A.N. Vouchers to obtain it. Or use an Assault tag (Imperial Army I.D. tag) and select Nyzul Isle Investigation to enter for free.",
          },
          prereqs={'RoV 2-11: Take Wing'},
          rewards={'None'} },

        { num='RoV 2-13', name='From the Ruins',
          steps={
              "Return to Aht Urhgan Whitegate and click on the Imperial Whitegate (Palace Door) for a cutscene and Key Item: Rhapsody in Crimson.",
          },
          notes={
              "Optional alternate darkness cutscenes (any time during Chapter 2 before mission 2-39):",
              "Re-enter Alzadaal Undersea Ruins for a cutscene (requires all TOAU missions complete).",
              "Zone into The Shrouded Maw for a cutscene (requires CoP 3-5 Darkness Named complete). Access via Pso'Xja HP#1 or Beaucedine Glacier (H-8).",
              "Zone into The Garden of Ru'Hmet and descend to the bottom level for a cutscene (requires all CoP missions complete). Access via Garden of Ru'Hmet HP#1 or Sueleen in Sealion's Den.",
          },
          prereqs={'RoV 2-12: Prime Number'},
          rewards={"Key Item: Rhapsody in Crimson"} },

        { num='RoV 2-14', name='Cauterize',
          steps={
              "Head to a Cavernous Maw in Batallia Downs, Rolanberry Fields, or Sauromugue Champaign and click the sparkling ??? for a cutscene.",
              "IF WotG NOT STARTED: mission proceeds to Uncertain Destinations.",
              "IF WotG STARTED: mission proceeds to Ganged Up On (if quests Champion of the Dawn and A Forbidden Reunion are not flagged/completed -- complete those first if they are).",
          },
          notes={
              "May require at least WotG Mission 8 (In the Name of the Father) to receive the cutscene.",
              "If Champion of the Dawn or A Forbidden Reunion are flagged, complete them first or the cutscene will not trigger.",
          },
          prereqs={'RoV 2-13: From the Ruins'},
          rewards={'None'} },

        { num='RoV 2-15', name='Uncertain Destinations',
          steps={
              "Examine the sparkling BLUE ??? next to a Cavernous Maw in Batallia Downs, Rolanberry Fields, or Sauromugue Champaign for a cutscene. Use the blue sparkling ???, NOT the white one.",
          },
          prereqs={'RoV 2-14: Cauterize'},
          rewards={'None'} },

        { num='RoV 2-16', name='Ganged Up On',
          steps={
              "IF ALL WotG COMPLETE: Examine the blue sparkling ??? next to a Cavernous Maw in Batallia Downs, Rolanberry Fields, or Sauromugue Champaign for a cutscene.",
              "IF WotG NOT COMPLETE (must be on WotG 8+ In the Name of the Father): Zone into Southern San d'Oria (S) for a cutscene and receive Key Item: Lightsworm. Use any Home Point, Survival Guide, Retrace, or Instant Retrace to zone in.",
              "If no cutscene triggers in S.Sandy (S): visit a Cavernous Maw blue sparkling ??? first, then return to S.Sandy (S).",
              "If you still have not progressed to Sacrifice: interact with the Mystic Retriever in Southern San d'Oria (S) at (M-6).",
          },
          notes={
              "Lilisette is unavailable during many WotG missions including: On Thin Ice, Proof of Valor, Adieu Lilisette, Where It All Began, and others. Check your WotG progress if she is not available.",
              "If you start Where It All Began (via Maiden of the Dusk), you must finish the full WotG storyline plus Champion of the Dawn and A Forbidden Reunion to continue.",
              "Stuck without a Lightsworm: go to the Goblin Footprint in Batallia Downs (S) at (F-9), watch all Ganged Up On cutscenes, wait a game day, then check the shimmering ??? next to any present-day Cavernous Maw to raise your Lightsworm.",
              "If missing Cipher: Lilisette II, retrieve it from the Mystic Retriever at (M-6) in Southern San d'Oria (S).",
              "Completing this mission unlocks ability to view all Wings of the Goddess mission cutscenes.",
          },
          prereqs={'RoV 2-15: Uncertain Destinations', 'WotG Mission 8+ required'},
          rewards={"Cipher: Lilisette II", "Ability to view all WotG mission cutscenes"} },

        { num='RoV 2-17', name='Sacrifice',
          steps={
              "IF WotG Mission 45+ (Time Slips Away): Enter Walk of Echoes from Pashhow Marshlands (S) at (J-9) or Grauberg (S) at (F-5). Check the Ornate Door inside.",
              "IF WotG Mission 8+ (In the Name of the Father): Enter Walk of Echoes by touching the glowing ??? on the ground next to a Cavernous Maw (use your Lightsworm when prompted): Batallia Downs (H-5), Rolanberry Fields (H-6, Survival Guide is closest), or Sauromugue Champaign (K-9). Run straight ahead, up the stairs, and click the Ornate Door.",
          },
          notes={
              "Bring a warp item (Warp Ring or Instant Warp) -- after the next mission you will be left with no fast way back to town.",
              "If you leave after entering for Ganged Up On, re-enter from Grauberg (S) to resume.",
              "Do NOT enter from Xarcabard (S) -- you will get a cutscene but will not be in the correct instance to reach the Ornate Door.",
          },
          prereqs={'RoV 2-16: Ganged Up On', 'WotG Mission 8+ required'},
          rewards={'None'} },

        { num='RoV 2-18', name='Somber Dreams',
          steps={
              "You auto-zone into Witchfire Glen in Grauberg (S) after the previous cutscene.",
              "Examine the blue glowing ??? northeast of the Veridical Conflux (NOT the one right beside it) to spawn NM Cetus. Defeat it.",
              "Re-examine the ??? for a cutscene.",
              "Re-enter Walk of Echoes by clicking the ??? beside the Veridical Conflux for a final cutscene.",
              "Use your warp item to return to town (as advised in RoV 2-17).",
          },
          notes={
              "Cetus gains Dread Spikes after Aetheric Pull -- stop melee attacks immediately when this happens.",
              "Intended for level 99. Solo with Trusts possible in the early 90s with difficulty.",
              "If you wipe, you CANNOT re-enter via the Cavernous Maw ??? -- you must walk to Grauberg (S) manually. Fastest route: Survival Guide to Pashhow Marshlands (S) or Vunkerl Inlet (S), then navigate to Grauberg (S).",
              "The final Walk of Echoes cutscene requires you to be on a WotG mission where Lilisette is available.",
          },
          prereqs={'RoV 2-17: Sacrifice'},
          rewards={'None', 'Title: Abyssal Purveyor'} },

        { num='RoV 2-19', name='Of Light and Darkness',
          steps={
              "Head to Norg and examine Gilgamesh's Oaken Door for a cutscene.",
          },
          prereqs={'RoV 2-18: Somber Dreams'},
          rewards={'None'} },

        { num='RoV 2-20', name='Temporary Farewells',
          steps={
              "Head to Misareaux Coast (G-5) and examine the sparkling ??? next to the Undulating Confluence. Fastest: use Misareaux Coast Home Point and walk up the riverbank toward the bridge. Or use the Survival Guide and walk north.",
          },
          prereqs={'RoV 2-19: Of Light and Darkness'},
          rewards={'None'} },

        { num='RoV 2-21', name='Brushing Up',
          steps={
              "Examine the ??? next to the Undulating Confluence in Misareaux Coast again for a cutscene.",
          },
          prereqs={'RoV 2-20: Temporary Farewells'},
          rewards={'None'} },

        { num='RoV 2-22', name='Keep On Giving',
          steps={
              "Choose a training type, obtain the required food, then trade it to the ??? at the Undulating Confluence in Misareaux Coast.",
              "Strength: trade a Beef Stewpot (15,000 gil from Curio Vendor Moogle).",
              "Style: trade 30x Spicy Crackers (450 gil each from Curio Vendor Moogle, 13,500 gil total).",
              "Endurance: trade a Serving of Zaru Soba (15,000 gil from Curio Vendor Moogle).",
          },
          notes={
              "Choice does not affect story progression -- pick whichever is cheapest or most convenient.",
              "Spicy Crackers are the easiest to craft if you prefer to make your own food.",
          },
          prereqs={'RoV 2-21: Brushing Up'},
          rewards={'None'} },

        { num='RoV 2-23', name='Past Imperfect',
          steps={
              "Return to Norg and examine Gilgamesh's Oaken Door for a cutscene.",
              "IF on ZM3 Kazham's Chieftainess: Gilgamesh will ask you to speak to Jakoh Wahcondalo in Kazham at (J-9) first. After doing so return to Norg and examine the Oaken Door again for another cutscene.",
          },
          notes={
              "This mission can be blocked or vary slightly depending on your current Rise of the Zilart mission progress.",
          },
          prereqs={'RoV 2-22: Keep On Giving'},
          rewards={'None'} },

        { num='RoV 2-24', name='The Cursed Temple',
          steps={
              "Enter Temple of Uggalepih from Yhoator Jungle (J-11) for a cutscene. Unity Warp Lv122 to Yhoator Jungle puts you at Bloodlet Spring -- head south to (J-11). Or use Survival Guide. Or use Escape from Den of Rancor HP#1.",
              "Navigate to the Granite Door on Map 3 at (J-6) for a cutscene.",
              "TO REACH (J-6): Zone in from (J-11), turn left after initial stairs then left again. Follow the path through the Granite Door at (J-7) into a hidden section. Follow the path to stairs at (J-3) and zone out to Yhoator Jungle at (J-9).",
              "Take each right (skipping dead ends), passing by the NM ledge stairs, until you zone back into the temple. Keep left until you reach the Granite Door at (J-6). Click it for the cutscene.",
          },
          notes={
              "Must have completed ZM4 The Temple of Uggalepih to receive the Granite Door cutscene.",
              "The Voidwatch NPC warp puts you right at the (J-7) Granite Door entrance.",
              "Tonberries and Bees in the hidden section aggro a level 99 by sight -- they are higher level than the earlier enemies.",
          },
          prereqs={'RoV 2-23: Past Imperfect', 'ZM4: The Temple of Uggalepih completed'},
          rewards={'None'} },

        { num='RoV 2-25', name='Wisdom of Our Forefathers',
          steps={
              "Examine the Granite Door at (J-6) on Map 3 of Temple of Uggalepih for a cutscene. Mission ends upon examining the door.",
          },
          prereqs={'RoV 2-24: The Cursed Temple'},
          rewards={'None'} },

        { num='RoV 2-26', name='Where Divinities Collide',
          steps={
              "Head to the Crag of Holla, Dem, or Mea. Examine the Shattered Telepoint to enter the Hall of Transference for a cutscene.",
          },
          prereqs={'RoV 2-25: Wisdom of Our Forefathers'},
          rewards={'None'} },

        { num='RoV 2-27', name='Visions of Dread',
          steps={
              "Cutscene plays automatically in the Hall of Transference after RoV 2-26.",
          },
          prereqs={'RoV 2-26: Where Divinities Collide'},
          rewards={'None'} },

        { num='RoV 2-28', name='To the Skies',
          steps={
              "Return to Norg and examine Gilgamesh's Oaken Door for a cutscene.",
          },
          prereqs={"RoV 2-27: Visions of Dread"},
          rewards={'None'} },

        { num="RoV 2-29", name="Escha - Ru'Aun",
          steps={
              "Head to (G-5) in Misareaux Coast and click the Undulating Confluence for a cutscene.",
              "Click the Undulating Confluence again to enter Escha - Ru'Aun for another cutscene.",
          },
          prereqs={"RoV 2-28: To the Skies"},
          rewards={'None'} },

        { num='RoV 2-30', name='The Decisive Heroine',
          steps={
              "Inside Escha - Ru'Aun: head north up the ramp, take the first left (west-northwest to H-10), and examine the blue ??? at the top of the stairs for a cutscene. Receive temporary Key Item: Siren's Plume and Key Item: Rhapsody in Emerald.",
          },
          prereqs={"RoV 2-29: Escha - Ru'Aun"},
          rewards={"Key Item: Rhapsody in Emerald"} },

        { num='RoV 2-31', name='Fall from Grace',
          steps={
              "Head to the Crag of Holla, Dem, or Mea and examine the Shattered Telepoint for a cutscene.",
          },
          prereqs={'RoV 2-30: The Decisive Heroine'},
          rewards={'None'} },

        { num='RoV 2-32', name='Banishing the Darkness',
          steps={
              "Head to Norg and examine Gilgamesh's Oaken Door for a cutscene.",
          },
          notes={
              "Cannot receive this cutscene if currently on: CoP 3-5 Darkness Named, CoP 5-3 Three Paths, CoP 6-1 For Whom the Verse is Sung, CoP 6-2 A Place to Return, or CoP 6-3 More Questions than Answers.",
          },
          prereqs={'RoV 2-31: Fall from Grace'},
          rewards={'None'} },

        { num='RoV 2-33', name='Over the Rainbow',
          steps={
              "Head to Windurst Walls HP#3 and speak to Shantotto at Shantotto's Manor (K-7) for a cutscene. Receive temporary Key Item: Most Curious Curio.",
          },
          prereqs={'RoV 2-32: Banishing the Darkness'},
          rewards={'None'} },

        { num='RoV 2-34', name='Cacophonous Discord',
          steps={
              "Head to Misareaux Coast, examine the Undulating Confluence at (G-5), and enter Escha - Ru'Aun for a cutscene.",
          },
          prereqs={'RoV 2-33: Over the Rainbow'},
          rewards={'None'} },

        { num='RoV 2-35', name='Eddies of Despair',
          steps={
              "Upon entering Escha - Ru'Aun, find the ??? next to Dremi on the left to receive Key Item: Eschan Droplets. Use the Eschan Portal to travel to Portal #2.",
              "At each portal find the nearby ??? to receive another Eschan Droplets Key Item, then use it to unlock the next portal. Repeat through Portal #15. Key ??? locations: #2=end of only path (not the one in front of the teleport), #3=top of first staircase near right pillar, #4=across bridge between two large left pillars, #5=end of only path, #6=(G-6) under second staircase on the bridge with closed door, #7=(F-5) directly left of second bridge, #8=end of only path, #9=up both stairs turn left then another left at water bridge -- ??? in middle (Gargoyles aggro at night in alcoves), #10=across both bridges at SW side of last platform, #11=end of only path, #12=Sneak up both stairs turn right, past a left staircase to (J-7), #13=across first bridge next to first large left pillar, #14=end of only path.",
              "Click the shining ??? at Portal #15 for a cutscene.",
          },
          notes={
              "This portal chain can be completed at any time after gaining Escha - Ru'Aun access -- not restricted to this mission.",
              "If you lose your Eschan Droplets KI, go back to the starting ??? near Dremi for a new one, then pay silt to use a portal to catch up.",
              "Key mob aggro: Eschan Limule/Murex/Amoeban/Clionid are only aggressive at night (18:00-6:00). Eschan Euvhi aggro Sound only when open (look like flowers). Sneak recommended throughout.",
          },
          prereqs={'RoV 2-34: Cacophonous Discord'},
          rewards={'None'} },

        { num='RoV 2-36', name='Pretender to the Throne',
          steps={
              "Click the ??? at Portal #15 a second time to begin the fight with Balamor.",
              "Defeat Balamor. After winning, check the ??? again for a cutscene.",
          },
          notes={
              "Balamor spams Last Laugh -- a conal Drain move. Mages should stand far back.",
              "If you fail or disconnect mid-fight, zone and re-enter Escha - Ru'Aun -- you will receive another Most Curious Curio on re-entry.",
              "After the fight, a ??? next to the Eschan Portal gives another Eschan Droplets KI. Portal #15 loops back to the zone start.",
          },
          prereqs={'RoV 2-35: Eddies of Despair'},
          rewards={"Cipher: Balamor", "Title: Banisher of the Profane"} },

        { num='RoV 2-37', name='Banished',
          steps={
              "Return to Norg and examine Gilgamesh's Oaken Door for a cutscene.",
          },
          prereqs={'RoV 2-36: Pretender to the Throne'},
          rewards={'None'} },

        { num='RoV 2-38', name='Call of the Void',
          steps={
              "Teleport to any of the Crags (Holla, Dem, or Mea) and click the Dimensional Portal for a cutscene. Receive Cipher: Selh'teus.",
          },
          notes={
              "If you did not receive Cipher: Selh'teus after the cutscene (inventory full), check the Mystic Retriever in Empyreal Paradox to obtain it.",
          },
          prereqs={'RoV 2-37: Banished'},
          rewards={"Cipher: Selh'teus"} },

        { num='RoV 2-39', name='Both Paths Taken',
          steps={
              "Walk forward to the Transcendental Radiance in Empyreal Paradox and examine it to enter the BCNM against Disjoined One. 15 minute time limit. Iroha fights alongside you -- if she dies she Reraises after 15 seconds (multiple times).",
              "After winning, the mission completes.",
          },
          notes={
              "Easily soloable with 5 Trusts. RDM can solo with no Trusts.",
              "If you fail or leave, use the Dimensional Portal at any teleport Crag to return to Empyreal Paradox.",
              "Players who have not reached CoP Dawn are confined to the basement area -- no access to the rest of Lumoria.",
              "Returning guides: use Home Point to The Garden of Ru'Hmet #1, then Descend on the elevator to reach Empyreal Paradox.",
          },
          prereqs={"RoV 2-38: Call of the Void"},
          rewards={'None', 'Title: Spirit Seeker'} },

        { num='RoV 2-40', name='The Man Behind the Mask',
          steps={
              "Return to Norg and examine Gilgamesh's Oaken Door for a cutscene. Receive Key Item: Rhapsody in Mauve.",
          },
          prereqs={'RoV 2-39: Both Paths Taken'},
          rewards={"Key Item: Rhapsody in Mauve"} },

        { num='RoV 2-41', name='Uncertain Futures',
          steps={
              "Zone into any area in a starting nation that has a Mog House entrance for a cutscene. Receive Key Item: Song of Hope.",
          },
          prereqs={'RoV 2-40: The Man Behind the Mask'},
          rewards={"Key Item: Song of Hope"} },

        { num='RoV 3-1', name='Darkness Beckons',
          steps={
              "Travel to the Crag of Holla, Dem, or Mea and examine the Dimensional Portal -- select the option to travel to Reisenjima. Receive a brief cutscene on arrival.",
              "Speak with Shiftrix the goblin at the entrance (no need to pay for info) to activate the Oseem augmentation system. He also sells a Map of Reisenjima (50 Silt) and Mollifiers (500 Silt, useful for the next mission).",
              "Make your way to the Etched Rock at (K-9) for a cutscene. Follow the main path -- no shortcut exists except via Cumulus Masque +1. Pick up Ethereal Ingress waypoints along the way (#3 and #4 in the northwest are the only substantial detour).",
          },
          notes={
              "Most mobs in Reisenjima aggro -- some have True Sight or True Sound. See the Reisenjima page on bg-wiki for details.",
              "Ethereal Ingress points do NOT blink when not yet acquired. Most are on or close to the main path.",
              "Consider picking up a Mollifier from Shiftrix (500 Silt) for the next mission while you are here.",
          },
          prereqs={'RoV 2-41: Uncertain Futures'},
          rewards={'None'} },

        { num='RoV 3-2', name='The Brewing Storm',
          steps={
              "Kill 3 Perfervid Narakas near Ethereal Ingress #6. They spawn at night only (20:00-04:00).",
              "After defeating all 3, the next mission starts automatically.",
          },
          notes={
              "Rhapsody in Mauve reduces the Narakas' level to 107 when you engage them.",
              "Have a Mollifier ready -- defeating a Naraka can spawn an Ascended Naraka.",
              "Naraka levels are reduced if you are in a party or alliance with others who are on this mission. If you leave the party or change areas, their levels and HP reset even mid-combat.",
          },
          prereqs={'RoV 3-1: Darkness Beckons'},
          rewards={'None'} },

        { num='RoV 3-3', name='The River Runs Red',
          steps={
              "Examine the Etched Rock at (K-9) in Reisenjima for a cutscene. Receive Key Item: Rhapsody in Fuchsia and (if you do not already have one) a Geomagnetron.",
          },
          notes={
              "If you receive the Geomagnetron here, it is already attuned -- speak to Darcia to obtain the Adoulinian charter permit.",
          },
          prereqs={'RoV 3-2: The Brewing Storm'},
          rewards={"Key Item: Rhapsody in Fuchsia", "Geomagnetron (if not already owned)"} },

        { num='RoV 3-4', name='The Crucible',
          steps={
              "Complete quest The Geomagnetron first: speak to Darcia in Lower Jeuno with the Geomagnetron obtained in RoV 3-3 to receive the Adoulinian charter permit.",
              "Optional: zone into any starting city with a Mog House entrance for a cutscene pointing you to Ceizak Battlegrounds -- this auto-advances you to RoV 3-5.",
              "Enter Ceizak Battlegrounds (via Waypoint in Lower Jeuno, Waypoint in Adoulin, from a connected Adoulin area, or Home Point crystal) for a cutscene.",
          },
          notes={
              "Requires Seekers of Adoulin Mission 1-7 (Meeting of the Minds) completed before the cutscene triggers.",
          },
          prereqs={'RoV 3-3: The River Runs Red', 'SoA Mission 1-7: Meeting of the Minds completed'},
          rewards={'None'} },

        { num='RoV 3-5', name='Forward Thinking',
          steps={
              "Zone into Ceizak Battlegrounds for a cutscene. Your Reisenjima Sanctorium Orb will be exchanged for the Drained Orb.",
          },
          prereqs={'RoV 3-4: The Crucible'},
          rewards={"Key Item: Drained Orb"} },

        { num='RoV 3-6', name='Tears of the Generals',
          steps={
              "Speak to Ploh Trishbahk at the Castle Adoulin gates in Eastern Adoulin for a cutscene.",
          },
          notes={
              "Requires at least SoA Mission 2-2 (An Aimless Journey) completed.",
              "Cannot receive this cutscene if currently on: SoA 3-6-3 Stonewalled, SoA 3-6-4 Salvation, SoA 4-5 Balamor the Deathborne Xol, SoA 4-5-1 Anagnorisis, or SoA 5-4-1 Abomination.",
          },
          prereqs={'RoV 3-5: Forward Thinking', 'SoA Mission 2-2: An Aimless Journey completed'},
          rewards={'None'} },

        { num='RoV 3-7', name='What He Left Behind',
          steps={
              "Head to Rala Waterways (B-6) and find the Augural Conveyor room. Closest entry: (F-5) in Western Adoulin near the Adoulin Waterfront Waypoint. Move east along the path and enter (B-6) from (C-7).",
              "Examine the glowing ??? on the ground near the room's entrance for a cutscene. Receive Cipher: Arciela II.",
          },
          notes={
              "If you have the Augural Conveyor unlocked, you can also use the 'enigmatic device' Waypoint option to teleport directly.",
              "Completing this mission unlocks the ability to view all Seekers of Adoulin mission cutscenes.",
          },
          prereqs={'RoV 3-6: Tears of the Generals'},
          rewards={"Cipher: Arciela II", "Ability to view all SoA mission cutscenes"} },

        { num='RoV 3-8', name='Gone but Not Forgotten',
          steps={
              "Head to Rala Waterways and examine the Sluice Gate at (C-6) to enter the secret hideout. Easiest access via Western Adoulin (F-5) from the Adoulin Waterfront Waypoint.",
              "Examine the Inconspicuous Barrel inside to receive Key Item: Founder King's Orb. Mission completes.",
          },
          notes={
              "Requires at least SoA Mission 2-7-1 (Behind the Sluices) completed -- specifically must have reached the part where you enter the sluice to gain proper access to the Sluice Gate.",
          },
          prereqs={'RoV 3-7: What He Left Behind', 'SoA Mission 2-7-1: Behind the Sluices (partial)'},
          rewards={"Key Item: Founder King's Orb"} },

        { num='RoV 3-9', name='August Artifacts',
          steps={
              "Return to the ??? near the Augural Conveyor at (C-6/B-6) in Rala Waterways for a cutscene.",
          },
          notes={
              "Only Sneak needed to avoid aggro along the path from the previous mission location.",
          },
          prereqs={"RoV 3-8: Gone but Not Forgotten"},
          rewards={'None'} },

        { num='RoV 3-10', name='Solemnity',
          steps={
              "Zone into Celennia Memorial Library in Eastern Adoulin for a cutscene.",
          },
          prereqs={'RoV 3-9: August Artifacts'},
          rewards={'None'} },

        { num='RoV 3-11', name='Eyes on You',
          steps={
              "Zone into the Hall of the Gods for a cutscene.",
          },
          notes={
              "Travel options: Ro'Maeve Survival Guide and zone directly into nearby Hall of the Gods (fastest). Or zone backwards from Ru'Aun Gardens. Or Voidwatch NPC warp (requires Ashen stratum abyssite III). Or Unity Warp Lv125 to southern entrance of Ro'Maeve.",
          },
          prereqs={'RoV 3-10: Solemnity'},
          rewards={'None'} },

        { num='RoV 3-12', name='Exploring the Ruins',
          steps={
              "Examine the Cermet Grate right in front of you in the Hall of the Gods for a cutscene.",
          },
          notes={
              "After completing this mission (if you have completed ZM through Awakening, CoP through Dawn, have Bundle of half-inscribed scrolls, and learned Cipher: Rainemard): go to Ru'Lude Gardens and speak to Jamal (H-5) to unlock RoE Quests 3. Complete objectives for Cipher: Ark GK/EV/MR/HM/TT. These are also required for the Filled Memory Gem which raises Trust levels.",
          },
          prereqs={'RoV 3-11: Eyes on You'},
          rewards={'None'} },

        { num='RoV 3-13', name='Become Something More',
          steps={
              "Return to the Reisenjima Sanctorium for a cutscene. Receive Key Item: Dimensional Compass.",
          },
          notes={
              "Reisenjima is accessible via the Dimensional Portals at the Crags of Holla, Mea, or Dem.",
          },
          prereqs={'RoV 3-12: Exploring the Ruins'},
          rewards={"Key Item: Dimensional Compass"} },

        { num='RoV 3-14', name='Unshakable Nightmares',
          steps={
              "Enter the Walk of Echoes for a cutscene. Preferred entry methods: blue ??? next to Cavernous Maws in Batallia Downs, Rolanberry Fields, or Sauromugue Champaign (present-day Survival Guides are fastest, requires Lightsworm). Or Veridical Conflux in Grauberg (S) at (F-5) (requires WotG 46). Or Veridical Conflux in Pashhow Marshlands (S) at (J-9) (requires Voidwatch Quest 15).",
          },
          notes={
              "Do NOT use the blue ??? next to the Cavernous Maw in Batallia Downs alone -- you will need to exit after the cutscene and use a different entry for the next mission as that is the wrong Walk of Echoes section.",
              "If you receive the message 'unable to make further progress due to an event occurring in Champion of the Dawn': zone into Walk of Echoes from Xarcabard (S) to get the Champion of the Dawn cutscene. Complete that quest and A Forbidden Reunion first. You will not receive the RoV 3-14 cutscene again -- just proceed to the next mission.",
          },
          prereqs={'RoV 3-13: Become Something More'},
          rewards={'None'} },

        { num='RoV 3-15', name='What Remains of Hope',
          steps={
              "Inside Walk of Echoes, find the white glowing ??? to the east (toward where Atomos is visible in the distant sky) for a cutscene.",
              "You will be teleported to Desuetia - Empyreal Paradox and receive Key Item: Cait Sith's Whisker. Mission completes automatically on arrival.",
          },
          notes={
              "If you entered from Xarcabard (S), you are in the wrong section -- use one of the correct entry methods from RoV 3-14.",
          },
          prereqs={'RoV 3-14: Unshakable Nightmares'},
          rewards={"Key Item: Cait Sith's Whisker"} },

        { num='RoV 3-16', name='Death Cares Not',
          steps={
              "Examine the Transcendental Radiance in Desuetia - Empyreal Paradox for a cutscene.",
          },
          prereqs={'RoV 3-15: What Remains of Hope'},
          rewards={'None'} },

        { num='RoV 3-17', name='No Time like the Future',
          steps={
              "Examine the Transcendental Radiance again to enter the BCNM fight against Sempurne.",
              "Defeat Sempurne. Mission completes on victory.",
          },
          notes={
              "Sempurne is a weakened version of Shinryu -- uses all of Shinryu's abilities but cannot recover HP from taking damage while readying TP moves or casting magic.",
              "Easily soloable with Trusts as an iLvl DD job.",
              "If you lose, obtain another Cait Sith's Whisker from Cait Sith outside the BCNM before re-entering.",
          },
          prereqs={'RoV 3-16: Death Cares Not'},
          rewards={'None'} },

        { num='RoV 3-18', name='Sin',
          steps={
              "Examine the Transcendental Radiance again after clearing the battlefield for a lengthy cutscene.",
          },
          notes={
              "To replay the cutscene with the flash-forward to Reisenjima later: check the Goblin Footprints in Reisenjima, listed under 'Penance'.",
          },
          prereqs={'RoV 3-17: No Time like the Future'},
          rewards={'None'} },

        { num='RoV 3-19', name='Penance',
          steps={
              "This mission completes automatically during the extended cutscene from RoV 3-18 (Sin). You will receive Key Item: Rhapsody in Puce when the cutscene ends.",
          },
          prereqs={'RoV 3-18: Sin'},
          rewards={"Key Item: Rhapsody in Puce", "Title: The Decider"} },

        { num='RoV 3-20', name='Vessel of Light',
          steps={
              "Return to Reisenjima Sanctorium via a Dimensional Portal at one of the Crags for a cutscene.",
          },
          prereqs={'RoV 3-19: Penance'},
          rewards={'None'} },

        { num='RoV 3-21', name='The Lifestream of Reisenjima',
          steps={
              "Examine the ??? at (H-5) in Reisenjima (on the hill near the large ruins) for a cutscene. Warp to Ethereal Ingress #5 and run west along the path. Beware True Sight Hippogryphs.",
          },
          notes={
              "If you receive a message about a Tribulens, you are at the wrong ??? -- use the one immediately adjacent to the ruins, not the one further down the hill.",
              "Cannot receive this cutscene if currently on: CoP 8-1 Garden of Antiquity, CoP 8-4 Dawn (prior to final cutscenes), or other Tenzen-related missions.",
          },
          prereqs={'RoV 3-20: Vessel of Light'},
          rewards={'None'} },

        { num='RoV 3-22', name='From West to East',
          steps={
              "Defeat 11 Obstreperous Panopts. Many spawn around (F-11) just north of Ethereal Ingress #1. Do NOT zone -- this resets your progress. You will receive a message after each kill showing how many remain.",
          },
          notes={
              "Purchase a Mollifier from Shiftrix before this mission -- defeating a Panopt can spawn the NM Ascended Panopt without it.",
              "Rhapsody in Fuchsia reduces Obstreperous Panopts to level 112 while on this mission.",
              "The area around (F-11) is full of other aggressive mobs -- be careful.",
          },
          prereqs={'RoV 3-21: The Lifestream of Reisenjima'},
          rewards={'None'} },

        { num='RoV 3-23', name='Good Things Come in Threes',
          steps={
              "Examine the Etched Rock at (K-9) in Reisenjima (Ethereal Ingress #6 / Sanctorium entrance) for a cutscene.",
          },
          prereqs={'RoV 3-22: From West to East'},
          rewards={'None'} },

        { num='RoV 3-24', name='Tackling the Problem',
          steps={
              "Examine the Reisen Crystal inside Reisenjima Sanctorium for a cutscene.",
          },
          prereqs={'RoV 3-23: Good Things Come in Threes'},
          rewards={'None'} },

        { num='RoV 3-25', name='Way to Divinity',
          steps={
              "Watch the cutscene that began at the end of RoV 3-24. You will be transported to Empyreal Paradox during the cutscene. The next mission starts automatically when it ends.",
          },
          prereqs={'RoV 3-24: Tackling the Problem'},
          rewards={'None', 'Title: The Ascended'} },

        { num='RoV 3-26', name='The Winds of Time',
          steps={
              "Check the Transcendental Radiance in Empyreal Paradox to enter the BCNM 'The Winds of Time'. Fight and defeat Metus. Trusts allowed. After winning a cutscene plays and the next mission starts.",
          },
          notes={
              "Metus uses Promathia TP moves (Bastion of Twilight, Wheel of Impregnability, Infernal Deliverance, Empty Salvation), plus Osmotic Wave, Censure, and Meteor.",
              "If you fail: return to Reisenjima Sanctorium, click the Reisen Crystal and agree to meet the Goddess -- you will return to Empyreal Paradox. After the cutscene use the Dimensional Portal to the right of the entrance to return to the Sanctorium. Click the Reisen Crystal again and agree to meet the Goddess a second time to receive Key Item: Extradimensional Scar to retry the fight.",
          },
          prereqs={'RoV 3-25: Way to Divinity'},
          rewards={'None'} },

        { num='RoV 3-27', name='Calm After the Storm',
          steps={
              "Watch the cutscene that plays after defeating Metus.",
          },
          notes={
              "If Tenzen is 'occupied' in a CoP mission (e.g. you are on CoP 8-4 Dawn but have not completed the final cutscenes), you cannot continue until he is free. Examine the Resume Point in Empyreal Paradox to continue once he is available.",
          },
          prereqs={'RoV 3-26: The Winds of Time'},
          rewards={'None'} },

        { num='RoV 3-28', name='Nary a Cloud in Sight',
          steps={
              "Continue watching the cutscene from RoV 3-27. At the end you will receive your rewards and the next mission starts automatically.",
          },
          prereqs={'RoV 3-27: Calm After the Storm'},
          rewards={"Cipher: Iroha", "Key Item: Rhapsody in Ochre", "Title: The Savior of Vana'diel"} },

        { num='RoV 3-29', name='An Unending Song',
          steps={
              "Zone into any area in a starting nation (Bastok, Windurst, or San d'Oria) that has a Mog House entrance for a brief cutscene.",
          },
          notes={
              "If your inventory was full when reaching this mission and you did not receive Cipher of Iroha's Alter Ego, examine the Mystic Retriever in Reisenjima to obtain it before the cutscene will trigger.",
          },
          prereqs={'RoV 3-28: Nary a Cloud in Sight'},
          rewards={'None'} },

        { num='RoV 3-30', name='A Deep Sleep',
          steps={
              "Go to Reisenjima Sanctorium for a cutscene.",
          },
          notes={
              "Alternative access: if you have completed CoP or are on the final CoP battle Dawn, use the Garden of Ru'Hmet HP#1, descend on the elevator into Empyreal Paradox, and click the Dimensional Portal to teleport to Reisenjima Sanctorium.",
          },
          prereqs={'RoV 3-29: An Unending Song'},
          rewards={'None'} },

        { num='RoV 3-31', name='Guardians',
          steps={
              "Travel to the Stone Circle at (G-6) in La Theine Plateau and examine the ??? for a cutscene. Receive Key Item: Breath of the Avatars.",
          },
          notes={
              "Unity Warp (Level 99) puts you relatively close.",
          },
          prereqs={'RoV 3-30: A Deep Sleep'},
          rewards={"Key Item: Breath of the Avatars", "Title: Blessed by the Avatars"} },

        { num='RoV 3-32', name='Iroha in Distress',
          steps={
              "Return to Reisenjima Sanctorium for a cutscene. Use Garden of Ru'Hmet HP and Empyreal Paradox Dimensional Portal to get there quickly.",
          },
          notes={
              "Completing this mission unlocks the ability to view all Rise of the Zilart mission cutscenes.",
          },
          prereqs={'RoV 3-31: Guardians'},
          rewards={"Ability to view all Rise of the Zilart mission cutscenes"} },

        { num='RoV 3-33', name='Absolute Trust',
          steps={
              "Touch the Reisen Crystal in Reisenjima Sanctorium for a cutscene.",
          },
          prereqs={'RoV 3-32: Iroha in Distress'},
          rewards={'None'} },

        { num='RoV 3-34', name="The Orb's Radiance",
          steps={
              "Examine the Reisen Crystal again to enter the BCNM against the Cloud of Darkness. Iroha fights alongside you.",
              "If you fail, return to the Stone Circle at (G-6) in La Theine Plateau for another Key Item: Breath of the Avatars before retrying.",
          },
          notes={
              "Cloud of Darkness begins absorbing either physical or magical damage after using Primordial Surge (AoE draw-in + drains 300-700 HP from players, 3000+ from Iroha). The gem on its head glows red during absorption. Watch Iroha's combat style: if she stops physical attacks and casts Fire VI/Flare, physical damage is being absorbed. If she only uses physical attacks, magic is being absorbed. Use the CORRECT damage type or risk being one-shotted.",
              "Phase ends when Cloud of Darkness uses Waning Vigor (applies Weakness 15s to tank). Below 25% Waning Vigor is replaced by Expunge (full dispel instead of Weakness).",
              "Cloud of Darkness absorbs elemental damage based on current weather -- avoid same-element magic.",
              "Iroha will Arise herself and eligible party members unlimited times. After accepting Arise: do not gain enmity immediately (run away briefly) so you can resummon Trusts.",
              "If you did not receive Cipher: Iroha II (full inventory), check the Mystic Retriever in Reisenjima Sanctorium.",
          },
          prereqs={'RoV 3-33: Absolute Trust', 'Key Item: Breath of the Avatars'},
          rewards={"Key Item: Phoenix's Blessing", "Key Item: Scintillating Rhapsody", "Cipher: Iroha II", "Title: Seer of Songs"} },

        { num='RoV 3-35', name='A Rhapsody for the Ages',
          steps={
              "Watch the ending cutscene. Rhapsodies of Vana'diel is complete!",
          },
          notes={
              "After this mission, The Voracious Resurgence missions become available.",
          },
          prereqs={"RoV 3-34: The Orb's Radiance"},
          rewards={"Rhapsodies of Vana'diel complete"} },

    },
}
