-- A Crystalline Prophecy Missions
-- Source: https://www.bg-wiki.com/ffxi/Category:Crystalline_Missions

return {
    id    = 'acp',
    label = 'A Crystalline Prophecy',
    entry = "Requires level 10+. Purchase the add-on from the PlayOnline store.",
    missions = {

        { num='1', name='A Crystalline Prophecy',
          steps={
              "Enter Lower Jeuno while level 10 or above for a cutscene.",
          },
          prereqs={'Level 10+'},
          rewards={'None'} },

        { num='2', name='The Echo Awakens',
          steps={
              "Collect 3 Seedspalls: Seedspall Lux from Orcs in Jugner Forest around (G-11) -- closest Survival Guide: Davoi. Seedspall Luna from Quadavs in Pashhow Marshlands around (K-10) -- closest Survival Guide: Beadeaux. Seedspall Astrum from Yagudos in Meriphataud Mountains around (K-8) -- closest Survival Guide: Castle Oztroja.",
              "Trade all 3 Seedspalls to the ??? at (G-6) in Qufim Island (mid-east section near 2 rock columns) for a cutscene.",
          },
          notes={
              "Crimson Key (repeatable): collect the 3 Seedspalls again and trade them to Squintrox Dryeyes in Port Jeuno at (G-8) for a Crimson Key (once per day). Use the key (Level 30) to open the red treasure coffer in Lower Jeuno at (J-8) for bonus rewards.",
          },
          prereqs={'ACP 1: A Crystalline Prophecy'},
          rewards={"Crimson Key (via repeatable bonus step)"} },

        { num='3', name='Gatherer of Light (I)',
          steps={
              "Kill goblins in Batallia Downs for Key Item: Bowl of Bland Goblin Salad (10% drop). Examine the ??? at (F-5) upper level to pop Vegnix Greenthumb. Kill it to receive Seedspall Roseum. Route to upper level: via Beaucedine Glacier, or trade a flower to the glowing spot at Batallia Downs (F-5) if you have Lycopodium Warps unlocked.",
              "Kill goblins in Rolanberry Fields for Key Item: Jug of Greasy Goblin Juice (10% drop). Examine the ??? at (D-11) to pop Chuglix Berrypaws. Kill it to receive Seedspall Caerulum. Routes: Unity Warp 125 to Rolanberry Fields, Voidwatch NPC (Jeuno > Crawlers' Nest entrance), or travel through Crawlers' Nest.",
              "Kill goblins in Sauromugue Champaign for Key Item: Chunk of Smoked Goblin Grub (10% drop). Examine the ??? at (I-9) SE corner to pop Dribblix Greasemaw. Kill it to receive Seedspall Viridis. Routes: Survival Guide to Sauromugue Champaign, Voidwatch NPC (Jeuno > Garlaige Citadel entrance), or travel through Garlaige Citadel.",
              "Examine the ??? at (G-6) in Qufim Island with all 3 Seedspalls for a cutscene.",
          },
          notes={
              "10% obtainment rate on goblin food KIs. In a party/alliance, 1 random member receives it -- all members on or past this mission are eligible. You MUST have the goblin food KI when the NM is killed to receive the Seedspall.",
              "Goblin food KIs are NOT lost when used to pop NMs -- save them for the Viridian Key step.",
              "Viridian Key (repeatable): after completing the mission, take all 3 goblin food KIs to Squintrox Dryeyes in Port Jeuno (G-8) for a Viridian Key (once per day, Level 40). You WILL lose the goblin food KIs when trading for the key. Use it on the red treasure coffer in Lower Jeuno (J-8).",
              "WARNING: Getting the Viridian Key starts a 1 real-day timer for Mission 4 (Gatherer of Light II). Do NOT get the key until you are ready for Mission 4.",
              "Squintrox will refuse if you already did Mission 3 or 4 the same day.",
          },
          prereqs={'ACP 2: The Echo Awakens'},
          rewards={"Viridian Key (via repeatable bonus step)"} },
        { num='4', name='Gatherer of Light (II)',
          steps={
              "Examine the ??? at (G-6) in Qufim Island to begin the battle. NO Trusts allowed -- buffs and pets are kept.",
              "Defeat 6 waves of 5 Seed Mandragoras (30 total). They are very weak -- one melee strike or AoE magic per wave. After all 30 are killed, receive Key Item: Amber Key.",
              "Examine the ??? again for a cutscene.",
          },
          notes={
              "Amber Key (repeatable): re-obtain Seedspall Roseum, Caerulum, and Viridis by re-popping the Goblin NMs from Mission 3 (goblin food KIs are not lost when popping NMs). Examine ??? at Qufim (G-6) to fight again for another Amber Key (once per day, Level 50). Use it on the red coffer in Lower Jeuno (J-8).",
              "After ALL Crystalline Missions are complete: all 3 Seedspalls can be bought from Squintrox Dryeyes for 500g + 5 Beastmen's Seals each.",
          },
          prereqs={'ACP 3: Gatherer of Light (I)'},
          rewards={"Amber Key"} },
        { num='5', name='Those Who Lurk in Shadows (I)',
          steps={
              "Enter Fei'Yin for a cutscene.",
          },
          prereqs={"ACP 4: Gatherer of Light (II)"},
          rewards={'None'} },
        { num='6', name='Those Who Lurk in Shadows (II)',
          steps={
              "Find all 9 Seed Afterglows in Fei'Yin within 30 minutes: red, orange, yellow, green, cerulean, blue, golden, silver, and white. They move periodically but stay in the same general areas. If you can't find yellow, check the circular room at (H-9)/(I-9).",
              "After collecting all 9, choose: Mark of Seed (to continue to the next mission) or Azure Key (repeatable reward).",
          },
          notes={
              "30-minute time limit. If you fail to collect all 9 in time, zone out and back in to restart.",
              "Can only repeat the Seed Afterglow gathering once per real-life day.",
              "Azure Key (Level 60): use it on the red treasure coffer in Lower Jeuno (J-8).",
              "Take the Mark of Seed on your first completion to progress the story. You can return for Azure Keys on subsequent days.",
          },
          prereqs={"ACP 5: Those Who Lurk in Shadows (I)"},
          rewards={"Mark of Seed (story progress) or Azure Key (repeatable reward)"} },
        { num='7', name='Those Who Lurk in Shadows (III)',
          steps={
              "Examine the Burning Circle at Qu'Bia Arena for a cutscene, then examine again to begin the BCNM. Trusts allowed.",
              "Fight 4 enemies: Seed Yagudo (WHM) -- Phantasmal Dance: AoE damage + Knockback + Bind. Seed Quadav (RDM) -- Feather Maelstrom: Amnesia + Bio. Seed Orc (WAR) -- shares hate with Yagudo first, then Quadav after Yagudo dies; Thunderous Yowl: AoE Curse + Plague. Seed Goblin (THF) -- teleports randomly around arena; Saucepan: AoE food debuff (-10 all stats, ~30 min duration); stacks Sneak Attack + Trick Attack with Goblin Rush and Bomb Toss.",
              "After the battle a cutscene plays and you receive Ivory Key (Level 70).",
          },
          notes={
              "Ivory Key repeat: re-obtain Mark of Seed from Mission 6 and repeat the BCNM. After all ACP missions complete, Mark of Seed can be bought from Squintrox Dryeyes for 1,500g + 15 Beastmen's Seals.",
              "Use Ivory Key on the red treasure coffer in Lower Jeuno (J-8).",
          },
          prereqs={"ACP 6: Those Who Lurk in Shadows (II)"},
          rewards={"Ivory Key"} },
        { num='8', name='Remember Me in Your Dreams',
          steps={
              "Enter the Hall of the Gods from Ro'Maeve for a cutscene. Must enter from the Ro'Maeve side -- if you enter from Ru'Aun Gardens, exit to Ro'Maeve and re-enter from there.",
          },
          prereqs={"ACP 7: Those Who Lurk in Shadows (III)"},
          rewards={'None'} },
        { num='9', name='Born of Her Nightmares',
          steps={
              "Enter Lower Delkfutt's Tower for a cutscene.",
          },
          prereqs={"ACP 8: Remember Me in Your Dreams"},
          rewards={'None'} },
        { num='10', name='Banishing the Echo',
          steps={
              "Examine a Seed Fragment to receive a Level 30 cap status. Under this cap you can collect Seed Afterglows as Key Items. No Trusts, no XP loss on death, cannot be healed by players without the cap. Use Prism Powder and Silent Oil -- Seed Fragments are surrounded by sight-aggro mobs. Drop Invisible next to the fragment when mobs face away, examine it, re-invisible immediately.",
              "LOWER DELKFUTT'S: Examine Seed Fragment on Floor 1 (H-10). Collect: Amicitia Stone -- Floor 1 (J-10). Veritas Stone -- Floor 2 (H-7). Sapientia Stone -- Floor 3 (I-9).",
              "MIDDLE DELKFUTT'S: Examine Seed Fragment on Floor 4 (G-6). Collect: Sanctitas Stone -- Floor 4 (H-10). Felicitas Stone -- Floor 5 (G-7). Divitia Stone -- Floor 6 (F-8). Studium Stone -- Floor 7 (H-9). Amoris Stone -- Floor 8 (I-8). Caritas Stone -- Floor 9 (G-8).",
              "UPPER DELKFUTT'S: Examine Seed Fragment on Floor 10 (F-7). Collect: Constantia Stone -- Floor 10 (F-10). Spei Stone -- Floor 11 (H-7). Salus Stone -- Floor 12 (H-7).",
              "Examine the Seed Fragment in Stellar Fulcrum with all 12 stones to receive Key Item: Omnis Stone.",
          },
          notes={
              "Magic-aggro mobs (dolls, elementals) are present in some areas -- maintain Invisible at all times except when examining.",
          },
          prereqs={"ACP 9: Born of Her Nightmares"},
          rewards={"Key Item: Omnis Stone"} },
        { num='11', name='Ode of Life Bestowing',
          steps={
              "Examine the Qe'Iov Gate in Stellar Fulcrum for a cutscene. Examine again to begin the BCNM vs Seed Crystal.",
              "Seed Crystal (~25,000 HP): strong physical and magical defense. Uses ranged AoE magic instead of melee. Draws In the primary hate holder. Casts all -ga III spells. Special attacks: Seed of Nihility (AoE damage + resets all job ability timers including 2-hours), Seed of Deference (AoE Charm, charmed players get Seed Mandragora costume), Seed of Deception (spawns a Seed Thrall clone of the hate target -- used frequently), Seed of Judgment (AoE knockback + high damage).",
          },
          notes={
              "Ebon Key repeat: re-obtain Omnis Stone from Mission 10 and repeat the fight. After all ACP missions complete, Omnis Stone can be bought from Squintrox Dryeyes for 2,000g + 20 Beastmen's Seals.",
              "Use Ebon Key (Level 75) on the red treasure coffer in Lower Jeuno (J-8).",
              "Also rewards a Prismatic Key on first completion.",
          },
          prereqs={"ACP 10: Banishing the Echo"},
          rewards={"Ebon Key", "Prismatic Key", "Title: Silencer of the Echo"} },
        { num='12', name='A Crystalline Prophecy (Fin.)',
          steps={
              "Head to the Tenshodo in Lower Jeuno and examine the Treasure Chest to choose your reward.",
          },
          notes={
              "To change your reward: discard the item, then buy an Omnis Stone from Squintrox Dryeyes in Port Jeuno (G-8) for 2,000g + 20 Beastmen's Seals. Re-enter the Stellar Fulcrum BCNM and you will receive the keys immediately after the fight.",
              "Completing ACP unlocks the ability to purchase Atma of Echoes.",
          },
          prereqs={"ACP 11: Ode of Life Bestowing"},
          rewards={"Choice: Mirke Wardecors / Nuevo Coselete / Royal Redingote", "Ability to purchase Atma of Echoes"} },
    },
}
