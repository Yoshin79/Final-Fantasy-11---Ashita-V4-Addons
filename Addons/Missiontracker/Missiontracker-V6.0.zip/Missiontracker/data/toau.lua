-- Treasures of Aht Urhgan Missions (TOAU) - 46 missions
-- Source: https://www.bg-wiki.com/ffxi/Category:Aht_Urhgan_Missions

return {
    id    = 'toau',
    label = 'Treasures of Aht Urhgan',
    entry = "ToAU expansion required. First complete quest The Road to Aht Urhgan to receive a Boarding Permit.",
    missions = {

        { num='1', name='Land of Sacred Serpents',
          steps={
              "Complete quest The Road to Aht Urhgan to receive a Boarding Permit (see prereqs for full walkthrough).",
              "Travel to Aht Urhgan Whitegate: take the ferry from Mhaura, OR use Unity Warp Lv125 to Wajaom Woodlands. Grab the Home Point near the dock.",
              "Speak to Naja Salaheem at Salaheem's Sentinels (I-10) -- upstairs in the NE corner -- to receive a Supplies Package.",
          },
          notes={
              "RoV shortcut: if on RoV Mission 2-5, select Where is Tenzen? when talking to Faursel to receive a Boarding Permit for free.",
              "Grab the Home Point and Survival Guide in Whitegate immediately on arrival.",
          },
          prereqs={
              "Quest: The Road to Aht Urhgan -- Speak to Faursel at Neptune's Spire in Lower Jeuno (J-8). Select the 3rd hidden option, then talk again and choose I want to go. Collect items and trade to Faursel, then zone and return the next Vana'diel day.",
              "ADVANCED: 1 Coffer Key from a beastman stronghold, OR any Testimony item, OR 3 Pso'Xja chips. Buy Coffer Keys from Curio Vendor Moogle for 5,000 gil with Rhapsody in Umber.",
              "INTERMEDIATE: Trade Jade Cryptex + Silver Engraving + 13 Knot Quipus.",
              "BEGINNER: Trade all 6 sub-job quest items: Magicked Skull, Damselfly Worm, Crab Apron, Bloody Robe, Dhalmel Saliva, Wild Rabbit Tail.",
              "GIL SHORTCUT: Pay 500,000 gil -- zone and return the next day for Boarding Permit + Map of Wajaom Woodlands, teleported to Wajaom Woodlands Leypoint.",
          },
          rewards={'Key Item: Supplies Package'} },

        { num='2', name='Immortal Sentries',
          steps={
              "Take the Supplies Package to any Staging Point (NOT Nyzul Isle SP or the Chamber of Passage) and speak to the Immortal NPC there to deliver it.",
              "Use the Runic Portal at the Staging Point to return to Aht Urhgan Whitegate.",
              "Speak to Naja Salaheem.",
          },
          notes={
              "Do NOT use the Runic Portal before delivering the package -- it warps you back and you cannot return yet.",
              "Fastest for new players: Azouph Isle SP via Voidwatch Warp to Caedarva Mire (requires level 75, Rank 3, 1,000 cruor from Atmacite Refiner). Exchange 1 Copper Voucher for cruor if needed.",
          },
          prereqs={'TOAU 1: Land of Sacred Serpents'},
          rewards={'PSC Wildcat Badge', '150 Imperial Standing', 'Mog Locker access', 'Sanction access', 'Assault access', 'Runic Portal access', 'Title: Private Second Class'} },

        { num='3', name='President Salaheem',
          steps={
              "Zone out of Salaheem's Sentinels (exit to Wajaom Woodlands west of the office under the stairs) and return.",
              "Speak to Rytaal at (K-10) inside the Commissions Agency (door at K-9) for an explanation of Assault and to unlock it.",
              "Speak to Naja Salaheem twice for two cutscenes. The next mission begins immediately.",
          },
          notes={
              "Trust: Abquhbah -- if you have completed RoV 2-7 Ever Forward, speak to Abquhbah after this mission.",
          },
          prereqs={'TOAU 2: Immortal Sentries'},
          rewards={'Assault access'} },

        { num='4', name='Knight of Gold',
          steps={
              "This mission begins immediately after the previous cutscene.",
              "Speak to Cacaroon at (G-11) across from the Mog House for a cutscene.",
              "Trade Cacaroon 1,000 gil OR one Imperial Bronze Piece. If paying gil you must manually trade it.",
              "Enter Walahra Temple at (K-8) for a cutscene.",
              "Head to Shararat Teahouse at (K-12) for a cutscene.",
              "Answer the questions: (1) Pick all 3 options. (2) Choose Raillefal's secret. (3) You are really... = A San d'Orian Prince. (4) Raillefal is really... = Prince Trion.",
          },
          prereqs={'TOAU 3: President Salaheem'},
          rewards={"Key Item: Raillefal's Letter"} },

        { num='5', name='Confessions of Royalty',
          steps={
              "Enter Chateau d'Oraguille from Northern San d'Oria (I-6).",
              "Speak to Halver at (I-9) to deliver Raillefal's Letter.",
          },
          prereqs={"TOAU 4: Knight of Gold"},
          rewards={'None'} },

        { num='6', name='Easterly Winds',
          steps={
              "Wait 1 Earth minute after mission 5, then approach the Palace in Ru'Lude Gardens for a cutscene.",
              "Choose Yes then That is what I am here for! to receive 10x Imperial Bronze Piece. Choosing What am I a donkey? completes but forfeits the reward.",
          },
          prereqs={"TOAU 5: Confessions of Royalty"},
          rewards={"10x Imperial Bronze Piece (if correct answers chosen)"} },

        { num='7', name='Westerly Winds',
          steps={
              "Head to Shararat Teahouse at (K-11) for a cutscene. Receive Key Item: Raillefal's Note and 1x Imperial Silver Piece. Dialogue choices have no effect.",
              "Speak to Naja Salaheem at (I-10) for a cutscene and receive the second Imperial Silver Piece.",
          },
          notes={
              "If asked for an Imp Wing, it is due to the Promotion: Private First Class quest -- trade one Imp Wing to continue.",
          },
          prereqs={'TOAU 6: Easterly Winds'},
          rewards={"Key Item: Raillefal's Note", "2x Imperial Silver Piece"} },

        { num='8', name='A Mercenary Life',
          steps={
              "Zone out and return to Salaheem's Sentinels at (I-10) for a cutscene.",
          },
          prereqs={'TOAU 7: Westerly Winds'},
          rewards={'None'} },

        { num='9', name='Undersea Scouting',
          steps={
              "IF Nyzul Isle SP NOT UNLOCKED: Travel to Bhaflau Thickets and trade 1 Imperial Silver Piece to Kamih Mapokhalam at (F-6) on Map 1 to enter Alzadaal Undersea Ruins. Approach the Gilded Doors at (H-8) on Map 7 for the cutscene. Then unlock the Nyzul Isle SP before leaving (enter Gilded Doors, take transporter LEFT -- Apex Gears are to the right -- take the portal left again, exit south, follow east to Gilded Doors for Nyzul Isle SP).",
              "IF Nyzul Isle SP ALREADY UNLOCKED: Use the Chamber of Passage Runic Portal to Nyzul Isle SP. Take the SE transport at (H-9) to Bhaflau Remnants, then right/east transport to Alzadaal Undersea Ruins.",
              "Alternative: trade 1 Imperial Silver Piece to Tyamah at (J-10) in Caedarva Mire (east exit from Nashmau).",
          },
          notes={
              "Unlock the Nyzul Isle SP before leaving -- it is one of the most frequently used Runic Portals.",
          },
          prereqs={'TOAU 8: A Mercenary Life'},
          rewards={"Key Item: Astral Compass"} },

        { num='10', name='Astral Waves',
          steps={
              "Return to Naja Salaheem at (I-10) for a cutscene.",
          },
          prereqs={'TOAU 9: Undersea Scouting'},
          rewards={'None'} },

        { num='11', name='Imperial Schemes',
          steps={
              "Wait one Vana'diel day, then zone and return to Naja Salaheem for a cutscene.",
          },
          prereqs={'TOAU 10: Astral Waves'},
          rewards={'None'} },

        { num='12', name='Royal Puppeteer',
          steps={
              "Wait one Vana'diel day and zone after mission 11, then head to Salaheem's Sentinels (I-10) for a cutscene.",
              "Travel to Nashmau and speak to Pyopyoroon at (H-7) -- he requests Jody's Acid.",
              "Obtain Jody's Acid (drops from Ameretats in Bhaflau Thickets or Wajaom Woodlands, or Great Ameretats in Wajaom Woodlands or Aydeewa Subterrane).",
              "Trade Jody's Acid to Pyopyoroon to receive Key Item: Vial of Spectral Scent.",
          },
          notes={
              "Completing this mission allows you to progress past RoV Mission 2-7 Ever Forward.",
          },
          prereqs={'TOAU 11: Imperial Schemes'},
          rewards={"Key Item: Vial of Spectral Scent"} },

        { num='13', name='Lost Kingdom',
          steps={
              "Head to Caedarva Mire via the west exit in Nashmau. Examine Jazaraat's Headstone at (E-10).",
              "Check the headstone a second time to spawn Fomor NM Jazaraat. Defeat it.",
              "Check the headstone a third time to receive Key Item: Ephramadian Gold Coin.",
          },
          prereqs={'TOAU 12: Royal Puppeteer'},
          rewards={"Key Item: Ephramadian Gold Coin", "Title: Royal Swordsman"} },

        { num='14', name='The Dolphin Crest',
          steps={
              "Return to Naja Salaheem for a cutscene. Mission 15 begins automatically afterward.",
          },
          prereqs={'TOAU 13: Lost Kingdom'},
          rewards={'None'} },

        { num='15', name='The Black Coffin',
          steps={
              "Head to the Cutter at (H-8) on Map 5 of Arrapago Reef. Best route: Arrapago Ring (100 Imperial Standing from Asrahd at Whitegate I-8) warps you near the Cutter. Or: Survival Guide to Caedarva Mire, run south to Arrapago Reef zone at (G-8) -- NOT the (G-6) zone -- head south to (H-8). Or: Dvucca Isle SP then west to (G-9) and zone in.",
              "Approach the Cutter for a cutscene. Examine the Cutter to enter the BCNM.",
              "BCNM: fight the Ashu Talif Crew (2 RNG + 2 RDM + 1 COR). After defeating all 5 a second wave of 4 spawns plus the Ashu Talif Captain. Reduce the Captain to ~20% HP to win.",
              "After the fight you will appear in Nashmau.",
          },
          notes={
              "ALL party members need an Ephramadian Gold Coin to enter. Get another from Jazaraat's Headstone at Caedarva Mire (E-10) if needed.",
              "Gessho assists you but waits 1-2 minutes before fighting -- use this time to buff.",
              "Ashu Talif Crew resist most Sleep without Elemental Seal. Lullaby lands easily at iLvl 119.",
          },
          prereqs={'TOAU 14: The Dolphin Crest', 'Key Item: Ephramadian Gold Coin'},
          rewards={'None'} },

        { num='16', name='Ghosts of the Past',
          steps={
              "Speak to Naja Salaheem in Aht Urhgan Whitegate for a cutscene.",
          },
          prereqs={'TOAU 15: The Black Coffin'},
          rewards={'None'} },

        { num='17', name='Guests of the Empire',
          steps={
              "Speak to Naja Salaheem for a cutscene, then play dress-up with her.",
              "Equip approved attire (see notes), plus gloves, leg armor, and boots. Remove your weapons.",
              "Speak to Naja again to confirm your outfit, then check the Imperial Whitegate door at (L-8) for a cutscene. Receive 1x Imperial Mythril Piece.",
          },
          notes={
              "Make sure your inventory has space before the palace cutscene or you must rewatch the entire scene.",
              "Approved body armors include: Adaman Cuirass, Aketon, Amir Korazin, Arhat's Gi, Black Cloak, Black Cotehardie, Blessed Bliaut, Bloody Aketon, Blue Cotehardie, Brigandine (free via RoE Conflict: Beadeaux), Byrnie, Cardinal Vest, Chasuble, Dusk Jerkin, Dragon Harness, Errant Houppelande, Hachiman Domaru, Haubergeon, Hauberk, Holy Breastplate, Homam Corazza, Igqira Weskit, Jaridah Peti, Justaucorps, Nashira Manteel (10k gil from Curio Vendor Moogle with Rhapsody in White), Noble's Tunic, Pahluwan Khazagand, Plastron, Scorpion Harness, Sipahi Jawshan, and others.",
              "Completing this mission unlocks Salvage access.",
          },
          prereqs={'TOAU 16: Ghosts of the Past'},
          rewards={"1x Imperial Mythril Piece", 'Salvage access', "Title: Ovjang's Errand Runner"} },

        { num='18', name='Passing Glory',
          steps={
              "Wait one Vana'diel day and zone after mission 17, then approach Naja Salaheem for a cutscene.",
          },
          notes={
              "After completing this mission, Ashu Talif Assault becomes available.",
              "Trust: Gessho -- examine the cushion in Aht Urhgan Whitegate at (J-12) to acquire Cipher: Gessho.",
          },
          prereqs={'TOAU 17: Guests of the Empire'},
          rewards={"Ashu Talif Assault access"} },

        { num='19', name='Sweets for the Soul',
          steps={
              "Enter the Shararat Teahouse in Aht Urhgan Whitegate for a cutscene.",
          },
          prereqs={'TOAU 18: Passing Glory'},
          rewards={'None'} },

        { num='20', name='Teahouse Tumult',
          steps={
              "Head to Aydeewa Subterrane. Routes: zone from Wajaom Woodlands at (G-7), Survival Guide to Aydeewa, or Unity Warp Lv135 Wajaom (entrance directly behind you) or Lv145 Aydeewa.",
              "After the entry cutscene, continue southwest to the room at (E-9/F-9) then head west down the ramp to Map 5.",
              "At (F-8/G-8) examine the blank target for a cutscene. Mission completes. Use Sneak and Invisible throughout.",
          },
          prereqs={'TOAU 19: Sweets for the Soul'},
          rewards={"None", "Title: Karababa's Tour Guide"} },

        { num='21', name='Finders Keepers',
          steps={
              "Enter Salaheem's Sentinels for a cutscene.",
          },
          prereqs={'TOAU 20: Teahouse Tumult'},
          rewards={'None'} },

        { num='22', name='Shield of Diplomacy',
          steps={
              "Travel to Navukgo Execution Chamber. Fastest: Mount Zhayolm Home Point is right outside. If no HP: Unity Warp Lv135 Mount Zhayolm, turn around, go forward, take the east junction at the (C-7)/(C-8) line.",
              "Zone into Navukgo Execution Chamber for a cutscene.",
              "Examine the Decorative Bronze Gate for another cutscene, then examine it again to enter the BCNM.",
              "Fight Khimaira 13. Keep Lady Karababa alive -- if her HP drops too low and she is not healed, she Warps out ending in a loss.",
          },
          notes={
              "Khimaira 13 abilities: Dreadstorm (AoE + Terror), Tenebrous Mist (TP reset to 0), Thunderstrike (AoE + Stun), Tourbillion (AoE + Knockback). All remove Utsusemi.",
              "Lady Karababa assists with Ancient Magic II spells -- keep her healed.",
          },
          prereqs={'TOAU 21: Finders Keepers'},
          rewards={"None", "Title: Karababa's Bodyguard"} },

        { num='23', name='Social Graces',
          steps={
              "Enter Salaheem's Sentinels for a cutscene.",
          },
          prereqs={'TOAU 22: Shield of Diplomacy'},
          rewards={'None'} },

        { num='24', name='Foiled Ambition',
          steps={
              "Wait one Vana'diel day and zone, then enter Salaheem's Sentinels for a cutscene.",
          },
          prereqs={'TOAU 23: Social Graces'},
          rewards={"5x Imperial Gold Piece", "Title: Karababa's Secret Agent"} },

        { num='25', name='Playing the Part',
          steps={
              "Wait one Vana'diel day and zone, then speak to Naja Salaheem for a cutscene.",
              "Choose Aphmau in the cutscene to continue the mission.",
          },
          prereqs={'TOAU 24: Foiled Ambition'},
          rewards={'None'} },

        { num='26', name='Seal of the Serpent',
          steps={
              "Unequip your weapon and examine the Imperial Whitegate door at (L-9) in Aht Urhgan Whitegate for a cutscene.",
          },
          prereqs={'TOAU 25: Playing the Part'},
          rewards={'None'} },

        { num='27', name='Misplaced Nobility',
          steps={
              "Head to Aydeewa Subterrane (same routes as mission 20).",
              "Navigate southwest to the room at (E-9/F-9), then head west down the ramp to Map 5.",
              "Examine the blank target at (F-8/G-8) -- same location as mission 20 -- for a cutscene. Mission completes.",
          },
          prereqs={'TOAU 26: Seal of the Serpent'},
          rewards={'None'} },

        { num='28', name='Bastion of Knowledge',
          steps={
              "Enter Walahra Temple in Aht Urhgan Whitegate for a cutscene.",
          },
          prereqs={'TOAU 27: Misplaced Nobility'},
          rewards={"None", "Title: Aphmau's Mercenary"} },

        { num='29', name='Puppet in Peril',
          steps={
              "Head to Jade Sepulcher in Mamook. Fastest: Bhaflau Thickets HP#1 then head north to Jade Sepulcher zone at (I-9). Or: Mamool Ja SP and head north. Use Sneak + Invisible or a mount.",
              "Examine the Ornamental Door for a cutscene. Check the door again and select Puppet in Peril to enter the BCNM.",
              "Fight Lancelord Gaheel Ja (PLD). Attack from behind -- Granite Skin (undispellable Stoneskin) blocks all frontal attacks but wears quickly. After winning a cutscene completes the mission.",
          },
          notes={
              "Gaheel Ja abilities: Clobber (large AoE), Granite Skin (frontal Stoneskin -- attack from behind), Blazing Angon (AoE). Casts Flash, Holy, Cure IV.",
          },
          prereqs={'TOAU 28: Bastion of Knowledge'},
          rewards={'None'} },

        { num='30', name='Prevalence of Pirates',
          steps={
              "Zone into Arrapago Reef for a cutscene. Best route: Arrapago Ring (100 Imperial Standing from Asrahd at Whitegate I-8) warps near the Cutter. Or: Caedarva Mire SG then south to Arrapago Reef (4) entrance. Or: Dvucca Isle SP.",
              "After the cutscene, approach the Cutter for another cutscene completing the mission. If entered from Caedarva Mire at (G-9) the Cutter is just north.",
          },
          notes={
              "Do NOT warp out after -- the next mission is accessible on foot south from the Cutter.",
          },
          prereqs={'TOAU 29: Puppet in Peril'},
          rewards={'Periqia Assault area entry permit'} },

        { num='31', name='Shades of Vengeance',
          steps={
              "Head to Dvucca Isle SP in Caedarva Mire (head south from the Cutter and zone into Caedarva Mire -- the SP is very close).",
              "Enter Periqia via the Runic Seal just west of Dvucca Isle SP.",
              "BCNM: fight up to 10x K23H1-LAMIA at (H-9). All have True Sight, link, and all attacks add Poison. Venomous Tail WS has a strong Poison effect. Defeat enough and the battle ends. Trusts allowed.",
              "A cutscene plays on victory completing the mission.",
          },
          notes={
              "If you fail, obtain another permit from Nahshib after one Vana'diel day.",
              "Players who have already cleared do NOT need another permit to help others.",
          },
          prereqs={'TOAU 30: Prevalence of Pirates'},
          rewards={"None", "Title: Nashmeira's Mercenary"} },

        { num='32', name='In the Blood',
          steps={
              "Speak to Naja Salaheem for a cutscene.",
          },
          prereqs={'TOAU 31: Shades of Vengeance'},
          rewards={"1x Imperial Gold Piece"} },

        { num='33', name="Sentinels' Honor",
          steps={
              "Wait one Vana'diel day and zone, then speak to Naja Salaheem for a cutscene.",
          },
          notes={
              "While waiting, get the Ephramadian Gold Coin needed for the next mission: Jazaraat's Headstone at Caedarva Mire (E-10).",
          },
          prereqs={'TOAU 32: In the Blood'},
          rewards={"None", "Title: Salaheem's Risk Assessor"} },

        { num='34', name='Testing the Waters',
          steps={
              "Obtain an Ephramadian Gold Coin from Jazaraat's Headstone at (E-10) in Caedarva Mire.",
              "Travel to the Cutter in Arrapago Reef at (H-8). Fastest: Arrapago Ring (100 Imperial Standing from Asrahd at Whitegate I-8). Or: Dvucca Isle SP then west to (G-9) and zone in, head north. Or: Caedarva Mire SG, exit tunnel into open area, head south to Arrapago Reef, then north.",
              "Approach the Cutter for a cutscene. You appear in Talacca Cove.",
          },
          notes={
              "Do NOT warp away after -- the next mission begins on Talacca Cove.",
          },
          prereqs={"TOAU 33: Sentinels' Honor", 'Key Item: Ephramadian Gold Coin'},
          rewards={"Key Item: Percipient Eye", "Title: Treasure Trove Tender"} },

        { num='35', name='Legacy of the Lost',
          steps={
              "After mission 34 you appear in Talacca Cove. Examine the Rock Slab in front of you to enter the 30-minute BCNM against Gessho.",
              "Fight Gessho (NIN). He warps around the arena and spawns 3-6 clones periodically. Clones have ~2,000 HP, are immune to Sleep, and can use Ninjutsu including Mijin Gakure. Kill clones quickly.",
              "Gessho gives up at ~15% HP. A final cutscene plays on victory.",
          },
          notes={
              "Gessho abilities: Hane Fubuki (ranged + Poison), Happobarai (AoE + Stun, blinkable), Hiden Sokyaku (Knockback + Stun), Rinpyotosha (Warcry), Shiko no Mitate (Defense Boost), Shibaraku (AoE + Knockback, blinkable).",
              "Beware clone Mijin Gakure -- if multiple clones use it simultaneously the damage is massive.",
              "For others joining: closest teleport is Caedarva Mire HP#1.",
          },
          prereqs={'TOAU 34: Testing the Waters'},
          rewards={"None", "Title: Gessho's Mercy"} },

        { num='36', name='Gaze of the Saboteur',
          steps={
              "Zone into Hazhalm Testing Grounds at Caedarva Mire Map 1 (D-9) for a cutscene. From mission 35 go left then take the first tunnel. Or warp to Caedarva Mire HP#1. Or warp to Nashmau HP and take the west exit.",
              "Check the Entry Gate for a final cutscene.",
          },
          prereqs={'TOAU 35: Legacy of the Lost'},
          rewards={"Key Item: Luminian Dagger", "Title: Emissary of the Empress"} },

        { num='37', name='Path of Blood',
          steps={
              "Enter Salaheem's Sentinels for a cutscene.",
          },
          prereqs={'TOAU 36: Gaze of the Saboteur'},
          rewards={'None'} },

        { num='38', name='Stirrings of War',
          steps={
              "Wait until the end of the current Vana'diel day and zone, then head to Shararat Teahouse for a cutscene.",
          },
          prereqs={'TOAU 37: Path of Blood'},
          rewards={"Key Item: Allied Council Summons"} },

        { num='39', name='Allied Rumblings',
          steps={
              "Head to Ru'Lude Gardens and approach the palace doors for a cutscene. Multiple cutscenes play here -- make sure you receive the one where you speak directly with Trion.",
          },
          prereqs={'TOAU 38: Stirrings of War'},
          rewards={'None'} },

        { num='40', name='Unraveling Reason',
          steps={
              "Optional: speak to Pherimociel in Ru'Lude Gardens (G-6) for a brief cutscene.",
              "Wait one Vana'diel day and zone after mission 39, then speak to Pherimociel again. You appear at the Leypoint in Wajaom Woodlands.",
          },
          prereqs={'TOAU 39: Allied Rumblings'},
          rewards={"None", 'Title: Endymion Paratrooper'} },

        { num='41', name='Light of Judgment',
          steps={
              "Speak to Rodin-Comidin outside the Automaton Workshop in Aht Urhgan Whitegate at (I-7).",
              "Prepare for a battle and head to Nyzul Isle Staging Point.",
          },
          prereqs={'TOAU 40: Unraveling Reason'},
          rewards={'Nyzul Isle route'} },

        { num='42', name='Path of Darkness',
          steps={
              "At the Nyzul Isle SP, activate the blank target (deactivated lamp) at (J-9) next to the Runic Portals and select Yes.",
              "Check the Runic Seal at (I-9) to enter the BCNM. Trusts allowed. Keep Naja Salaheem alive -- mission fails if she dies.",
              "BATTLE 1: Fight Amnaf + 4x Imperial Gears. Gears spawn when Amnaf is aggro'd -- gather all on you with AoE before they kill Naja. Gears susceptible to Gravity and Bind. Amnaf can be slept. After defeat Amnaf warps to next room.",
              "BATTLE 2: Amnaf + 4x Imperial Gears (Triple Gears, easier to sleep). Amnaf gives up at ~25% HP and warps.",
              "BATTLE 3: Amnaf transforms into a Soulflayer. Her Sleepga resets all hate. Defeat her to win.",
          },
          notes={
              "AoE immediately to pull hate from all gears away from Naja. Trust Valaineral's Uriel Blade is great for hate if you lack AoE.",
              "If you fail, return to Rodin-Comidin in Whitegate for another key item.",
          },
          prereqs={'TOAU 41: Light of Judgment'},
          rewards={"None", "Title: Naja's Comrade-in-Arms"} },

        { num='43', name='Fangs of the Lion',
          steps={
              "Approach Naja Salaheem in Aht Urhgan Whitegate for a cutscene.",
          },
          prereqs={'TOAU 42: Path of Darkness'},
          rewards={"Key Item: Mythril Mirror", "Title: Nashmeira's Loyalist"} },

        { num='44', name="Nashmeira's Plea",
          steps={
              "Check the blank target at the Nyzul Isle SP for a cutscene, then head to the Runic Seal at (I-9) to enter the 45-minute BCNM. Trusts allowed.",
              "BATTLE 1 -- Raubahn (BLU): defeat him 3 times (re-raises twice). Each re-raise resets Azure Lore timer. He frequently casts Eyes On Me, which hits hard when paired with Azure Lore. On his 3rd life he gains immunity to the damage type used most -- vary your damage type to avoid this.",
              "BATTLE 2 -- Razfahd (PLD): cannot move. At 50% HP uses Perfect Defense. Casts Banish IV, Banishga III, Dia III, Holy II.",
              "BATTLE 3 -- Alexander (PLD): cannot move. Most time-consuming. Key abilities: Divine Judgement (AoE 1000+ damage + clears Utsusemi, used at 50% and repeatedly), Gospel of the Lost (heals ~900-1100 HP + removes debuffs, can be Stunned), Radiant Sacrament (AoE + Magic Defense Down + clears Utsusemi), Void of Repentance (Terror), Perfect Defense. Defeat Alexander to win.",
          },
          notes={
              "If you fail, return to Naja Salaheem for another key item to retry.",
              "Do not stray too far from Alexander or he will use Draw In.",
          },
          prereqs={"TOAU 43: Fangs of the Lion"},
          rewards={"None", 'Title: Preventer of Ragnarok'} },

        { num='45', name='Ragnarok',
          steps={
              "Approach Naja Salaheem for a cutscene.",
          },
          prereqs={"TOAU 44: Nashmeira's Plea"},
          rewards={'None'} },

        { num='46', name='Imperial Coronation',
          steps={
              "Equip approved attire (same armor list as mission 17), plus gloves, leg armor, and boots. Remove your weapon and shield.",
              "Check the Imperial Whitegate door at (L-8) in Aht Urhgan Whitegate for a cutscene.",
          },
          notes={
              "Approved body armors include: Adaman Cuirass, Aketon, Amir Korazin, Arhat's Gi, Black Cloak, Black Cotehardie, Blessed Bliaut, Blue Cotehardie, Brigandine (free via RoE Conflict: Beadeaux), Byrnie, Cardinal Vest, Chasuble, Dusk Jerkin, Dragon Harness, Errant Houppelande, Hachiman Domaru, Haubergeon, Hauberk, Holy Breastplate, Homam Corazza, Igqira Weskit, Jaridah Peti, Justaucorps, Nashira Manteel, Noble's Tunic, Pahluwan Khazagand, Plastron, Rasetsu Samue, Scorpion Harness, Sipahi Jawshan, Sha'ir Manteel, Vermillion Cloak, Yigit Gomlek, and others.",
          },
          prereqs={'TOAU 45: Ragnarok'},
          rewards={'None'} },

    },
}
