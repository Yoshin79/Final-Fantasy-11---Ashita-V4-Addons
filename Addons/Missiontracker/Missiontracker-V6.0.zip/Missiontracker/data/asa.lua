-- A Shantotto Ascension Missions
-- Source: https://www.bg-wiki.com/ffxi/Category:A_Shantotto_Ascension_Missions

return {
    id    = 'asa',
    label = 'A Shantotto Ascension',
    entry = "Requires level 10+. Purchase the add-on from the PlayOnline store.",
    missions = {

        { num='1', name='A Shantotto Ascension',
          steps={
              "Zone into Windurst Walls from Windurst Woods or Windurst Waters while level 10 or above for the starting cutscene. Entering via any other means (including the Mog House) will NOT trigger it.",
          },
          prereqs={'Level 10+'},
          rewards={'None'} },

        { num='2', name='Burgeoning Dread',
          steps={
              "Zone into East Sarutabaruta or West Sarutabaruta via one of Windurst's gates for a cutscene.",
          },
          notes={
              "Pay attention to which Enfeeblement Kit is requested in the cutscene -- it is required for the next mission.",
          },
          prereqs={'ASA 1: A Shantotto Ascension'},
          rewards={'None'} },
        { num='3', name='That Which Curdles Blood',
          steps={
              "Craft the Enfeeblement Kit you were assigned in Mission 2 (Silence, Sleep, Poison, or Blindness). If you forgot which, speak to: Kuroido-Moido at Port Windurst (E-7), Faulpie at Southern San d'Oria (E-8), or Abd-al-Raziq at Bastok Mines (L-7).",
              "Components to craft: Padded Box (Earth Crystal + Bast Parchment x2 + Inferior Cocoon, or use Woodworking Kit 5 from guild NPC). Fine Parchment x2 (Dark Crystal + Parchment + Pumice Stone each). Enchanted Ink x2 (Dark Crystal + Black Ink + Magicked Blood each). Plus the appropriate potion (Silencing/Sleeping/Poison/Blinding Potion).",
              "Combine all components with an Earth Crystal to make the Enfeeblement Kit. Alchemy 10+ recommended. All components can be traded but the kit itself cannot -- you must synth it yourself.",
              "Trade the Enfeeblement Kit to the Trodden Snow at (H-7) in Qufim Island for a cutscene.",
          },
          notes={
              "Synths can fail -- have backup ingredients ready.",
              "Moogle Key (repeatable, once per day): speak to Squintrox Dryeyes in Port Jeuno (G-8), trade him the requested Enfeeblement Kit for a Moogle Key. Use it (Level 30) on the red coffer in Lower Jeuno Tenshodo (J-8). Requires Tenshodo Member's Card -- complete quest 'Tenshodo Membership' if needed.",
          },
          prereqs={'ASA 2: Burgeoning Dread'},
          rewards={"Moogle Key (via repeatable bonus step)"} },
        { num='4', name='Sugar-coated Directive',
          steps={
              "You receive 6 seal Key Items. Attach at least 3 to Protocrystals at any of the 6 Cloisters (Storms, Frost, Flames, Tremors, Tides, Gales).",
              "At each Protocrystal: click once, then click again to enter the Sugar-coated Directive BCNM. Fight a weakened Prime Avatar. The avatar will NOT die until it has used its Astral Flow ability 5 times. No Trusts. Content level ~40, soloable by most jobs at 55-60.",
              "After the battle click the Protocrystal again to attach the seal and receive a counterseal Key Item. If you leave before getting the counterseal, return to the crystal -- you do NOT need to fight again.",
              "After collecting at least 3 counterseals, return to the Trodden Snow at Qufim Island (H-7) for a cutscene and your Gil reward.",
          },
          notes={
              "Gil reward scales with number of counterseals: 3 = 3,000g, 4 = 10,000g, 5 = 30,000g, 6 = 50,000g.",
              "Bird Key (repeatable, once per day): speak to Squintrox Dryeyes in Port Jeuno (G-8) for 6 new seals. Complete 3 Protocrystal fights and return with 3 counterseals for a Bird Key. Use it (Level 40) on the red coffer in Lower Jeuno Tenshodo (J-8). Requires Tenshodo Member's Card.",
          },
          prereqs={'ASA 3: That Which Curdles Blood'},
          rewards={"3,000-50,000 Gil", "Bird Key (via repeatable bonus step)"} },
        { num='5', name='Enemy of the Empire (I)',
          steps={
              "Talk to Andrause at (I-8) in Norg. He tells you 3 specific monsters to photograph in Sea Serpent Grotto. He will sell you a Soultrapper and 12 Blank Soul Plates for 800 gil (can buy 12 more per day after JP midnight).",
              "Equip Soultrapper in Ranged slot and Blank Soul Plates in Ammo slot. Use the Soultrapper on each target mob. Cannot use while Sneak or Invisible is active. May fail -- try again.",
              "All 3 monsters must be from Sea Serpent Grotto only. You may need a Beastcoin to access the right area: Silver = Sea Bonze/Grotto Pugil area, Mythril = Bog/Marsh/Swamp Sahagin area, Gold = Coastal/Delta/Lagoon/Shore Sahagin area. Unity Warp 125 puts you past the Gold Beastcoin door.",
              "Trade the 3 Soul Plates to Andrause one at a time to receive Key Item: Black Book.",
              "Click the Outcropping at (F-10) in Gustav Tunnel for a cutscene. Click it again to immediately start Mission 6 and fight 3 Tenshodo agents.",
          },
          notes={
              "The Black Book is consumed when the Mission 6 fight begins -- if you lose, return to Andrause with 3 more Soul Plates for another book.",
              "Delta Sahagin can sometimes be pulled to the open area at (J-12)/(K-12 Map 1) using magic from the ledge behind the Ornamental Door.",
          },
          prereqs={'ASA 4: Sugar-coated Directive'},
          rewards={"Key Item: Black Book"} },
        { num='6', name='Enemy of the Empire (II)',
          steps={
              "Go to the Outcropping at (F-10) in Gustav Tunnel for a cutscene. Interact again to start the BCNM -- consumes your Black Book. No Trusts. Buffs are kept (Phalanx negates all damage except Bompupu's nukes).",
              "3 agents (Renfred, Bompupu, Gorattz) start untargetable, cast Utsusemi: Ni, then spawn 4 clones each. Kill clones until the real agents join the fight. Real agents have higher HP and keep casting Utsusemi. Killing an agent despawns their clones after a few seconds.",
              "Defeat all 3 agents. Receive Cactuar Key. Interact with the Outcropping again for the final cutscene.",
          },
          notes={
              "Windower users: the last cutscene may freeze -- the mission still completes. Log out and back in to continue. Replay the cutscene at the Goblin Footprint at (K-6/7) by trading it any item or Gil (returned to you).",
              "Routes to Gustav Tunnel (F-10): Unity Warp 128 from Cape Teriggan. Or Survival Guide to Gustav Tunnel (K-7) -- you will be on the opposite end of the tunnel.",
              "Cactuar Key repeat (once per day, Level 50): re-obtain a Black Book from Andrause in Norg (3 more Soul Plates), or buy Black Book from Squintrox Dryeyes for 500g + 5 Beastmen's Seals after all ASA missions complete. Use Cactuar Key on the red coffer in Lower Jeuno Tenshodo (J-8).",
          },
          prereqs={'ASA 5: Enemy of the Empire (I)'},
          rewards={"Cactuar Key"} },
        { num='7', name='Sugar-coated Subterfuge',
          steps={
              "Talk to Aldo at (J-8) inside Tenshodo Headquarters in Lower Jeuno for a cutscene.",
          },
          prereqs={'ASA 6: Enemy of the Empire (II)'},
          rewards={'None'} },
        { num='8', name='Shantotto in Chains',
          steps={
              "Click the Ensorcelled Door at (B-10) SW corner of Ro'Maeve. No cutscene -- you are told about a hexagonal depression. This flags the mission.",
              "Collect 6 Luminous Fragment Key Items from NMs. High drop rate but not guaranteed. NMs despawn 5 min after being engaged and respawn 2 min after despawn or death. Party/alliance members all receive the KI if it drops.",
              "RO'MAEVE NMs: Blue Fragment -- Lode Golem (E-9/10), takes only Blizzard/Water/Stone magic or COR Quick Draw. Purple Fragment -- Fired Urn (K-9/10), takes only slashing damage. Yellow Fragment -- Steely Weapon (G-10/11), takes only ranged weapon damage (NIN Daken does NOT count).",
              "SANCTUARY OF ZI'TAH NMs (17:00-7:00 Vana'diel time only): Green Fragment -- Holey Horror (H-8), takes only piercing damage (ranged does NOT count, NIN Daken DOES count). Red Fragment -- Skeleton Scuffler (F-8), takes only blunt damage (Quick Draw works but severely reduced). Beige Fragment -- Blest Bones (F-7), takes only Thunder/Fire/Wind magic or Quick Draw.",
              "Return to the Ensorcelled Door at (B-10) in Ro'Maeve with all 6 fragments for a cutscene.",
          },
          notes={
              "Windower users: the last cutscene may freeze -- mission still completes. Log out and back in to continue.",
              "Sanctuary of Zi'Tah NMs only appear between 17:00-7:00 Vana'diel time. Plan accordingly.",
          },
          prereqs={'ASA 7: Sugar-coated Subterfuge'},
          rewards={'None'} },
        { num='9', name='Fountain of Trouble',
          steps={
              "Collect at least 1 Elemental Sap Crystal from glowing ??? spots in Toraimarai Canal. At level 99+: fastest is to warp to Toraimarai Canal HP#1, grab the Dark Sap Crystal near the HP at (F-8) Map 1, then backtrack to Full Moon Fountain.",
              "Once you have at least 1 sap crystal, check the Moon Spiral in Full Moon Fountain for a cutscene to complete the mission.",
          },
          notes={
              "All 8 sap crystals weaken the corresponding Fomor avatar's Astral Flow in Mission 10 -- collect all 8 if attempting the next fight below level 99.",
              "Sap locations -- Map 1: Dark (F-8), Earth (J-8 or H-7), Water (H-7 or J-9), Fire (J-9), Lightning (H-7). Map 2: Fire (F-10 or J-8), Ice (I-8 or H-7), Light (G-8), Lightning (G-10/11), Wind (H-9 or J-9).",
          },
          prereqs={'ASA 8: Shantotto in Chains'},
          rewards={'None'} },
        { num='10', name='Battaru Royale',
          steps={
              "Click the Moon Spiral again (while possessing at least 1 elemental sap KI from Mission 9) for the option to enter the Battaru Royale BCNM.",
              "Fight 8 Tarutaru Fomors, one per element (Boulders/Earth, Torrents/Water, Gusts/Wind, Flames/Fire, Glaciers/Ice, Sparks/Lightning, Lights/Light, Shadows/Dark). Each casts spells of its element and uses standard Fomor TP abilities. At ~50% HP each summons its corresponding avatar which uses Astral Flow before despawning.",
              "Defeat all 8 Fomors to win. Receive Chocobo Key.",
          },
          notes={
              "Sap crystals from Mission 9 weaken each Fomor's avatar Astral Flow -- collect all 8 if fighting below level 99.",
              "Chocobo Key: use on red coffer in Lower Jeuno Tenshodo (J-8).",
          },
          prereqs={'ASA 9: Fountain of Trouble'},
          rewards={"Chocobo Key"} },
        { num='11', name='Romancing the Clone',
          steps={
              "Talk to Aldo at (J-8) in Tenshodo Headquarters in Lower Jeuno for a cutscene.",
          },
          prereqs={'ASA 10: Battaru Royale'},
          rewards={'None'} },
        { num='12', name='Sisters in Arms',
          steps={
              "Collect at least 1 Tablet of Hexes Key Item from glowing ??? spots in Temple of Uggalepih or Den of Rancor. At level 99+: fastest is warp to Den of Rancor HP#1, exit south via the switch, grab Tablet of Hexes: Blight at (H-9) Map 2, warp back to Den of Rancor HP#1, continue to the Sacrificial Chamber.",
              "Check the Mahogany Door in the Sacrificial Chamber for a cutscene. Check it again to begin Mission 13's BCNM.",
          },
          notes={
              "Tablets each grant a specific buff in the next fight -- collect all 16 if attempting Mission 13 below level 99.",
              "Temple of Uggalepih tablets: Malice (F-10 Map 1), Deceit (F-8 Map 1), Envy (F-8 Map 2), Greed (G-10 Map 2), Pride (J-11 Map 2), Bale (I-8 Map 2).",
              "Den of Rancor tablets: Regret (E-5), Strife (H-6), Dolor (J-9), Agony (E-10), Rancor (F-11), Rage (K-11), Despair (J-13) -- all Map 1. Penury (F-9 Map 3). Death (L-13 Map 2). Blight (H-9 Map 2).",
          },
          prereqs={'ASA 11: Romancing the Clone'},
          rewards={'None'} },
        { num='13', name='Project: Shantottofication',
          steps={
              "Click the Mahogany Door in the Sacrificial Chamber again to enter the BCNM. Trusts allowed. Tablet KIs are consumed on entry and grant buffs. Soloable at 119 without tablets.",
              "Fight D. Shantotto + Shantotto. D. Shantotto: high-level magic + Scythe WSs including Salvation Scythe (AoE damage + Poison + Paralysis). Shantotto: high-level magic + Staff WSs including Divine Malison (AoE damage + Stun + Slow + Silence + Plague).",
              "At 50% HP either one enters rage mode -- calls the other over to skillchain on the current target. Cannot be separated. The raged Shantotto cannot be killed (stays at 1% HP) until rage ends.",
          },
          notes={
              "Full tablet set bonuses: +150 to all elemental resistances, +150 to all stats, 3x HP/MP, and a special Reraise with no Weakness penalty.",
              "If you wipe after rage mode triggers: rage will NOT repeat on re-entry to the same battlefield instance.",
              "Tonberry Key: use on red coffer in Lower Jeuno Tenshodo (J-8).",
          },
          prereqs={'ASA 12: Sisters in Arms'},
          rewards={"Tonberry Key"} },
        { num='14', name='An Uneasy Peace',
          steps={
              "Zone into Windurst Walls from Windurst Woods or Windurst Waters for a cutscene and Behemoth Key. Must use the zone line -- entering via Mog House or HP Warp will NOT trigger the cutscene.",
          },
          notes={
              "Use the Behemoth Key on the red coffer in Lower Jeuno Tenshodo to choose your final reward.",
          },
          prereqs={'ASA 13: Project: Shantottofication'},
          rewards={"Behemoth Key"} },
        { num='15', name='A Shantotto Ascension (Fin)',
          steps={
              "Redeem the Behemoth Key at the Tenshodo in Lower Jeuno for your reward.",
          },
          notes={
              "To change your reward: discard the item. To re-enter the BCNM: get 1 Tablet of Hexes (fastest: Den of Rancor HP#1 > exit south via switch > Blight tablet at H-9 > warp back > Sacrificial Chamber). Or buy all hex tablets from Squintrox Dryeyes in Port Jeuno for 2,000g + 20 Beastmen's Seals after all ASA missions complete.",
              "Must use your previous Tonberry Key (Shantotto) at the red chest in Tenshodo before re-entering -- you cannot enter the BCNM while holding one.",
              "Completing ASA unlocks the ability to purchase Atma of Ambition.",
          },
          prereqs={'ASA 14: An Uneasy Peace'},
          rewards={"Choice: Blitzer Poleyn / Desultor Tassets / Tatsumaki Sitagoromo", "Ability to purchase Atma of Ambition"} },
    },
}
