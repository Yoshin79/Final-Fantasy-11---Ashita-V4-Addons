-- Rise of the Zilart Missions (ZM1-ZM20)
-- Source: https://www.bg-wiki.com/ffxi/Category:Zilart_Missions

return {
    id    = 'zilart',
    label = 'Rise of the Zilart',
    entry = "Complete any nation's 5-2 Shadow Lord mission. Rise of the Zilart expansion required.",
    missions = {

        { num='ZM1', name='The New Frontier',
          steps={
              "Obtain Rank 6 in your home nation (required to progress Zilart missions).",
              "Travel to Norg and zone in -- a cutscene triggers automatically.",
              "If you previously postponed the cutscene, use Tales' Beginning near HP#1 in Norg to resume.",
          },
          notes={
              "Travel to Norg: use Kazham Airship Pass from Port Jeuno to Kazham, then travel via Sea Serpent Grotto. Or if on RoV 1-5+, Pacomart and Tonasav can transport you directly.",
              "Additional travel: Adoulin Waypoints (Norg or Kazham warp rune), or Unity Warp -- Sea Serpent Grotto (CL 125) is closest.",
              "You MUST be minimum Rank 6 in your home nation to continue past this point.",
          },
          prereqs={"Any nation 5-2 Shadow Lord mission complete", "Rank 6 required"},
          rewards={"Key Item: Map of Norg (if not already owned)"} },

        { num='ZM2', name="Welcome t'Norg",
          steps={
              "Head to (L-8) in Norg and enter the Oaken Door for a cutscene with Gilgamesh.",
          },
          notes={
              "If you see a cutscene with Iroha instead, re-enter the Oaken Door after that cutscene plays to get the correct ZM2 cutscene.",
          },
          prereqs={"ZM1: The New Frontier"},
          rewards={"None"} },

        { num='ZM3', name="Kazham's Chieftainess",
          steps={
              "Travel to Kazham and speak to Jakoh Wahcondalo at (J-9) -- receive Key Item: Sacrificial Chamber Key.",
          },
          notes={
              "Elshimo Low > Kazham > Home Point #1 puts you right next to Jakoh Wahcondalo's house.",
          },
          prereqs={"ZM2: Welcome t'Norg"},
          rewards={"Key Item: Sacrificial Chamber Key"} },

        { num='ZM4', name='The Temple of Uggalepih',
          steps={
              "Goal: reach the Sacrificial Chamber BCNM in the Den of Rancor.",
              "FASTEST: Use Den of Rancor HP#1 warp directly, then zone into the Sacrificial Chamber and examine the door.",
              "SECOND: Unity Warp (Level 128) to Den of Rancor -- you still need an Unlit Lantern unless someone with the HP opens the Rancor door for you.",
              "FULL METHOD: Obtain Key Item: Paintbrush of Souls (see ZM4 Mini-Quest on bg-wiki) and an Unlit Lantern (dropped by Tonberry Jinxers in Yhoator Jungle, Maledictors/Pursuers in Temple of Uggalepih, or Imprecators in Den of Rancor).",
              "Temple route: enter from Yhoator Jungle (J-11/12), exit northwest at (F-5), re-enter at (H-11), kill Temple Guardian at (I-10) if up, go to (I-7). Stand at the empty frame with the Paintbrush, check it, wait 30 seconds without moving or using commands, check again. Door opens into Den of Rancor.",
              "Den of Rancor: use Sneak and Invisible throughout. At (E-5) Map 1, drop Invisible and trade Unlit Lantern to Altar of Rancor for Rancor Flame. Drop down hole at (F-7) NE corner to Map 2. Navigate to (E-5). Light all 4 lanterns outside the Sacrificial Chamber gate.",
              "Grab the Den of Rancor Home Point, then zone into the Sacrificial Chamber and examine the door to enter the BCNM.",
              "BCNM: fight 3 Tonberry NMs -- Grav'iton (THF), Molyb'iton (BLM), Tungs'iton (SMN). Kill order: THF first, then BLM, then SMN. Buff inside -- all buffs wear on entry.",
              "After winning receive Key Item: Dark Fragment and a cutscene.",
          },
          notes={
              "Kill Grav'iton (THF) FIRST -- cannot be slept and uses Everyone's Rancor (10x Everyone's Grudge damage). Silence and Sleep the other two.",
              "Molyb'iton uses Manafont. Tungs'iton uses Astral Flow -- defeat quickly. Ensure full HP before engaging it.",
              "High Rancor is very dangerous here -- lower it via quest Everyone's Grudge in Norg before proceeding.",
              "4 Unlit Lanterns ideal for lighting all 4 lanterns simultaneously, but can be done solo by going back and forth from the Altar.",
              "The Paintbrush check requires 30 seconds of no movement or commands -- if interrupted you must start over.",
          },
          prereqs={"ZM3: Kazham's Chieftainess", "Key Item: Sacrificial Chamber Key"},
          rewards={"Key Item: Dark Fragment", "Title: Bearer of the Wisewoman's Hope"} },

        { num='ZM5', name='Headstone Pilgrimage',
          steps={
              "Collect all 8 Elemental Fragments. Dark Fragment already obtained from ZM4. Collect the remaining 7 from Cermet Headstones across Vana'diel.",
              "EARTH FRAGMENT (no fight): Western Altepa Desert -- enter Quicksand Caves at (J-9) Map 3, fall down sandpit at (K-6), follow path back out. Or Unity Warp (Lv125) W.Altepa -- turn into crevasse, follow path, headstone at (H-8)/(H-9).",
              "WATER FRAGMENT (no fight): La Theine Plateau -- enter Ordelle's Caves at (F-7) Map 2, navigate back out to La Theine. Cermet Headstone at end of valley at (G-11). Geomagnetic Fount for La Theine lets out near this headstone.",
              "ICE FRAGMENT (no fight): Fei'Yin -- Cloister of Frost in the basement, headstone in back of room. Fei'Yin HP#2 is right outside the Cloister.",
              "FIRE FRAGMENT (fight): Ifrit's Cauldron from Yhoator Jungle (G-6). Navigate Map 4>7>5>2>7>8, exit to Yuhtunga Jungle at (C-7). Headstone at (L-6)/(L-7) near tunnel under waterfall at (K-7) -- spawns Opo-opo NMs Carthi and Tipha. Defeat both (immune to sleep, aggro through Sneak). Check headstone again.",
              "LIGHTNING FRAGMENT (fight): Behemoth's Dominion (G-9). Unity Warp Lv135 fastest. Headstone spawns Legendary Weapon (BLM/RDM) and Ancient Weapon (WAR). Defeat both, check headstone again.",
              "WIND FRAGMENT (fight): Cape Teriggan -- HP or Unity Warp (Lv128). Hidden tunnel at (F-7), go north to another at (G-5), follow to headstone at (H-5). Spawns Shadow NM Axesarion the Wanderer. Defeat and check headstone again.",
              "LIGHT FRAGMENT (fight): The Sanctuary of Zi'Tah -- (J-9) SE corner, hug left wall to NE corner of (I-7). Headstone spawns Doomed NM Doomed Pilgrims. Defeat and check headstone again.",
              "Upon collecting all 8 you receive 'You now have all 8 fragments of light!' and the mission completes.",
          },
          notes={
              "Always confirm you received the Key Item message -- 'You need to move closer' can look similar at a glance.",
              "Fire Fragment: bring 3 Ice Clusters to clear flame spouts (otherwise wait up to 7 Earth minutes each). Bring Silent Oils and Prism Powders. Beware Ash Dragon near Yuhtunga exit (True Sound at night).",
              "Lightning Fragment: Legendary Weapon is aspirable; Ancient Weapon is not. Both susceptible to Bind/Gravity but not Sleep or Silence.",
              "Fire Fragment bonus: trade a Garnet to the headstone after getting the fragment for an Opo-opo Necklace.",
              "Wind Fragment bonus: trade a Rain Lily to the headstone after getting the fragment for a Flagellant's Rope.",
              "Light Fragment bonus: return to this headstone after ZM7 for a Bat Earring.",
          },
          prereqs={"ZM4: The Temple of Uggalepih"},
          rewards={"Key Items: Earth/Fire/Ice/Lightning/Water/Wind/Light/Dark Fragments", "Title: Bearer of the Eight Prayers"} },

        { num='ZM6', name='Through the Quicksand Caves',
          steps={
              "SHORTCUT: If you have Quicksand Caves HP#1 or the Proto-Waypoint, use it -- drop down and follow the path west to the Chamber of Oracles.",
              "FULL ROUTE: Western Altepa Desert tunnel at (C/D-11) south side, follow to unmarked area. Head down ramp to (D-12) and enter Quicksand Caves.",
              "Inside: step on weight pad at (I-9) to pass door. Go west to (H-7) for another weight pad. In next room drop down the hole. Head to (D-4) to zone into Chamber of Oracles.",
              "BCNM: fight Centurio V-III (PLD), Triarius V-VIII (BLM), Princeps V-XI (RNG). Open with Sleepga, Silence PLD and BLM. Kill PLD first (uses Invincible, can rebuff), then BLM (keep Silenced to neutralize Manafont), then RNG last (beware Eagle Eye Shot).",
              "After clearing the BCNM you zone into another area of the Chamber of Oracles -- ZM7 starts.",
          },
          notes={
              "Weight pads require: 1 Galka, OR 2 Hume/Elvaan/Mithra, OR 3 Tarutaru. Complete quest Open Sesame for Key Item: Loadstone to pass doors solo.",
              "All mobs aggro Sound -- keep Sneak up. Antica TP attack Jamming Wave causes Silence -- mages bring Echo Drops.",
              "Unity Warp (Lv125) places you at W.Altepa Desert (I-7) near the entrance tunnel.",
          },
          prereqs={"ZM5: Headstone Pilgrimage"},
          rewards={"None -- completing the BCNM starts ZM7 automatically"} },

        { num='ZM7', name='The Chamber of Oracles',
          steps={
              "You will be in a room with a large device. Check each of the 8 parts of the device to insert the 8 fragments obtained in ZM5.",
              "After all fragments are inserted a cutscene plays -- receive Key Item: Prismatic Fragment. ZM8 starts automatically.",
          },
          notes={
              "This mission begins automatically after clearing the ZM6 BCNM.",
              "Return to the Light Fragment headstone in The Sanctuary of Zi'Tah after this mission to receive a Bat Earring.",
          },
          prereqs={"ZM6: Through the Quicksand Caves"},
          rewards={"Key Item: Prismatic Fragment", "Title: Lightweaver"} },

        { num='ZM8', name="Return to Delkfutt's Tower",
          steps={
              "Zone into Lower Delkfutt's Tower from Qufim Island or via Survival Guide for a cutscene.",
              "Make your way to the Stellar Fulcrum. Upper Delkfutt's Tower HP#1 puts you right at the zone.",
              "WITH KEY: Go to basement via Cermet Door at (E-8) floor 1, through door at (J-8), click ??? at (H-8) on the spiral staircase to teleport to the 10th floor.",
              "WITHOUT KEY: Climb the tower manually to Upper Delkfutt's Tower.",
              "In Upper Delkfutt: head to (F-8) and through the door (not on map). Climb to 11th floor using Sneak and Invisible (Bats/Giants aggro, Dolls/Pots aggro magic). To (J-6) for 12th floor. Take teleporter at (F-10) into Stellar Fulcrum.",
              "Click the Qe'lov Gate to enter the BCNM. Buff inside -- all buffs wear on entry. Trusts allowed.",
              "BCNM: fight Kam'lanaut (~10,000 HP). Immune to Sleep and Silence. After winning the mission completes.",
          },
          notes={
              "Kam'lanaut uses Great Wheel (AoE ~200 dmg + hate reset) and Light Blade (single target ~700-1200, charge time, can Stun, blink with Utsusemi).",
              "Casts Silencega, Dispelga, Slowga. Elemental Blade gives en-spell -- magic of that element heals him. Dispel immediately.",
              "Optional: speak to Aldo at Tenshodo HQ in Lower Jeuno first for a cutscene.",
          },
          prereqs={"ZM7: The Chamber of Oracles"},
          rewards={"None", "Title: Destroyer of Antiquity"} },

        { num='ZM9', name="Ro'Maeve",
          steps={
              "Go to Norg and click the Oaken Door at (K-8). Select 'Open the door' to start the cutscene with Lion and Gilgamesh.",
              "After the cutscene you will be standing outside the Oaken Door again -- ZM10 starts automatically.",
          },
          notes={
              "Make sure to select 'Open the door' option specifically -- if you are on other missions (CoP or RoV) a different cutscene may play instead.",
              "Optional: speak to Aldo at Tenshodo HQ first for additional dialogue.",
          },
          prereqs={"ZM8: Return to Delkfutt's Tower"},
          rewards={"None"} },

        { num='ZM10', name='The Temple of Desolation',
          steps={
              "Travel to Ro'Maeve. Head to (H-5) and zone into the Hall of the Gods.",
              "Run through the hallway and check the Cermet Grate twice -- ZM11 starts automatically.",
          },
          notes={
              "Everything in Ro'Maeve detects magic -- use Silent Oils and Prism Powders (or cast Sneak/Invisible at the zone line before entering).",
              "Ro'Maeve Survival Guide puts you right at the Hall of the Gods zone. Unity Warp (Lv125) puts you at the Ro'Maeve entrance.",
              "Mounts can be used in Ro'Maeve.",
          },
          prereqs={"ZM9: Ro'Maeve"},
          rewards={"None", "Title: Sealer of the Portal of the Gods"} },

        { num='ZM11', name='The Hall of the Gods',
          steps={
              "Return to Norg, open the Oaken Door at (K-8), and speak to Gilgamesh -- he speaks of a Mithra who was once trying to sell a crystal. ZM12 starts automatically.",
          },
          prereqs={"ZM10: The Temple of Desolation"},
          rewards={"None"} },

        { num='ZM12', name='The Mithra and the Crystal',
          steps={
              "Go to Rabao HP#2 and speak to Maryoh Comyujah at (G-7) in front of the windmill. Choose the TOP option 'Sounds fair' -- do not spam Enter or you will miss it.",
              "Travel to secret entrance in Western Altepa Desert (C/D-11) -- same hidden zone as ZM6. Inside on Map 5, go to (K-8) through pressure door to Map 6. On Map 6 head to (G-8) for another pressure door. Enter and fall down the hole.",
              "Near where you land find the ???. Buff up and select 'Yes' to dig -- spawns Pot NM Ancient Vessel. Move very close to the ??? if it does not spawn immediately.",
              "Defeat Ancient Vessel then check the ??? again -- receive Key Item: Scrap of Papyrus.",
              "Return to Rabao and speak to Maryoh Comyujah again -- receive Key Item: Cerulean Crystal.",
              "Head back to the Hall of the Gods, touch the sealed gate for a cutscene. Go down the hallway and examine the Shimmering Circle for the final cutscene. ZM13 starts automatically.",
          },
          notes={
              "The Quicksand Caves section is on the OPPOSITE side of the area from ZM6 -- same entrance but different path inside.",
              "Proto-Waypoint in Rabao (G-8) can get you into Quicksand Caves on the right map, but you still need to navigate to the correct hole.",
          },
          prereqs={"ZM11: The Hall of the Gods"},
          rewards={"Key Item: Cerulean Crystal"} },

        { num='ZM13', name='The Gate of the Gods',
          steps={
              "After the final ZM12 cutscene you are teleported up and granted access to Tu'Lia (Sky).",
              "Run forward and zone into Ru'Aun Gardens -- ZM14 starts automatically.",
          },
          notes={
              "Grab the Survival Guide just ahead after zoning into Ru'Aun Gardens.",
              "The Shimmering Circle downstairs can be used to return to Tu'Lia at any time.",
              "If you have the quest for Prishe's Boots +1 active, a different cutscene plays on first entry -- exit and re-enter to get the correct ZM cutscene.",
          },
          prereqs={"ZM12: The Mithra and the Crystal"},
          rewards={"Permanent access to Tu'Lia (Sky) -- Ru'Aun Gardens and beyond"} },

        { num='ZM14', name='Ark Angels',
          steps={
              "Zone into Ru'Aun Gardens for a cutscene with Zeid and Aldo.",
              "Enter The Shrine of Ru'Avitau from (H-8). Head north and examine the blank target at (G/H-11) for a cutscene. Return to Ru'Aun Gardens.",
              "Complete all 5 La'Loff Amphitheater BCNM fights. Use red portals to reach each island. After each fight use the red portal back, activate the pincerstone to unlock the blue warp to the next island. Travel counter-clockwise (West to East).",
              "HP#1 -- Ark Angel HM (WAR/NIN): Mighty Strikes + Mijin Gakure. Cross Reaver WS (cone ~500-900 + Stun). Non-elemental so Bar spells have no effect.",
              "HP#2 -- Ark Angel TT (BLM/DRK): Manafont + Blood Weapon. Amon Drive WS (AoE ~100-300, Paralysis + Petrification, absorbed by Utsusemi). Teleports around arena.",
              "HP#3 -- Ark Angel MR (THF/BST): Perfect Dodge + Charm. Havoc Spiral WS (AoE ~100-300, Sleep, absorbed by Utsusemi). Summons tiger or Mandragora pet -- sleep and ignore. Can Charm tank even with pet alive.",
              "HP#4 -- Ark Angel EV (PLD/WHM): Invincible + Benediction. Dominion Slash WS (AoE ~100-300, Silence + Dispel, absorbed by Utsusemi). Shield Strike (cone ~100 + Stun). Bring Echo Drops. Gravity/Bind kiting recommended.",
              "HP#5 -- Ark Angel GK (SAM/DRG): Call Wyvern + Meikyo Shisui (multiple times). Dragonfall WS (AoE ~100-300, Bind, absorbed by Utsusemi). NIN tank recommended.",
              "After all 5 fights receive the 5 Shard Key Items -- ZM15 begins.",
          },
          notes={
              "Shortcut: Quest Divine Might lets you fight all 5 simultaneously as an alliance BCNM. Requires an Ark Pentasphere obtained during a full moon.",
              "Ru'Aun Gardens aggro: Dolls on blue wall pads aggro magic -- stay on far side of path. Birds do NOT detect magic.",
              "Trusts ARE allowed in the individual fights.",
              "Divine Might earring choices: Suppanomimi, Bushinomimi, Abyssal Earring, Beastly Earring, or Knight's Earring.",
          },
          prereqs={"ZM13: The Gate of the Gods"},
          rewards={"Key Items: Shards of Apathy/Arrogance/Cowardice/Envy/Rage", "Title: Pentacide Perpetrator (Divine Might only)"} },

        { num='ZM15', name='The Sealed Shrine',
          steps={
              "Head to Norg and speak to Gilgamesh.",
              "Return to Ru'Aun Gardens and enter the Shrine of Ru'Avitau from any entrance for a cutscene. Teleporting to the Home Point also triggers the cutscene.",
          },
          notes={
              "Entering from (I-6) near Ru'Aun Gardens HP#1 saves time approaching ZM16.",
              "If you completed ZM14 via Divine Might and have not yet chosen your earring reward, enter the Shrine from the (H-9) entrance to force your log to update.",
          },
          prereqs={"ZM14: Ark Angels"},
          rewards={"None"} },

        { num='ZM16', name='The Celestial Nexus',
          steps={
              "Enter the Shrine of Ru'Avitau from (I-6) in Ru'Aun Gardens -- Map 1. Use Sneak and head south. Go past (J-7) through the first yellow door. Head west to the room with 2 Monoliths at (H-7) -- use Invisible and go south around the square hallway (Aura Statues) to the room with 2 Dark Elementals at (H-10). Go north down a flight of stairs to the Celestial Nexus at (H-9).",
              "Gather and prepare -- then enter the BCNM. Buffs wear on entry.",
              "FORM 1: 2 Exoplates (~10,000 HP each) surround Eald'narche plus 2 Orbitals (low HP, resummoned if killed, sleep reliable). Defeat Exoplates fast. Phase Shift at ~66%, ~33%, and ~1% HP -- AoE physical damage (~600-1300) with Stun/Bind. Heal to full and get shadows up before it fires.",
              "Eald'narche (Form 1) has ~2,000 HP and casts Sleepga II -- defeat him quickly after Exoplates are down.",
              "FORM 2: Eald'narche alone (~2,500 HP). Teleports around the arena. Casts Black Magic including Bindga. Uses Vortex (AoE Terror + Bind), Stellar Burst (AoE Silence), Omega Javelin (Petrification). All absorbed by Utsusemi. You have 1 minute before he aggros regardless of range.",
              "After clearing receive a cutscene and are returned to the Hall of the Gods. ZM17 begins.",
          },
          notes={
              "Shrine of Ru'Avitau is full magic aggro -- mages must use Silent Oils and Prism Powders. Ninjutsu and Spectral Jig are alternatives.",
              "Yellow doors require someone to operate the Monolith nearby -- closest is around (I/J-9/10).",
              "Form 2 may have high magic defense. Poison Potions and Stun make Form 2 significantly easier.",
              "If you wipe, wait until ejected before moving -- you will aggro anywhere on the battlefield.",
          },
          prereqs={"ZM15: The Sealed Shrine"},
          rewards={"None", "Title: Burier of the Illusion"} },

        { num='ZM17', name='Awakening',
          steps={
              "Enter Norg for a cutscene with Gilgamesh. If no cutscene triggers, go to the Captain's Chamber and speak to Gilgamesh there.",
              "Click on the Neptune's Spire Inn door in Lower Jeuno for a cutscene with Aldo.",
              "Both cutscenes must be completed (in any order) before zoning to Ru'Lude Gardens to trigger ZM18.",
          },
          notes={
              "Shadows of the Departed will not trigger unless CoP Epilogue 1: Storms of Fate is completed before zoning to Ru'Lude Gardens to trigger ZM18.",
          },
          prereqs={"ZM16: The Celestial Nexus"},
          rewards={"Rise of the Zilart complete", "Enables Chains of Promathia epilogue quests"} },

        { num='ZM18', name='Shadows of the Departed',
          steps={
              "Walk into the palace in Ru'Lude Gardens for a cutscene and Key Item: Note written by Esha'ntarl.",
              "Visit all 3 Promyvions and collect a Sliver from the Memory Flux on the 4th floor of each:",
              "Promyvion - Holla: enter from La Theine Plateau, Memory Flux at (J-10).",
              "Promyvion - Dem: enter from Konschtat Highlands, Memory Flux at (K-4).",
              "Promyvion - Mea: enter from Tahrongi Canyon, Memory Flux at (K-6).",
              "Return to the palace in Ru'Lude Gardens for a final cutscene with Esha'ntarl.",
          },
          notes={
              "Must complete Storms of Fate before this quest triggers.",
              "Wait until the next in-game day after Storms of Fate before talking to Esha'ntarl -- there is a cutscene with her that does NOT provide the key item. The wait does not apply if you reset your memories.",
              "Enter Promyvions through the Shattered Telepoints and the middle Cermet Gate.",
          },
          prereqs={"ZM17: Awakening", "Quest: Storms of Fate completed"},
          rewards={"Key Items: Promyvion - Holla/Dem/Mea Slivers"} },

        { num='ZM19', name='Apocalypse Nigh',
          steps={
              "Zone and wait until the next in-game day after completing Shadows of the Departed.",
              "Enter the palace in Ru'Lude Gardens.",
              "Zone into Sealion's Den for a cutscene, then speak with Sueleen to head to Al'Taieu. If you get a Sueleen cutscene instead of Prishe, zone back to Tavnazian Safehold and re-enter.",
              "Zone into the Grand Palace of Hu'Xzoi and click the entrance to The Garden of Ru'Hmet (Gate of the Gods) for a cutscene.",
              "Go to the Empyreal Paradox and check the Transcendental Radiance for a cutscene, then check it again to enter the BCNM.",
              "BCNM: fight Kam'lanaut and Eald'narche simultaneously. Kite Kam'lanaut while everyone focuses on Eald'narche first (~5,000 HP). Stun Eald'narche's nukes. Once Eald'narche is down, focus on Kam'lanaut.",
              "After winning speak to Aldo in Lower Jeuno (J-8) for a cutscene. Must be Rank 5+ in your nation.",
              "Zone and wait until the next Vana'diel day, then speak to Gilgamesh in Norg to complete the quest and receive your earring.",
          },
          notes={
              "Kam'lanaut: Light Blade (high dmg, reduced by kiting), Great Wheel (AoE + hate reset), En-spells (nukes of matching element HEAL him -- Dispel immediately). Casts Silencega, Slowga, Graviga, Dispelga.",
              "Eald'narche: ~5,000 HP, teleports, resists magic. Vortex (AoE Terror), Stellar Burst (AoE Silence), Omega Javelin (Petrification). Casts all -ga III nukes including Bindga and Sleepga II. Stun his nukes.",
              "Gravity is hard to land on Kam'lanaut without Elemental Seal.",
              "Fastest route to Empyreal Paradox: Home Point Lumoria > Garden of Ru'Hmet > #1, then descend.",
              "To reacquire a different earring: drop your earring BEFORE zoning into Empyreal Paradox, select ??? near the entrance and erase memories, then redo Shadows of the Departed and Apocalypse Nigh.",
          },
          prereqs={"ZM18: Shadows of the Departed", "CoP Mission 8-4 completed"},
          rewards={"Choice of: Ethereal Earring, Hollow Earring, Magnetic Earring, or Static Earring", "Title: Breaker of the Chains"} },

        { num='ZM20', name='The Last Verse',
          steps={
              "No walkthrough required. This mission appears automatically in your log upon completion of Apocalypse Nigh.",
          },
          notes={
              "This is the final mission of both Rise of the Zilart and Chains of Promathia. It simply signifies both storylines are complete. Also appears as Promathia Mission 8-5 in the CoP log.",
          },
          prereqs={"ZM19: Apocalypse Nigh"},
          rewards={"Rise of the Zilart and Chains of Promathia fully complete"} },

    },
}
