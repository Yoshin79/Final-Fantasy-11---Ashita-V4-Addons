return {
    ["show_display"] = true,
    ["colors"] =     {
        ["geo_high"] = 4278255360,
        ["indi"] = 4289388031,
        ["geo_low"] = 4294901760,
        ["background"] = -16777114,
        ["geo_mid"] = 4294967040,
    },
    ["positions"] =     {
        ["geo"] =         {
            ["y"] = 794,
            ["x"] = 781,
        },
        ["indi"] =         {
            ["y"] = 825,
            ["x"] = 781,
        },
        ["entrust"] =         {
            ["y"] = 763,
            ["x"] = 764,
        },
    },
    ["font"] =     {
        ["family"] = "Arial",
        ["size"] = 14,
    },
}