--[[
* Looty - Inventory Module
* Reads main inventory (container 0) from Ashita memory.
* Tags items as keep/drop/store based on active profile lists.
]]--

require('common');

local M = {};

-- ============================================
-- State
-- ============================================

M.items = {};   -- array of item data tables

-- ============================================
-- Item data structure
-- ============================================
--[[
  {
    slotIndex : inventory slot (1-based)
    id        : item id
    name      : item name string
    count     : stack count
    tag       : 'keep' | 'drop' | 'store'
  }
]]--

-- ============================================
-- Helpers
-- ============================================

local function getItemName(id)
    if not id or id == 0 or id == 65535 then return nil; end
    local res = AshitaCore:GetResourceManager():GetItemById(id);
    if not res or not res.Name then return string.format('Item#%d', id); end

    local n1 = res.Name[1];
    if not n1 or n1 == '' then return string.format('Item#%d', id); end

    -- Name[2] sometimes has the full unabbreviated name.
    -- Only use it if it's longer AND consists entirely of printable ASCII (no garbage bytes).
    local n2 = res.Name[2];
    if n2 and #n2 > #n1 then
        if n2:match('^[%a%d%s%.%-%\'%+%%%(%)%[%]]+$') then
            return n2;
        end
    end

    return n1;
end

local function icontains(tbl, val)
    if not val then return false; end
    val = val:lower();
    for _, v in ipairs(tbl) do
        if v:lower() == val then return true; end
    end
    return false;
end

-- ============================================
-- Memory read
-- ============================================

function M.ReadFromMemory(profile)
    local memMgr = AshitaCore:GetMemoryManager();
    if not memMgr then return; end
    local inv = memMgr:GetInventory();
    if not inv then return; end

    M.items = {};
    local maxSlots = inv:GetContainerCountMax(0) or 80;

    local dropList  = (profile and profile.dropList)  or {};
    local storeList = (profile and profile.storeList) or {};

    for i = 1, maxSlots do
        local item = inv:GetContainerItem(0, i);
        if item and item.Id and item.Id > 0 and item.Id ~= 65535 then
            local name = getItemName(item.Id);
            if name then
                local tag = 'keep';
                if icontains(dropList, name)  then tag = 'drop';
                elseif icontains(storeList, name) then tag = 'store'; end

                M.items[#M.items+1] = {
                    slotIndex = i,           -- loop index (1-80)
                    itemIndex = item.Index,  -- item's own memory Index field
                    id        = item.Id,
                    name      = name,
                    count     = item.Count or 1,
                    tag       = tag,
                };
            end
        end
    end
end

-- ============================================
-- Tag refresh (call after profile change)
-- ============================================

function M.RefreshTags(profile)
    if not profile then return; end
    local dropList  = profile.dropList  or {};
    local storeList = profile.storeList or {};

    for _, item in ipairs(M.items) do
        if icontains(dropList, item.name)  then
            item.tag = 'drop';
        elseif icontains(storeList, item.name) then
            item.tag = 'store';
        else
            item.tag = 'keep';
        end
    end
end

-- ============================================
-- Drop item via packet 0x28 (Lootwhore format)
-- pk_DropItem layout (12 bytes):
--   [0x00] uint32 Header   = 0
--   [0x04] uint32 Quantity = item count
--   [0x08] uint8  Location = 0 (inventory)
--   [0x09] uint8  Index    = item memory index
--   [0x0A] uint16 Unknown  = 0
-- ============================================

function M.DropItem(item)
    if not item or not item.itemIndex or not item.count then return false; end

    -- Build 12-byte drop packet matching Lootwhore's pk_DropItem exactly:
    --   [0x00] uint32 Header   = 0
    --   [0x04] uint32 Quantity = item.count
    --   [0x08] uint8  Location = 0 (main inventory)
    --   [0x09] uint8  Index    = item.itemIndex
    --   [0x0A] uint16 Unknown  = 0
    -- Ashita uses Lua 5.1 so bitwise ops must use the bit library, not & / >>
    local qty = item.count;
    local buf = {
        0x00, 0x00, 0x00, 0x00,          -- Header (uint32 = 0)
        bit.band(qty, 0xFF),             -- Quantity byte 0
        bit.band(bit.rshift(qty, 8),  0xFF), -- Quantity byte 1
        bit.band(bit.rshift(qty, 16), 0xFF), -- Quantity byte 2
        bit.band(bit.rshift(qty, 24), 0xFF), -- Quantity byte 3
        0x00,                            -- Location = 0 (inventory)
        item.itemIndex,                  -- Index
        0x00, 0x00,                      -- Unknown (uint16 = 0)
    };
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x28, buf);
    return true;
end

function M.GetItems()
    return M.items;
end

function M.GetCount()
    return #M.items;
end

-- ============================================
-- Lifecycle
-- ============================================

function M.Initialize()
    M.items = {};
end

function M.Clear()
    M.items = {};
end

function M.Cleanup()
    M.items = {};
end

return M;
