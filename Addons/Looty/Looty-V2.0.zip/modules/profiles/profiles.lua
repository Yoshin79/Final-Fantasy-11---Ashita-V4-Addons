--[[
* Looty - Profile Module
* Saves/loads named profiles as Lua files.
* Profile path: <AshitaInstall>/config/looty/<name>.lua
*
* Profile structure:
*   lotList      : array of item names to auto-lot
*   passList     : array of item names to auto-pass
*   dropList     : array of item names to auto-drop
*   storeList    : array of item names to auto-store
*   defaultAction: 'lot' | 'pass' | 'ignore'
*   rarePass     : bool
*   smartPass    : bool
]]--

require('common');
local chat = require('chat');

local M = {};

-- ============================================
-- State
-- ============================================

M.profile = {
    lotList       = {},
    passList      = {},
    dropList      = {},
    storeList     = {},
    defaultAction = 'ignore',
    rarePass      = false,
    smartPass     = false,
};

-- ============================================
-- Path helpers
-- ============================================

local function profileDir()
    return string.format('%sconfig\\looty\\', AshitaCore:GetInstallPath());
end

local function profilePath(name)
    return profileDir() .. name .. '.lua';
end

local function ensureDir()
    os.execute('mkdir "' .. profileDir() .. '" 2>nul');
end

-- ============================================
-- List helpers
-- ============================================

local function icontains(tbl, val)
    val = val:lower();
    for _, v in ipairs(tbl) do
        if v:lower() == val then return true; end
    end
    return false;
end

local function iremove(tbl, val)
    val = val:lower();
    for i, v in ipairs(tbl) do
        if v:lower() == val then
            table.remove(tbl, i);
            return true;
        end
    end
    return false;
end

-- ============================================
-- Save
-- ============================================

function M.SaveProfile(name)
    if not name or name == '' then
        print(chat.header('Looty') .. chat.error('Profile name cannot be empty.'));
        return false;
    end
    ensureDir();

    local lines = {
        '-- Looty profile: ' .. name,
        'local p = {}',
        string.format('p.defaultAction = %q', M.profile.defaultAction),
        string.format('p.rarePass  = %s', tostring(M.profile.rarePass)),
        string.format('p.smartPass = %s', tostring(M.profile.smartPass)),
    };

    local function writeList(field, tbl)
        lines[#lines+1] = 'p.' .. field .. ' = {';
        for _, v in ipairs(tbl) do
            lines[#lines+1] = string.format('    %q,', v);
        end
        lines[#lines+1] = '}';
    end

    writeList('lotList',   M.profile.lotList);
    writeList('passList',  M.profile.passList);
    writeList('dropList',  M.profile.dropList);
    writeList('storeList', M.profile.storeList);
    lines[#lines+1] = 'return p';

    local f = io.open(profilePath(name), 'w');
    if not f then
        print(chat.header('Looty') .. chat.error('Cannot write profile: ' .. profilePath(name)));
        return false;
    end
    f:write(table.concat(lines, '\n'));
    f:close();
    print(chat.header('Looty') .. chat.message('Profile saved: ' .. name));
    return true;
end

-- ============================================
-- Load
-- ============================================

function M.LoadProfile(name)
    if not name or name == '' then
        print(chat.header('Looty') .. chat.error('Profile name cannot be empty.'));
        return false;
    end

    local path = profilePath(name);

    -- Check file exists before attempting load (avoids noisy error on first run)
    local f = io.open(path, 'r');
    if not f then return false; end
    f:close();

    local ok, data = pcall(dofile, path);
    if not ok or type(data) ~= 'table' then
        print(chat.header('Looty') ..
              chat.error('Failed to load profile "' .. name .. '": ' .. tostring(data)));
        return false;
    end

    M.profile.lotList       = data.lotList       or {};
    M.profile.passList      = data.passList      or {};
    M.profile.dropList      = data.dropList      or {};
    M.profile.storeList     = data.storeList     or {};
    M.profile.defaultAction = data.defaultAction or 'ignore';
    M.profile.rarePass      = data.rarePass      or false;
    M.profile.smartPass     = data.smartPass     or false;

    -- Sync to gLootyConfig (values are single-element tables)
    if gLootyConfig then
        gLootyConfig.defaultAction  = M.profile.defaultAction;
        gLootyConfig.rarePass[1]    = M.profile.rarePass;
        gLootyConfig.smartPass[1]   = M.profile.smartPass;
    end

    print(chat.header('Looty') .. chat.message('Profile loaded: ' .. name));
    return true;
end

-- ============================================
-- List manipulation
-- ============================================

local VALID_LISTS = { lot=true, pass=true, drop=true, store=true };

function M.AddItem(listName, itemName)
    if not VALID_LISTS[listName] then
        print(chat.header('Looty') .. chat.error('Invalid list: ' .. listName));
        return false;
    end
    if not itemName or itemName == '' then return false; end

    local field = listName .. 'List';
    local tbl   = M.profile[field];
    if icontains(tbl, itemName) then
        print(chat.header('Looty') ..
              chat.message('"' .. itemName .. '" is already in the ' .. listName .. ' list.'));
        return false;
    end
    tbl[#tbl+1] = itemName;
    print(chat.header('Looty') ..
          chat.message('Added "' .. itemName .. '" to ' .. listName .. ' list.'));
    return true;
end

function M.RemoveItem(listName, itemName, silent)
    if not VALID_LISTS[listName] then
        if not silent then
            print(chat.header('Looty') .. chat.error('Invalid list: ' .. listName));
        end
        return false;
    end
    if not itemName or itemName == '' then return false; end

    local field = listName .. 'List';
    if iremove(M.profile[field], itemName) then
        if not silent then
            print(chat.header('Looty') ..
                  chat.message('Removed "' .. itemName .. '" from ' .. listName .. ' list.'));
        end
        return true;
    end
    -- Only print "not found" when explicitly called by user, not internal cleanup
    if not silent then
        print(chat.header('Looty') ..
              chat.error('"' .. itemName .. '" not found in ' .. listName .. ' list.'));
    end
    return false;
end

-- ============================================
-- Enumerate saved profiles
-- ============================================

function M.ListProfiles()
    local names = {};
    local handle = io.popen('dir /b "' .. profileDir() .. '*.lua" 2>nul');
    if handle then
        for line in handle:lines() do
            local n = line:match('^(.+)%.lua$');
            if n then names[#names+1] = n; end
        end
        handle:close();
    end
    return names;
end

-- ============================================
-- Accessors
-- ============================================

function M.GetProfile()
    return M.profile;
end

-- ============================================
-- Lifecycle
-- ============================================

function M.Initialize()
    -- Reset to defaults; LoadProfile called separately
    M.profile = {
        lotList       = {},
        passList      = {},
        dropList      = {},
        storeList     = {},
        defaultAction = 'ignore',
        rarePass      = false,
        smartPass     = false,
    };
    ensureDir();
end

return M;
