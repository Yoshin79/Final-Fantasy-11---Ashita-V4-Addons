--[[
* Looty - Treasure Pool Module
* Reads pool state from Ashita memory API (same source as xiui).
* Sends lot/pass using correct 0x41/0x42 packet format from xiui/actions.lua.
]]--

require('common');

local M = {};

-- ============================================
-- Constants
-- ============================================

M.MAX_POOL_SLOTS      = 10;
M.POOL_TIMEOUT_SEC    = 300;   -- 5 minutes

-- ============================================
-- State
-- ============================================

M.items     = {};          -- slot (0-9) -> item data table
M.dirty     = true;        -- flag: needs re-read from memory
M.tsCache   = {};          -- DropTime -> expiresAt  (avoids recalc)
M.graceCnt  = {};          -- slot -> frames item has been absent

local GRACE_FRAMES = 3;

-- ============================================
-- Item data structure
-- ============================================
--[[
  {
    slot          : 0-9
    itemId        : number
    itemName      : string
    count         : number  (always 1 per pool slot in XI)
    expiresAt     : os.time() + timeout
    dropTime      : raw DropTime from memory
    playerLot     : raw lot value  (0=pending, 1-999=lotted, 65535=passed)
    winningLot    : current highest lot
    winningName   : name of current lot leader
  }
]]--

-- ============================================
-- Helpers
-- ============================================

local function getItemName(id)
    if not id or id == 0 or id == 65535 then return 'Unknown'; end
    local res = AshitaCore:GetResourceManager():GetItemById(id);
    if not res or not res.Name then return string.format('Item#%d', id); end

    local n1 = res.Name[1];
    if not n1 or n1 == '' then return string.format('Item#%d', id); end

    local n2 = res.Name[2];
    if n2 and #n2 > #n1 then
        if n2:match('^[%a%d%s%.%-%\'%+%%%(%)%[%]]+$') then
            return n2;
        end
    end

    return n1;
end

-- ============================================
-- Memory read
-- ============================================

function M.ReadFromMemory()
    local memMgr = AshitaCore:GetMemoryManager();
    if not memMgr then return false; end
    local inv = memMgr:GetInventory();
    if not inv then return false; end

    local now      = os.time();
    local hasItems = false;
    local active   = {};

    for slot = 0, M.MAX_POOL_SLOTS - 1 do
        local item = inv:GetTreasurePoolItem(slot);
        if item and item.ItemId and item.ItemId > 0 and item.ItemId ~= 65535 then
            hasItems       = true;
            active[slot]   = true;
            M.graceCnt[slot] = 0;

            -- Timestamp cache
            if not M.tsCache[item.DropTime] then
                M.tsCache[item.DropTime] = now + M.POOL_TIMEOUT_SEC;
            end

            M.items[slot] = {
                slot        = slot,
                itemId      = item.ItemId,
                itemName    = getItemName(item.ItemId),
                count       = 1,
                expiresAt   = M.tsCache[item.DropTime],
                dropTime    = item.DropTime,
                playerLot   = item.Lot,
                winningLot  = item.WinningLot,
                winningName = item.WinningEntityName or '',
            };
        end
    end

    -- Grace-period removal
    for slot, _ in pairs(M.items) do
        if not active[slot] then
            M.graceCnt[slot] = (M.graceCnt[slot] or 0) + 1;
            if M.graceCnt[slot] >= GRACE_FRAMES then
                M.items[slot]   = nil;
                M.graceCnt[slot] = nil;
            else
                hasItems = true;
            end
        end
    end

    M.dirty = false;
    return hasItems;
end

-- ============================================
-- Sorted item list (for display)
-- ============================================

function M.GetSorted()
    local t = {};
    for _, item in pairs(M.items) do
        t[#t+1] = item;
    end
    table.sort(t, function(a, b)
        return (a.expiresAt or 0) > (b.expiresAt or 0);
    end);
    return t;
end

-- ============================================
-- Lot status helpers
-- ============================================

-- Returns 'lotted' | 'passed' | 'pending'
function M.GetLotStatus(slot)
    local item = M.items[slot];
    if not item then return 'pending'; end
    local lot = item.playerLot;
    if not lot or lot == 0 then return 'pending'; end
    if lot >= 65535              then return 'passed'; end
    return 'lotted';
end

function M.GetTimeRemaining(slot)
    local item = M.items[slot];
    if not item then return 0; end
    return math.max(0, item.expiresAt - os.time());
end

function M.FormatTime(secs)
    return string.format('%d:%02d', math.floor(secs / 60), secs % 60);
end

function M.HasItems()
    return next(M.items) ~= nil;
end

function M.GetCount()
    local n = 0;
    for _ in pairs(M.items) do n = n + 1; end
    return n;
end

function M.MarkDirty()
    M.dirty = true;
end

-- ============================================
-- Packet sending  (xiui format: 0x41 lot, 0x42 pass)
-- ============================================

function M.LotItem(slot)
    if slot == nil or slot < 0 or slot >= M.MAX_POOL_SLOTS then return false; end
    local item = M.items[slot];
    if not item then return false; end
    if M.GetLotStatus(slot) == 'lotted' then return false; end

    -- Rare check
    if M.IsItemRare(item.itemId) and M.PlayerHasItem(item.itemId) then
        return false, 'Already have ' .. item.itemName .. ' (Rare)';
    end
    -- Inventory full check
    if M.IsInventoryFull() then
        return false, 'Inventory is full';
    end

    local pkt = struct.pack('bbbbbbbb', 0x41, 0x04, 0x00, 0x00, slot, 0x00, 0x00, 0x00):totable();
    AshitaCore:GetPacketManager():AddOutgoingPacket(pkt[1], pkt);
    return true;
end

function M.PassItem(slot)
    if slot == nil or slot < 0 or slot >= M.MAX_POOL_SLOTS then return false; end
    local item = M.items[slot];
    if not item then return false; end
    if M.GetLotStatus(slot) == 'passed' then return false; end

    local pkt = struct.pack('bbbbbbbb', 0x42, 0x04, 0x00, 0x00, slot, 0x00, 0x00, 0x00):totable();
    AshitaCore:GetPacketManager():AddOutgoingPacket(pkt[1], pkt);
    return true;
end

function M.LotAll()
    if M.IsInventoryFull() then return 0; end
    local mgr   = AshitaCore:GetPacketManager();
    local count = 0;
    for slot = 0, M.MAX_POOL_SLOTS - 1 do
        local item = M.items[slot];
        if item then
            local lot = item.playerLot;
            if lot == nil or lot == 0 then
                local skip = M.IsItemRare(item.itemId) and M.PlayerHasItem(item.itemId);
                if not skip then
                    local pkt = struct.pack('bbbbbbbb', 0x41, 0x04, 0x00, 0x00, slot, 0x00, 0x00, 0x00):totable();
                    mgr:AddOutgoingPacket(pkt[1], pkt);
                    count = count + 1;
                end
            end
        end
    end
    return count;
end

function M.PassAll()
    local mgr   = AshitaCore:GetPacketManager();
    local count = 0;
    for slot = 0, M.MAX_POOL_SLOTS - 1 do
        local item = M.items[slot];
        if item then
            local lot = item.playerLot;
            if lot == nil or lot == 0 then
                local pkt = struct.pack('bbbbbbbb', 0x42, 0x04, 0x00, 0x00, slot, 0x00, 0x00, 0x00):totable();
                mgr:AddOutgoingPacket(pkt[1], pkt);
                count = count + 1;
            end
        end
    end
    return count;
end

-- ============================================
-- Auto-execute: apply profile lists to pool
-- ============================================

function M.AutoExecute(profile, cfg)
    if not profile then return; end
    local function icontains(tbl, val)
        val = val:lower();
        for _, v in ipairs(tbl) do
            if v:lower() == val then return true; end
        end
        return false;
    end

    local defaultAction = cfg.defaultAction or 'ignore';

    for slot = 0, M.MAX_POOL_SLOTS - 1 do
        local item = M.items[slot];
        if item and (not item.playerLot or item.playerLot == 0) then
            local name = item.itemName;
            if icontains(profile.lotList or {}, name) then
                M.LotItem(slot);
            elseif icontains(profile.passList or {}, name) then
                M.PassItem(slot);
            elseif defaultAction == 'lot' then
                M.LotItem(slot);
            elseif defaultAction == 'pass' then
                M.PassItem(slot);
            end
        end
    end
end

-- ============================================
-- Item validation helpers
-- ============================================

local ITEM_FLAG_RARE = 0x8000;

function M.IsItemRare(itemId)
    if not itemId or itemId == 0 or itemId == 65535 then return false; end
    local res = AshitaCore:GetResourceManager():GetItemById(itemId);
    if not res or not res.Flags then return false; end
    return bit.band(res.Flags, ITEM_FLAG_RARE) == ITEM_FLAG_RARE;
end

function M.PlayerHasItem(itemId)
    if not itemId or itemId == 0 then return false; end
    local inv = AshitaCore:GetMemoryManager():GetInventory();
    if not inv then return false; end
    local max = inv:GetContainerCountMax(0) or 0;
    for i = 1, max do
        local it = inv:GetContainerItem(0, i);
        if it and it.Id == itemId then return true; end
    end
    return false;
end

function M.IsInventoryFull()
    local inv = AshitaCore:GetMemoryManager():GetInventory();
    if not inv then return false; end
    local used = inv:GetContainerCount(0);
    local max  = inv:GetContainerCountMax(0);
    if not used or not max then return false; end
    return used >= max;
end

-- ============================================
-- Lifecycle
-- ============================================

function M.Initialize()
    M.items    = {};
    M.dirty    = true;
    M.tsCache  = {};
    M.graceCnt = {};
end

function M.Clear()
    M.items    = {};
    M.tsCache  = {};
    M.graceCnt = {};
    M.dirty    = true;
end

function M.Cleanup()
    M.Clear();
end

return M;
