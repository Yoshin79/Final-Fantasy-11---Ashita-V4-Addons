--[[
* Looty - Display Module
* ImGui window with 4 tabs:
*   Pool      - treasure pool items with Lot/Pass buttons + timer bar
*   Inventory - tagged inventory list (keep/drop/store)
*   Lists     - manage lot/pass/drop/store lists + profile save/load
*   Settings  - display preferences
*
* Rendering follows xiui display.lua conventions:
*   - imgui.GetWindowDrawList() for custom primitives
*   - Timer bar via AddRectFilled on the draw list
*   - Color constants mirror xiui palette
]]--

require('common');
local chat    = require('chat');
local imgui   = require('imgui');
local pool    = require('modules.treasurepool.pool');
local inv     = require('modules.inventory.inventory');
local profiles= require('modules.profiles.profiles');

local M = {};

-- ============================================
-- Color palette (RGBA 0-1 table for imgui,
--               0xAARRGGBB hex for draw list)
-- ============================================

local C = {
    lot       = { 0.20, 0.75, 0.22, 1.0 },
    pass      = { 0.85, 0.22, 0.22, 1.0 },
    keep      = { 0.25, 0.55, 0.90, 1.0 },
    store     = { 0.85, 0.68, 0.10, 1.0 },
    drop      = { 0.85, 0.22, 0.22, 1.0 },
    disabled  = { 0.50, 0.50, 0.50, 1.0 },
    rowA      = { 0.10, 0.10, 0.10, 0.80 },
    rowB      = { 0.14, 0.14, 0.14, 0.80 },
    hdr       = { 0.12, 0.12, 0.12, 1.00 },
    -- Timer bar colors (hex for draw list)
    timerNorm = 0xFF4488FF,  -- blue  >= 120s
    timerWarn = 0xFFFFCC44,  -- amber  < 120s
    timerCrit = 0xFF4444FF,  -- red    <  60s (note: ABGR order for imgui draw list)
};

-- Use imgui's ABGR hex for AddRectFilled
-- Blue >= 120s, amber 60-119s, red <60s
local function timerBarColor(remaining)
    if remaining < 60  then return imgui.GetColorU32({ 1.0, 0.27, 0.27, 0.90 }); end
    if remaining < 120 then return imgui.GetColorU32({ 1.0, 0.80, 0.27, 0.90 }); end
    return imgui.GetColorU32({ 0.27, 0.53, 1.0, 0.90 });
end

local function timerTextColor(remaining)
    if remaining < 60  then imgui.PushStyleColor(ImGuiCol_Text, {1.0, 0.40, 0.40, 1.0}); return true; end
    if remaining < 120 then imgui.PushStyleColor(ImGuiCol_Text, {1.0, 0.85, 0.30, 1.0}); return true; end
    return false;
end

-- ============================================
-- UI helpers
-- ============================================

local function colorButton(label, col, w, h)
    local r, g, b, a = col[1], col[2], col[3], col[4];
    imgui.PushStyleColor(ImGuiCol_Button, {r*0.75, g*0.75, b*0.75, a});
    imgui.PushStyleColor(ImGuiCol_ButtonHovered, {r,      g,      b,      a});
    imgui.PushStyleColor(ImGuiCol_ButtonActive, {r*0.55, g*0.55, b*0.55, a});
    local clicked = imgui.Button(label, {w or 0, h or 0});
    imgui.PopStyleColor(3);
    return clicked;
end

local function trimStr(s)
    return (s:gsub('^%s+', ''):gsub('%s+$', ''));
end

-- ============================================
-- UI state
-- ============================================

local profileNameBuf  = { '' };
local invSearchBuf    = { '' };
local addBufs = {
    lot   = { '' },
    pass  = { '' },
    drop  = { '' },
    store = { '' },
};

-- ============================================
-- Tab: Pool
-- ============================================

local function drawPoolTab()
    -- Read memory every draw (same as xiui pattern)
    pool.ReadFromMemory();

    -- Global action buttons
    if colorButton('Lot All##la', C.lot, 90, 22) then
        pool.LotAll();
    end
    imgui.SameLine();
    if colorButton('Pass All##pa', C.pass, 90, 22) then
        pool.PassAll();
    end
    imgui.SameLine();
    if imgui.Button('Refresh##rp', {72, 22}) then
        pool.ReadFromMemory();
        inv.ReadFromMemory(profiles.GetProfile());
    end

    imgui.Separator();

    local items = pool.GetSorted();

    if #items == 0 then
        if gLootyConfig.autoHideWhenEmpty[1] then
            imgui.TextDisabled('  Pool is empty.');
        else
            imgui.TextDisabled('  Pool is empty.');
        end
        return;
    end

    -- Column widths  (must sum to ~window inner width ~490)
    local COL_NAME   = 155;
    local COL_QTY    = 30;
    local COL_TIMER  = 58;
    local COL_STATUS = 70;
    local COL_BTNS   = 100;  -- enough for "Lot" + "Pass" buttons with spacing

    -- Header row
    imgui.PushStyleColor(ImGuiCol_ChildBg, {C.hdr[1], C.hdr[2], C.hdr[3], C.hdr[4]});
    imgui.Columns(5, 'ph', false);
    imgui.SetColumnWidth(0, COL_NAME);
    imgui.SetColumnWidth(1, COL_QTY);
    imgui.SetColumnWidth(2, COL_TIMER);
    imgui.SetColumnWidth(3, COL_STATUS);
    imgui.SetColumnWidth(4, COL_BTNS);
    imgui.TextDisabled('Item');   imgui.NextColumn();
    imgui.TextDisabled('Qty');    imgui.NextColumn();
    imgui.TextDisabled('Timer');  imgui.NextColumn();
    imgui.TextDisabled('Status'); imgui.NextColumn();
    imgui.TextDisabled('Action'); imgui.NextColumn();
    imgui.Columns(1);
    imgui.PopStyleColor();
    imgui.Separator();

    -- Scrollable region for pool rows
    imgui.BeginChild('poolscroll', {0, 0});

    local drawList = imgui.GetWindowDrawList();

    for idx, item in ipairs(items) do
        imgui.Columns(5, 'pr' .. idx, false);
        imgui.SetColumnWidth(0, COL_NAME);
        imgui.SetColumnWidth(1, COL_QTY);
        imgui.SetColumnWidth(2, COL_TIMER);
        imgui.SetColumnWidth(3, COL_STATUS);
        imgui.SetColumnWidth(4, COL_BTNS);

        -- Item name
        local displayName = item.itemName;
        if #displayName > 20 then displayName = displayName:sub(1,18) .. '..'; end
        imgui.Text(displayName);
        if imgui.IsItemHovered() and #item.itemName > 20 then
            imgui.BeginTooltip();
            imgui.Text(item.itemName);
            imgui.EndTooltip();
        end
        imgui.NextColumn();

        -- Count
        imgui.Text(tostring(item.count));
        imgui.NextColumn();

        -- Timer column: text on top, bar drawn flush below it
        local remaining = pool.GetTimeRemaining(item.slot);
        if gLootyConfig.showTimerText[1] then
            local popped = timerTextColor(remaining);
            imgui.Text(pool.FormatTime(remaining));
            if popped then imgui.PopStyleColor(); end
        else
            imgui.Text('--');
        end

        -- Timer progress bar: draw immediately after text, same column
        if gLootyConfig.showTimerBar[1] then
            local cx, cy = imgui.GetCursorScreenPos();
            local barW = COL_TIMER - 10;
            local barH = 3;
            local pct  = math.min(1.0, remaining / pool.POOL_TIMEOUT_SEC);
            local trackCol = imgui.GetColorU32({ 0.15, 0.15, 0.15, 0.8 });
            local fillCol  = timerBarColor(remaining);
            drawList:AddRectFilled({cx, cy},             {cx + barW,       cy + barH}, trackCol, 1.0);
            drawList:AddRectFilled({cx, cy},             {cx + barW * pct, cy + barH}, fillCol,  1.0);
            imgui.Dummy({barW, barH + 1});
        end
        imgui.NextColumn();

        -- Status
        local status = pool.GetLotStatus(item.slot);
        if status == 'lotted' then
            imgui.PushStyleColor(ImGuiCol_Text, {C.lot[1], C.lot[2], C.lot[3], 1.0});
            imgui.Text('Lot: ' .. (item.playerLot or 0));
            imgui.PopStyleColor();
        elseif status == 'passed' then
            imgui.PushStyleColor(ImGuiCol_Text, {C.pass[1], C.pass[2], C.pass[3], 1.0});
            imgui.Text('Passed');
            imgui.PopStyleColor();
        else
            if gLootyConfig.showLots[1] and item.winningLot and item.winningLot > 0 then
                imgui.PushStyleColor(ImGuiCol_Text, {0.90, 0.80, 0.30, 1.0});
                local wn = item.winningName or '?';
                if #wn > 7 then wn = wn:sub(1,6) .. '.'; end
                imgui.Text(wn .. ':' .. item.winningLot);
                imgui.PopStyleColor();
            else
                imgui.TextDisabled('--');
            end
        end
        imgui.NextColumn();

        -- Action buttons: full labels, proper sizes
        local isPending = (status == 'pending');
        local isLotted  = (status == 'lotted');

        if status == 'passed' then
            imgui.PushStyleColor(ImGuiCol_Text, {0.5, 0.5, 0.5, 1.0});
            imgui.Text('Passed');
            imgui.PopStyleColor();
        else
            if colorButton('Lot##l' .. idx, C.lot, 42, 20) then
                pool.LotItem(item.slot);
            end
            imgui.SameLine();
            if colorButton('Pass##p' .. idx, C.pass, 46, 20) then
                pool.PassItem(item.slot);
            end
        end

        imgui.NextColumn();
        imgui.Columns(1);
        imgui.Spacing();
    end

    imgui.EndChild();
end

-- ============================================
-- Tab: Inventory
-- ============================================

local function drawInventoryTab()
    -- Search + refresh bar
    imgui.SetNextItemWidth(170);
    imgui.InputText('##is', invSearchBuf, 64);
    imgui.SameLine();
    if imgui.Button('Refresh##ri', {70, 0}) then
        inv.ReadFromMemory(profiles.GetProfile());
        -- Auto-drop anything on the drop list found in current inventory
        local dropped = 0;
        for _, item in ipairs(inv.GetItems()) do
            if item.tag == 'drop' then
                inv.DropItem(item);
                dropped = dropped + 1;
            end
        end
        if dropped > 0 then
            print(chat.header('Looty') .. chat.message('Auto-dropping ' .. dropped .. ' item(s) from drop list.'));
        end
    end
    imgui.SameLine();
    imgui.TextDisabled(string.format('%d items', inv.GetCount()));

    imgui.Separator();

    local items  = inv.GetItems();
    local search = trimStr(invSearchBuf[1]):lower();

    if #items == 0 then
        imgui.TextDisabled('  Inventory empty or not loaded. Click Refresh.');
        return;
    end

    imgui.TextDisabled('Right-click an item to tag it  |  Drop Now drops immediately');
    imgui.Spacing();
    -- Single-column layout: tag label + name fills most of the row,
    -- Qty and Drop Now sit on the right via SameLine from right edge.
    -- This avoids all column-width math and scrollbar clipping issues.

    imgui.Separator();

    -- Scrollable rows
    imgui.BeginChild('invscroll', {0, 0});

    local availW = imgui.GetContentRegionAvail();
    local btnW   = 80;   -- "Drop Now" button
    local qtyW   = 30;   -- qty number approx width

    for idx, item in ipairs(items) do
        if search == '' or item.name:lower():find(search, 1, true) then

            -- Tag label colored
            local tagCol = C.keep;
            local tagStr = 'KEEP';
            if item.tag == 'drop'  then tagCol = C.drop;  tagStr = 'DROP';
            elseif item.tag == 'store' then tagCol = C.store; tagStr = 'STOR'; end

            imgui.PushStyleColor(ImGuiCol_Text, {tagCol[1], tagCol[2], tagCol[3], 1.0});
            imgui.Text(tagStr);
            imgui.PopStyleColor();
            imgui.SameLine(0, 6);

            -- Item name - truncate to leave room for qty + button
            local maxNamePx = availW - btnW - qtyW - 80;
            local dn = item.name;
            -- rough char width at default font ~7px per char
            local maxChars = math.floor(maxNamePx / 7);
            if #dn > maxChars then dn = dn:sub(1, maxChars - 2) .. '..'; end
            imgui.Text(dn);

            -- Tooltip for truncated names
            if imgui.IsItemHovered() and #item.name > maxChars then
                imgui.BeginTooltip();
                imgui.Text(item.name);
                imgui.EndTooltip();
            end

            -- Right-click context menu
            if imgui.BeginPopupContextItem('ctx'..idx) then
                imgui.TextDisabled('Tag: ' .. item.name);
                imgui.Separator();

                imgui.PushStyleColor(ImGuiCol_Text, {C.keep[1], C.keep[2], C.keep[3], 1.0});
                if imgui.MenuItem('  Keep  (remove from all lists)') then
                    item.tag = 'keep';
                    profiles.RemoveItem('drop',  item.name, true);
                    profiles.RemoveItem('store', item.name, true);
                end
                imgui.PopStyleColor();

                imgui.PushStyleColor(ImGuiCol_Text, {C.drop[1], C.drop[2], C.drop[3], 1.0});
                if imgui.MenuItem('  Drop  (add to auto-drop list)') then
                    item.tag = 'drop';
                    profiles.RemoveItem('store', item.name, true);
                    profiles.AddItem('drop', item.name);
                end
                imgui.PopStyleColor();

                imgui.PushStyleColor(ImGuiCol_Text, {C.store[1], C.store[2], C.store[3], 1.0});
                if imgui.MenuItem('  Store  (add to auto-store list)') then
                    item.tag = 'store';
                    profiles.RemoveItem('drop', item.name, true);
                    profiles.AddItem('store', item.name);
                end
                imgui.PopStyleColor();

                imgui.Separator();
                imgui.PushStyleColor(ImGuiCol_Text, {1.0, 0.35, 0.35, 1.0});
                if imgui.MenuItem('  Drop Now  (drop from inventory)') then
                    inv.DropItem(item);
                    ashita.tasks.once(2, function()
                        inv.ReadFromMemory(profiles.GetProfile());
                    end);
                end
                imgui.PopStyleColor();
                imgui.EndPopup();
            end

            -- Qty + Drop Now right-side, on same logical row
            imgui.SameLine(availW - btnW - qtyW - 10);
            imgui.TextDisabled(tostring(item.count));
            imgui.SameLine(availW - btnW - 4);

            imgui.PushStyleColor(ImGuiCol_Button,        {0.55, 0.12, 0.12, 1.0});
            imgui.PushStyleColor(ImGuiCol_ButtonHovered, {0.80, 0.18, 0.18, 1.0});
            imgui.PushStyleColor(ImGuiCol_ButtonActive,  {0.38, 0.08, 0.08, 1.0});
            if imgui.Button('Drop Now##dn'..idx, {btnW, 18}) then
                inv.DropItem(item);
                ashita.tasks.once(2, function()
                    inv.ReadFromMemory(profiles.GetProfile());
                end);
            end
            imgui.PopStyleColor(3);

        end
    end

    imgui.EndChild();
end

-- ============================================
-- Tab: Lists
-- ============================================

-- ============================================
-- Tab: Lists
-- ============================================

-- Section colors: bright text on a dark header background
-- Override the CollapsingHeader to have a neutral bg so colored text is visible
local LIST_SECTION_COLORS = {
    lot   = { text = {0.30, 0.95, 0.35, 1.0}, bg = {0.10, 0.22, 0.11, 1.0} },
    pass  = { text = {1.00, 0.40, 0.40, 1.0}, bg = {0.22, 0.10, 0.10, 1.0} },
    drop  = { text = {1.00, 0.55, 0.20, 1.0}, bg = {0.22, 0.14, 0.06, 1.0} },
    store = { text = {1.00, 0.85, 0.20, 1.0}, bg = {0.20, 0.18, 0.06, 1.0} },
};

local function drawListSection(title, listKey)
    local prof  = profiles.GetProfile();
    local field = listKey .. 'List';
    local tbl   = prof[field] or {};
    local sc    = LIST_SECTION_COLORS[listKey];

    -- Dark tinted header background so bright text is readable
    imgui.PushStyleColor(ImGuiCol_Header,        {sc.bg[1],        sc.bg[2],        sc.bg[3],        1.0});
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, {sc.bg[1]+0.06,   sc.bg[2]+0.06,   sc.bg[3]+0.06,   1.0});
    imgui.PushStyleColor(ImGuiCol_HeaderActive,  {sc.bg[1]+0.10,   sc.bg[2]+0.10,   sc.bg[3]+0.10,   1.0});
    imgui.PushStyleColor(ImGuiCol_Text,          {sc.text[1], sc.text[2], sc.text[3], 1.0});
    local open = imgui.CollapsingHeader(
        string.format('%s  (%d)##hdr%s', title, #tbl, listKey));
    imgui.PopStyleColor(4);

    if open then
        imgui.Indent(12);

        -- Add row
        local buf = addBufs[listKey];
        imgui.SetNextItemWidth(170);
        imgui.InputText('##add' .. listKey, buf, 64);
        imgui.SameLine();
        -- + button uses the section's text color
        imgui.PushStyleColor(ImGuiCol_Button,        {sc.bg[1]+0.05, sc.bg[2]+0.05, sc.bg[3]+0.05, 1.0});
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, {sc.bg[1]+0.15, sc.bg[2]+0.15, sc.bg[3]+0.15, 1.0});
        imgui.PushStyleColor(ImGuiCol_ButtonActive,  {sc.bg[1],      sc.bg[2],      sc.bg[3],      1.0});
        imgui.PushStyleColor(ImGuiCol_Text,          {sc.text[1], sc.text[2], sc.text[3], 1.0});
        local add = imgui.Button('+##ab' .. listKey, {24, 0});
        imgui.PopStyleColor(4);
        if add then
            local val = trimStr(buf[1]);
            if val ~= '' then
                profiles.AddItem(listKey, val);
                buf[1] = '';
            end
        end
        imgui.SameLine();
        imgui.TextDisabled('type item name, press +');

        -- List items
        for i = #tbl, 1, -1 do
            imgui.PushStyleColor(ImGuiCol_Text, {sc.text[1], sc.text[2], sc.text[3], 0.9});
            imgui.BulletText(tbl[i]);
            imgui.PopStyleColor();
            imgui.SameLine();
            if imgui.SmallButton('x##rm' .. listKey .. i) then
                profiles.RemoveItem(listKey, tbl[i]);
            end
        end
        if #tbl == 0 then imgui.TextDisabled('  (empty)'); end

        imgui.Unindent(12);
        imgui.Spacing();
    end
end

local function drawListsTab()
    -- ── Profile management bar ──────────────────────
    imgui.Text('Profile:');
    imgui.SameLine();
    imgui.SetNextItemWidth(140);
    imgui.InputText('##pn', profileNameBuf, 64);
    imgui.SameLine();
    if imgui.Button('Save##sp', {46, 0}) then
        local n = trimStr(profileNameBuf[1]);
        if n ~= '' and profiles.SaveProfile(n) then
            gLootyConfig.currentProfile = n;
        end
    end
    imgui.SameLine();
    if imgui.Button('Load##lp', {46, 0}) then
        local n = trimStr(profileNameBuf[1]);
        if n ~= '' and profiles.LoadProfile(n) then
            gLootyConfig.currentProfile = n;
            inv.RefreshTags(profiles.GetProfile());
        end
    end

    -- Quick-load saved profiles
    local saved = profiles.ListProfiles();
    if #saved > 0 then
        imgui.SameLine();
        imgui.TextDisabled('|');
        for _, pn in ipairs(saved) do
            imgui.SameLine();
            if imgui.SmallButton(pn .. '##ql') then
                profileNameBuf[1] = pn;
                if profiles.LoadProfile(pn) then
                    gLootyConfig.currentProfile = pn;
                    inv.RefreshTags(profiles.GetProfile());
                end
            end
        end
    end

    imgui.Separator();
    imgui.Spacing();

    -- ── Global settings ─────────────────────────────
    -- Default action combo
    imgui.Text('Default pool action:');
    imgui.SameLine();
    local actionOptions = { 'ignore', 'lot', 'pass' };
    local curIdxBuf = { 0 };
    for i, a in ipairs(actionOptions) do
        if a == gLootyConfig.defaultAction then curIdxBuf[1] = i - 1; end
    end
    imgui.SetNextItemWidth(90);
    local changed = imgui.Combo('##da', curIdxBuf, actionOptions, #actionOptions);
    if changed then
        gLootyConfig.defaultAction = actionOptions[curIdxBuf[1] + 1];
        profiles.GetProfile().defaultAction = gLootyConfig.defaultAction;
    end

    imgui.SameLine();
    imgui.Checkbox('Rare Pass##rpc', gLootyConfig.rarePass);
    profiles.GetProfile().rarePass = gLootyConfig.rarePass[1];
    imgui.SameLine();
    imgui.Checkbox('Smart Pass##spc', gLootyConfig.smartPass);
    profiles.GetProfile().smartPass = gLootyConfig.smartPass[1];

    imgui.Spacing();
    imgui.Separator();
    imgui.Spacing();

    -- ── Four list sections ───────────────────────────
    drawListSection('Auto-LOT List',   'lot');
    drawListSection('Auto-PASS List',  'pass');
    drawListSection('Auto-DROP List',  'drop');
    drawListSection('Auto-STORE List', 'store');
end

-- ============================================
-- Tab: Settings
-- ============================================

local function drawSettingsTab()
    imgui.Spacing();

    local _, v;

    imgui.Checkbox('Show Timer Bar',                  gLootyConfig.showTimerBar);
    imgui.Checkbox('Show Timer Text',                 gLootyConfig.showTimerText);
    imgui.Checkbox('Show Winning Lot',                gLootyConfig.showLots);
    imgui.Checkbox('Auto-Hide When Empty',            gLootyConfig.autoHideWhenEmpty);
    imgui.Checkbox('Auto-Execute Lists on Pool Update', gLootyConfig.autoExecute);

    imgui.Spacing();
    imgui.Separator();

    imgui.Text('Window Opacity:');
    imgui.SameLine();
    imgui.SetNextItemWidth(150);
    imgui.SliderFloat('##winalpha', gLootyConfig.alpha, 0.30, 1.0);

    imgui.Spacing();
    imgui.Separator();
    imgui.Spacing();

    imgui.TextDisabled('Commands');
    imgui.BulletText('/looty               - toggle window');
    imgui.BulletText('/looty lot           - lot all pool items');
    imgui.BulletText('/looty pass          - pass all pool items');
    imgui.BulletText('/looty reload        - refresh pool + inventory');
    imgui.BulletText('/looty save [n]      - save profile');
    imgui.BulletText('/looty load <n>   - load profile');
    imgui.BulletText('/looty add lot|pass|drop|store <item>');
    imgui.BulletText('/looty remove lot|pass|drop|store <item>');
    imgui.BulletText('/looty default lot|pass|ignore');
end

-- ============================================
-- Main window
-- ============================================

-- No NoCollapse flag = Ashita gives us the built-in ▼ collapse arrow in the title bar for free
local WIN_FLAGS = 0;

function M.DrawWindow()
    local alpha = gLootyConfig.alpha[1] or 0.92;
    imgui.SetNextWindowBgAlpha(alpha);
    imgui.SetNextWindowSize({ 560, 440 }, ImGuiCond_FirstUseEver);

    local visible = imgui.Begin(
        string.format('Looty  [%s]', gLootyConfig.currentProfile or 'default'),
        gLootyConfig.show,
        WIN_FLAGS);

    -- When collapsed imgui.Begin returns false - just end and return
    if not visible then
        imgui.End();
        return;
    end

    if imgui.BeginTabBar('##lwuitabs') then

        if imgui.BeginTabItem('Pool##pt') then
            imgui.Spacing();
            drawPoolTab();
            imgui.EndTabItem();
        end

        if imgui.BeginTabItem('Inventory##invt') then
            imgui.Spacing();
            drawInventoryTab();
            imgui.EndTabItem();
        end

        if imgui.BeginTabItem('Lists##lt') then
            imgui.Spacing();
            drawListsTab();
            imgui.EndTabItem();
        end

        if imgui.BeginTabItem('Settings##st') then
            imgui.Spacing();
            drawSettingsTab();
            imgui.EndTabItem();
        end

        imgui.EndTabBar();
    end

    imgui.End();
end

return M;
