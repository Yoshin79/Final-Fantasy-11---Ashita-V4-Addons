--[[
* Looty - Ashita V4 Lua Addon
* Visual loot management UI built on xiui's treasure pool infrastructure.
*
* Combines:
*   - Lootwhore (ThornyFFXI) command logic: lot/pass/drop/store lists + profiles
*   - xiui (ThornyFFXI) rendering patterns: real memory API, correct packet format,
*     imgui draw-list rendering with GDI fonts
*
* Structure:
*   looty.lua         - addon entry, event wiring
*   modules/treasurepool/   - pool data reading + lot/pass actions  (from xiui)
*   modules/inventory/      - inventory reading + drop/store tagging
*   modules/profiles/       - profile save/load (Lootwhore-style XML->Lua)
*   display.lua             - ImGui window (pool, inventory, lists, settings tabs)
]]--

addon.name    = 'Looty'
addon.author  = 'Oneword - Based off of Thornys Lootwhore'
addon.version = '2.0'
addon.desc    = 'Visual loot manager: treasure pool, inventory tagger, profile-based auto-lot/pass/drop/store.'
addon.link    = 'https://github.com/Yoshin79'

require('common');
local chat    = require('chat');
local imgui   = require('imgui');

-- Sub-modules
local pool     = require('modules.treasurepool.pool');
local inv      = require('modules.inventory.inventory');
local profiles = require('modules.profiles.profiles');
local display  = require('display');

-- ============================================
-- Globals used by display / sub-modules
-- ============================================
-- All boolean/float values that imgui reads/writes must be single-element tables.
-- Plain booleans/numbers are read-only in Ashita V4's imgui Lua bindings.
gLootyConfig = {
    -- Window
    show              = { true },
    alpha             = { 0.92 },
    -- Pool tab (wrapped for Checkbox)
    showTimerBar      = { true },
    showTimerText     = { true },
    showLots          = { true },
    showButtonsAlways = { true },
    autoHideWhenEmpty = { true },
    expanded          = { false },
    -- Auto-execute
    autoExecute       = { false },
    -- Profile (plain strings/tables, not imgui-driven)
    currentProfile    = 'default',
    defaultAction     = 'ignore',   -- 'lot' | 'pass' | 'ignore'
    rarePass          = { false },
    smartPass         = { false },
};

-- ============================================
-- Addon lifecycle
-- ============================================

ashita.events.register('load', 'looty_load', function()
    pool.Initialize();
    inv.Initialize();
    profiles.Initialize();

    -- Try to load default profile (silently fail on first run - no file yet)
    if profiles.LoadProfile('default') then
        gLootyConfig.currentProfile = 'default';
    end

    print(chat.header('Looty') ..
          chat.message('Loaded v' .. addon.version .. '.  /looty for help.'));
end);

ashita.events.register('unload', 'looty_unload', function()
    pool.Cleanup();
    inv.Cleanup();
end);

-- ============================================
-- Render
-- ============================================

ashita.events.register('d3d_present', 'looty_present', function()
    if not gLootyConfig.show[1] then return; end
    display.DrawWindow();
end);

-- ============================================
-- Packet handling
-- ============================================

ashita.events.register('packet_in', 'looty_packet_in', function(e)
    -- 0x00D2 = item added to treasure pool
    -- 0x00D3 = lot/pass result packet
    if e.id == 0x00D2 or e.id == 0x00D3 then
        -- Pool state updated; refresh + auto-execute after one frame
        pool.MarkDirty();
        if gLootyConfig.autoExecute[1] then
            ashita.tasks.once(1, function()
                pool.ReadFromMemory();
                pool.AutoExecute(profiles.GetProfile(), gLootyConfig);
            end);
        end
    end

    -- 0x001E = inventory/container update
    if e.id == 0x001E then
        ashita.tasks.once(1, function()
            inv.ReadFromMemory(profiles.GetProfile());
            -- Auto-drop any items on the drop list via packet (Lootwhore method)
            local dropList = profiles.GetProfile().dropList or {};
            if #dropList > 0 then
                for _, item in ipairs(inv.GetItems()) do
                    if item.tag == 'drop' then
                        inv.DropItem(item);
                    end
                end
            end
        end);
    end
end);

-- ============================================
-- Zone change → clear pool state
-- ============================================

ashita.events.register('packet_in', 'looty_zone', function(e)
    if e.id == 0x000A then   -- Zone-in packet
        pool.Clear();
        inv.Clear();
    end
end);

-- ============================================
-- Commands
-- ============================================

ashita.events.register('command', 'looty_command', function(e)
    local args = e.command:args();
    if #args == 0 then return; end
    local cmd = args[1]:lower();
    if cmd ~= '/looty' and cmd ~= '/loot' then return; end

    e.blocked = true;
    local sub = (args[2] or ''):lower();

    if sub == '' then
        gLootyConfig.show[1] = not gLootyConfig.show[1];

    elseif sub == 'lot' then
        pool.ReadFromMemory();
        local n = pool.LotAll();
        print(chat.header('Looty') .. chat.message('Lotted ' .. n .. ' item(s).'));

    elseif sub == 'pass' then
        pool.ReadFromMemory();
        local n = pool.PassAll();
        print(chat.header('Looty') .. chat.message('Passed ' .. n .. ' item(s).'));

    elseif sub == 'reload' or sub == 'refresh' then
        pool.ReadFromMemory();
        inv.ReadFromMemory();
        print(chat.header('Looty') .. chat.message('Refreshed pool and inventory.'));

    elseif sub == 'save' then
        local name = args[3] or gLootyConfig.currentProfile;
        if profiles.SaveProfile(name) then
            gLootyConfig.currentProfile = name;
        end

    elseif sub == 'load' then
        local name = args[3];
        if not name then
            print(chat.header('Looty') .. chat.error('Usage: /looty load <profilename>'));
        elseif profiles.LoadProfile(name) then
            gLootyConfig.currentProfile = name;
            inv.RefreshTags(profiles.GetProfile());
        end

    elseif sub == 'add' then
        -- /looty add lot|pass|drop|store <item>
        local list = (args[3] or ''):lower();
        local item = args[4] or '';
        if item == '' then
            print(chat.header('Looty') .. chat.error('Usage: /looty add lot|pass|drop|store <item>'));
        else
            profiles.AddItem(list, item);
        end

    elseif sub == 'remove' or sub == 'rem' then
        local list = (args[3] or ''):lower();
        local item = args[4] or '';
        profiles.RemoveItem(list, item);

    elseif sub == 'default' then
        local action = (args[3] or ''):lower();
        if action == 'lot' or action == 'pass' or action == 'ignore' then
            gLootyConfig.defaultAction = action;
            profiles.GetProfile().defaultAction = action;
            print(chat.header('Looty') ..
                  chat.message('Default action set to: ' .. action));
        else
            print(chat.header('Looty') .. chat.error('Usage: /looty default lot|pass|ignore'));
        end

    elseif sub == 'help' then
        local h = chat.header('Looty');
        local m = chat.message;
        print(h .. m('/looty                          - toggle window'));
        print(h .. m('/looty lot                      - lot all pending pool items'));
        print(h .. m('/looty pass                     - pass all pending pool items'));
        print(h .. m('/looty reload                   - refresh pool + inventory'));
        print(h .. m('/looty save [name]               - save profile'));
        print(h .. m('/looty load <name>               - load profile'));
        print(h .. m('/looty add lot|pass|drop|store <item>'));
        print(h .. m('/looty remove lot|pass|drop|store <item>'));
        print(h .. m('/looty default lot|pass|ignore  - set default pool action'));
    else
        print(chat.header('Looty') ..
              chat.error('Unknown subcommand: "' .. sub .. '".  Try /looty help'));
    end
end);
