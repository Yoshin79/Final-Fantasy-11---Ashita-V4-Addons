# Looty — Ashita V4 Lua Addon (v2.1)

Visual loot manager for FFXI on Ashita V4. Handles treasure pool lotting/passing and inventory drop management with saved profiles.

---

## Installation

Copy the `looty` folder into your addons directory:
```
<AshitaV4>/addons/looty/
```

Load in game:
```
/addon load looty
```

---

## Quick Start

1. Go to the **Lists tab** and add items to your Auto-LOT, Auto-PASS, or Auto-DROP lists
2. Hit **Save** and give your profile a name (e.g. `default`)
3. Your profile auto-loads on startup if saved as `default`
4. When a treasure pool appears, Looty shows it in the **Pool tab** with Lot/Pass buttons
5. In the **Inventory tab**, hit **Refresh** to scan your bags — anything on your drop list gets dropped automatically

---

## Tabs

### Pool
Shows all current treasure pool items with a countdown timer and Lot/Pass buttons per item. **Lot All** and **Pass All** buttons at the top act on everything you haven't decided yet. If Auto-Execute is enabled in Settings, items are lotted or passed automatically based on your lists as soon as they appear.

### Inventory
Shows your main inventory. Hit **Refresh** to scan your bags — any items on your Auto-DROP list are dropped immediately. Right-click any item to tag it Keep, Drop, or Store (this updates your active profile lists). The **Drop Now** button on each row drops that specific item instantly.

### Lists
Manage your four lists: Auto-LOT, Auto-PASS, Auto-DROP, and Auto-STORE. Type an item name and press `+` to add it. Click `x` to remove. Use the Profile bar at the top to save and load named profiles — saved profiles appear as quick-load buttons. Set a default pool action (lot/pass/ignore) for items not on any list.

### Settings
Toggle timer bar, timer text, winning lot display, and auto-hide when pool is empty. Enable Auto-Execute to have Looty act on pool items automatically. Adjust window opacity.

---

## Commands

| Command | Description |
|---------|-------------|
| `/looty` | Toggle window |
| `/looty lot` | Lot all pending pool items |
| `/looty pass` | Pass all pending pool items |
| `/looty reload` | Refresh pool and inventory |
| `/looty save [name]` | Save current profile |
| `/looty load <n>` | Load a profile |
| `/looty add lot\|pass\|drop\|store <item>` | Add item to a list |
| `/looty remove lot\|pass\|drop\|store <item>` | Remove item from a list |
| `/looty default lot\|pass\|ignore` | Set default pool action |
| `/looty help` | Show all commands in chat |

---

## Profiles

Profiles are saved as Lua files in:
```
<AshitaV4>/config/looty/<n>.lua
```
A profile named `default` is loaded automatically on startup. You can have separate profiles per character or situation (e.g. `endgame`, `farming`).

---

## Notes
