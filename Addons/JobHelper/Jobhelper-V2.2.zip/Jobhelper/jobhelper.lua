addon.name      = 'jobhelper';
addon.author    = 'Oneword - Info from Final Fantasy 11 and web resources from https://ffxiclopedia.fandom.com/wiki and https://www.bg-wiki.com/';
addon.version   = '2.2';
addon.desc      = 'Helper addon to assist with unlocking jobs.';

require('common');
local imgui = require('imgui');

-- Color schemes
local colors = {
    title = { 0.7, 0.3, 1.0, 1.0 },      -- Purple
    header = { 0.4, 0.8, 1.0, 1.0 },      -- Light Blue
    requirement = { 1.0, 0.8, 0.2, 1.0 }, -- Gold
    step = { 0.9, 0.9, 0.9, 1.0 },        -- Off White
    location = { 0.3, 1.0, 0.5, 1.0 },    -- Green
    bullet = { 1.0, 0.5, 0.0, 1.0 },      -- Orange
    separator = { 0.5, 0.5, 1.0, 0.5 },   -- Semi-transparent Blue
    warning = { 1.0, 0.4, 0.4, 1.0 },     -- Red
    note = { 1.0, 0.7, 0.2, 1.0 }         -- Golden yellow
};

-- JobHelper variables
local jobhelper = {
    is_open = { true },
    settings = {
        position_x = 100,
        position_y = 100,
    },
    selected_job = nil,
    jobs = {
        COR = {
            name = "Corsair",
            requirements = {
                "Main job level 30+",
                "Access to Aht Urhgan areas",
                "One of the following:",
                "  - Lamian Fang Key",
                "  - THF with Thief's Tools",
                "  - Access to Ilrusi Atoll Staging Point"
            },
            steps = {
                { text = "1. Talk to Ratihb in ", location = "Aht Urhgan Whitegate (J-12)", detail = "Shararat Teahouse, second floor" },
                { text = "2. Talk to Mafwahb at ", location = "Aht Urhgan Whitegate (L-9)", detail = "near Imperial Whitegate" },
                { text = "3. Travel to Arrapago Reef (choose a route):" },
                { text = "   Route A - Via Nashmau:" },
                { text = "   - Take ferry from Port Ephramad to Nashmau" },
                { text = "   - Exit Nashmau North to ", location = "Caedarva Mire (H-6)" },
                { text = "   - Zone into Arrapago Reef at ", location = "Caedarva Mire (I-6)" },
                { text = "4. In Arrapago Reef (Map 1):" },
                { text = "   - Travel north to ship" },
                { text = "   - Cross plank, go down eastern shore" },
                { text = "   - Open Iron Gate at ", location = "(J-10)", detail = "requires key" },
                { text = "   - Open second gate at ", location = "(I-9)" },
                { text = "   - Find (???) on ship at ", location = "(H-10)" },
                { text = "5. Enter Talacca Cove from ", location = "Caedarva Mire (E-9) Map 1", detail = "outside of Nashmau west exit" },
                { text = "   - Home Point #1 in Caedarva Mire puts you right at this zone" },
                { text = "   - Go around the left side of the lake in the large room until you find a (???) spot" },
                { text = "   - Examine (???) for a cutscene and key item: Forgotten Hexagun" },
                { text = "   - Travel west into the tunnel entrance, then North to find the Rock Slab" },
                { text = "   - Examine the Rock Slab for a cutscene that ends the quest to receive your reward" }
            },
            warnings = {
                "Dangerous mobs in areas:",
                "- Caedarva Mire: Imps (True Sight), Chigoes, Treants (Sound)",
                "- Arrapago Reef: Lamiae (Sight), Draugars (Sound)",
                "Must have free inventory slot for Corsair Die",
                "Cannot have Corsair Die already in inventory"
            },
            af_quests = {
                {
                    name = "AF1 - Equipped for All Occasions (COR 40+)",
                    reward = "Trump Gun",
                    steps = {
                        { text = "   Items needed: Lamian Fang Key" },
                        { text = "1. Talk to Ratihb at ", location = "Aht Urhgan Whitegate (J-12)", detail = "Shararat Teahouse" },
                        { text = "   - Quest won't appear in log until next step" },
                        { text = "2. Examine (???) in ", location = "Arrapago Reef (H-10)", detail = "must be on COR Lv40+" },
                        { text = "   - Use Arrapago Reef Survival Guide to get there quickly" },
                        { text = "   - Need Lamian Fang Key: drops from Lamiae/Draugers, or daily (???) at Caedarva Mire (I-7)" },
                        { text = "   - Use Lamian Fang Key on Iron Gate at (J-10), go west to unlocked Iron Gate" },
                        { text = "   - Answer: Maze of Shakhrami (wrong answer is OK)" },
                        { text = "3. Go to Maze of Shakhrami Map 2 (K-9) - find Iron Door in NW corner room" },
                        { text = "   - Fastest: Unity Warp 119 to Buburimu Peninsula, take exit H to Map 2" },
                        { text = "   - Or: Survival Guide to Buburimu > Abyssea warp > zone in, take exit H" },
                        { text = "   - Does NOT need to be on COR to spawn NM" },
                        { text = "4. Examine Iron Door to spawn NM: Lost Soul - defeat it" },
                        { text = "5. Check Iron Door again for cutscene with Imutira - receive Wheel Lock Trigger" },
                        { text = "6. Return to (???) in Arrapago Reef (H-10) for cutscene" },
                        { text = "7. Speak to Ratihb in ", location = "Aht Urhgan Whitegate (J-12)", detail = "may need to speak twice" },
                    }
                },
                {
                    name = "AF2 - Navigating the Unfriendly Seas (COR 50+)",
                    reward = "Corsair's Culotte",
                    steps = {
                        { text = "   Items needed: Lamian Fang Key, fishing rod + bait" },
                        { text = "1. Examine (???) in ", location = "Arrapago Reef (H-10) Map 1", detail = "need Lamian Fang Key - can switch jobs after" },
                        { text = "2. Fish up a Hydrogauge in Al Zahbi, Aht Urhgan Whitegate, Nashmau, or Ferry:" },
                        { text = "   - Any rod and bait works" },
                        { text = "   - Recommended: large fish rod (S.H. Fishing Rod) with Insect Balls in Whitegate" },
                        { text = "   - Message: 'You feel something pulling at your line'" },
                        { text = "3. Trade Hydrogauge to Leleroon at ", location = "Nashmau (G-7)" },
                        { text = "4. Head to Wajaom Woodlands (G-8) and trade Hydrogauge to the Leypoint" },
                        { text = "   - Olduum Ring or Survival Guide nearby for quick access" },
                        { text = "5. Wait 1 minute then examine Leypoint again" },
                        { text = "6. Return to (???) in Arrapago Reef (H-10) Map 1 for reward" },
                    }
                },
                {
                    name = "AF3 - Against All Odds (COR 50+)",
                    reward = "Corsair's Tricorne",
                    steps = {
                        { text = "   Items needed: Life Float (received in quest)" },
                        { text = "1. Go to Shararat Teahouse in ", location = "Aht Urhgan Whitegate (K-12)", detail = "must be on COR - receive Life Float" },
                        { text = "   - After cutscene can commission crafted AF from Leleroon" },
                        { text = "   - Can switch to any job for rest of quest" },
                        { text = "2. Travel to The Ashu Talif in Arrapago Reef:" },
                        { text = "   Option A: Dvucca Isle Staging Point > Caedarva Mire Map 2 > west to (F-9) > zone into Arrapago Reef entrance 3 > north to (H-8)" },
                        { text = "   Option B: Survival Guide in Caedarva Mire > west out of tunnel > south into Arrapago Reef right beside Ashu Talif" },
                        { text = "3. Approach the Cutter for cutscene" },
                        { text = "4. Examine the Cutter to enter battlefield vs Yazquhl and Gowam:" },
                        { text = "   - Up to 6 players, no level cap, buffs wear on entry, Trusts allowed" },
                        { text = "5. Receive Corsair's Tricorne after post-fight cutscene" },
                        { text = "   - If you lose, return after 1 real day (midnight JST) for new Life Float" },
                    }
                },
                {
                    name = "Crafted AF - Leleroon (after Against All Odds)",
                    reward = "Corsair's Gants / Bottes / Frac",
                    steps = {
                        { text = "Speak to Leleroon at ", location = "Nashmau (G-7)", detail = "choose which piece you want first" },
                        { text = "   - Receive Leleroon's Letter (color matches piece)" },
                        { text = "   - Trade materials first, then coins separately to the NPC" },
                        { text = "   - Wait 1 game day and change zones to receive armor" },
                        { text = "" },
                        { text = "Corsair's Gants (Hands) - Leleroon's Letter (green):" },
                        { text = "   - NPC: Zhuk Vojahom - examine Door: House in ", location = "Windurst Waters (E-7 NW corner)" },
                        { text = "   - Materials: Gold Thread + Karakul Leather + Red Grass Cloth + Wamoura Silk" },
                        { text = "   - Fee: 4x Imperial Mythril Pieces" },
                        { text = "" },
                        { text = "Corsair's Bottes (Feet) - Leleroon's Letter (blue):" },
                        { text = "   - NPC: Watzahl - examine Door: House in ", location = "Bastok Mines (I-7)", detail = "top floor, dead end of walk bridge" },
                        { text = "   - Materials: Karakul Leather + Lm. Bf. Leather + Mythril Sheet + Wolf Felt" },
                        { text = "   - Fee: 4x Imperial Mythril Pieces" },
                        { text = "" },
                        { text = "Corsair's Frac (Body) - Leleroon's Letter (red):" },
                        { text = "   - NPC: Raqtibahl in Rusty Anchor Pub in ", location = "Port San d'Oria" },
                        { text = "   - Materials: Gold Chain + Red Grass Cloth + Sailcloth + Velvet Cloth" },
                        { text = "   - Fee: 1x Imperial Gold Piece" },
                    },
                    notes = {
                        "Trade materials to the DOOR not the NPC directly for Gants and Bottes",
                        "Must zone AND wait 1 game day to receive each finished piece"
                    }
                }
            }
        },

        GEO = {
            name = "Geomancer",
            requirements = {
                "Main job level 30+",
                "Petrified Log",
                "Fistful of homeland soil"
            },
            steps = {
                { text = "1. Speak to Sylvie in ", location = "Western Adoulin (I-5)" },
                { text = "2. Obtain Petrified Log" },
                { text = "3. Get homeland soil from your nations crag:" },
                { text = "   - San d'Oria - ", location = "Crag of Holla" },
                { text = "   - Windurst - ", location = "Crag of Mea" },
                { text = "   - Bastok - ", location = "Crag of Dem" },
                { text = "   Note: Check for \"Ergon Locus (???)\" under the telepoint stairs" },
                { text = "4. Trade items to Sylvie" },
                { text = "5. Visit Ergon Locus in ", location = "Ceizak Battlegrounds (K-10)" },
                { text = "6. Use /heal and wait for message (up to 8 minutes)" }
            },
            af_quests = {
                {
                    name = "AF1 - For Whom the Bell Tolls (GEO 90+)",
                    reward = "Filiae Bell + Dowser's Wand + 4,000-10,000 Bayld",
                    steps = {
                        { text = "1. Speak to Sylvie at ", location = "Western Adoulin (I-5)", detail = "Waterfront Waypoint #9 - must be on GEO, can switch after" },
                        { text = "2. Speak to Nhili Uvolep at ", location = "Eastern Adoulin (I-7)", detail = "Sverdhried Hillock Waypoint #7" },
                        { text = "   - If you get Trial Wand or wrong cutscene, talk to her again (no zoning needed)" },
                        { text = "3. Travel to Morimar Basalt Fields Frontier Station at (K-10) - speak to Vestavius" },
                        { text = "4. Travel to Morimar Basalt Fields (J-6) NW corner (east from Bivouac #2)" },
                        { text = "   - Examine Ergon Locus (???) south of the giant rock (not sparkling) for cutscene" },
                        { text = "   - Receive Silver Luopan key item (or Bayld if you don't get KI)" },
                        { text = "5. Examine Ergon Locus (???) a second time to spawn NM: Deranged Ameretat (~75k HP)" },
                        { text = "   - Uses Sweet Breath and Bad Breath (Extremely Bad Breath below 50% - run out of range)" },
                        { text = "   - NM won't use EBB while Indi- or Geo- enfeeble is active" },
                        { text = "   - High Magic Evasion and damage reduction, immune to nearly all enfeebles including Stun" },
                        { text = "   - Recommended: ranged Trusts (Apururu, Semih Lafihna, Tenzen II, Makki-Chebukki)" },
                        { text = "6. After defeat, examine Ergon Locus (???) a third time for cutscene - lose Silver Luopan" },
                        { text = "7. Return to Sylvie at ", location = "Western Adoulin (I-5)", detail = "for reward" },
                        { text = "   - Must wait 1 game day before next quest" },
                    }
                },
                {
                    name = "AF2 - The Bloodline of Zacariah (GEO 90+)",
                    reward = "Geomancy Mitaines",
                    steps = {
                        { text = "   Must wait until next game day after For Whom the Bell Tolls" },
                        { text = "   Items needed: 3x Acuex Ore" },
                        { text = "1. Speak to Sylvie at ", location = "Western Adoulin (I-5)", detail = "must be on GEO, can switch after" },
                        { text = "   - Flagging this quest unlocks crafted AF from Wescolina at (H-7) Western Adoulin" },
                        { text = "2. Obtain 3x Acuex Ore:" },
                        { text = "   - Buy from AH (Materials > Smithing)" },
                        { text = "   - Farm from Putrid Acuex or Flatus Acuex in Cirdas Caverns" },
                        { text = "3. Trade 3x Acuex Ore to Sylvie" },
                        { text = "4. Head to Cirdas Caverns (M-8/9) - examine Overgrown Grave for cutscene:" },
                        { text = "   - Fastest: Cirdas Caverns Augural Conveyor warp" },
                        { text = "   - Alt: Yorcia Weald Frontier Station" },
                        { text = "   - Colonization Reive at (M-8) may block path - clear it first" },
                        { text = "5. Speak to Nhili Uvolep at ", location = "Eastern Adoulin (I-7)", detail = "Sverdhried Hillock Waypoint #7 - receive Geomancy Mitaines" },
                    }
                },
                {
                    name = "AF3 - The Communion (GEO 90+)",
                    reward = "Geomancy Pants + up to 10,000 Bayld",
                    steps = {
                        { text = "   Must wait until next game day after The Bloodline of Zacariah" },
                        { text = "   WARNING: Unload FastCS before Nhili Uvolep cutscene and set 30 FPS" },
                        { text = "   (//lua u fastcs) and (//config FrameRateDivisor 2)" },
                        { text = "1. Speak to Sylvie at ", location = "Western Adoulin (I-5)", detail = "must be on GEO, can switch after" },
                        { text = "2. Speak to Nhili Uvolep at ", location = "Eastern Adoulin (I-7)", detail = "Waypoint #7 - receive Lhaiso Neftereh's Bell" },
                        { text = "   - Talk twice if you get wrong cutscene or Geomancerrific quest" },
                        { text = "3. Head to Cirdas Caverns (M-8/9) - examine Overgrown Grave for cutscene" },
                        { text = "   - Fastest: Cirdas Caverns Augural Conveyor warp" },
                        { text = "   - Clear Colonization Reive if blocking path" },
                        { text = "4. Examine Overgrown Grave again to spawn NM: Ancestral Rage (~70k HP)" },
                        { text = "   - Gravitation elemental (Earth + Darkness) with very high physical damage reduction" },
                        { text = "   - Uses Sleepga II, AOE Drain, AOE Aspir" },
                        { text = "   - Entomb (AOE Earth, Slow, Petrify, Hate Reset) and Tenebral Crush (AOE Darkness, Def Down)" },
                        { text = "   - Formless Strikes does NOT work" },
                        { text = "   - Can be slept with Repose and Lullaby" },
                        { text = "5. After defeat, examine Overgrown Grave again for cutscene" },
                        { text = "6. Return to Sylvie for final cutscene, Geomancy Pants, title, and lose bell KI" },
                    }
                },
                {
                    name = "Relic AF - Wescolina + Hestefa (after The Communion)",
                    reward = "Bagua Galero/Tunic/Mitaines/Pants/Sandals",
                    steps = {
                        { text = "--- Step 1: Get Tapestry of Bagua Poetry ---" },
                        { text = "Speak to Hestefa in ", location = "Celennia Memorial Library", detail = "Eastern Adoulin HP #2 or Scouts Coalition Waypoint #2" },
                        { text = "   - Must be wearing all 5 pieces of GEO Artifact armor (can mix +2/+3, NOT +4)" },
                        { text = "   - Cannot have Futharkic Concepts in Flux KI from RUN Relic quest" },
                        { text = "   - Receive: Tapestry of Bagua Poetry" },
                        { text = "--- Step 2: Get Crystallized Lifestream Essence ---" },
                        { text = "Speak to Nhili Uvolep at ", location = "Eastern Adoulin (I-7)", detail = "Waypoint #7 - hand over tapestry" },
                        { text = "Head to Outer Ra'Kaznar - Outer Ra'Kaznar Augural Conveyor is fastest warp" },
                        { text = "   - With GEO as main job, check Geomantic Fumes at (L-8) for cutscene" },
                        { text = "   - Head south from entrance then west to find roots - target is nearby" },
                        { text = "   - Receive: Crystallized Lifestream Essence" },
                        { text = "--- Step 3: Commission from Wescolina (H-7 Western Adoulin) ---" },
                        { text = "   - Receive claim slip, return next game day for armor piece" },
                        { text = "   - No day wait between pieces (unlike Artifact)" },
                        { text = "" },
                        { text = "Each piece costs 97,000 Bayld + one of these material sets:" },
                        { text = "Bagua Galero (Head): Griffon Leather + Sekishitsu + Raaz Leather" },
                        { text = "   - Or: Griffon Leather + Frontier Soda" },
                        { text = "Bagua Tunic (Body): Griffon Leather + Ether Leather + Akaso Cloth" },
                        { text = "   - Or: Griffon Leather + Chocolate Crepe" },
                        { text = "Bagua Mitaines (Hands): Griffon Leather + Bismuth Sheet + Akaso Thread" },
                        { text = "   - Or: Griffon Leather + Campfire Chocolate" },
                        { text = "Bagua Pants (Legs): Griffon Leather + Ether Cotton + Akaso Cloth" },
                        { text = "   - Or: Griffon Leather + Cascade Candy" },
                        { text = "Bagua Sandals (Feet): Griffon Leather + Ether Cotton + Sparkstrand" },
                        { text = "   - Or: Griffon Leather + Trail Cookie" },
                    },
                    notes = {
                        "ALL pieces require 97,000 Bayld fee in addition to materials",
                        "Simplified route: use food items (Frontier Soda etc.) instead of crafted materials"
                    }
                },
                {
                    name = "Empyrean AF - Treasures of the Earth (GEO 99)",
                    reward = "Azimuth Coat + Hood/Gloves/Tights/Gaiters",
                    steps = {
                        { text = "   Requires: Completed all GEO quests + turned in Crystallized Lifestream Essence to Wescolina" },
                        { text = "1. Speak to Sylvie at ", location = "Western Adoulin (I-5)", detail = "Waterfront Waypoint #9 - must be on GEO" },
                        { text = "2. Go to Morimar Basalt Fields (J-6) NE of Bivouac #2 - check Ergon Locus (???) for cutscene" },
                        { text = "3. Go to (G/H-7) - ascend Scalable Area NW side of Hot Spring - head east to (H-6/7)" },
                        { text = "   - Check (???) at base of cliff overhang beneath the Ergon Locus for cutscene" },
                        { text = "   - If no Climbing KI: die, Tractor, and Raise twice down from Bivouac #5" },
                        { text = "4. Return to Sylvie - choose one of 3 challenge fights:" },
                        { text = "" },
                        { text = "Option A - Lv109 Solo (Holla crystal of gales) - La Theine Plateau:" },
                        { text = "   - Check Ergon Locus (???) at Crag of Holla (K-8) - Trusts allowed, no Fellows" },
                        { text = "   - Fight: Otherworldly Rimester (Ghost BRD) - weak to Magic Burst" },
                        { text = "   - Reward: 10,000 Bayld + Pale Azure Cloth" },
                        { text = "" },
                        { text = "Option B - Lv125 Solo (Dem crystal of dunes) - Konschtat Highlands:" },
                        { text = "   - Check Ergon Locus (???) at Crag of Dem (I-6) - Trusts allowed, 3 min limit" },
                        { text = "   - Fight: Otherworldly Rimester (Ghost) - no GEO required" },
                        { text = "   - Reward: 3 random mats (Fiendish Skin/Siren's Hair/Arachne Thread/Khroma Ore/Star Sapphire)" },
                        { text = "" },
                        { text = "Option C - Lv135 GEO Only (Mea crystal of flames) - Tahrongi Canyon:" },
                        { text = "   - Check Ergon Locus (???) at Crag of Mea (I-6) - NO Trusts or Fellows, 3 min limit" },
                        { text = "   - Fight: Otherworldly Rimester - rotating elemental weakness (check pattern)" },
                        { text = "   - Hit weakness with 3-4 Tier III+ nukes for ~80% HP in damage when weak" },
                        { text = "   - Dark Sphere is most dangerous - shadows won't absorb" },
                        { text = "   - If you fail, return to Sylvie for new Mea crystal - retry as often as needed" },
                        { text = "   - Reward: 10 random mats + 1 Codex of Etchings" },
                        { text = "" },
                        { text = "5. Return to Sylvie - receive Treatise on Azimuth Clothcraft" },
                        { text = "6. Talk to Wescolina at ", location = "Western Adoulin (H-7)" },
                        { text = "7. Talk to Helina at ", location = "Selbina (H-9)", detail = "inside Weaver's Guild" },
                        { text = "8. Wait until next game day then talk to Helina for Azimuth Coat + 15,000 XP" },
                        { text = "" },
                        { text = "--- Empyrean Set pieces from Helina (Selbina) ---" },
                        { text = "   - Discount available if completed Part 1 of Saved by the Bell (Ergon quest)" },
                        { text = "Azimuth Hood (Head): Dragua's Scale + Siren's Hair + Khroma Ore | Or 20 H-P Bayld (10 discounted)" },
                        { text = "Azimuth Gloves (Hands): Dragua's Scale + Siren's Hair + Fiendish Skin | Or 15 H-P Bayld (7 discounted)" },
                        { text = "Azimuth Tights (Legs): Dragua's Scale + Siren's Hair + Arachne Thread | Or 10 H-P Bayld (5 discounted)" },
                        { text = "Azimuth Gaiters (Feet): Dragua's Scale + Fiendish Skin + Arachne Thread | Or 25 H-P Bayld (12 discounted)" },
                    },
                    notes = {
                        "Can repeat quest fight once per Earth day or Conquest Tally for more mats",
                        "Lv135 fight: when you hit weakness, immediately nuke same element again for follow-up damage"
                    }
                },
                {
                    name = "Ergon Weapon - Saved by the Bell (Idris)",
                    reward = "Idris (GEO Ergon Staff)",
                    steps = {
                        { text = "   Requires: The Communion complete, All Coalitions Legend Rank+" },
                        { text = "   Note: Can start as any job - Idris is equippable by GEO only" },
                        { text = "   Note: If working on Epeolatry, must complete or quit it first" },
                        { text = "--- Setup ---" },
                        { text = "1. Speak to Nhili Uvolep at ", location = "Eastern Adoulin (I-7)" },
                        { text = "2. Go to Dho Gates (F-12) Map 1 - examine Inlet of Whispers for Rusted Handbell" },
                        { text = "   - Surrounded by Apex mobs that aggro sound - be careful" },
                        { text = "   - Waypoint #4 Foret de Hennetiel or HP near Dho Gates entrance" },
                        { text = "3. Return to Nhili Uvolep" },
                        { text = "4. Speak to Runje Desaali at ", location = "Eastern Adoulin (J-11)" },
                        { text = "--- Part 1 - Nodal Wand I ---" },
                        { text = "5. Trade 100 High-Purity Bayld to Geosuke (Leafkin) at ", location = "Eastern Adoulin (J-10)", detail = "can be done cumulatively" },
                        { text = "   - Receive: Emblazoned Handbell" },
                        { text = "6. Speak to Nhili Uvolep again (talk twice if needed)" },
                        { text = "7. With GEO as main job, examine Water of Whispers in Dho Gates (H-7) for 1v1 BC:" },
                        { text = "   - Foret de Hennetiel HP is close to Dho Gates entrance" },
                        { text = "   - 15 min limit, NO subjob or Trusts, no KI lost on failure, retry immediately" },
                        { text = "   - Enemy: Bygone Geomancer (Fomor) - immune to damage initially" },
                        { text = "   - Destroy her luopans (up to 3 at a time) - each destroyed = -4% HP (need 25 total)" },
                        { text = "   - Luopans take reduced damage from all elements EXCEPT the element that counters them" },
                        { text = "   - Most luopans take full darkness damage - Cataclysm can one-shot multiple at once" },
                        { text = "   - Except Geo-Languor: use Aero, Fire, or Thunder instead of Cataclysm" },
                        { text = "   - Strategy: Geo-Regen bubble + Indi-Acumen, use Coalition Ether/Potion for MP/HP" },
                        { text = "   - Tip: use elemental wheel - Geo-Slow (Earth) is weak to Wind, etc." },
                        { text = "8. Return to Nhili Uvolep - receive Nodal Wand I" },
                        { text = "--- Part 2 - Nodal Wand II (-2% luopan damage) ---" },
                        { text = "9. Trade Nodal Wand I to Runje Desaali to begin Part 2" },
                        { text = "10. Trade to Geosuke: 200 Ghastly Stones + 500 H-P Bayld + Gabbrath Meat + Rockfin Tooth + Bztavian Stinger" },
                        { text = "   - NQ stones only (+1/+2 do NOT work) - trade to Ornery Dhole for Obsidian Fragments" },
                        { text = "   - Buy NQ Ghastly Stones for 50 Obsidian Fragments each, Copper Voucher also gives frags" },
                        { text = "   - Receive: Ripple Prominence Concretion" },
                        { text = "11. Trade Nodal Wand I to Ergon Locus at ", location = "Dho Gates (E-10)", detail = "Marjami Ravine Frontier Station is nearby" },
                        { text = "   - 2 cliffs require Climbing KI - or wipe/tractor/raise up both" },
                        { text = "   - Receive: Nodal Wand II" },
                        { text = "--- Part 3 - Nodal Wand III (Mag.Acc+5, Mag.Atk+5, -3% luopan dmg) ---" },
                        { text = "12. Trade Nodal Wand II to Runje Desaali to begin Part 3" },
                        { text = "13. Trade to Geosuke: 200 Verdigris Stones + 2,500 H-P Bayld + Yggdreant Bole + Waktza Crest + Cehuetzi Pelt" },
                        { text = "   - NQ stones only - buy for 100 Obsidian Fragments each from Ornery Dhole" },
                        { text = "   - Receive: Inferno Concretion" },
                        { text = "14. Trade Nodal Wand II to Ergon Locus at ", location = "Moh Gates (K-10)", detail = "does NOT need GEO main" },
                        { text = "   - Yahse Hunting Grounds Waypoint #1 > (H-5) is close" },
                        { text = "   - 1 cliff requires Climbing KI - or wipe/tractor/raise" },
                        { text = "   - Receive: Nodal Wand III" },
                        { text = "--- Part 4 - Idris ---" },
                        { text = "15. Trade Nodal Wand III to Runje Desaali to begin Part 4" },
                        { text = "16. Trade to Geosuke: 200 Wailing Stones + 9,999 H-P Bayld + Pristine Yggrete Crystal" },
                        { text = "   - NQ stones only - buy for 200 Obsidian Fragments each from Ornery Dhole" },
                        { text = "   - Receive: Cyclone Concretion" },
                        { text = "17. Trade Nodal Wand III to Ergon Locus at ", location = "Sih Gates (K-11)", detail = "Foret de Hennetiel Frontier Station is nearby" },
                        { text = "   - Requires Watercrafting KI to reach - or wipe/tractor/raise across water" },
                        { text = "   - Receive: Idris!" },
                    },
                    notes = {
                        "Talk to Runje > 'View materials (GEO)' to check turn-in progress at any time",
                        "If you drop a Nodal Wand: talk to Geosuke multiple times > answer Yes > trade 1,000,000 gil to Runje",
                        "Macro '/item Coalition Ether <me>' for instant MP recovery during BCNM"
                    }
                }
            }
        },

        BRD = {
            name = "Bard",
            requirements = {
                "Level 30+",
                "Jeuno Reputation 1",
                "Complete 3 prerequisite quests in order",
                "Parchment (buy or craft)"
            },
            prereq_quests = {
                {
                    name = "1. The Old Monument",
                    steps = {
                        { text = "1. Talk to Mertaire in ", location = "Lower Jeuno (I-8)", detail = "Merry Minstrel Meadhouse" },
                        { text = "   - Optional: Talk to Mataligeat at the counter" },
                        { text = "2. Talk to Bki Tbujhja behind the counter in the same room" },
                        { text = "3. Obtain a Parchment:" },
                        { text = "   - Buy from Pikini-Mikini at the Warehouse in Mhaura (~2000 gil)" },
                        { text = "   - Or craft one if skill allows" },
                        { text = "4. Head to Buburimu Peninsula:" },
                        { text = "   - Fastest: Survival Guide in Bibiki Bay" },
                        { text = "   - Find hidden path in shallows at ", location = "(G-10)", detail = "western edge of Khoonta Dunes beach" },
                        { text = "   - Path takes you to (F/G-9)" },
                        { text = "5. Click the Song Runes on the west side up from the beach for a cutscene" },
                        { text = "6. Trade Parchment to the Song Runes to obtain Poetic Parchment" },
                    },
                    notes = {
                        "Quest is hidden and does NOT appear in log until completed",
                        "Do NOT buy a Parchment for the next quest - only needed here"
                    }
                },
                {
                    name = "2. A Minstrel in Despair",
                    steps = {
                        { text = "1. Return to Mertaire in ", location = "Lower Jeuno (I-8)", detail = "Merry Minstrel Meadhouse" },
                        { text = "2. Trade the Poetic Parchment to Mertaire for a cutscene" },
                        { text = "   - Reward: 2100 gil" },
                    },
                    notes = {
                        "Quest is hidden and does NOT appear in log until completed"
                    }
                },
                {
                    name = "3. Path of the Bard",
                    steps = {
                        { text = "1. Optional: Talk to Mataligeat, then talk to Mertaire" },
                        { text = "2. Talk to Bki Tbujhja in ", location = "Lower Jeuno (I-8)", detail = "Merry Minstrel Meadhouse" },
                        { text = "   - She mentions Song Runes in Valkurm Dunes" },
                        { text = "3. Head to secret beach at far west of Valkurm Dunes:" },
                        { text = "   - Fastest: Survival Guide warp for Gustav Tunnel" },
                        { text = "   - Go to the hidden beach at ", location = "(C-6)" },
                        { text = "   - Head southeast to the bottom right of (B-7)" },
                        { text = "4. Click the Song Rune for a cutscene to complete the quest" },
                        { text = "   - Reward: Bard job unlocked + 3000 gil" },
                    },
                    notes = {
                        "Quest is hidden and does NOT appear in log until completed",
                        "Do NOT bring a Parchment - not needed for this quest"
                    }
                }
            },
            af_quests = {
                {
                    name = "AF1 - Painful Memory (BRD 40+)",
                    reward = "Paper Knife",
                    steps = {
                        { text = "1. Speak to Mertaire at ", location = "Lower Jeuno (H-8)", detail = "Merry Minstrel Meadhouse - receive Mertaire's bracelet" },
                        { text = "2. Travel to Ranguemont Pass - head to pool at ", location = "(E-5)" },
                        { text = "3. Activate the Waters of Oblivion - spawns NM: Tros" },
                        { text = "   - One pop clears for multiple people in group" },
                        { text = "   - Does NOT need to be on BRD to activate - just need bracelet" },
                        { text = "4. Defeat Tros" },
                        { text = "5. Click Waters of Oblivion again for cutscene and Paper Knife" },
                    }
                },
                {
                    name = "AF2 - The Requiem (BRD 50+)",
                    reward = "Choral Slippers + Star Ring (tarnished)",
                    steps = {
                        { text = "   Items needed: Holy Water" },
                        { text = "1. Speak to Bki Tbujhja at ", location = "Lower Jeuno (H-8)", detail = "Merry Minstrel Meadhouse" },
                        { text = "   - Trade Holy Water to her" },
                        { text = "   - Optional: Speak to Malatigeat for background info" },
                        { text = "   - Can switch to any job after" },
                        { text = "2. Travel to Eldieme Necropolis via (F-5) in Batallia Downs:" },
                        { text = "   - Must go through Beaucedine Glacier to reach (F-5) entrance" },
                        { text = "   - Fastest: Voidwatch warp or Unity warp to Beaucedine Glacier" },
                        { text = "   - Lycopodium NPC teleport in Batallia Downs works if unlocked" },
                        { text = "3. Head to room with 5 unbroken sarcophagi at (D-4)" },
                        { text = "4. Trade Holy Water to a sarcophagus - spawns 3 skeleton NMs:" },
                        { text = "   - Yum Kimil (BLM ~Lv60-65), Dog Guardian, Owl Guardian (~Lv50-55)" },
                        { text = "   - Sarcophagus that spawns NMs is random - try the side with 3, closest to exit door" },
                        { text = "   - Resistant to Lullaby even at 75 BRD" },
                        { text = "   - Does NOT need to be on BRD to activate" },
                        { text = "5. Defeat all 3 NMs then interact with same sarcophagus again" },
                        { text = "   - Receive cutscene and Star Ring (tarnished)" },
                        { text = "   - Others doing quest can trade their Holy Water after fight for their cutscene" },
                        { text = "6. Return to Bki Tbujhja for Choral Slippers" },
                    }
                },
                {
                    name = "AF3 - The Circle of Time (BRD 50+)",
                    reward = "Choral Justaucorps",
                    steps = {
                        { text = "   Items needed: Star Ring (tarnished) from AF2" },
                        { text = "1. Speak to Mertaire in Lower Jeuno" },
                        { text = "2. Speak to Imasuke at ", location = "Port Jeuno (E-6)", detail = "must be on BRD - can switch after" },
                        { text = "3. Travel to Xarcabard (I-10) - examine Perennial Snow at end of short tunnel" },
                        { text = "   - Wait 1 Earth minute then examine again to receive Star Ring (indecipherable)" },
                        { text = "4. Return to Imasuke in Port Jeuno" },
                        { text = "5. Go to Chateau d'Oraguille - speak to Chalvatot at (F-7) for Moon Ring" },
                        { text = "6. Travel to Monastic Cavern via Davoi at (H-11)" },
                        { text = "7. Walk to small circular room at (I-8) with altar" },
                        { text = "   - Beware True Sight Orcish Warlord roaming the area - clear Orcs first" },
                        { text = "8. Examine altar to spawn NM: Bugaboo - defeat it" },
                        { text = "9. Examine altar again for cutscene" },
                        { text = "10. Return to Chalvatot for Choral Justaucorps" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Harmonious Hands (BRD 50+)",
                    reward = "Choral Cuffs + Roundlet + Cannions",
                    steps = {
                        { text = "   Requires: Started The Requiem" },
                        { text = "   Items needed: Zvahl Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on BRD" },
                        { text = "2. Go to Castle Zvahl Baileys and find a Treasure Coffer" },
                        { text = "   - Farm or buy Zvahl Coffer Key (Curio Vendor Moogle needs Rhapsody in Umber KI)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on BRD to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map - MUST be on BRD for this step" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine same torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (BRD must be main job):" },
                        { text = "   - Crawlers Nest coffer > Choral Roundlet" },
                        { text = "   - Castle Oztroja coffer > Choral Cannions" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Must be on BRD to spawn Dark Spark - unique requirement for this job",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        DRK = {
            name = "Dark Knight",
            requirements = {
                "Level 30+",
                "Complete 2 prerequisite quests",
                "Chaosbringer sword (received in quest)",
                "100 kills with Chaosbringer equipped"
            },
            prereq_quests = {
                {
                    name = "1. Blade of Darkness (Main unlock quest)",
                    steps = {
                        { text = "1. Talk to Gumbah in ", location = "Bastok Mines (J-7)", detail = "upper floor, across bridge toward Alchemy Guild" },
                        { text = "   - Talk until you get the correct quest cutscene" },
                        { text = "   - Check quest log to confirm before heading out" },
                        { text = "   - Note: Inheritance (Ground Strike) quest takes priority - confirm correct dialogue" },
                        { text = "2. Travel to Palborough Mines Map 3 (H-8):" },
                        { text = "   - Fastest: Palborough Mines Home Point #1 at (H-10)" },
                        { text = "   - Or: Port Bastok > North Gustaberg (K-3) > Palborough > 3rd floor" },
                        { text = "   - Pull the boat lever on the 3rd floor to ride it" },
                        { text = "3. Receive cutscene and Chaosbringer in Zeruhn Mines" },
                        { text = "   - Chaosbringer is a Lv1 Great Sword usable by WAR/DRK/RUN" },
                        { text = "   - Anyone can pull the lever - just make the trip" },
                        { text = "4. Kill 100 enemies with Chaosbringer equipped as the killing blow:" },
                        { text = "   - Must be a standard/critical melee strike - NOT weapon skills or abilities" },
                        { text = "   - Abilities like Jump do NOT count" },
                        { text = "   - Monster suicides (Bomb Toss, Self-Destruct, Final Sting) do NOT count" },
                        { text = "   - Enemy does NOT need to give EXP - any enemy counts" },
                        { text = "   - Nothing resets count except dropping the sword" },
                        { text = "   - Tip: Sub BLM and nuke to weaken, then finish with Chaosbringer" },
                        { text = "   - Tip: Use RoE 'Area Kills' quest to help track count" },
                        { text = "5. Travel to Beadeaux via ", location = "Pashhow Marshlands (L-11)", detail = "zone in with Chaosbringer in inventory" },
                        { text = "   - Chaosbringer must be in inventory but does NOT need to be equipped" },
                        { text = "   - Can travel as ANY job" },
                        { text = "   - Can also use the Beadeaux Survival Guide warp" },
                        { text = "   - Cutscene upon zoning unlocks Dark Knight" },
                    },
                    notes = {
                        "Pashhow Marshlands reached from top-right of Konschtat or bottom of Rolanberry Fields",
                        "If you drop Chaosbringer take the Palborough ferry again for a new one",
                        "Consider doing Blade of Death (200 kills total) at same time"
                    }
                },
                {
                    name = "2. Blade of Death (Optional - rewards Deathbringer)",
                    steps = {
                        { text = "1. Talk to Gumbah in ", location = "Bastok Mines (J-7)", detail = "receive Letter from Zeid" },
                        { text = "   - Requires Bastok Reputation 3" },
                        { text = "2. Kill another 100 enemies with Chaosbringer (200 total from first receipt)" },
                        { text = "   - Kills from Blade of Darkness count - just reach 200 total" },
                        { text = "   - Same rules apply: melee killing blow only, no WS/abilities" },
                        { text = "3. Travel to Gusgen Mines - go to standing water at ", location = "(J-7) Map 1" },
                        { text = "   - From entrance: take right at first intersection" },
                        { text = "   - Take left at next intersection" },
                        { text = "   - Short distance, tunnel off to the right" },
                        { text = "   - Follow bend, another tunnel to right leads to pond at (J-7)" },
                        { text = "4. Trade Chaosbringer to the (???) in the water for cutscene with Zeid" },
                        { text = "   - Chaosbringer replaced with Deathbringer (Lv5 DRK Great Sword)" },
                    },
                    notes = {
                        "NM Smothered Schmidt spawns at pond - detects by sound, use Sneak or Silent Oil",
                        "If Chaosbringer dropped, take Palborough ferry again for new one (resets kills)"
                    }
                }
            },
            af_quests = {
                {
                    name = "AF1 - Dark Legacy (DRK 40+)",
                    reward = "Raven Scythe",
                    steps = {
                        { text = "   Items needed: Yagudo Cherry" },
                        { text = "1. Speak to Raibaht in ", location = "Metalworks (G-8)", detail = "must be on DRK - can switch after" },
                        { text = "2. Speak to Mighty Fist in ", location = "Metalworks (G-9)", detail = "lower level inside Darksteel Forge - receive Letter from Darksteel Forge" },
                        { text = "3. Travel to Windurst Waters - speak to Cochal-Monchal at ", location = "(F-8)", detail = "HP #1 North Map, Optistery" },
                        { text = "4. Get a Yagudo Cherry (vendor or AH) - one is enough for multiple players" },
                        { text = "5. Travel to Giddeus - trade Yagudo Cherry to (???) at ", location = "(H-14)" },
                        { text = "   - Clear area before trading - spawns NM: Vaa Huja the Erudite" },
                        { text = "6. Defeat Vaa Huja the Erudite" },
                        { text = "7. Click (???) again for key item: Darksteel Formula" },
                        { text = "8. Return to Raibaht in ", location = "Metalworks (G-8)", detail = "for Raven Scythe" },
                    }
                },
                {
                    name = "AF2 - Dark Puppet (DRK 50+)",
                    reward = "Chaos Sollerets",
                    steps = {
                        { text = "   Items needed: Darksteel Ingot (one enough for multiple players)" },
                        { text = "1. Speak to Cid in ", location = "Metalworks (G-8)", detail = "must be on DRK - can switch after" },
                        { text = "2. Obtain a Darksteel Ingot from AH or crafting" },
                        { text = "3. Zone into Ordelle's Caves for a cutscene" },
                        { text = "   - Survival Guide and Voidwatch warp both go to same entrance" },
                        { text = "4. Take east path (B) - trade Darksteel Ingot to (???) at ", location = "Ordelle's Caves Map 1 (I-8)" },
                        { text = "   - Spawns NM: Gerwitz's Axe" },
                        { text = "5. Defeat Gerwitz's Axe - drops Gerwitz's Axe (item)" },
                        { text = "   - Defeated = need new Darksteel Ingot to respawn" },
                        { text = "6. Head south up ramp (D) - at (H-11/12) drop down SE hole - go east to Map 3 (E)" },
                        { text = "7. Trade Gerwitz's Axe to (???) at ", location = "Map 3 (H-8)", detail = "spawns Gerwitz's Sword" },
                        { text = "8. Defeat Gerwitz's Sword - drops Gerwitz's Sword (item)" },
                        { text = "9. Head south to large square room" },
                        { text = "10. Trade Gerwitz's Sword to (???) at (H-10) - spawns Gerwitz's Soul" },
                        { text = "11. Defeat Gerwitz's Soul" },
                        { text = "   - All party members in zone get credit even if too far for EXP" },
                        { text = "12. Head to La Theine Plateau exit at (G-10) for cutscene and Chaos Sollerets" },
                    }
                },
                {
                    name = "AF3 - Blade of Evil (DRK 50+)",
                    reward = "Chaos Burgeonet",
                    steps = {
                        { text = "   Items needed: Quadav Mage Blood (from Topaz Quadav)" },
                        { text = "1. Travel to Beadeaux - zone in from Pashhow Marshlands for cutscene to start quest" },
                        { text = "   - Fastest: Survival Guide > Derfland > Beadeaux, exit to Pashhow then re-enter" },
                        { text = "   - Can switch to any job after" },
                        { text = "2. Farm Topaz Quadav until Quadav Mage Blood drops" },
                        { text = "   - One is enough for a group" },
                        { text = "3. Go to Qufim - enter Delkfutt's Tower and climb to Floor 7 (Middle Delkfutt's Tower)" },
                        { text = "4. Use teleporter at (J-6) on Floor 7 to go down one floor" },
                        { text = "   - Puts you in circular chamber with no exits and a (???)" },
                        { text = "5. Trade Quadav Mage Blood to (???) to spawn Gerwitz's Scythe + 2 Scythe Victims" },
                        { text = "   - Only need to defeat Gerwitz's Scythe to progress" },
                        { text = "6. Defeat NMs then board teleporter back upstairs" },
                        { text = "   - Quest completes and you receive Chaos Burgeonet" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Shadowy Hands (DRK 50+)",
                    reward = "Chaos Gauntlets + Flanchard + Cuirass",
                    steps = {
                        { text = "   Requires: Started Dark Puppet" },
                        { text = "   Items needed: Eldieme Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on DRK" },
                        { text = "2. Go to The Eldieme Necropolis and find a Treasure Coffer" },
                        { text = "   - Buy Magicked Astrolabe from Churano-Shurano in ", location = "Windurst Waters (F-8)", detail = "10,000 gil, opens doors solo" },
                        { text = "   - Farm or buy Eldieme Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on DRK to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine same torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (DRK must be main job):" },
                        { text = "   - Monastic Cavern coffer > Chaos Flanchard" },
                        { text = "   - Castle Oztroja coffer > Chaos Cuirass" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        SCH = {
            name = "Scholar",
            requirements = {
                "Wings of the Goddess expansion",
                "Level 30+ as BLM, RDM, SMN, or BLU",
                "One Hour Ability ready (Manafont/Chainspell/Astral Flow/Azure Lore)",
                "12 sheets of Vellum (or 144 Rolanberries to trade for them)"
            },
            steps = {
                { text = "1. Enter The Eldieme Necropolis (S) via ", location = "Batallia Downs (S) (J-10)" },
                { text = "   - Or speak to your nation Campaign Arbiter for direct teleport (if visited before)" },
                { text = "2. Talk to Erlene at ", location = "Eldieme Necropolis (S) (J-8)", detail = "she asks for 12 sheets of Vellum" },
                { text = "3. Head to Crawlers Nest (S) (K-8) and talk to Tucker to get Vellum:" },
                { text = "   - Trade 4 stacks of Rolanberries per trade, 3 trades total (12 stacks = 12 Vellum)" },
                { text = "   - Rolanberries: buy from Gekko or Champalpieu in Jeuno (~120 gil each)" },
                { text = "   - MUST talk to Erlene first or Tucker will not trade" },
                { text = "4. Switch to BLM, RDM, SMN, or BLU (any level - does not need to be 30+)" },
                { text = "   - Make sure your One Hour Ability is NOT on cooldown" },
                { text = "5. Return to Erlene and trade 12 sheets of Vellum for a cutscene" },
                { text = "6. Activate your One Hour Ability while still at Erlene:" },
                { text = "   - BLM: Manafont  |  RDM: Chainspell  |  SMN: Astral Flow  |  BLU: Azure Lore" },
                { text = "7. Talk to Erlene while the One Hour effect is still active for final cutscene" },
                { text = "   - Scholar appears in job list after cutscene with Schultz" },
            },
            notes = {
                "If you traded Vellum but forgot correct job, leave and change job - no need to get Vellum again",
                "12 stacks Rolanberries = 17,280 gil total if buying from vendors",
                "Can do quest as BLM/RDM/SMN/BLU at any level as long as original job was 30+"
            },
            af_quests = {
                {
                    name = "AF1 - On Sabbatical (SCH 40+)",
                    reward = "Klimaform",
                    steps = {
                        { text = "1. Speak to Erlene in ", location = "The Eldieme Necropolis (S) (J-8)", detail = "receive Ulbrecht's Sealed Letter" },
                        { text = "2. Speak to Gentle Tiger in ", location = "Bastok Markets (S) (H-6)", detail = "may need to speak twice" },
                        { text = "3. Travel to SW corner of Pashhow Marshlands (S) - touch Indescript Markings at (E-11)/(E-10) border" },
                        { text = "   - Level ~80 Virulent Peistes aggro on sight in the area - use Invisible or kill them" },
                        { text = "   - Receive: Schultz's Sealed Letter" },
                        { text = "4. Return to Erlene for Klimaform Schema" },
                    }
                },
                {
                    name = "AF2 - Downward Helix (SCH 50+)",
                    reward = "Scholar's Bracers",
                    steps = {
                        { text = "   Must zone and wait until next game day after On Sabbatical" },
                        { text = "1. Speak to Erlene at ", location = "The Eldieme Necropolis (S) (J-8)", detail = "must be on SCH" },
                        { text = "2. Zone into Southern San d'Oria (S) from East Ronfaure (S)" },
                        { text = "   - Survival Guide and telecrystal will NOT work - must walk in" },
                        { text = "3. Return to Erlene and speak to her" },
                        { text = "4. Zone into Sauromugue Champaign (S) from Rolanberry Fields (S) for cutscene" },
                        { text = "5. Examine Indescript Markings in ", location = "Sauromugue Champaign (S) (J-7)", detail = "SE corner of quadrant on the ledge near a (???)" },
                        { text = "   - Markings disappear during Earth Dusty weather" },
                        { text = "   - Receive: Ulbrecht's Mortarboard" },
                        { text = "6. Return to Erlene for Scholar's Bracers" },
                        { text = "   - After this quest unlock crafted AF from Loussaire in Bastok Markets (S) (G-10)" },
                    }
                },
                {
                    name = "AF3 - Seeing Blood-red (SCH, any level)",
                    reward = "Scholar's Mortarboard",
                    steps = {
                        { text = "   Must zone and wait until next game day after Downward Helix" },
                        { text = "1. Speak to Erlene at ", location = "The Eldieme Necropolis (S) (J-8)", detail = "must be on SCH - can switch after" },
                        { text = "2. Travel to Indescript Markings in Pashhow Marshlands (S) at N edge of (E-11)" },
                        { text = "   - Recall-Pashh telepoint or Survival Guide puts you at south end" },
                        { text = "   - Receive: Unaddressed Sealed Letter" },
                        { text = "3. Read the Unaddressed Sealed Letter from your Temporary Key Item menu" },
                        { text = "4. Return to Erlene for cutscene - receive Porting Magic Transcript" },
                        { text = "5. Go to Grauberg (S) (E-10) - enter cave opposite the waterfall" },
                        { text = "   - Cave entrance is on boundary of (E-10)/(F-10) on dry land before waterfall" },
                        { text = "   - Examine unnamed shimmering light on the ground" },
                        { text = "6. Inspect Indescript Marking on cave wall to enter instance (Ruhotz Silvermines)" },
                        { text = "   - Only party leader with quest active can enter the party" },
                        { text = "   - If you fail: trade Erlene a Sheet of Vellum for new Porting Magic Transcript" },
                        { text = "7. Fight Ulbrecht (SCH Lv67, ~12,000 HP) - 30 min limit, up to 6 players, Trusts allowed:" },
                        { text = "   - Uses Dark Arts Stratagems, Dagger (Wasp Sting), and random tier III nukes" },
                        { text = "   - Immune to Silence - can be Slept, Bound, Gravity'd" },
                        { text = "   - At ~50% uses Tabula Rasa and spams spells" },
                        { text = "   - Battle ends when HP drops below 20%" },
                        { text = "8. Return to Erlene for Scholar's Mortarboard" },
                    }
                },
                {
                    name = "Crafted AF - Loussaire (after Downward Helix)",
                    reward = "Loafers / Pants / Gown",
                    steps = {
                        { text = "Speak to Loussaire at ", location = "Bastok Markets (S) (G-10)", detail = "must be on SCH to start, any job after" },
                        { text = "   - Receive armor immediately but must zone and wait game day to start next piece" },
                        { text = "" },
                        { text = "Scholar's Loafers (Feet):" },
                        { text = "   - Rafflesia Dreamspit: Indescript Markings in Fort Karugo-Narugo (S)" },
                        { text = "   - Locations: (I-9),(I-10),(H-8),(G-7),(H-5),(G-5) - moves each time gathered" },
                        { text = "   - Drogarogan Bonemeal: Indescript Markings in Meriphataud Mountains (S) (E-7)" },
                        { text = "   - South side of spine - appears 7:00-17:00 game time" },
                        { text = "" },
                        { text = "Scholar's Pants (Legs):" },
                        { text = "   - Slug Mucus: Indescript Markings in Pashhow Marshlands (S) where Slugs roam" },
                        { text = "   - Possible locations: (J-6),(G-6),(K-5),(I-6),(I-7) - moves after each gather" },
                        { text = "   - Djinn Ember: Indescript Markings in Vunkerl Inlet (S) at (D-11)" },
                        { text = "   - Appears with Thunder weather or possibly at 16:00-6:00 game time" },
                        { text = "" },
                        { text = "Scholar's Gown (Body):" },
                        { text = "   - Peiste Dung: Indescript Markings in Pashhow Marshlands (S) (K-8)-(H-10) in Peiste areas" },
                        { text = "   - Sample of Grauberg Chert: Indescript Markings in Grauberg (S) at (D-8)" },
                    },
                    notes = {
                        "Indescript Markings can be weather or time dependent - check notes if not spawning",
                        "Zone and wait for game day change after each piece to continue"
                    }
                }
            }
        },

        BST = {
            name = "Beastmaster",
            requirements = {
                "Level 30+ on any job",
                "Complete all 3 prerequisite quests in order"
            },
            prereq_quests = {
                {
                    name = "1. Chocobo's Wounds (Level 20+)",
                    steps = {
                        { text = "1. Talk to Brutus in ", location = "Upper Jeuno Chocobo Stables (G-7)" },
                        { text = "   - If Chocobo on the Loose! triggers first, talk to Brutus 2 more times" },
                        { text = "   - Choose 'Nope, never!' to start Chocobo's Wounds instead" },
                        { text = "2. Obtain 4x Gausebit Grass:" },
                        { text = "   - Buy from AH under Weapons > Ammo & Misc. > Pet Items" },
                        { text = "   - Farm from Crane Flies in ", location = "Meriphataud Mountains (E-5)", detail = "near outpost, ~42% drop" },
                        { text = "   - Farm from Wadi Hares in Dangruf Wadi (lower drop rate)" },
                        { text = "3. Trade Gausebit Grass to the chocobo next to Osker" },
                        { text = "   - First 2 trades will be rejected (chocobo still scared)" },
                        { text = "   - Wait ~1 real minute between each feeding attempt" },
                        { text = "   - Successfully feed all 4 to complete the quest" },
                        { text = "4. Optional: Visit Dietmund's door in ", location = "Lower Jeuno (G-11)", detail = "for cutscene" },
                    },
                    notes = {
                        "Do NOT confuse Gausebit Grass with Gysahl Greens - wrong item",
                        "Feedings do not need to be consecutive days",
                        "Quest does NOT appear in log until completion"
                    }
                },
                {
                    name = "2. Save My Son (Level 30+)",
                    steps = {
                        { text = "1. Examine Door: Merchant's House in ", location = "Lower Jeuno (G-11)", detail = "above chocobo stables" },
                        { text = "   - Dietmund answers and asks for a herb" },
                        { text = "2. Optional: Talk to Shalott in ", location = "Upper Jeuno (G-7)", detail = "outside Chocobo Stables" },
                        { text = "3. Go to ", location = "Qufim Island (F-8)" },
                        { text = "   - Find the path going down along the cliff at (F-8)" },
                        { text = "   - Go all the way down/around to the right of the map marker" },
                        { text = "   - Night Flowers are at the bottom in a seaside cave" },
                        { text = "4. Examine Night Flowers between 21:30 and 4:00 for cutscene" },
                        { text = "5. Return to Door: Merchant's House in ", location = "Lower Jeuno (G-11)", detail = "for reward" },
                    },
                    notes = {
                        "Use Sneak/Silent Oil - Kraken (37-38) may spawn on the flowers",
                        "Arrive before 20:00 to avoid Banshee aggro at night",
                        "Goblin Bounty Hunter patrols the cliff path - use Invisible",
                        "NM Atkorkamuy spawns at (F-8) - not aggressive but high level",
                        "Map marker is slightly east - go right of blue marker"
                    }
                },
                {
                    name = "3. Path of the Beastmaster (Level 30+)",
                    steps = {
                        { text = "1. Talk to Brutus in ", location = "Upper Jeuno Chocobo Stables (G-7)" },
                        { text = "   - If Chocobo on the Loose! triggers:" },
                        { text = "   - Talk to the boy near the steps caring for the chocobo" },
                        { text = "   - Talk to Brutus again to bypass it" },
                        { text = "   - May need multiple attempts to get the correct cutscene" },
                        { text = "2. Zone out of Upper Jeuno to receive Beastmaster" },
                        { text = "3. Optional: Click Dietmund's door in ", location = "Lower Jeuno (G-11)", detail = "for thank you cutscene" },
                    },
                    notes = {
                        "Quest does NOT appear in your quest log until completion",
                        "If stuck, try zoning and talking to Brutus again"
                    }
                }
            },
            af_quests = {
                {
                    name = "AF1 - Wings of Gold (BST 40+)",
                    reward = "Barbaroi Axe",
                    steps = {
                        { text = "1. Speak to Brutus at ", location = "Upper Jeuno (G-7)", detail = "must be on BST Lv40+ - can switch after" },
                        { text = "2. Kill monsters on floors 7-10 of Upper Delkfutt's Tower for Delkfutt Chest Key:" },
                        { text = "   - Drops from: Gigas Wallwatcher/Kettlemaster/Spirekeeper/Torturer/Bonecutter" },
                        { text = "   - Also: Gigas Stonemason/Punisher/Hallwatcher/Sculptor, Magic Urn, Evil Spirit" },
                        { text = "   - Light Elemental, Thunder Elemental" },
                        { text = "   - Or buy from Curio Vendor Moogle" },
                        { text = "3. Use key to open a chest in the zone - receive Guiding Bell" },
                        { text = "4. Return to Brutus for Barbaroi Axe" },
                    }
                },
                {
                    name = "AF2 - Scattered Into Shadow (BST 50+)",
                    reward = "Beast Gaiters",
                    steps = {
                        { text = "   Items needed: Oztroja Chest Key, Beast Collar (from chest)" },
                        { text = "1. Speak to Brutus at ", location = "Upper Jeuno (G-7)", detail = "receive 3 Aquaflora key items - can switch jobs after" },
                        { text = "2. Go to Fei'Yin Map 2 - examine 3 pools in order:" },
                        { text = "   - Home Point #2 closest warp (just outside Cloister of Frost)" },
                        { text = "   - Pool 1: (H-8), Pool 2: (H-5), Pool 3: (F-5)" },
                        { text = "3. After examining (F-5), NM Dabotz's Ghost spawns (can spawn at any pool)" },
                        { text = "   - Remove Sneak before examining - NM spawns in water and won't aggro otherwise" },
                        { text = "   - Dabotz's Ghost is a BLM - casts Tornado and uses Curse often" },
                        { text = "4. Defeat Dabotz's Ghost then check pool at (F-5) again" },
                        { text = "5. Return to Brutus for cutscene" },
                        { text = "6. Go to Castle Oztroja - kill monsters for Oztroja Chest Key" },
                        { text = "   - Or buy from Curio Vendor Moogle" },
                        { text = "7. Open chest in castle to receive Beast Collar" },
                        { text = "8. Trade Beast Collar to Tebhi (Opo-opo NPC) near brass door to magicite pond" },
                        { text = "   - Tebhi roams the indoor pond - Tebhi disappears for 3 min after accepting" },
                        { text = "9. Return to Brutus for Beast Gaiters" },
                    }
                },
                {
                    name = "AF3 - A New Dawn (BST 50+)",
                    reward = "Beast Trousers",
                    steps = {
                        { text = "   Items needed: Mahogany Lumber" },
                        { text = "1. Examine Door: Merchant's House at ", location = "Lower Jeuno (G-11)", detail = "upper level behind Greyson at HP #1" },
                        { text = "   - Can switch to any job after cutscene" },
                        { text = "2. Trade Mahogany Lumber to Osker near chocobos and Brutus at ", location = "Upper Jeuno (G-7)" },
                        { text = "   - Receive Tamer's Whistle" },
                        { text = "3. Enter The Eldieme Necropolis from (F-5) entrance:" },
                        { text = "   - Zone into Batallia Downs from Beaucedine Glacier then enter (F-5)" },
                        { text = "   - Or use Lycopodium NPC warp in Batallia Downs if unlocked" },
                        { text = "   - Voidwatch/Unity warps to Beaucedine Glacier also work" },
                        { text = "4. Inside, head to (D-4) - clear room if low level" },
                        { text = "5. Examine the NE sarcophagus - spawns 3 NMs:" },
                        { text = "   - Taifun (Tiger), Trombe (Tiger), Sturm (Hound)" },
                        { text = "   - Only Sturm needs to be defeated - tigers can be charmed to help" },
                        { text = "6. Defeat Sturm then examine sarcophagus for cutscene and Beast Trousers" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Wild Hands (BST 50+)",
                    reward = "Beast Gloves + Helm + Jackcoat",
                    steps = {
                        { text = "   Requires: Started Scattered Into Shadow" },
                        { text = "   Items needed: Nest Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on BST" },
                        { text = "2. Go to Crawler's Nest and find a Treasure Coffer" },
                        { text = "   - Farm or buy Nest Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on BST to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine same torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (BST must be main job):" },
                        { text = "   - Garlaige Citadel coffer > Beast Helm" },
                        { text = "   - Beadeaux coffer > Beast Jackcoat" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        SMN = {
            name = "Summoner",
            requirements = {
                "Main job level 30+",
                "Carbuncle's Ruby (Rare/Ex)",
                "Access to outdoor areas"
            },
            steps = {
                { text = "1. Obtain Carbuncle's Ruby" },
                { text = "   - Drops from Leech-type mobs (Bloodsucker, Bouncing Ball)" },
                { text = "   - Recommended areas: ", location = "Bostaunieux Oubliette or Toraimarai Canal" },
                { text = "   - TH increases drop rate" },
                { text = "2. Go to House of the Hero in ", location = "Windurst Walls (G-3)" },
                { text = "3. Collect seven colors by experiencing different weather types:" }
            },
            weather_requirements = {
                { color = "Red", element = "Fire", weather = "Heat Wave", areas = "Valkurm Dunes, Cape Teriggan, Eastern Altepa Desert" },
                { color = "Orange", element = "None", weather = "Clear Skies", areas = "West/East Sarutabaruta, Valkurm Dunes" },
                { color = "Yellow", element = "Earth", weather = "Dust Storms", areas = "Tahrongi Canyon, Konschtat Highlands" },
                { color = "Green", element = "Wind", weather = "High Winds", areas = "Tahrongi Canyon, La Theine Plateau" },
                { color = "Blue", element = "Water", weather = "Rain", areas = "La Theine Plateau, Jugner Forest" },
                { color = "Indigo", element = "Ice", weather = "Snow", areas = "Beaucedine Glacier, Xarcabard" },
                { color = "Violet", element = "Lightning", weather = "Thunderstorms", areas = "Konschtat Highlands, Jugner Forest" }
            },
            warnings = {
                "Cannot use Wings of the Goddess zones",
                "Must be outdoor, enemy-populated areas",
                "Cannot use Scholar weather effects",
                "Qufim Island and Behemoth's Dominion do NOT work"
            },
            af_quests = {
                {
                    name = "AF1 - The Puppet Master (SMN 40+)",
                    reward = "Kukulcan's Staff",
                    steps = {
                        { text = "   Items needed: Earth Pendulum (received in quest)" },
                        { text = "1. Interact with House of the Hero in ", location = "Windurst Walls (G-4)", detail = "HP #1 - must be on SMN" },
                        { text = "2. Speak to Juroro in ", location = "Port Bastok (I-8)", detail = "HP #1 - receive Earth Pendulum" },
                        { text = "3. Travel through Quicksand Caves to Cloister of Tremors:" },
                        { text = "   - HP #2 is at the entrance to Cloister of Tremors" },
                        { text = "   - Enter Quicksand Caves via Eastern Altepa Desert at (K-7)" },
                        { text = "   - Drop down twice using red arrow paths to reach (C-9)" },
                        { text = "4. Trade Earth Pendulum to Protocrystal to enter battlefield" },
                        { text = "   - Fight NM: Galgalim (Lv56) - Trusts allowed" },
                        { text = "   - Galgalim has Fire Spikes, Poison, and Paralyze" },
                        { text = "5. Speak to Juroro again after the fight" },
                        { text = "6. Speak to Koru-Moru in ", location = "Windurst Walls (E-7)", detail = "for Kukulcan's Staff" },
                    }
                },
                {
                    name = "AF2 - Class Reunion (SMN 50+)",
                    reward = "Evoker's Spats",
                    steps = {
                        { text = "   Must zone after The Puppet Master before starting" },
                        { text = "   Items needed: 4x Astragalos, Ice Pendulum (received in quest)" },
                        { text = "1. Interact with House of the Hero in ", location = "Windurst Walls", detail = "must be on SMN - receive Carbuncle's Tear" },
                        { text = "2. Speak to Koru-Moru at ", location = "Windurst Walls (E-7)", detail = "he asks for 4 Astragalos" },
                        { text = "   - Buy Astragalos from Bonecrafting Guild in Windurst Woods from Shih Tayuun" },
                        { text = "3. Trade 4x Astragalos to Koru-Moru" },
                        { text = "4. Speak to these 3 NPCs in any order:" },
                        { text = "   - Fuepepe: east Aurastery in ", location = "Windurst Waters North (L-6)", detail = "may need to talk multiple times" },
                        { text = "   - Furakku-Norakku: east Opistery in ", location = "Windurst Waters North (G-8)" },
                        { text = "   - Shantotto: her manor in ", location = "Windurst Walls (K-7)", detail = "talk until she mentions Sunny-Pabonny" },
                        { text = "5. Speak to Gulmama in ", location = "Northern San d'Oria (E-7)", detail = "receive Ice Pendulum" },
                        { text = "6. Head to Cloister of Frost in Fei'Yin (HP #2 is closest):" },
                        { text = "   - Enter Fei'Yin via Beaucedine Glacier at (J-4) or Unity warp" },
                        { text = "   - Go to (G-9) Map 1 > downstairs > zone into Cloister at (I-5) Map 2" },
                        { text = "7. Trade Ice Pendulum to Protocrystal - fight 6 Dryads (Trusts allowed)" },
                        { text = "   - All 6 share hate - can be difficult to solo at lower levels" },
                        { text = "8. Speak to Koru-Moru for Evoker's Spats" },
                    }
                },
                {
                    name = "AF3 - Carbuncle Debacle (SMN 50+)",
                    reward = "Evoker's Horn",
                    steps = {
                        { text = "   Must zone after Class Reunion before starting" },
                        { text = "   Items needed: Lightning Pendulum, Daze-breaker charm, Wind Pendulum (all in quest)" },
                        { text = "1. Interact with House of the Hero in ", location = "Windurst Walls", detail = "must be on SMN" },
                        { text = "2. Speak to Koru-Moru at ", location = "Windurst Walls (E-7)" },
                        { text = "3. Travel to Mhaura - speak to Ripapa at (I-9) for Lightning Pendulum" },
                        { text = "4. Travel to Cloister of Storms via Sanctuary of Zi'Tah (K-12) > Boyahda Tree:" },
                        { text = "   - In Boyahda Tree go upstairs at (B-7) then to (J-12) on next map" },
                        { text = "   - HP #1 is closest" },
                        { text = "5. Trade Lightning Pendulum to Lightning Protocrystal - fight:" },
                        { text = "   - Lightning Gremlin (drains TP) and Thunder Gremlin (drains MP)" },
                        { text = "   - Both resist sleep" },
                        { text = "   - WARNING: BCNM cutscene may freeze - unload FastCS or reduce to 30 FPS" },
                        { text = "6. Return to Koru-Moru in ", location = "Windurst Walls (E-7)", detail = "receive Daze-breaker Charm" },
                        { text = "7. Go to Rabao - speak to Agado-Pugado at (G-9) for Wind Pendulum" },
                        { text = "8. Travel to Cloister of Gales via Western Altepa > Kuftal Tunnel > Cape Teriggan:" },
                        { text = "   - Zone into Kuftal Tunnel from Western Altepa at (H-4)" },
                        { text = "   - Go through to exit all the way north on Map 1" },
                        { text = "   - Cloister is at (F-5) in Cape Teriggan" },
                        { text = "9. Trade Wind Pendulum to Wind Protocrystal - fight NM: Ogmios (Manticore)" },
                        { text = "10. Return to Koru-Moru in ", location = "Windurst Walls (E-7)", detail = "for Evoker's Horn" },
                    },
                    notes = {
                        "BCNM cutscene freeze fix: unload FastCS when it pauses, or use //config FrameRateDivisor 2"
                    }
                },
                {
                    name = "AF4 - Borghertz's Calling Hands (SMN 50+)",
                    reward = "Evoker's Bracers + Doublet + Pigaches",
                    steps = {
                        { text = "   Requires: Started Class Reunion" },
                        { text = "   Items needed: Grotto Coffer Key (or Thief's Tools) + Mythril Beastcoin" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on SMN" },
                        { text = "2. Head to Sea Serpent Grotto and find a Treasure Coffer:" },
                        { text = "   Option A - Unity Warp (Lv125) > Sea Serpent Grotto Map 4 (L-5):" },
                        { text = "   - Open Gold Door, go north, find Mythril Door" },
                        { text = "   - Examine Mythril Door until it mentions mythril dust, trade Mythril Beastcoin to open" },
                        { text = "   Option B - Use Proto-Waypoint to teleport to (J-5) Map 3 behind Mythril Door" },
                        { text = "   - Coffer spawns: (H-7),(I-9),(H-8),(G-6),(F-6),(G-10),(F-9),(D-9),(E-11)" },
                        { text = "   - Farm/buy Grotto Coffer Key or pick lock as THF - NOT need to be on SMN to open" },
                        { text = "   - Also drops from: Blubber Eyes, Bog/Marsh/Swamp Sahagin, Razorjaw Pugil, Rock Crab" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (SMN must be main job):" },
                        { text = "   - Temple of Uggalepih coffer > Evoker's Doublet" },
                        { text = "   - Toraimarai Canal coffer > Evoker's Pigaches" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        PUP = {
            name = "Puppetmaster",
            requirements = {
                "Main job level 30+",
                "Access to Aht Urhgan areas",
                "Ability to reach Arrapago Reef"
            },
            steps = {
                { text = "1. Talk to Shamarhaan near fountain in ", location = "Bastok Markets (F-9)" },
                { text = "2. Talk to Iruki-Waraki (top floor) in ", location = "Aht Urhgan Whitegate (K-9)" },
                { text = "3. Talk to Ghatsad in Automaton Workshop (top floor) in ", location = "Aht Urhgan Whitegate (I-7)" },
                { text = "4. Travel to Arrapago Reef:" },
                { text = "   Option A - From Nashmau:" },
                { text = "   - Take ferry from Port Ephramad to Nashmau" },
                { text = "   - Exit Nashmau North to ", location = "Caedarva Mire (H-6)" },
                { text = "   - Zone into Arrapago Reef at ", location = "Caedarva Mire (I-6)" },
                { text = "   Option B - Using Survival Guide:" },
                { text = "   - Use Aht Urhgan Whitegate Survival Guide to teleport to Arrapago Reef entrance" },
                { text = "   Option C - Using Runic Portal:" },
                { text = "   - Use Runic Portal to Azouph Isle Staging Point" },
                { text = "   - Head to tunnel at ", location = "(I-6)" },
                { text = "5. Find (???) under stairs on south/first boat in ", location = "Arrapago Reef Map 1 (H-10)" },
                { text = "6. Return to Ghatsad in ", location = "Aht Urhgan Whitegate (I-7)" },
                { text = "7. Wait until next game day, talk to Ghatsad again" },
                { text = "8. Return to Iruki-Waraki in ", location = "Aht Urhgan Whitegate (K-9)" }
            },
            warnings = {
                "Dangerous mobs in Caedarva Mire:",
                "- Imps (True Sight aggro)",
                "- Chigoes (Hidden nameplates until aggro)",
                "- Treants (Sound aggro)",
                "Cannot be invisible when examining (???)",
                "Mobs will aggro level 99 characters"
            },
            af_quests = {
                {
                    name = "AF1 - The Wayward Automaton (PUP 40+)",
                    reward = "Turbo Animator",
                    steps = {
                        { text = "1. Talk to Iruki-Waraki in ", location = "Aht Urhgan Whitegate (K-9)", detail = "2nd floor, Way of the Devout" },
                        { text = "2. Go to Nashmau and talk to Dnegan at ", location = "Nashmau (H-6)", detail = "2nd floor" },
                        { text = "   - Can switch to any job here before spawning the NM" },
                        { text = "3. Exit Nashmau east gate, head to east side of lake at ", location = "(I-10)" },
                        { text = "   - Cross lily pads to reach island with (???)" },
                        { text = "4. Click (???) to spawn NM: Caedarva Toad - defeat it" },
                        { text = "5. Check (???) again for cutscene" },
                        { text = "   - If you zone before clicking (???) you must fight the NM again" },
                        { text = "6. Return to Iruki-Waraki in ", location = "Aht Urhgan Whitegate (K-9)", detail = "receive Turbo Animator" },
                    }
                },
                {
                    name = "AF2 - Operation Teatime (PUP 50+)",
                    reward = "Puppetry Churidars",
                    steps = {
                        { text = "   Items needed: Sleeping Potion, Chai, Lamian Fang Key" },
                        { text = "1. Zone after AF1 then talk to Iruki-Waraki in ", location = "Aht Urhgan Whitegate (K-9)" },
                        { text = "2. Trade Iruki-Waraki a Sleeping Potion and a Chai for cutscene:" },
                        { text = "   - Sleeping Potion: Auction House" },
                        { text = "   - Chai: Shararat Teahouse (K/J-12) in southern Whitegate" },
                        { text = "3. Go to Nashmau and talk to Dnegan at ", location = "Nashmau (H-6)", detail = "2nd floor" },
                        { text = "   - Question 1: Choose 'Ask how to get around Nashmau' OR 'Shall we go out for tea?'" },
                        { text = "   - Question 2: Choose Chai OR Coffee (either works)" },
                        { text = "   - Question 3: Choose 'the cup with a suspicious VAPOR'" },
                        { text = "4. Exit Nashmau north gate to Caedarva Mire" },
                        { text = "   - Get Lamian Fang Key at ", location = "Caedarva Mire (I-7)", detail = "small ledge behind a Jnun - once per game day" },
                        { text = "   - Enter Arrapago Reef at (I-6)" },
                        { text = "5. Navigate Arrapago Reef:" },
                        { text = "   - Open Iron Gate at (J-10) with Lamian Fang Key" },
                        { text = "   - Run north to (H-7) and open door, go through" },
                        { text = "   - Head north to tunnel entrance at (I-6)" },
                        { text = "   - Go east then take fork south through tunnel back to Caedarva Mire" },
                        { text = "6. Shortly after exiting, click (???) for cutscene" },
                        { text = "   - Do NOT drop down or you must walk through Arrapago Reef again" },
                        { text = "7. Iruki-Waraki rewards you after the cutscene" },
                    },
                    notes = {
                        "Selecting 'Ask about the automaton' on Q1 ends cutscene - retry next game day",
                        "Selecting 'I'll pass, thanks' on Q2 ends cutscene - retry next game day"
                    }
                },
                {
                    name = "AF3 - Puppetmaster Blues (PUP 50+)",
                    reward = "Puppetry Taj",
                    steps = {
                        { text = "   Key Items needed: Valkeng's Memory Chip, Toggle Switch" },
                        { text = "1. Talk to Iruki-Waraki in ", location = "Aht Urhgan Whitegate (K-9)" },
                        { text = "2. Speak to Shamarhaan in ", location = "Bastok Markets (F-9)", detail = "receive Valkeng's Memory Chip" },
                        { text = "3. Go to Mount Zhayolm (L-8) and click (???) near cliff edge on flat circular vent" },
                        { text = "   - Receive Toggle Switch key item" },
                        { text = "   - Access via Halvung Staging Point in Aht Urhgan Whitegate" },
                        { text = "4. Travel to Talacca Cove:" },
                        { text = "   - Fastest: Home Point #1 in Caedarva Mire (right at entrance)" },
                        { text = "   - Or: Nashmau west exit > Caedarva Mire west then north to (E-9)" },
                        { text = "5. In Talacca Cove follow the left wall to Rock Slab at (F-6)" },
                        { text = "6. Click Rock Slab to enter BCNM: Puppetmaster Blues" },
                        { text = "   - Level restriction applied on entry, buffs wear, Trusts disappear" },
                        { text = "   - Trusts can be called once inside" },
                        { text = "   - Max 6 party members, 30 minute time limit" },
                        { text = "7. After fight answer the question (answer does not matter)" },
                        { text = "8. Return to Shamarhaan in ", location = "Bastok Markets (F-9)", detail = "for cutscene" },
                        { text = "9. Return to Iruki-Waraki in ", location = "Aht Urhgan Whitegate (K-9)", detail = "for cutscene" },
                        { text = "10. Speak to Sajhra at ", location = "Nashmau (H-9)", detail = "Nashmau Pier exit" },
                        { text = "   - Pay 100 gil boarding fee, go around building to reach Sajhra" },
                        { text = "11. Return to Iruki-Waraki for final cutscene and Puppetry Taj" },
                    },
                    notes = {
                        "BCNM Boss: Valkeng changes frames based on highest damage type dealt",
                        "Physical damage > switches to Valoredge (high DEF, fast attacks)",
                        "Magical damage > switches to Stormwaker (resist magic, Chainspell at 25%)",
                        "Ranged damage > switches to Sharpshot (high ACC/EVA, fires every 4-5s)",
                        "Balance damage types to avoid locking Valkeng into a hard frame",
                        "If you fail BCNM you keep key items and can retry"
                    }
                },
                {
                    name = "Crafted AF - Dhima Polevhia (after AF3)",
                    reward = "Babouches / Dastanas / Tobe",
                    steps = {
                        { text = "Talk to Dhima Polevhia in ", location = "Aht Urhgan Whitegate (J-8)", detail = "2nd floor, north of Iruki-Waraki" },
                        { text = "   - Trade materials + Imperial currency together in one trade" },
                        { text = "   - Wait until next Vana'diel day then talk to her to receive piece" },
                        { text = "   - Must receive previous piece before commissioning the next one" },
                        { text = "   - Can choose any order for the 3 pieces" },
                        { text = "" },
                        { text = "Puppetry Babouches (Feet - Lv54):" },
                        { text = "   - Ruby + Platinum Sheet + Marid Leather + Wamoura Cloth" },
                        { text = "   - Fee: 2x Imperial Mythril Pieces" },
                        { text = "" },
                        { text = "Puppetry Dastanas (Hands - Lv56):" },
                        { text = "   - Rainbow Thread + Wamoura Cloth + Marid Leather + Platinum Sheet" },
                        { text = "   - Fee: Imperial Mythril Piece" },
                        { text = "" },
                        { text = "Puppetry Tobe (Body - Lv58):" },
                        { text = "   - Scarlet Linen + Moblinweave + Wamoura Cloth + Ruby" },
                        { text = "   - Fee: Imperial Gold Piece" },
                    },
                    notes = {
                        "Imperial currency from Ugrihd in Whitegate via Imperial Standing Points",
                        "Silver Piece = 100 pts  |  Mythril Piece = 200 pts  |  Gold Piece = 1000 pts"
                    }
                }
            }
        },

        NIN = {
            name = "Ninja",
            requirements = {
                "Level 30+",
                "Access to Norg via:",
                "- Kazham Airship Pass OR",
                "- RoV Mission: The Beginning"
            },
            steps = {
                { text = "1. Talk to Kaede in ", location = "Port Bastok (J-5)", detail = "northernmost house" },
                { text = "2. Talk to Kagetora in ", location = "Port Bastok (F-6)", detail = "Warehouse 2, upper floor, western warehouse" },
                { text = "3. Talk to Ensetsu in ", location = "Port Bastok (J-5)" },
                { text = "4. Get Strangely Shaped Coral:" },
                { text = "   - Go to ", location = "Korroloka Tunnel Map 5 (L-8)" },
                { text = "   - Find (???) that spawns three Korroloka Leeches" },
                { text = "   - Kill leeches and click (???) for coral" },
                { text = "5. Return to Ensetsu in ", location = "Port Bastok (J-5)" },
                { text = "6. Travel to Norg:" },
                { text = "   Port Jeuno → Kazham → Yuhtunga Jungle → Sea Serpent Grotto → Norg" },
                { text = "7. Talk to Ryoma on the docks in ", location = "Norg (H-8)" },
                { text = "8. Return to Ensetsu in ", location = "Port Bastok (J-5)" }
            },
            warnings = {
                "Leech Fight Warnings:",
                "- Leeches immediately attack player who checks (???)",
                "- Thread Leeches nearby will link",
                "- Ghosts spawn in the area",
                "Sea Serpent Grotto Warnings:",
                "- Need Sneak (blood aggro at level 30)",
                "- Multiple aggressive mobs en route to Norg"
            },
            af_quests = {
                {
                    name = "AF1 - 20 in Pirate Years (NIN 40+)",
                    reward = "Anju + Zushio",
                    steps = {
                        { text = "1. Talk to Ryoma at ", location = "Norg (H-8)", detail = "Home Point #1 - must be on NIN" },
                        { text = "2. Speak to Kagetora inside Warehouse #2 at ", location = "Port Bastok (F-6)", detail = "HP #3" },
                        { text = "3. Speak to Ensetsu at ", location = "Port Bastok (I-5)" },
                        { text = "4. Travel to Eastern Altepa Desert (H-5)/(H-6)" },
                        { text = "   - Can switch to any job at this point" },
                        { text = "   - Fastest: Survival Guide to Western Altepa Desert then zone to Eastern" },
                        { text = "5. Clear area then examine (???)" },
                        { text = "   - Spawns 2 Spider NMs: Tsuchigumo (non-sleepable)" },
                        { text = "6. Defeat both Tsuchigumo - wait for corpses to disappear" },
                        { text = "7. Click (???) again for Trick Box" },
                        { text = "8. Return to Ryoma in Norg for Anju + Zushio" },
                    }
                },
                {
                    name = "AF2 - I'll Take the Big Box (NIN 50+)",
                    reward = "Ninja Hakama",
                    steps = {
                        { text = "   Must zone and re-enter Norg after 20 in Pirate Years before starting" },
                        { text = "   Items needed: Oak Pole (buy with Sparks)" },
                        { text = "1. Speak to Ryoma in Norg" },
                        { text = "2. Talk to Ensetsu at ", location = "Port Bastok (I-5)" },
                        { text = "3. Go to Rabao - talk to Leodarion at ", location = "(F-8)", detail = "west side of lake near windmill" },
                        { text = "4. Trade Oak Pole to Leodarion (costs 156 Sparks from RoE NPC):" },
                        { text = "   - Rolandienne: Southern San d'Oria (G-10)" },
                        { text = "   - Isakoth: Bastok Markets (E-11)" },
                        { text = "   - Fhelm Jobeizat: Windurst Woods (J-10)" },
                        { text = "   - Eternal Flame: Western Adoulin (H-11)" },
                        { text = "   - Found under 'Equ. Lv. 40-50' Page 2" },
                        { text = "5. Speak to Leodarion again next Vana'diel day - receive Seance Staff" },
                        { text = "6. Take ferry from Mhaura to Selbina at nighttime:" },
                        { text = "   - Ferry at 16:00 departure - NM Enagakure spawns at 20:00" },
                        { text = "   - Ferry at 0:00 departure - NM already on deck, disappears at 4:00" },
                        { text = "   - UNLOAD FastCS addon - it will boot you to Selbina at night" },
                        { text = "7. Defeat NM: Enagakure on main deck" },
                        { text = "8. Make sure you have 1 free inventory slot - wait until ferry docks in Selbina" },
                        { text = "   - Receive cutscene and Ninja Hakama upon arrival" },
                    },
                    notes = {
                        "FastCS or similar addons must be disabled for ferry night spawn"
                    }
                },
                {
                    name = "AF3 - True Will (NIN 50+)",
                    reward = "Ninja Chainmail",
                    steps = {
                        { text = "   Items needed: Kuftal Coffer Key (or Thief's Tools)" },
                        { text = "1. Speak to Ryoma in Norg" },
                        { text = "2. Travel to Yhoator Jungle (I-7):" },
                        { text = "   - Fastest: Survival Guide (Elshimo Uplands > Yhoator Jungle)" },
                        { text = "   - Unity Warp (Lv122) puts you at (J-7)" },
                        { text = "3. Examine (???) at (I-7) NW of Bloodlet Spring - spawns 3 Sahagin NMs:" },
                        { text = "   - Kappa Akuso (MNK), Kappa Biwa (BRD), Kappa Bonze (WHM)" },
                        { text = "   - Only need to kill ONE - zone to Den of Rancor to split them" },
                        { text = "4. After defeating - wait for corpses to disappear then examine (???) for Old Trick Box" },
                        { text = "5. Return to Ryoma in Norg for cutscene" },
                        { text = "6. Go to Rabao - speak to Leodarion at ", location = "(F-7)", detail = "west side of lake near windmill" },
                        { text = "7. Go to Kuftal Tunnel - obtain Kuftal Coffer Key:" },
                        { text = "   - Fastest: Survival Guide (Vollbow > Kuftal Tunnel) or Unity Warp (Lv125)" },
                        { text = "   - Or buy from Curio Vendor Moogle" },
                        { text = "8. Open Treasure Coffer for Large Trick Box" },
                        { text = "9. Return to Leodarion for Ninja Chainmail" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Lurking Hands (NIN 50+)",
                    reward = "Ninja Tekko + Kyahan + Hatsuburi",
                    steps = {
                        { text = "   Requires: Started I'll Take the Big Box" },
                        { text = "   Items needed: Cauldron Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on NIN" },
                        { text = "2. Go to Ifrit's Cauldron and find a Treasure Coffer:" },
                        { text = "   - Unity Warp (Lv122) > Yhoator Jungle > hug right wall" },
                        { text = "   - Or use Elshimo Uplands Outpost Warp or Survival Guide" },
                        { text = "   - Farm or buy Cauldron Coffer Key (Curio Vendor Moogle any nation)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on NIN to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Fastest: Survival Guide teleport" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine same torch for Shadow flames (can return later if forgotten)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (NIN must be main job):" },
                        { text = "   - Sea Serpent Grotto coffer > Ninja Kyahan" },
                        { text = "   - Requires: Trade Mythril Beastcoin to Mythril Door for Map 3 access" },
                        { text = "   - Boyahda Tree coffer > Ninja Hatsuburi" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Sea Serpent Grotto: interact with Mythril Door until it mentions mythril dust, then trade Mythril Beastcoin",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        SAM = {
            name = "Samurai",
            requirements = {
                "Level 30+",
                "Access to Norg",
                "Access to Sanctuary of Zi'tah",
                "Access to Konschtat Highlands",
                "Hatchet (tool)"
            },
            steps = {
                { text = "1. Talk to Jaucribaix in ", location = "Norg (K-8)", detail = "upper level, end of hallway" },
                { text = "2. Talk to Aeka in ", location = "Norg (I-8)", detail = "receive Oriental Steel" },
                { text = "3. Talk to Ranemaud in ", location = "Norg (I-7)", detail = "receive Sacred Sprig" },
                { text = "4. Sacred Branch - First Item:" },
                { text = "   - Go to ", location = "Sanctuary of Zi'tah (K-10)" },
                { text = "   - Follow east path to unmapped area at ", location = "(L-10)" },
                { text = "   - Climb rocks at base of large tree" },
                { text = "   - Trade/Use Hatchet at (???) to spawn Guardian Treant" },
                { text = "   - Defeat Guardian Treant" },
                { text = "   - Trade Sacred Sprig to (???) for Sacred Branch" },
                { text = "5. Bomb Steel - Second Item:" },
                { text = "   - Go to cave in ", location = "Konschtat Highlands (D-8)" },
                { text = "   - Trade Oriental Steel to (???) to spawn Forger" },
                { text = "   - Defeat Forger for Bomb Steel" },
                { text = "6. Return to Jaucribaix in ", location = "Norg (K-8)" },
                { text = "7. Wait 3 game days (about 3 real hours)" },
                { text = "8. Talk to Jaucribaix for final cutscene" }
            },
            warnings = {
                "Guardian Treant has 10 minute respawn timer",
                "If you fail Forger fight, need new Oriental Steel",
                "Multiple Forger spawns need 1-2 minute wait between",
                "Keep Mumeito for future AF quest"
            },
            af_quests = {
                {
                    name = "AF1 - The Sacred Katana (SAM 40+)",
                    reward = "Magoroku",
                    steps = {
                        { text = "   Items needed: Sack of Fish Bait (from Goblin Robbers), Mumeito" },
                        { text = "1. Talk to Jaucribaix at ", location = "Norg (K-8)", detail = "near Captain's Chamber - must be on SAM, can switch after" },
                        { text = "2. Travel to Sanctuary of Zi'Tah - kill Goblin Robbers for Sack of Fish Bait (common drop)" },
                        { text = "3. Trade Fish Bait to (???) at ", location = "Sanctuary of Zi'Tah (E-8)", detail = "spawns NM: Isonade (~6,100 HP)" },
                        { text = "4. Defeat Isonade - re-examine (???) for Handful of Crystal Scales" },
                        { text = "5. Return to Norg - trade Mumeito to Jaucribaix for Magoroku" },
                        { text = "   - If you lost Mumeito: Ranemaud at (I-7) sells replacement for 30,000 gil" },
                    }
                },
                {
                    name = "AF2 - Yomi Okuri (SAM 50+)",
                    reward = "Myochin Sune-Ate",
                    steps = {
                        { text = "   Must zone after The Sacred Katana before starting" },
                        { text = "   Items needed: Bastore Sardine, Frost Turnip, Giant Sheep Meat, Hecteyes Eye" },
                        { text = "1. Speak to Jaucribaix in ", location = "Norg (K-8)" },
                        { text = "2. Speak to Washu at ", location = "Norg (J-8)" },
                        { text = "3. Trade Washu all 4 ingredients - receive Washu's tasty wurst" },
                        { text = "4. Go to Labyrinth of Onzozo - examine (???) at (F-8) to spawn NM: Ubume" },
                        { text = "   - Fastest: Survival Guide to Labyrinth of Onzozo (G-11) near Buburimu zone" },
                        { text = "   - Ubume is BRD-type Greater Bird (~Lv60-65) - casts Horde Lullaby" },
                        { text = "5. Defeat Ubume - examine (???) again for Yomotsu Feather" },
                        { text = "6. Return to Norg - speak to Jaucribaix" },
                        { text = "7. Exit Norg, re-enter, speak to Jaucribaix again for Yomotsu Hirasaka" },
                        { text = "8. Go to Valkurm Dunes (B-7) - examine (???) between 18:00 and 4:00" },
                        { text = "   - Fastest: Survival Guide to Gustav Tunnel" },
                        { text = "   - Spawns NMs: Doman (Fomor ~Lv52) and Onryo (Ghost ~Lv52)" },
                        { text = "9. Defeat both NMs - wait for corpses to disappear" },
                        { text = "   - Examine (???) again for Faded Yomotsu Hirasaka" },
                        { text = "10. Speak to Jaucribaix for Myochin Sune-Ate" },
                    }
                },
                {
                    name = "AF3 - A Thief in Norg!? (SAM 50+)",
                    reward = "Myochin Kabuto",
                    steps = {
                        { text = "   Must zone after Yomi Okuri before starting" },
                        { text = "   Items needed: Gold Thread" },
                        { text = "1. Speak to Jaucribaix in ", location = "Norg (K-8)" },
                        { text = "2. Speak to Sanosuke in ", location = "Port Jeuno (H-8)", detail = "inside Duty Free Shop" },
                        { text = "3. Speak to Phoochuchu in ", location = "Mhaura (H-8)", detail = "ground level, under the bridge" },
                        { text = "4. Examine the door on lower level in ", location = "Bastok Mines (J-6)", detail = "near Alchemy Guild" },
                        { text = "   - Door must be CLOSED - if another player has it open no cutscene" },
                        { text = "5. Enter Waughroon Shrine through Palborough Mines top floor" },
                        { text = "   - Can use Domenic for cutscene - Home Point warp is fastest if unlocked" },
                        { text = "6. Return to Jaucribaix in Norg - receive Banishing Charm" },
                        { text = "7. Trade Banishing Charm to Burning Circle in Waughroon Shrine for BC fight:" },
                        { text = "   - 3 Demons: Rasetsu (DRK), Gaki (BLM), Onki (SMN with elemental)" },
                        { text = "   - All can use 2-hour abilities - 30 minute time limit" },
                        { text = "   - Trust Magic usable inside BC" },
                        { text = "8. Defeat demons - receive Charred Helm" },
                        { text = "9. Speak to Jaucribaix - trade a Gold Thread to him" },
                        { text = "10. Zone out of Norg then return to Jaucribaix for Myochin Kabuto" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Loyal Hands (SAM 50+)",
                    reward = "Myochin Kote + Domaru + Haidate",
                    steps = {
                        { text = "   Requires: Started Yomi Okuri" },
                        { text = "   Items needed: Kuftal Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on SAM" },
                        { text = "2. Go to Kuftal Tunnel and find a Treasure Coffer:" },
                        { text = "   - Map 1 spawns: (H-7), (H-6)" },
                        { text = "   - Map 2 spawns: (K-11),(G-9),(H-9),(J-7),(J-8),(I-4),(F-6),(D-9)" },
                        { text = "   - Farm or buy Kuftal Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on SAM to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (SAM must be main job):" },
                        { text = "   - Temple of Uggalepih coffer > Myochin Domaru" },
                        { text = "   - Quicksand Caves coffer > Myochin Haidate" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        RNG = {
            name = "Ranger",
            requirements = {
                "Main job level 30+",
                "Access to Sauromugue Champaign",
                "Form of Warp recommended"
            },
            steps = {
                { text = "1. Talk to Perih Vashai in ", location = "Windurst Woods (K-7)" },
                { text = "2. Optional: Talk to guards Muhk Johldy and Kapeh Myohrye for more info" },
                { text = "3. Go to Sauromugue Champaign:" },
                { text = "   - Go to ", location = "(L-8)", detail = "climb up the cliff" },
                { text = "   - Head south to ", location = "(L-10)" },
                { text = "4. Enter cave and find Tiger Bones:" },
                { text = "   - Click Tiger Bones to spawn Old Sabertooth" },
                { text = "   - Wait for Old Sabertooth to die naturally (~3 minutes)" },
                { text = "   - Click Tiger Bones again for Old tiger's fang" },
                { text = "5. Return to Perih Vashai in ", location = "Windurst Woods (K-7)" }
            },
            warnings = {
                "3 Sabertooth Tigers guard cave entrance",
                "Do NOT kill Old Sabertooth - must die naturally",
                "If killed accidentally, wait 5 minutes to respawn"
            },
            notes = {
                "Tigers won't aggro level 40+ characters",
                "Can use mount or Invisible to avoid tigers",
                "Stay behind Tiger Bones to avoid Old Sabertooth aggro",
                "Can get fang if someone else spawned Sabertooth",
                "Just need to see death message for key item"
            },
            af_quests = {
                {
                    name = "AF1 - Sin Hunting (RNG 40+)",
                    reward = "Sniping Bow",
                    steps = {
                        { text = "   Items needed: Glittersand (from Evil Weapons), Perchond's envelope (from NPC)" },
                        { text = "1. Talk to Perih Vashai in ", location = "Windurst Woods (K-7)", detail = "receive Chieftainness's twinstone earring" },
                        { text = "2. Travel to Ranguemont Pass - talk to Perchond at ", location = "(F-10)" },
                        { text = "   - Semih Lafihna is not there - Perchond mentions Glittersand near pond" },
                        { text = "3. Go to pond at (E-5) - kill Evil Weapons until Glittersand drops" },
                        { text = "   - High level (88+) Goblins in area - use Invisible/Prism Powder if low level" },
                        { text = "4. Trade Glittersand to Perchond - receive Perchond's envelope" },
                        { text = "5. Go to Jugner Forest top of (I-6) near lake - speak to Alexius" },
                        { text = "6. Go to (H-6) in Jugner Forest - find (???) on a tree for cutscene" },
                        { text = "7. Return to Perih Vashai for Sniping Bow" },
                    }
                },
                {
                    name = "AF2 - Fire and Brimstone (RNG 50+)",
                    reward = "Hunter's Beret",
                    steps = {
                        { text = "   Must zone after Sin Hunting before starting" },
                        { text = "   Items needed: Old Earring (via Scavenge in Castle Oztroja)" },
                        { text = "1. Talk to Perih Vashai in ", location = "Windurst Woods (K-7)" },
                        { text = "2. Go to Mhaura - speak to Koh Lenbalalako at ", location = "(F-9)", detail = "Blacksmith Guild - talk twice for cutscene" },
                        { text = "3. Enter Eldieme Necropolis through ", location = "Batallia Downs (I-10)", detail = "for cutscene with Mithran Tracker" },
                        { text = "   - Survival Guide puts you at correct entrance but won't trigger cutscene" },
                        { text = "   - Must zone out and back in for cutscene" },
                        { text = "   - Does NOT need to be on RNG for this part" },
                        { text = "4. Go to (G-9) inside and examine Gravestone for cutscene" },
                        { text = "   - Magicked Astrolabe (10,000 gil from Churano-Shurano) lets you get here solo" },
                        { text = "5. Return to Perih Vashai in Windurst Woods" },
                        { text = "6. Go to Castle Oztroja - requires Scavenge (set RNG main or sub):" },
                        { text = "   - Hit correct handle at (I-8) Map 1 to go through brass door" },
                        { text = "   - Map 2: get 4-switch password at (I-10), then open brass door at (G-8)" },
                        { text = "   - Map 3: find pool with leeches at (H-9)" },
                        { text = "   - Use Scavenge in pool until Old Earring drops (may take multiple attempts)" },
                        { text = "   - Can come as high level job with RNG subjob for Scavenge" },
                        { text = "7. Trade Old Earring to Perih Vashai for Hunter's Beret" },
                    }
                },
                {
                    name = "AF3 - Unbridled Passion (RNG 50+)",
                    reward = "Hunter's Socks + 99x Ice Arrow",
                    steps = {
                        { text = "   Must zone after Fire and Brimstone before starting" },
                        { text = "   Items needed: Gold Earring" },
                        { text = "1. Talk to Perih Vashai in ", location = "Windurst Woods (K-7)" },
                        { text = "2. Go to Mhaura - speak twice to Koh Lenbalalako at ", location = "(F-9)" },
                        { text = "   - She asks for a Gold Earring" },
                        { text = "   - Gold Earring free from RoE Conflict: Xarcabard (first time completion)" },
                        { text = "3. Trade Gold Earring to Koh for cutscene - receive Koh's letter" },
                        { text = "4. Zone into Xarcabard for cutscene - hints to look near Castle Zvahl Baileys" },
                        { text = "   - Fastest: Survival Guide to Castle Zvahl Baileys" },
                        { text = "5. Find cave at (E-7) in Xarcabard - examine (???) for cutscene" },
                        { text = "   - Spawns NM: Koenigstiger - defeat it (~3 min repop)" },
                        { text = "   - Each player needs their own cutscene and kill" },
                        { text = "6. Head south to cave at (E-8) - check (???) for cutscene" },
                        { text = "7. Check (???) again for 99 Ice Arrows (optional)" },
                        { text = "8. Return to Perih Vashai for Hunter's Socks" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Chasing Hands (RNG 50+)",
                    reward = "Hunter's Bracers + Braccae + Jerkin",
                    steps = {
                        { text = "   Requires: Started Fire and Brimstone" },
                        { text = "   Items needed: Garlaige Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on RNG" },
                        { text = "2. Go to Garlaige Citadel and find a Treasure Coffer" },
                        { text = "   - Farm or buy Garlaige Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on RNG to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (RNG must be main job):" },
                        { text = "   - Crawler's Nest coffer > Hunter's Braccae" },
                        { text = "   - Monastic Cavern coffer > Hunter's Jerkin" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        BLU = {
            name = "Blue Mage",
            requirements = {
                "Main job level 30+",
                "1000 gil for divination",
                "Access to Aht Urhgan areas"
            },
            steps = {
                { text = "1. Talk to Waoud in ", location = "Aht Urhgan Whitegate (J-10)", detail = "2nd Floor" },
                { text = "2. Answer divination questions correctly:" },
                { text = "   - What is destiny? → One forges for oneself" },
                { text = "   - Does accomplishment require sacrifice? → Absolutely" },
                { text = "   - Forbidden scroll choice? → Burn the scroll" },
                { text = "   - Save 10,000 lives? → Without hesitation" },
                { text = "   - Life choice? → A chaotic life" },
                { text = "   - Life as beast vs death? → Embrace life as a beast" },
                { text = "   - Companion turns against you? → Cut him down" },
                { text = "   - End loved one's suffering? → Grant the request" },
                { text = "   - Friend dying in battle? → End his pain" },
                { text = "   - Orders vs justice? → Follow your sense of justice" },
                { text = "3. Obtain requested item (one of three):" },
                { text = "   - Dangruf Stone - From geysers (cannot be bought/traded)" },
                { text = "   - Valkurm Sunsand - From beach (can be bought at AH)" },
                { text = "   - Siren's Tear - From river (can be traded/bazaared)" }
            },
            warnings = {
                "Failed divination costs 1000 gil",
                "Must wait until next game day to retry divination",
                "Must have requested item for pool cutscene",
                "Answering 'no' three times resets quest"
            },
            af_quests = {
                {
                    name = "AF1 - Beginnings (BLU 40+)",
                    reward = "Immortal's Scimitar",
                    steps = {
                        { text = "   Requires: Aht Urhgan Mission 2 complete, BLU Lv40+" },
                        { text = "1. Speak to Waoud at ", location = "Aht Urhgan Whitegate (J-10)", detail = "select 'Gaze Away' - must be on BLU" },
                        { text = "   - Quest is from Raubahn but Waoud acts as contact" },
                        { text = "2. Visit all 5 Staging Points as BLU main and speak to Immortals:" },
                        { text = "   - Fastest: Runic Portal at (L-7) in Whitegate (200 Imperial Standing each)" },
                        { text = "   - Trade 1 Copper Voucher = 1000 Imperial Standing (enough for all 5)" },
                        { text = "   - Ilrusi Atoll SP: speak to Meyaada > Brand of the Springserpent" },
                        { text = "   - Dvucca Isle SP: speak to Nahshib > Brand of the Galeserpent" },
                        { text = "   - Halvung SP: speak to Waudeen > Brand of the Flameserpent" },
                        { text = "   - Mamool Ja SP: speak to Daswil > Brand of the Skyserpent" },
                        { text = "   - Azouph Isle SP: speak to Nareema > Brand of the Stoneserpent" },
                        { text = "3. After getting all 5 Brands, speak to Waoud again for Immortal's Scimitar" },
                    }
                },
                {
                    name = "AF2 - Omens (BLU 50+)",
                    reward = "Magus Charuqs",
                    steps = {
                        { text = "   Must zone after Beginnings before starting" },
                        { text = "   Wait 1 in-game day and re-zone into Whitegate if needed" },
                        { text = "1. Speak to Waoud at ", location = "Aht Urhgan Whitegate (J-10)" },
                        { text = "2. Travel to Navukgo Execution Chamber (Mount Zhayolm):" },
                        { text = "   - Use HP in Mount Zhayolm just outside chamber, or Unity warps (Lv128/135)" },
                        { text = "   - Does NOT need to be on BLU to enter or complete BCNM" },
                        { text = "3. Examine Decorative Bronze Gate to start BC fight:" },
                        { text = "   - Trusts allowed - up to 18 players" },
                        { text = "   - More players = more Immortal Flans spawn" },
                        { text = "4. Return to Whitegate and speak to Waoud - receive Sealed Immortal Envelope" },
                        { text = "5. Deliver envelope to Lathuya at ", location = "Aht Urhgan Whitegate (F-8)", detail = "2nd floor inside stall" },
                        { text = "6. Zone into Wajaom Woodlands from Whitegate (G/H-10 Stairwell)" },
                        { text = "   - Head south and zone into Aydeewa Subterrane entrance at (K-9)" },
                        { text = "   - No enemies in tunnel - examine unnamed target by pond at (H-7) for cutscene" },
                        { text = "7. Return to Whitegate and speak to Lathuya for Magus Charuqs" },
                    }
                },
                {
                    name = "AF3 - Transformations (BLU 50+)",
                    reward = "Magus Keffiyeh",
                    steps = {
                        { text = "   Must zone after Omens before starting" },
                        { text = "   Items needed: 1,000 gil + Imperial Silver Piece OR Remnants Permit OR Captain Wildcat Badge" },
                        { text = "1. Speak to Waoud at (J-10) as BLU Lv50+ - select 'Gaze Away'" },
                        { text = "   - He takes 1,000 gil - quest is now active" },
                        { text = "   - If you get Trust: Nashmeira cutscene, examine door again for correct cutscene" },
                        { text = "2. Check Imperial Whitegate door at (L-8) in Whitegate for cutscene" },
                        { text = "   - Can switch to any job after this point" },
                        { text = "3. Get 2 cutscenes in Alzadaal Undersea Ruins via Runic Portal route:" },
                        { text = "   - Use Runic Portal to Nyzul Isle Staging Point" },
                        { text = "   - Take north exit, step on NE teleporter at (H-8) toward Silver Sea Remnants" },
                        { text = "   - Use east teleporter, then west teleporter in next room" },
                        { text = "   - At (H-9) walk toward exit for 1st cutscene" },
                        { text = "   - Take west teleport in same room, walk south for 2nd cutscene" },
                        { text = "4. Travel to Alzadaal Undersea Ruins via Caedarva Mire (E-11):" },
                        { text = "   - Use Caedarva Mire HP or Nashmau west exit" },
                        { text = "   - Speak to Nasheefa at (E-11) to enter ruins (need Silver Piece/Permit/Badge)" },
                        { text = "   - Use teleporter at (I-9) (right side when entering room)" },
                        { text = "   - Examine blank spot at NW corner of (G-7) for pre-fight cutscene" },
                        { text = "   - Spawn and defeat Nepionic Soulflayer" },
                        { text = "   - Examine blank spot again for reward cutscene" },
                        { text = "   - If you zone before cutscene you must fight Soulflayer again" },
                    },
                    notes = {
                        "Must have correct cutscene flagged before leaving Whitegate in step 2",
                        "Activating this quest unlocks Lathuya's BLU crafted armor commissions"
                    }
                },
                {
                    name = "Crafted AF - Lathuya (after Transformations)",
                    reward = "Shalwar / Bazubands / Jubbah",
                    steps = {
                        { text = "Speak to Lathuya at ", location = "Aht Urhgan Whitegate (F-8)", detail = "2nd floor inside stall" },
                        { text = "   - Trade materials + Imperial currency in one trade, then currency separately" },
                        { text = "   - Receive Magus order slip - return after game day changes (must zone too)" },
                        { text = "   - Can choose any order, wait 1 game day between pieces" },
                        { text = "" },
                        { text = "Magus Shalwar (Legs):" },
                        { text = "   - Gold Chain + Velvet Cloth + Flan Meat + Imp. Silk Cloth" },
                        { text = "   - Fee: 2x Imperial Mythril Pieces" },
                        { text = "" },
                        { text = "Magus Bazubands (Hands):" },
                        { text = "   - Platinum Sheet + Velvet Cloth + Karakul Leather + Venom Potion" },
                        { text = "   - Fee: 2x Imperial Mythril Pieces" },
                        { text = "" },
                        { text = "Magus Jubbah (Body):" },
                        { text = "   - Velvet Cloth + Chimera Blood + Karakul Cloth + Imp. Silk Cloth" },
                        { text = "   - Fee: 4x Imperial Mythril Pieces" },
                    },
                    notes = {
                        "Logging off is NOT enough - must zone to receive completed armor",
                        "Mythril Piece = 200 Imperial Standing Points from Ugrihd in Whitegate"
                    }
                }
            }
        },

        RUN = {
            name = "Rune Fencer",
            requirements = {
                "Main job level 30+",
                "Adoulinian charter permit",
                "Access to Yahse Hunting Grounds"
            },
            steps = {
                { text = "1. Talk to Octavien in ", location = "Eastern Adoulin (I-8)", detail = "Use Sverdhried Hillock Waypoint" },
                { text = "2. Get Yahse Wildflower Petal:" },
                { text = "   - Go to ", location = "Yahse Hunting Grounds (K-7)" },
                { text = "   - Take boat from Eastern Adoulin ", location = "(G-5)" },
                { text = "   - Use 'The Wharf to Yahse' Waypoint" },
                { text = "   - Go to K-7 Just off the Beach - Examine the Yahse Wildflower" },
                { text = "3. Return to Octavien:" },
                { text = "   - Use Sverdhried Hillock Waypoint" },
                { text = "   - During cutscene, select 'Use Rune Enchantment...?'" },
                { text = "   - Keep selecting until quest completes (1-100 times)" }
            },
            warnings = {
                "Umbril appear at night (20:00-4:00)",
                "Umbril are aggressive to sight and magic",
                "Keep Sowilo Claymore for future AF quest"
            },
            af_quests = {
                {
                    name = "AF1 - Forging New Bonds (RUN 90+)",
                    reward = "Beorc Sword + Runeist Armor crafting unlock",
                    steps = {
                        { text = "   Items needed: Sowilo Claymore (or Elixir), 1x Ifritite" },
                        { text = "1. Zone and return to speak with Octavien at ", location = "Eastern Adoulin (I-8)", detail = "must be on RUN, can switch after" },
                        { text = "   - Optional: speak to Gaddiux at Inventors' Coalition Western Adoulin (J-10) for lore" },
                        { text = "2. Check Inconspicuous Barrel in ", location = "Western Adoulin (I-4)", detail = "alley near Adoulin Waterfront waypoint" },
                        { text = "   - Yestin-Ovestin appears and asks for Rune Saber + Frost-encrusted Flame Gem" },
                        { text = "3. Check Tomato Vantage Point in Arboretum in ", location = "Rala Waterways (E-10)", detail = "closest: Western Adoulin Mog House entrance" },
                        { text = "   - Trade Sowilo Claymore OR Elixir to Tomato Vantage Point for Rune Saber" },
                        { text = "   - Ask about Frost-encrusted Flame Gem to receive Flask of Fruiserum" },
                        { text = "4. Go to Moh Gates (K-8) - trade Ifritite to Molten Rift for cutscene (lose Flask of Fruiserum)" },
                        { text = "   - Fastest: Morimar Frontier Station waypoint" },
                        { text = "   - Must go through Colonization Reive at (I-7)" },
                        { text = "   - If doing multiple: everyone trade Ifritite BEFORE spawning NM" },
                        { text = "5. Check Molten Rift again to spawn NM: Staumarth" },
                        { text = "   - Resists everything except Thunder - spams Spectral Floe/Scouring Spate" },
                        { text = "   - Apex Efts in area are non-aggressive" },
                        { text = "   - Does NOT need to be on RUN, Trusts allowed" },
                        { text = "   - If defeated: interact with Molten Rift again to respawn (no new Ifritite needed)" },
                        { text = "   - Receive: Frost-encrusted Flame Gem" },
                        { text = "6. Check Inconspicuous Barrel at Western Adoulin (I-4) - lose Rune Saber + Gem KIs" },
                        { text = "7. Wait 1 game day then check Inconspicuous Barrel again - read note" },
                        { text = "8. Talk to Octavien for Beorc Sword" },
                    }
                },
                {
                    name = "AF2 - Legacies Lost and Found (RUN, any level)",
                    reward = "Runeist Trousers + 6,000-22,000 Bayld",
                    steps = {
                        { text = "   Must zone after Forging New Bonds before starting" },
                        { text = "1. Speak to Octavien at ", location = "Eastern Adoulin (I-8)", detail = "must be on RUN - receive Letter from Octavien" },
                        { text = "2. Speak to Ohruru at ", location = "Port Windurst (E-7)", detail = "inside Orastery in the back" },
                        { text = "   - Use Ignis, speak to Ohruru twice more for cutscene" },
                        { text = "3. Visit at least 3 of 8 Strange Apparatuses - use listed Rune 3 times then examine Hazy Rune:" },
                        { text = "   - Dangruf Wadi (E-11): use Unda x3 > Stone of Unda" },
                        { text = "   - Gusgen Mines Map 2 (J-5): use Flabra x3 > Stone of Flabra" },
                        { text = "   - Crawlers Nest Map 3 (K-8): use Sulpor x3 > Stone of Sulpor" },
                        { text = "   - Ordelle's Caves (E-12): use Gelus x3 > Stone of Gelus" },
                        { text = "   - Eldieme Necropolis Map 2 (K-13): use Ignis x3 > Stone of Ignis" },
                        { text = "   - (Fall into WESTERNMOST hole at Map 1 (G-9) room D - NOT the center hole)" },
                        { text = "   - Outer Horutoto Ruins Map 5 (E-6): use Tellus x3 > Stone of Tellus" },
                        { text = "   - (Enter from northern tower West Sarutabaruta or Voidwatch Warp)" },
                        { text = "   - Garlaige Citadel Map 3 (K-8): use Tenebrae x3 > Stone of Tenebrae (behind Gate #2)" },
                        { text = "   - Maze of Shakhrami Map 2 (L-10): use Lux x3 > Stone of Lux" },
                        { text = "   - (Enter from Buburimu Peninsula - Unity Warp drops you at entrance)" },
                        { text = "4. Return to Ohruru at Port Windurst and answer her quiz questions:" },
                        { text = "   Opponent uses spell element? Fire=Unda, Earth=Flabra, Water=Sulpor, Wind=Gelus, Ice=Ignis, Thunder=Tellus, Light=Tenebrae, Dark=Lux" },
                        { text = "   Opponent inflicts status? Para/Stun/Frost=Ignis, Sil/Grav/Choke=Gelus, Slow/Pet/Rasp=Flabra, Stun/Shock=Tellus, Poison/Drown=Sulpor, Addle/Amn/Plague/Disease/Burn=Unda, Bane/Blind/Bio/Sleep/Drain=Lux, Dia/Sleep/Charm/Holy=Tenebrae" },
                        { text = "   Opponent weak to element? Fire=Ignis, Earth=Tellus, Water=Unda, Wind=Flabra, Ice=Gelus, Thunder=Sulpor, Light=Lux, Dark=Tenebrae" },
                        { text = "   Ward to use? Reduce elem dmg=Vallation, Party elem dmg=Valiance, Absorb=Liement, Enhance resist=Pflug" },
                        { text = "   - Receive: Secrets of Runic Enhancement key item" },
                        { text = "5. Speak to Octavien at ", location = "Eastern Adoulin (I-8)" },
                        { text = "6. Examine Inconspicuous Barrel at ", location = "Western Adoulin (I-4)", detail = "hand over Secrets of Runic Enhancement" },
                        { text = "7. Wait 1 game day then examine Inconspicuous Barrel again for Runeist Trousers" },
                    }
                },
                {
                    name = "AF3 - Destiny's Device (RUN, any level)",
                    reward = "Runeist Coat",
                    steps = {
                        { text = "1. Speak to Octavien at ", location = "Eastern Adoulin (I-8)", detail = "must be on RUN - receive Runic Kinegraver" },
                        { text = "2. Speak to Gaddiux at Inventors' Coalition ", location = "Western Adoulin (J-10)" },
                        { text = "   - Select Adoulinian Kelp option, then top 2 options until he mentions Yahse Wildflower Petal" },
                        { text = "3. Click Yahse Wildflower at ", location = "Yahse Hunting Grounds (K-7)", detail = "receive Yahse Wildflower Petal" },
                        { text = "4. Travel to Marjami Ravine (I-8) - find (???) at base of waterfall east of Bivouac #2" },
                        { text = "   - Use Ignis 3 times then interact with (???) for cutscene and Vial of Vivid Rainbow Extract" },
                        { text = "   - If no cutscene: return to Gaddiux and repeat options until he sends you here again" },
                        { text = "5. Speak to Gaddiux again - select Adoulinian Kelp option for another cutscene" },
                        { text = "6. Speak to Octavien" },
                        { text = "7. Travel to secret beach at ", location = "Foret de Hennetiel (J-11)", detail = "south of Bivouac #2 - examine Bloodstained Glove for cutscene" },
                        { text = "8. After all party members watch cutscene, click Bloodstained Glove again to spawn NM: Insidio" },
                        { text = "   - Any job, Trusts allowed" },
                        { text = "   - Orobon NM with Mayhem Lantern (AoE Charm) - gains phys dmg reduction after each use" },
                        { text = "   - Strategy: let Trusts get hate, move out of Charm range, let them kill it (~8-10 min)" },
                        { text = "   - Alt: use Tenebrae with Pflug and Magic Evasion buffs" },
                        { text = "   - Other players assisting receive up to 10,000 Bayld (once per player)" },
                        { text = "9. Return to Octavien for Runeist Coat" },
                        { text = "   - Optional: speak to Zurko-Bazurko at Mhaura proto-waypoint for extra cutscene" },
                    }
                },
                {
                    name = "Relic AF - Hestefa + Yestin-Ovestin (after Destiny's Device)",
                    reward = "Futhark Bandeau/Coat/Mitons/Trousers/Boots",
                    steps = {
                        { text = "1. Speak to Hestefa in ", location = "Celennia Memorial Library", detail = "wearing all 5 RUN Artifact pieces - receive Futharkic Concepts in Flux" },
                        { text = "   - Cannot have GEO's Tapestry of Bagua Poetry KI at same time" },
                        { text = "   - Destiny's Device not required if you got Runeist set via Deed Voucher" },
                        { text = "2. Examine Door: Amchuchu's Laboratory at Inventors' Coalition in Western Adoulin" },
                        { text = "3. Go to Outer Ra'Kaznar (M-6) as RUN - check Meeting Point target for Strand of Ra'Kaznar Filament" },
                        { text = "   - Fastest: waypoint in Western or Eastern Adoulin to enigmatic device in Outer Ra'Kaznar" },
                        { text = "   - Meeting Point is very close to the ruins entrance" },
                        { text = "4. Speak to Yestin-Ovestin at Inconspicuous Barrel (I-4) Western Adoulin to commission armor" },
                        { text = "   - Wait 1 game day per piece, can start next piece immediately after receiving previous" },
                        { text = "" },
                        { text = "Each piece costs 97,000 Bayld + one of these material sets:" },
                        { text = "Futhark Bandeau (Head): Wootz Ingot + Scintillant Ingot + Snowsteel | Or Wootz + Rice Ball" },
                        { text = "Futhark Coat (Body): Wootz Ingot + Ether Leather + Runeweave | Or Wootz + Sausage Roll" },
                        { text = "Futhark Mitons (Hands): Wootz Ingot + Raaz Leather + Runeweave | Or Wootz + Roasted Corn" },
                        { text = "Futhark Trousers (Legs): Wootz Ingot + Holy Leather + Runeweave | Or Wootz + Smoked Mackerel" },
                        { text = "Futhark Boots (Feet): Wootz Ingot + Holy Leather + Sparkstrand | Or Wootz + Rarab Tail" },
                    },
                    notes = {
                        "ALL pieces require 97,000 Bayld + Wootz Ingot + one craft mat OR food item",
                        "Cannot have GEO Tapestry of Bagua Poetry KI while doing RUN Relic"
                    }
                },
                {
                    name = "Empyrean AF - Epiphany (RUN 99)",
                    reward = "Erilaz Surcoat + Galea/Gauntlets/Leg Guards/Greaves",
                    steps = {
                        { text = "   Requires: At least 1 piece of Rune Fencer Relic Armor obtained" },
                        { text = "1. Speak to Octavernost at ", location = "Western Adoulin (K-9)", detail = "Big Bridge waypoint - must be on RUN (NOT same NPC as unlock quest)" },
                        { text = "2. Head to Outer Ra'Kaznar (M-6) - check Meeting Point for cutscene and Refined Ra'Kaznar Fiber" },
                        { text = "   - Close to enigmatic waypoint warp" },
                        { text = "3. Return to Octavernost - choose one of 3 solo fights (all vs Arcus Blades animated weapon):" },
                        { text = "   - Arcus Blades has low HP but casts Dispelga + Tier IV-VI elemental nukes (Tier VI can one-shot)" },
                        { text = "" },
                        { text = "Option A - Lv109 (Iridal core of the tomb) - King Ranperre's Tomb:" },
                        { text = "   - Examine (???) at (H-10) to enter Map 2, then go NW to (E-8), through fake wall, examine Hazy Rune" },
                        { text = "   - Trusts allowed, can change jobs, food/Vallation/Valiance preserved" },
                        { text = "   - Reward: 10,000 Bayld, Refined Ra'Kaznar Fiber becomes Arcus Fiber" },
                        { text = "" },
                        { text = "Option B - Lv125 (Iridal core of the ruins) - Fei'Yin:" },
                        { text = "   - Fei'Yin (G-9) > Map 2 > (E-7) > Map 1 > (G-6) > examine Hazy Rune" },
                        { text = "   - Trusts allowed, can change jobs, food/Vallation/Valiance preserved" },
                        { text = "   - Reward: 3 random Erilaz set materials" },
                        { text = "" },
                        { text = "Option C - Lv135 (Iridal core of the pass) - Ranguemont Pass:" },
                        { text = "   - Find Strange Apparatus in Ranguemont Pass, examine Hazy Rune" },
                        { text = "   - NO Trusts, MUST be on RUN, food/Vallation/Valiance preserved" },
                        { text = "   - Reward: 10 random Erilaz mats + Codex of Etchings + title: Sword Saint" },
                        { text = "" },
                        { text = "4. Optional: Return to Octavernost then check Amchuchu's Laboratory at Inventors' Coalition (J-10)" },
                        { text = "5. Wait 1 game day then talk to Octavernost for Erilaz Surcoat + 15,000 XP" },
                        { text = "6. After receiving Surcoat, speak to Octavernost to forge rest of set:" },
                        { text = "   - No zoning needed, any job, 1 piece per game day" },
                        { text = "   - Discount available if completed Part 1 of Quiescence (Ergon quest)" },
                        { text = "" },
                        { text = "Erilaz Galea (Head): Isgebind's Heart + Molybdenum Ingot + Molybdenum Ore | Or 15 H-P Bayld (7 discounted)" },
                        { text = "Erilaz Gauntlets (Hands): Isgebind's Heart + Flocon-de-mer + Cerberus Hide | Or 10 H-P Bayld (5 discounted)" },
                        { text = "Erilaz Leg Guards (Legs): Isgebind's Heart + Galateia + Cerberus Hide | Or 25 H-P Bayld (12 discounted)" },
                        { text = "Erilaz Greaves (Feet): Isgebind's Heart + Molybdenum Ingot + Cerberus Hide | Or 20 H-P Bayld (10 discounted)" },
                        { text = "Erilaz Surcoat (Body, replacement): Isgebind's Heart + Galateia + Molybdenum Ingot | Or 30 H-P Bayld (15 discounted)" },
                    },
                    notes = {
                        "Can repeat fight once per Conquest Tally for more materials",
                        "Lv135 fight: only RUN main, no Trusts - bring your best gear sets"
                    }
                },
                {
                    name = "Ergon Weapon - Quiescence (Epeolatry)",
                    reward = "Epeolatry (RUN Ergon Sword)",
                    steps = {
                        { text = "   Requires: Destiny's Device complete, All Coalitions Legend Rank+" },
                        { text = "   Note: Can start as any job - Epeolatry equippable by RUN only" },
                        { text = "   Note: If working on Idris, must complete or quit it first" },
                        { text = "--- Setup ---" },
                        { text = "1. Speak to Gaddiux at Inventors' Coalition in ", location = "Western Adoulin (J-10)" },
                        { text = "2. Get a Pickaxe (buy from Tevigogo at Western Adoulin D-9 near Pioneers Coalition)" },
                        { text = "   - Trailblazing Pickaxe also works" },
                        { text = "3. Head to Yorcia Weald (I-8) - examine the (???):" },
                        { text = "   - From Bivouac #2 head north past Colonization Reive then east into numbing blossoms" },
                        { text = "   - Multiple (???) in area - try each if nothing happens" },
                        { text = "   - Bush at (H-8) may block path - opens 21:00-3:00 game time" },
                        { text = "   - When Enlightened Endeavor KI resonates, trade Pickaxe to (???)" },
                        { text = "   - Receive: Numbing Blossom Seed then keep digging for Broken Rapier Hilt" },
                        { text = "   - If too slow you can retry immediately" },
                        { text = "4. Return to Gaddiux at Inventors' Coalition" },
                        { text = "5. Speak to Runje Desaali at ", location = "Eastern Adoulin (J-11)", detail = "she begins tracking materials" },
                        { text = "--- Part 1 - Lexeme Blade I ---" },
                        { text = "6. Trade 100 High-Purity Bayld to Runje Desaali (cumulatively) - receive Vial of Crimson Catalyst" },
                        { text = "7. Speak to Octavien at ", location = "Eastern Adoulin (I-8)", detail = "talk until he mentions the Vial" },
                        { text = "8. Travel to Rala Waterways (M-6) from Eastern Adoulin (F-7)" },
                        { text = "   - Examine door behind Yeggha Dolashi - select 'Quiescence' to enter BC" },
                        { text = "   - MUST be on RUN, 15 min limit, subjob removed" },
                        { text = "   - Fight: Zurko-Bazurko (dual-wield swords, Savage Blade, Chant du Cygne)" },
                        { text = "   - Frequently parries - use Swipe and Lunge as most effective options" },
                        { text = "   - Casts Protect IV, Shell V, Phalanx" },
                        { text = "   - Zurko's Lunge does big damage if no opposing runes active - keep runes up!" },
                        { text = "   - Receive: Quiescence key item" },
                        { text = "9. Speak to Gaddiux for cutscene with Amchuchu - receive Lexeme Blade I" },
                        { text = "--- Part 2 - Lexeme Blade II (DMG:228 PDT II -2%) ---" },
                        { text = "10. Trade Lexeme Blade I to Runje Desaali to begin Part 2" },
                        { text = "11. Trade to Runje: 200 Ghastly Stones + 500 H-P Bayld + Gabbrath Horn + Rockfin Fin + Bztavian Wing" },
                        { text = "   - NQ stones only - trade +1/+2 to Ornery Dhole for Obsidian Fragments" },
                        { text = "   - Buy NQ Ghastly Stones for 50 Obsidian Fragments each, Copper Voucher gives frags" },
                        { text = "   - Receive: Superlative Runic Ring of Deluge" },
                        { text = "12. Trade Lexeme Blade I to Runic Overflow at ", location = "Foret de Hennetiel (K-10)", detail = "Bivouac #2" },
                        { text = "   - Receive: Lexeme Blade II" },
                        { text = "--- Part 3 - Lexeme Blade III (DMG:231 Enmity+10 PDT II -3%) ---" },
                        { text = "13. Trade Lexeme Blade II to Runje Desaali to begin Part 3" },
                        { text = "14. Trade to Runje: 200 Verdigris Stones + 2,500 H-P Bayld + Yggdreant Root + Waktza Rostrum + Cehuetzi Claw" },
                        { text = "   - NQ stones only - buy for 100 Obsidian Fragments each" },
                        { text = "   - Receive: Superlative Runic Ring of Luster" },
                        { text = "15. Trade Lexeme Blade II to Runic Overflow at ", location = "Marjami Ravine (I-12)", detail = "Bivouac #2" },
                        { text = "   - Receive: Lexeme Blade III" },
                        { text = "--- Part 4 - Epeolatry ---" },
                        { text = "16. Trade Lexeme Blade III to Runje Desaali to begin Part 4" },
                        { text = "17. Trade to Runje: 200 Wailing Stones + 9,999 H-P Bayld + Pristine Yggrete Crystal" },
                        { text = "   - NQ stones only - buy for 200 Obsidian Fragments each" },
                        { text = "   - Receive: Superlative Runic Ring of Vision" },
                        { text = "18. Trade Lexeme Blade III to Runic Overflow on top of barrel at ", location = "Western Adoulin (I-10)", detail = "beside Delve NPC at Inventors Coalition" },
                        { text = "   - Receive: Epeolatry!" },
                    },
                    notes = {
                        "Talk to Runje > 'View materials (RUN)' to check turn-in progress at any time",
                        "If you drop a Lexeme Blade: talk to Geosuke multiple times > answer Yes > trade 1,000,000 gil to Runje",
                        "Keep Zurko's Lunge countered with opposing runes or it will hit very hard"
                    }
                }
            }
        },

        DNC = {
            name = "Dancer",
            requirements = {
                "Main job level 30+",
                "Wings of the Goddess expansion",
                "Pure White Feather (from Cavernous Maws mission)",
                "Access to Jugner Forest (S)"
            },
            steps = {
                { text = "1. Talk to Laila in ", location = "Upper Jeuno (G-7)" },
                { text = "   - Choose 'I surely do' then 'Never!'" },
                { text = "2. Talk to Rhea Myuliah next to Laila" },
                { text = "3. Go to Lion Springs Tavern in ", location = "Southern San d'Oria (K-6)" },
                { text = "   - Talk to Valderotaux" },
                { text = "   - Any dialogue choices work" },
                { text = "4. Return to Rhea Myuliah in ", location = "Upper Jeuno (G-7)" },
                { text = "5. Get Stardust Pebble:" },
                { text = "   - Go to ", location = "Jugner Forest (S) (I-5)" },
                { text = "   - Click Glowing Pebbles" },
                { text = "6. Return to Laila in ", location = "Upper Jeuno (G-7)" }
            },
            notes = {
                "Can use Batallia Downs (S) Survival Guide",
                "If Rhea answers instead of Laila, continue quest",
                "Home Point #3 in Southern San d'Oria is near tavern"
            },
            af_quests = {
                {
                    name = "AF1 - The Unfinished Waltz (DNC 40+)",
                    reward = "War Hoop",
                    steps = {
                        { text = "1. Speak to Laila in ", location = "Upper Jeuno (G-7)", detail = "must be on DNC - watch for 'seeing you dance' cutscene" },
                        { text = "2. Speak to Rhea Myuliah next to Laila in ", location = "Upper Jeuno (G-7)" },
                        { text = "3. Head to Grauberg (S) - examine (???) in Witchfire Glen at (F-5):" },
                        { text = "   - (???) is in middle of 3 closely-packed trees slightly NW of Veridical Conflux" },
                        { text = "   - Must be on DNC to initiate cutscene" },
                        { text = "   - Fastest: use lightsworm at any maw outside Jeuno > Walk of Echoes > exit with conflux" },
                        { text = "4. Examine (???) again to spawn NM: Migratory Hippogryph" },
                        { text = "   - Must stay on DNC for entire fight (if you zone must re-examine as DNC)" },
                        { text = "5. Defeat NM - examine (???) again for cutscene and The Essence of Dance" },
                        { text = "6. Open The Essence of Dance key item (Permanent Key Items menu, after Gate Crystals)" },
                        { text = "7. Speak to Laila in ", location = "Upper Jeuno (G-7)", detail = "for War Hoop" },
                    }
                },
                {
                    name = "AF2 - The Road to Divadom (DNC 50+)",
                    reward = "Dancer's Tights",
                    steps = {
                        { text = "   Must zone and wait until next game day after The Unfinished Waltz" },
                        { text = "   Items needed: Block of Yagudo Glue (get before quest if possible)" },
                        { text = "   - Farm from Yagudo Piper/Lutenist/Chanter/Conductor/Drummer in Shadowreign zones" },
                        { text = "   - Easiest: Survival Guide to Meriphataud Mountains (S) > farm in Castle Oztroja (S)" },
                        { text = "1. Speak to Laila in ", location = "Upper Jeuno (G-7)" },
                        { text = "2. Zone into Jugner Forest (S) for cutscene:" },
                        { text = "   - Fastest: Survival Guide to Batallia Downs (S)" },
                        { text = "3. Examine Glowing Pebbles at ", location = "Jugner Forest (S) (I-5)", detail = "for cutscene" },
                        { text = "4. Trade Yagudo Glue to the Glowing Pebbles at (I-5) - must be on DNC" },
                        { text = "5. Speak to Laila in ", location = "Upper Jeuno (G-7)", detail = "must be on DNC - for Dancer's Tights" },
                        { text = "   - After quest, speak to Olgald at Upper Jeuno (G-7) to unlock crafted AF from Matthias" },
                    }
                },
                {
                    name = "AF3 - Comeback Queen (DNC 50+)",
                    reward = "Dancer's Casaque",
                    steps = {
                        { text = "   Must zone and wait until next game day after The Road to Divadom" },
                        { text = "1. Speak to Laila in ", location = "Upper Jeuno (G-7)", detail = "receive Wyatt's Proposal" },
                        { text = "2. Speak to Harmodios in ", location = "Bastok Markets (K-10)", detail = "inside music shop, closest to HP #4" },
                        { text = "3. Return to Laila in Upper Jeuno" },
                        { text = "4. Speak to Rhea Myuliah in ", location = "Upper Jeuno (G-7)", detail = "practice the performance" },
                        { text = "   - Young people prefer Waltz" },
                        { text = "   - Older people prefer Samba" },
                        { text = "   - Children prefer Jig" },
                        { text = "   - Use correct dance when people walk away to regain attention" },
                        { text = "5. Speak to Laila after game day wait to perform" },
                        { text = "   - Audience: 3 children, 2 young men/women, 2 older people" },
                        { text = "   - Focus on Jig and Waltz to keep at least 5 of 7 watching" },
                        { text = "   - If failed: zone and wait until next game day to retry" },
                        { text = "6. Complete performance to receive Dancer's Casaque" },
                    }
                },
                {
                    name = "Crafted AF - Matthias (after Road to Divadom + speak to Olgald)",
                    reward = "Tiara / Toe Shoes / Bangles",
                    steps = {
                        { text = "Speak to Olgald in ", location = "Upper Jeuno (G-7)", detail = "after Road to Divadom to unlock commissions" },
                        { text = "Matthias is on a bridge near music store in ", location = "Bastok Markets (J-9)", detail = "HP #4 closest" },
                        { text = "   - Zone and wait for game day to change to receive each piece" },
                        { text = "   - Can commission next piece immediately after receiving previous one" },
                        { text = "" },
                        { text = "Dancer's Tiara (Head):" },
                        { text = "   - Imperial Silk Cloth + Silver Brocade + Wolf Felt" },
                        { text = "" },
                        { text = "Dancer's Toe Shoes (Feet):" },
                        { text = "   - Wamoura Cloth + Moblinweave + Gold Brocade" },
                        { text = "" },
                        { text = "Dancer's Bangles (Hands):" },
                        { text = "   - Karakul Cloth + Rainbow Cloth + Rainbow Velvet" },
                    },
                    notes = {
                        "No Imperial currency fee for DNC crafted AF - materials only"
                    }
                }
            }
        },

        DRG = {
            name = "Dragoon",
            requirements = {
                "Main job level 30+",
                "Rise of the Zilart expansion",
                "Access to Chateau d'Oraguille:",
                "- San d'Oria: Rank 2+",
                "- Others: Started 2-3 Mission",
                "Pickaxe",
                "Sneak/Invisible recommended"
            },
            steps = {
                { text = "1. Talk to Ceraulian/Arminibit in ", location = "Port San d'Oria Cargo Room A (I-9)" },
                { text = "2. Talk to Novalmauge in Bostaunieux Oubliette:", detail = "patrols (F-8) to (G-8)" },
                { text = "3. Talk to Morjean in ", location = "Northern San d'Oria Cathedral (L-7)", detail = "left room" },
                { text = "4. Get Wyvern Egg:" },
                { text = "   - Buy Pickaxe (Ostalie in Southern San d'Oria)" },
                { text = "   - Go to Maze of Shakhrami ", location = "Tahrongi Canyon (K-5)" },
                { text = "   - Find excavation point on first map" },
                { text = "   - Trade Pickaxe to point for egg" },
                { text = "5. Return to Morjean for cutscene" },
                { text = "6. Go to Meriphataud Mountains:" },
                { text = "   - Find (???) at ", location = "(K-8)", detail = "eastern edge of Drogaroga's Spine" },
                { text = "   - Trade Wyvern Egg to (???)" }
            },
            warnings = {
                "Cannot complete with active Souls in Shadow quest",
                "Check Tahrongi side excavation points first",
                "Level 80+ mobs on Maze second map"
            },
            af_quests = {
                {
                    name = "AF1 - A Craftsman's Work (DRG 40+)",
                    reward = "Peregrine",
                    steps = {
                        { text = "1. Speak to Miaux in ", location = "Northern San d'Oria (E-6)", detail = "must be on DRG - can switch after" },
                        { text = "2. Go to Eastern Altepa Desert - examine (???) in lower part of (H-8)" },
                        { text = "   - Survival Guide warp puts you very near" },
                        { text = "   - Or use Teleport-Altep" },
                        { text = "   - Spawns NMs: Decurio I, II, and III" },
                        { text = "3. Defeat all 3 Decurio NMs" },
                        { text = "4. Examine (???) again for Altepa Polishing Stone" },
                        { text = "5. Return to Miaux for Peregrine" },
                    }
                },
                {
                    name = "AF2 - Chasing Quotas (DRG 50+)",
                    reward = "Drachen Brais",
                    steps = {
                        { text = "   Items needed: Gold Hairpin (not +1)" },
                        { text = "1. Speak to Ceraulian inside ", location = "Port San d'Oria Cargo Room A (I-10)", detail = "can switch jobs after agreeing" },
                        { text = "2. Trade Gold Hairpin to Ceraulian (Gold Hairpin +1 does NOT work)" },
                        { text = "3. Wait 1 minute then speak to Ceraulian again" },
                        { text = "4. Speak to Miaux in ", location = "Northern San d'Oria (E-6)", detail = "receive Shiny Earring" },
                        { text = "5. Speak to Ardea in ", location = "Bastok Markets (H-8)", detail = "in front of Goldsmithing Guild, next to HP #4" },
                        { text = "   - Must complete Rock Racketeer quest first if it is active" },
                        { text = "6. Speak to Esca in ", location = "West Ronfaure (F-6)" },
                        { text = "7. Travel to island in Batallia Downs (I-11) via Eldieme Necropolis:" },
                        { text = "   - Enter Eldieme Necropolis at (I-10) in Batallia Downs or use Survival Guide" },
                        { text = "   - Hug south wall to large room at (G-9) - fall through grave at center point D to Map 2" },
                        { text = "   - All enemies sound aggro even at Lv99" },
                        { text = "   - Go to point E to zone to Map 3, follow path south back to Batallia Downs" },
                        { text = "   - Or use Magicked Astrolabe (10,000 gil) to navigate solo" },
                        { text = "8. Examine (???) at (I-11) - WEST side of island at cliff's edge - spawns NM: Sturmtiger" },
                        { text = "9. Defeat Sturmtiger - examine (???) again for Ranchuriome's Legacy" },
                        { text = "10. Return to Ceraulian for Drachen Brais" },
                    }
                },
                {
                    name = "AF3 - Knight Stalker (DRG 50+)",
                    reward = "Drachen Armet",
                    steps = {
                        { text = "   Items needed: Kuftal Coffer Key" },
                        { text = "1. Speak to Rahal in ", location = "Chateau d'Oraguille (H-9)", detail = "Royal Knight Quarters - must be on DRG" },
                        { text = "2. Speak to Ceraulian in ", location = "Port San d'Oria Cargo Room A (I-10)", detail = "for cutscene, then speak again" },
                        { text = "3. Get Kuftal Coffer Key and open any coffer in Kuftal Tunnel:" },
                        { text = "   - Survival Guide or UNM warp to reach area" },
                        { text = "   - Receive: Challenge to the Royal Knights (key item)" },
                        { text = "4. Return to Rahal and speak to him" },
                        { text = "5. Speak to Balasiel in ", location = "Southern San d'Oria (F-7)" },
                        { text = "6. Speak to Rahal again" },
                        { text = "7. Go to Temple of Uggalepih - Survival Guide is fastest warp" },
                        { text = "   - Head to (F-10) Map 1 - hidden area at (F-9)" },
                        { text = "   - At least ONE person must be on DRG with wyvern summoned to spawn NMs" },
                        { text = "   - Others can be on any job and still receive reward" },
                        { text = "8. Click (???) with wyvern out to spawn: Cleuvarion M Resoaix + Rompaulion S Citalle" },
                        { text = "   - Only need to defeat Rompaulion S Citalle" },
                        { text = "9. Check (???) again after fight for cutscene and Drachen Armet" },
                    },
                    notes = {
                        "Wyvern MUST be summoned to spawn the NMs - at least one DRG required"
                    }
                },
                {
                    name = "AF4 - Borghertz's Dragon Hands (DRG 50+)",
                    reward = "Drachen Finger Gauntlets + Mail + Greaves",
                    steps = {
                        { text = "   Requires: Started Chasing Quotas" },
                        { text = "   Items needed: Boyahda Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on DRG" },
                        { text = "2. Go to The Boyahda Tree and find a Treasure Coffer" },
                        { text = "   - Farm or buy Boyahda Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on DRG to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (DRG must be main job):" },
                        { text = "   - Ifrit's Cauldron coffer > Drachen Mail" },
                        { text = "   - Quicksand Caves coffer > Drachen Greaves" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        PLD = {
            name = "Paladin",
            requirements = {
                "Main job level 30+",
                "Complete quest series in order:",
                "- A Squire's Test (Level 7+)",
                "- A Squire's Test II (Level 10+)",
                "- A Knight's Test (Level 30+)",
                "Sneak and Invisible recommended"
            },
            quest_series = {
                squire_test_1 = {
                    level = "7+",
                    items_needed = { "Revival Tree Root" },
                    steps = {
                        { text = "1. Talk to Balasiel in ", location = "Southern San d'Oria (F-7)" },
                        { text = "2. Trade Revival Tree Root to Balasiel" }
                    },
                    notes = {
                        "Can buy Revival Tree Root from AH (Materials -> Alchemy)",
                        "Can get root from any undead, not just King Ranperre's Tomb"
                    }
                },
                squire_test_2 = {
                    level = "10+",
                    items_needed = { "Sneak", "Invisible", "Form of Warp recommended" },
                    steps = {
                        { text = "1. Talk to Balasiel again" },
                        { text = "2. Go to Ordelle's Caves:", location = "La Theine Plateau (F-6)" },
                        { text = "3. Navigate to stalactite room (Map 2 G-7)" },
                        { text = "4. Touch (???) in pool, then quickly touch second (???) Obtained Key Item Stalactite dew" },
                        { text = "5. Return to Balasiel - Obtained key item Squire certificate" }
                    }
                },
                knights_test = {
                    level = "30+",
                    items_needed = { "Sneak", "Invisible" },
                    steps = {
                        { text = "1. Talk to Balasiel for Book of Tasks" },
                        { text = "2. Get Book of the West from Baunise at ", location = "Southern San d'Oria (H-9)" },
                        { text = "3. Get Book of the East from Cahaurme at ", location = "Southern San d'Oria (J-9)" },
                        { text = "4. Go to Davoi for Knight's Soul:" },
                        { text = "   - Go to broken bridge at ", location = "(I-8)" },
                        { text = "   - Drop into water" },
                        { text = "   - Follow water west to ", location = "(D-8)" },
                        { text = "   - Exit at ", location = "(D-9)" },
                        { text = "   - Go southeast through camp" },
                        { text = "   - Head south to Disused Well Click on it to Receive Knight's Soul at ", location = "(E-10)" },
                        { text = "5. Return to Balasiel" }
                    }
                }
            },
            af_quests = {
                {
                    name = "Pre-AF - Father and Son (Any Level)",
                    reward = "Willow Fish Rod (trade back to unlock AF1)",
                    steps = {
                        { text = "   Required before Sharpening the Sword (AF1)" },
                        { text = "1. Talk to Ailbeche in ", location = "Northern San d'Oria (J-9)", detail = "Parade Grounds" },
                        { text = "2. Find Exoroche at Helbort's Blade in ", location = "Southern San d'Oria (K-7)" },
                        { text = "3. Return to Ailbeche - receive Willow Fish Rod" },
                        { text = "4. Trade the Willow Fish Rod BACK to Ailbeche to unlock AF1" },
                        { text = "   - Doing so changes title to Family Counselor" },
                    }
                },
                {
                    name = "AF1 - Sharpening the Sword (PLD 40+)",
                    reward = "Honor Sword",
                    steps = {
                        { text = "   Requires: Completed Father and Son and traded back fishing rod" },
                        { text = "1. Speak to Ailbeche near Home Point #2 in ", location = "Northern San d'Oria (J-8)" },
                        { text = "2. Talk to Sobane at ", location = "Southern San d'Oria (D-6)", detail = "talk twice if first talk gives cutscene" },
                        { text = "3. Go to Ordelle's Caves from ", location = "La Theine Plateau (F-7)", detail = "Survival Guide is fastest - puts you on Map 2" },
                        { text = "4. Navigate to circular room at (H-10) on Map 2:" },
                        { text = "   - Take first left, walk to (I-6) Map 2, use exit B to Map 1" },
                        { text = "   - Walk to (H-9) exit D back to Map 2" },
                        { text = "   - Examine Stalagmite at (H-10) - be careful not to fall down hole" },
                        { text = "5. Defeat NM: Polevik (Earth Elemental)" },
                        { text = "6. Examine Stalagmite again for Ordelle whetstone" },
                        { text = "7. Return to Ailbeche for Honor Sword" },
                    }
                },
                {
                    name = "AF2 - A Boy's Dream (PLD 50+)",
                    reward = "Gallant Leggings",
                    steps = {
                        { text = "   Items needed: Giant Shell Bug, large fishing rod (Clothespole or Composite)" },
                        { text = "1. Speak to Ailbeche in ", location = "Northern San d'Oria (J-8)" },
                        { text = "2. Talk to Exoroche at Helbort's Blades in ", location = "Southern San d'Oria (K-7)" },
                        { text = "3. Return to Ailbeche" },
                        { text = "4. Trade Ailbeche a Giant Shell Bug:" },
                        { text = "   - Buy from AH, or defeat Dreadbug via (???) on Crawlers Nest Map 2 SW of (H-9)" },
                        { text = "   - Dreadbug drops up to 4 Giant Shell Bugs, respawns once per game day while quest active" },
                        { text = "   - Do NPC interactions FIRST or you will waste the bug in next step" },
                        { text = "5. Fish in Castle Oztroja using Giant Shell Bug as bait (fishing skill not required):" },
                        { text = "   - Enter through Brass Door at (I-8) Map 1" },
                        { text = "   - Map 2: go to exit (F) at (G-7)" },
                        { text = "   - Next map: head to exit (I) - puts you on Map 7" },
                        { text = "   - Fish in pond at (H-8)/(H-9) Map 7 - beware 2 Oozes in pond" },
                        { text = "6. Odontotyrannus (Monster) will be fished up - defeat it for Odontotyrannus" },
                        { text = "   - Can fish up BEFORE trading Giant Shell Bug to Ailbeche" },
                        { text = "7. Return to Ailbeche and trade the Odontotyrannus" },
                        { text = "8. Go to Selbina - trade Odontotyrannus to Zaldon at ", location = "Selbina (H-9)", detail = "Fisherman's Guild" },
                        { text = "   - Receive Knight's boots" },
                        { text = "9. Return to Ailbeche again" },
                        { text = "10. Speak to Exoroche at Helbort's Blades in ", location = "Southern San d'Oria (K-7)" },
                        { text = "11. Go to Chateau d'Oraguille - select Trion's door (Prince Royal's Rm H-7) for Gallant Leggings" },
                    }
                },
                {
                    name = "AF3 - Under Oath (PLD 50+)",
                    reward = "Gallant Surcoat",
                    steps = {
                        { text = "   Requires: San d'Oria Rank 2 or Bastok/Windurst Rank 3" },
                        { text = "   Items needed: Zvahl Coffer Key (or Thief's Tools/Living Key/Skeleton Key)" },
                        { text = "1. Examine door Prince Royal's Rm in ", location = "Chateau d'Oraguille (H-8)", detail = "must be on PLD - can switch jobs after" },
                        { text = "2. Speak to Vemalpeau in ", location = "Southern San d'Oria (M-7)", detail = "inside a house" },
                        { text = "3. Speak to Najjar in ", location = "Southern San d'Oria (K-6)", detail = "Lion Springs" },
                        { text = "4. Speak to Ullasa in ", location = "Southern San d'Oria (B-6)", detail = "Count's Manor" },
                        { text = "5. Get Zvahl Coffer Key and open any coffer in Castle Zvahl Baileys:" },
                        { text = "   - Drops from Ahriman, Abyssal/Arch/Blood/Doom Demons (near coffer spawns)" },
                        { text = "   - Or pick lock as THF with Thief's Tools/Living Key/Skeleton Key" },
                        { text = "   - Or buy from Curio Vendor Moogle 5,000 gil (need Rhapsody in Umber KI)" },
                        { text = "   - Receive: Mique's paintbrush (key item)" },
                        { text = "6. Return to Vemalpeau - go to 2nd story and examine (???) on the painting" },
                        { text = "   - Read letter behind painting for Strange sheet of paper" },
                        { text = "7. Speak to Exoroche at ", location = "Southern San d'Oria (K-7)", detail = "Helbort's Blades - learn how to read letter" },
                        { text = "8. Go to Davoi - find Village Well at ", location = "(G-9)" },
                        { text = "   - Examine Well to spawn: Three-eyed Prozpuz (RNG) and One-eyed Gwajboj (PLD)" },
                        { text = "   - Defeat both - One-eyed Gwajboj drops Well Weight" },
                        { text = "   - 3 min wait between fights for multiple players" },
                        { text = "9. Trade Well Weight to Village Well for cutscene and Knight's confession" },
                        { text = "10. Speak to Ailbeche in ", location = "Northern San d'Oria (J-9)" },
                        { text = "11. Travel to Jugner Forest - head to Maiden's Spring (E-6) for cutscene" },
                        { text = "12. Return to Chateau d'Oraguille - speak to Prince Trion for Gallant Surcoat" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Stalwart Hands (PLD 50+)",
                    reward = "Gallant Gauntlets + Coronet + Breeches",
                    steps = {
                        { text = "   Requires: Started A Boy's Dream" },
                        { text = "   Items needed: Eldieme Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on PLD" },
                        { text = "2. Go to The Eldieme Necropolis and find a Treasure Coffer" },
                        { text = "   - Buy Magicked Astrolabe from Churano-Shurano in ", location = "Windurst Waters (F-8)", detail = "10,000 gil, opens doors solo" },
                        { text = "   - Farm or buy Eldieme Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on PLD to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine same torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (PLD must be main job):" },
                        { text = "   - Garlaige Citadel coffer > Gallant Coronet" },
                        { text = "   - Beadeaux coffer > Gallant Breeches" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        WAR = {
            name = "Warrior",
            starter_job = true,
            requirements = {
                "Warrior is a starting job - no unlock quest required"
            },
            steps = {},
            af_quests = {
                {
                    name = "AF1 - The Doorman (WAR 40+)",
                    reward = "Razor Axe",
                    steps = {
                        { text = "1. Talk to Phara in ", location = "Bastok Mines (J-9)", detail = "beside Gobbie Mystery Box at HP #2" },
                        { text = "2. Go to Davoi and click the Hide Flap at ", location = "(K-9/10)" },
                        { text = "   - Spawns 2 NMs: Barakbok and Gavotvut" },
                        { text = "3. Defeat both NMs then check the Hide Flap for Sword grip material" },
                        { text = "   - Hide Flap moves to random spot in area after checking" },
                        { text = "   - Multiple people: wait 5 min between pops" },
                        { text = "4. Speak to Phara then wait a game day (past 00:00)" },
                        { text = "5. Speak to Phara again for Yasin's sword" },
                        { text = "6. Speak to Naji outside President's Office in ", location = "Metalworks (J-8)", detail = "may need to speak twice" },
                    }
                },
                {
                    name = "AF2 - The Talekeeper's Truth (WAR 50+)",
                    reward = "Fighter's Calligae",
                    steps = {
                        { text = "   Items needed: Mottled Quadav Egg, Parasite Skin" },
                        { text = "1. Talk to Phara in ", location = "Bastok Mines (J-9)" },
                        { text = "2. Talk to Deidogg in ", location = "Bastok Mines (H-6)", detail = "bottom of ramp to guild - talk twice" },
                        { text = "   - Quest can be completed on any job from here" },
                        { text = "3. Go to Palborough Mines top floor - find (???) at ", location = "(G-10)", detail = "dead end room" },
                        { text = "   - Home Point #1 is very close" },
                        { text = "   - Or use Domenic to teleport to Waughroon Shrine nearby" },
                        { text = "4. Examine (???) to spawn NM: Ni'Ghu Nestfender - defeat it" },
                        { text = "   - Drops Mottled Quadav Egg (3 min respawn)" },
                        { text = "5. Return to Bastok and trade Mottled Quadav Egg to Deidogg" },
                        { text = "6. Go to Castle Oztroja - kill Yagudo Parasite in pond on 3rd floor ", location = "(H-9)", detail = "for Parasite Skin" },
                        { text = "7. Return to Bastok and trade Parasite Skin to Deidogg" },
                        { text = "8. Wait a game day (past 00:00) then talk to Deidogg for reward" },
                    }
                },
                {
                    name = "AF3 - Borghertz's Warring Hands (WAR 50+)",
                    reward = "Fighter's Mufflers + Mask + Cuisses",
                    steps = {
                        { text = "   Requires: Started The Talekeeper's Truth" },
                        { text = "   Items needed: Eldieme Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on WAR" },
                        { text = "2. Go to The Eldieme Necropolis and find a Treasure Coffer" },
                        { text = "   - Buy Magicked Astrolabe from Churano-Shurano in ", location = "Windurst Waters (F-8)", detail = "10,000 gil, opens doors solo" },
                        { text = "   - Farm or buy Eldieme Coffer Key, or pick lock as THF" },
                        { text = "   - Does NOT need to be on WAR to open coffer" },
                        { text = "   - Receive: Old gauntlets" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Head to Lower Jeuno Tenshodo area - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Jeuno Duty-Free at ", location = "(H-8)", detail = "underground beside Digaga" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click a torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine a torch for Shadow flames" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (WAR must be main job):" },
                        { text = "   - Crawlers Nest coffer > Fighter's Mask" },
                        { text = "   - Castle Zvahl Baileys coffer > Fighter's Cuisses" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces do not need to be obtained to complete the quest"
                    }
                }
            }
        },

        MNK = {
            name = "Monk",
            starter_job = true,
            requirements = {
                "Monk is a starting job - no unlock quest required"
            },
            steps = {},
            af_quests = {
                {
                    name = "AF1 - Ghosts of the Past (MNK 40+)",
                    reward = "Beat Cesti",
                    steps = {
                        { text = "   Items needed: Pickaxe, Miner's Pendant (from NM)" },
                        { text = "1. Talk to Oggbi in ", location = "Port Bastok (E-6)", detail = "Steaming Sheep Restaurant - must be on MNK" },
                        { text = "   - If over 250 H2H skill he may offer Asuran Fists trial first" },
                        { text = "   - Can switch jobs after quest is active" },
                        { text = "2. Get a Pickaxe from AH or from Numa at ", location = "Port Bastok (E-7)", detail = "store in front of Steaming Sheep, down stairs" },
                        { text = "3. Travel to Gusgen Mines:" },
                        { text = "   - Go straight ahead, down staircase, use west switch to open door to 2nd map" },
                        { text = "   - Take ramp down at (F-5) to reach 3rd map" },
                        { text = "4. Trade Pickaxe to (???) at ", location = "Gusgen Mines Map 3 (G-7)", detail = "spawns Wandering Ghost" },
                        { text = "   - Pickaxe stays in inventory after trade" },
                        { text = "   - 3 min repop if doing multiple" },
                        { text = "5. Defeat Wandering Ghost - pick up Miner's Pendant" },
                        { text = "6. Trade Miner's Pendant to Oggbi for Beat Cesti" },
                    }
                },
                {
                    name = "AF2 - The First Meeting (MNK 50+)",
                    reward = "Temple Gaiters",
                    steps = {
                        { text = "   Must zone after completing AF1 before starting this quest" },
                        { text = "1. Talk to Oggbi in ", location = "Port Bastok (E-6)", detail = "Steaming Sheep Restaurant - must be on MNK" },
                        { text = "   - Can switch jobs once quest is active" },
                        { text = "2. Travel to Fei'Yin - zone into and back out of Qu'Bia Arena for cutscene" },
                        { text = "   - Receive key item: Letter from Dalzakk" },
                        { text = "   - Home Point warp #1 available if unlocked" },
                        { text = "3. Travel to Davoi - find Hide Flap at ", location = "(F-7)/(G-7)" },
                        { text = "4. Click Hide Flap to spawn Deloknok (PLD) and Bilopdop (MNK)" },
                        { text = "   - Defeat both NMs" },
                        { text = "   - Hide Flap moves to random hut in area after each check" },
                        { text = "   - Find new Hide Flap location and check for San d'Orian martial arts scroll" },
                        { text = "   - Each player needs to trigger NMs once to retrieve key item" },
                        { text = "   - Few minute cooldown between NM pops" },
                        { text = "5. Return to Oggbi in ", location = "Port Bastok (E-6)", detail = "receive Temple Gaiters" },
                    }
                },
                {
                    name = "AF3 - True Strength (MNK 50+)",
                    reward = "Temple Hose",
                    steps = {
                        { text = "   Items needed: Yagudo Drink" },
                        { text = "1. Talk to Ayame in ", location = "Metalworks (K-7)" },
                        { text = "   - If finished ToAU missions may need to speak twice" },
                        { text = "   - Get Yagudo Drink from AH or Curio Vendor Moogle" },
                        { text = "   - Can switch to any job after talking to Ayame" },
                        { text = "2. Travel to Castle Oztroja - you do NOT need passwords to enter Altar Room" },
                        { text = "3. Head to top floor - do NOT go through the timed gate" },
                        { text = "4. Find torch with (???) at ", location = "Castle Oztroja (H-8)", detail = "in H-shaped room before timed gate" },
                        { text = "5. Trade Yagudo Drink to (???) to spawn Huu Xalmo the Savage" },
                        { text = "   - Drops Xalmo Feather (3 min cooldown between pops)" },
                        { text = "6. Trade Xalmo Feather to Ayame for Temple Hose" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Striking Hands (MNK 50+)",
                    reward = "Temple Gloves + Crown + Cyclas",
                    steps = {
                        { text = "   Requires: Started The First Meeting" },
                        { text = "   Items needed: Nest Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on MNK" },
                        { text = "2. Go to Crawler's Nest and find a Treasure Coffer" },
                        { text = "   - Farm or buy Nest Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on MNK to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (MNK must be main job):" },
                        { text = "   - Garlaige Citadel coffer > Temple Crown" },
                        { text = "   - Beadeaux coffer > Temple Cyclas" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        WHM = {
            name = "White Mage",
            starter_job = true,
            requirements = {
                "White Mage is a starting job - no unlock quest required"
            },
            steps = {},
            af_quests = {
                {
                    name = "AF1 - Messenger from Beyond (WHM 40+)",
                    reward = "Blessed Hammer",
                    steps = {
                        { text = "1. Talk to Narcheral in ", location = "Northern San d'Oria (M-6)", detail = "upstairs in cathedral - must be on WHM" },
                        { text = "   - Can switch to any job after quest is active" },
                        { text = "2. Head to Secret Beach at ", location = "Valkurm Dunes (B-8)" },
                        { text = "   - Fastest: Survival Guide warp to Gustav Tunnel, walk out" },
                        { text = "3. Between 18:00 and 5:00 a (???) appears near the Song Runes" },
                        { text = "   - Click (???) to spawn NM: Marchelute" },
                        { text = "4. Defeat Marchelute - drops Tavnazia Pass" },
                        { text = "5. Return Tavnazia Pass to Narcheral for Blessed Hammer" },
                    }
                },
                {
                    name = "AF2 - Prelude of Black and White (WHM 50+)",
                    reward = "Healer's Duckbills",
                    steps = {
                        { text = "   Items needed: Moccasins, Yagudo Holy Water" },
                        { text = "   Requires: Access to Chateau d'Oraguille" },
                        { text = "   - San d'Oria players: Rank 2+" },
                        { text = "   - Other nations: Bastok/Windurst Mission 2-3" },
                        { text = "1. Examine Door: Prince Regent's Rm in ", location = "Chateau d'Oraguille (H-8)", detail = "must be on WHM" },
                        { text = "2. Kill Yagudo Abbots until Yagudo Holy Water drops:" },
                        { text = "   Option A - Castle Oztroja Map 3:" },
                        { text = "   - Abbots behind brass door at (G-8)" },
                        { text = "   - Combination behind secret door at (I-10) same map" },
                        { text = "   Option B - Castle Zvahl Keep Map 2:" },
                        { text = "   - Abbots at (G-9) and (G-10) - fewer spawns but lower level" },
                        { text = "3. Obtain Moccasins:" },
                        { text = "   - Buy from Auction House, dropped from multiple enemies, or Leathercraft Lv59 synth" },
                        { text = "4. Trade Moccasins + Yagudo Holy Water to Narcheral in ", location = "Northern San d'Oria (M-6)", detail = "cathedral upstairs" },
                    }
                },
                {
                    name = "AF3 - Pieuje's Decision (WHM 50+)",
                    reward = "Healer's Bliaut",
                    steps = {
                        { text = "   Items needed: Tavnazia Bell (from NM), Tavnazian Mask (from NM)" },
                        { text = "1. Open Door: Prince Regent's Rm in ", location = "Chateau d'Oraguille (H-8)", detail = "can switch jobs after" },
                        { text = "2. Go to Eldieme Necropolis - kill Dark Stalkers until Tavnazia Bell drops:" },
                        { text = "   - 4 spawn points near Hume Bones at (G-8) center of Map 2" },
                        { text = "   - Also 4 spawns at C and B drops of Map 1" },
                        { text = "3. Travel to Fei'Yin and zone in for a cutscene" },
                        { text = "   - Warping to Home Point will trigger the cutscene" },
                        { text = "4. Find (???) at ", location = "Fei'Yin Map 1 (G-8)" },
                        { text = "   - Trade Tavnazia Bell to (???) to spawn Altedour I Tavnazia" },
                        { text = "   - Warning: one of the strongest AF NMs - come prepared" },
                        { text = "   - Few minute wait between pops if doing multiple" },
                        { text = "   - Drops Tavnazian Mask" },
                        { text = "5. Trade Tavnazian Mask to Narcheral in ", location = "Northern San d'Oria (M-6)", detail = "cathedral upstairs" },
                    },
                    notes = {
                        "Altedour I Tavnazia is considered one of the toughest AF NMs - bring help"
                    }
                },
                {
                    name = "AF4 - Borghertz's Healing Hands (WHM 50+)",
                    reward = "Healer's Mitts + Cap + Pantaloons",
                    steps = {
                        { text = "   Requires: Started Prelude of Black and White" },
                        { text = "   Items needed: Beadeaux Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on WHM" },
                        { text = "   - Can switch jobs for remaining steps" },
                        { text = "2. Go to Beadeaux and find a Treasure Coffer" },
                        { text = "   - Farm or buy Beadeaux Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on WHM to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (WHM must be main job):" },
                        { text = "   - Garlaige Citadel coffer > Healer's Cap" },
                        { text = "   - Crawlers Nest coffer > Healer's Pantaloons" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        BLM = {
            name = "Black Mage",
            starter_job = true,
            requirements = {
                "Black Mage is a starting job - no unlock quest required"
            },
            steps = {},
            af_quests = {
                {
                    name = "AF1 - The Three Magi (BLM 40+)",
                    reward = "Casting Wand",
                    steps = {
                        { text = "   Items needed: Any synthesis crystal (to get Faded Crystal)" },
                        { text = "1. Speak to Chumimi in ", location = "Heavens Tower basement (Windurst)", detail = "must be on BLM" },
                        { text = "   - Choose which NPC to agree with (title only, no quest effect)" },
                        { text = "   - Can switch to any job after cutscene" },
                        { text = "2. Head to any Telepoint and trade a synthesis crystal to receive a Faded Crystal" },
                        { text = "3. Travel to Xarcabard toward ", location = "(E-8)" },
                        { text = "   - Fastest: Castle Zvahl Baileys Survival Guide then zone out to Xarcabard" },
                        { text = "4. Find (???) marker in the glowing trenches near Castle Zvahl Baileys zone" },
                        { text = "5. Trade Faded Crystal to (???) to spawn Chaos Elemental (Light Elemental)" },
                        { text = "   - Resistant to all physical damage" },
                        { text = "   - 3 min repop wait if doing multiple" },
                        { text = "6. Defeat Chaos Elemental - pick up Glowstone" },
                        { text = "7. Return Glowstone to Chumimi for Casting Wand" },
                    }
                },
                {
                    name = "AF2 - Recollections (BLM 50+)",
                    reward = "Wizard's Sabots",
                    steps = {
                        { text = "   Must zone out of Heavens Tower after AF1 before starting" },
                        { text = "1. Speak to Chumimi in ", location = "Heavens Tower basement (Windurst)" },
                        { text = "   - Optional: Cutscene with Laityn in ", location = "Ru'Lude Gardens (G-9)" },
                        { text = "2. Go to Crawlers Nest basement - get Bag of Seeds from Fire or Water Elemental" },
                        { text = "   - Elementals only appear during weather - check Appollonia in ", location = "Upper Jeuno (G-6)", detail = "for Rolanberry Fields weather" },
                        { text = "   - Elementals pop in donut room on Map 3 near Strange Apparatus" },
                        { text = "   - Alt: Get seeds from Garden Furrow via Kuyin Hathdenna (look for seeds)" },
                        { text = "3. Return to Chumimi and trade Bag of Seeds" },
                        { text = "4. Go to Castle Zvahl Baileys - kill Demon Generals/Magistrates/Chancellors/Commanders for Whine Cellar Key" },
                        { text = "   - Found at bottom of four corner areas on Map 3 (fall from Map 2)" },
                        { text = "5. Zone into Castle Zvahl Keep" },
                        { text = "6. Head to Ore Door at ", location = "(H-7)", detail = "hug right wall, through iron gate, first ore door before 2nd iron gate" },
                        { text = "   - Trade Whine Cellar Key to Ore Door for cutscene and Foe Finder Mk. I" },
                        { text = "7. Return to Chumimi for final cutscene and Wizard's Sabots" },
                    }
                },
                {
                    name = "AF3 - The Root of the Problem (BLM 50+)",
                    reward = "Wizard's Petasos",
                    steps = {
                        { text = "   Must zone out of Heavens Tower after AF2 before starting" },
                        { text = "   Items needed: Silk Cloth, Manafont (must be on BLM for canal step)" },
                        { text = "1. Speak to Chumimi in ", location = "Heavens Tower basement (Windurst)", detail = "must be on BLM" },
                        { text = "2. Trade a Silk Cloth to Koru-Moru at ", location = "Windurst Walls (E-7)" },
                        { text = "3. Return to Chumimi to receive Sluice Surveyor Mk. I" },
                        { text = "4. Go to Toraimarai Canal - find two (???) points (must be on BLM for Manafont):" },
                        { text = "   - First (???) at NE corner of (H-7) on Map 1" },
                        { text = "   - From Survival Guide follow left wall to grate - (???) is right there" },
                        { text = "   - Second (???) at (I-9) on Map 1" },
                        { text = "   - Must examine when directly in front - too far or wrong side gives error" },
                        { text = "5. At one (???) get cutscene - use Manafont then check (???) again" },
                        { text = "   - Usually the second point but rarely can be first" },
                        { text = "   - Can switch jobs after using Manafont" },
                        { text = "6. Go to (J-8) - click the NON-GLOWING (???) for cutscene to spawn Magic Sludge (Dark Elemental)" },
                        { text = "   - Two (???) side by side - use the one that is NOT glowing" },
                        { text = "   - Highly resistant to physical damage and magic" },
                        { text = "   - Only the player who initiates the cutscene gets NM credit" },
                        { text = "   - 3 min wait between pops" },
                        { text = "7. Click (???) again after fight for cutscene" },
                        { text = "8. Return to Chumimi for final cutscene and Wizard's Petasos" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Sorcerous Hands (BLM 50+)",
                    reward = "Wizard's Gloves + Coat + Tonban",
                    steps = {
                        { text = "   Requires: Started Recollections" },
                        { text = "   Items needed: Garlaige Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on BLM" },
                        { text = "2. Go to Garlaige Citadel and find a Treasure Coffer" },
                        { text = "   - Farm or buy Garlaige Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on BLM to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (BLM must be main job):" },
                        { text = "   - Monastic Cavern coffer > Wizard's Coat" },
                        { text = "   - The Eldieme Necropolis coffer > Wizard's Tonban" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        RDM = {
            name = "Red Mage",
            starter_job = true,
            requirements = {
                "Red Mage is a starting job - no unlock quest required"
            },
            steps = {},
            af_quests = {
                {
                    name = "AF1 - The Crimson Trial (RDM 40+)",
                    reward = "Fencing Degen",
                    steps = {
                        { text = "1. Speak to Sharzalion in ", location = "Southern San d'Oria (K-6)", detail = "Lion Springs Tavern - must be on RDM, answer Yes" },
                        { text = "2. Go to Davoi and fight Purpleflash Brukdok (BLM) at ", location = "(E-9)/(F-9)", detail = "drops Davoi Storage Key" },
                        { text = "   - May need Sneak/Invisible to reach NM" },
                        { text = "   - Enter creek from broken bridge at (I-8) or ramp at (J-10)" },
                        { text = "   - Walk west through creek to fork at (I-9), take west fork" },
                        { text = "   - Continue to (D-8), ramp exits creek into NM area" },
                        { text = "   - 10 min respawn, each RDM needs their own key" },
                        { text = "3. Trade Davoi Storage Key to targetable Storage Hole (moves daily):" },
                        { text = "   - Storage Holes are in open areas on the ground" },
                        { text = "   - Possible locations: (E-10),(F-6),(F-7),(F-9),(G-9),(G-10),(H-8)," },
                        { text = "     (I-7),(I-8),(J-7),(J-8),(K-7),(K-8),(K-9),(K-10)" },
                        { text = "   - Center Island hole at (H-8) reachable from the river" },
                        { text = "   - Receive key item: Orcish dried food" },
                        { text = "4. Return to Sharzalion for Fencing Degen" },
                    }
                },
                {
                    name = "AF2 - Enveloped in Darkness (RDM 50+)",
                    reward = "Warlock's Boots",
                    steps = {
                        { text = "   Requires: Access to Chateau d'Oraguille (San d'Oria Rank 2 or other nation Mission 2-3)" },
                        { text = "   Items needed: Velvet Cloth, Nest Chest Key" },
                        { text = "1. Speak to Curilla in ", location = "Chateau d'Oraguille (I-9)", detail = "receive Old pocket watch - can switch jobs after" },
                        { text = "2. Go to Northern San d'Oria Cathedral basement - speak to Pagisalis" },
                        { text = "   - Basement stairs are to the left after entering Cathedral" },
                        { text = "   - Trade Velvet Cloth to Pagisalis - receive Old boots" },
                        { text = "3. Speak to Curilla again" },
                        { text = "4. Go to Crawlers Nest - open a Treasure Chest with Nest Chest Key" },
                        { text = "   - Buy Nest Chest Key from Curio Vendor Moogle (need Rhapsody in White KI)" },
                        { text = "   - Chest respawns every 3 minutes" },
                        { text = "   - Receive key item: Crawler blood" },
                        { text = "5. On Map 2 examine (???) at ", location = "(I-10)", detail = "bury Old boots and Crawler blood" },
                        { text = "   - If you get 'Someone has been digging here' you forgot to talk to Curilla again" },
                        { text = "6. Check (???) again for Warlock's Boots (short wait up to 60 seconds, no zoning needed)" },
                    }
                },
                {
                    name = "AF3 - Peace for the Spirit (RDM 50+)",
                    reward = "Warlock's Chapeau",
                    steps = {
                        { text = "   Requires: Access to Chateau d'Oraguille" },
                        { text = "   Items needed: Antique Coin (from NM), Nail Puller (from NM)" },
                        { text = "1. Talk to Curilla in ", location = "Chateau d'Oraguille (I-9)", detail = "must be on RDM, can switch after" },
                        { text = "2. Go to Southern San d'Oria - speak to Sharzalion at ", location = "(K-6)", detail = "Lion Springs Tavern" },
                        { text = "3. Kill Miser Murphy in Fei'Yin for Antique Coin:" },
                        { text = "   - Pops at (H-8) Map 1 if quest is active" },
                        { text = "   - 10 minute respawn" },
                        { text = "4. Trade coin to the Dry Fountain at ", location = "(H-8)", detail = "for cutscene" },
                        { text = "5. Return to Southern San d'Oria - speak to Sharzalion then Daggao in the bar" },
                        { text = "6. Go to Garlaige Citadel (G-8) behind first banishing gate on Map 2" },
                        { text = "   - Click Oaken Box in first room to the left to spawn Guardian Statue" },
                        { text = "   - If 'Something feels wrong' message appears, turn off Sneak first" },
                        { text = "7. Defeat Guardian Statue for Nail Puller" },
                        { text = "8. Trade Nail Puller to same Oaken Box for cutscene" },
                        { text = "9. Zone into Northern San d'Oria for cutscene and Warlock's Chapeau" },
                    }
                },
                {
                    name = "AF4 - Borghertz's Vermillion Hands (RDM 50+)",
                    reward = "Warlock's Gloves + Tights + Tabard",
                    steps = {
                        { text = "   Requires: Started Enveloped in Darkness" },
                        { text = "   Items needed: Eldieme Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on RDM" },
                        { text = "2. Go to The Eldieme Necropolis and find a Treasure Coffer" },
                        { text = "   - Buy Magicked Astrolabe from Churano-Shurano in ", location = "Windurst Waters (F-8)", detail = "10,000 gil, opens doors solo" },
                        { text = "   - Farm or buy Eldieme Coffer Key (5,000 gil from Curio Vendor Moogle)" },
                        { text = "   - Or pick lock as THF - does NOT need to be on RDM to open" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - find (???) near crates by AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (RDM must be main job):" },
                        { text = "   - Garlaige Citadel coffer > Warlock's Tights" },
                        { text = "   - Castle Oztroja coffer > Warlock's Tabard" },
                        { text = "   - Note: Castle Oztroja brass gate combo changes each Vana'diel day" },
                        { text = "   - 4 lever combos (U=Up D=Down): DDDD, UUUU, UUUD, UDUU, UUDU, DUUU," },
                        { text = "     UUDD, UDUD, UDDU, DUUD, DUDU, DDUU, UDDD, DUDD, DDUD, DDDU" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

        THF = {
            name = "Thief",
            starter_job = true,
            requirements = {
                "Thief is a starting job - no unlock quest required"
            },
            steps = {},
            af_quests = {
                {
                    name = "AF1 - The Tenshodo Showdown (THF 40+)",
                    reward = "Marauder's Knife",
                    steps = {
                        { text = "   Requires: Tenshodo Membership" },
                        { text = "   Note: Having Windurst Mission 2-1 active prevents starting this quest" },
                        { text = "1. Talk to Nanaa Mihgo in ", location = "Windurst Woods (J-3)", detail = "must be on THF - may need to talk multiple times" },
                        { text = "   - Receive Letter from the Tenshodo" },
                        { text = "2. Go to Lower Jeuno - talk to Harnek inside Tenshodo at ", location = "(J-7)" },
                        { text = "   - Receive Tenshodo envelope" },
                        { text = "3. Travel to Selbina - talk to Elfriede at ", location = "(J-9)", detail = "Shepherd's Muster Inn" },
                        { text = "   - Sneaking Tiger asks for Quadav Stew" },
                        { text = "4. Go to Beadeaux - Steal from Garnet/Silver/Zircon/Bronze Quadav for Quadav Stew" },
                        { text = "   - Can steal BEFORE going to Selbina to save time" },
                        { text = "5. Return to Selbina - trade Quadav Stew to Elfriede" },
                        { text = "   - Receive Signed envelope" },
                        { text = "6. Return to Lower Jeuno - talk to Harnek at (J-7) for reward" },
                    }
                },
                {
                    name = "AF2 - As Thick as Thieves (THF 50+)",
                    reward = "Rogue's Bonnet",
                    steps = {
                        { text = "   Items needed: Gausebit Grass, Rock Salt, Lizard Egg (multiple may be needed)" },
                        { text = "1. Speak to Nanaa Mihgo in ", location = "Windurst Woods (J-3)" },
                        { text = "   - Answer: V (correct answer from signed envelope)" },
                        { text = "   - Receive: Gang whereabouts note, First forged envelope, Second forged envelope" },
                        { text = "2. Speak to Cha Lebagta and Bopa Greso just south at (J-4) for clues" },
                        { text = "--- First Envelope (Sauromugue Champaign) ---" },
                        { text = "3. Check (???) at towers in Sauromugue Champaign to spawn Climbpix Highrise:" },
                        { text = "   - Tower locations: (G-6), (G/H-8), (I/J-7), (J/K-8), (K-9), (I-9/10)" },
                        { text = "   - Message 'impossible to climb with bare hands' confirms correct spots" },
                        { text = "   - (I-9/10) requires: Survival Guide warp, Voidwatch warp, Cavernous Maw, or Garlaige 3rd gate" },
                        { text = "4. Defeat Climbpix Highrise for Grapnel" },
                        { text = "5. Go to tower at (I/J-7) - remove ALL equipment" },
                        { text = "   - Trade Grapnel to (???) for cutscene and First signed forged envelope" },
                        { text = "--- Second Envelope (Dice Games) ---" },
                        { text = "6. Go to Lower Jeuno (H-10) - talk to Sniggnix in back hallway at Muckvix's Junk Shop" },
                        { text = "   - Beat him at dice (keep rolling until you win)" },
                        { text = "7. Go to Dangruf Wadi - beat 3 Goblins at dice in order:" },
                        { text = "   - Saltvix: trade Rock Salt to (???) at (G-7) west room" },
                        { text = "   - Grasswix: trade Gausebit Grass to (???) at (F-4/5) tunnel exit" },
                        { text = "   - Eggblix: trade Lizard Egg to (???) at (E-12) - hidden cave at (F-11), drop down hole, head south" },
                        { text = "   - No need to redo previous goblins if you lose - just trade item again" },
                        { text = "   - Difficulty reduces after each loss (2016 update)" },
                        { text = "8. After winning all 3, go to (J-3) Dangruf Wadi - ride geyser up cliff, zone into North Gustaberg" },
                        { text = "9. Follow river east all the way to waterfall (stay south side)" },
                        { text = "   - Find (???) - click to spawn Gambilox Wanderling (3 min repop)" },
                        { text = "   - Defeat Gambilox - click (???) again for Regal Die" },
                        { text = "10. Return to Lower Jeuno - trade Regal Die to Sniggnix for Second signed forged envelope" },
                        { text = "11. Return to Nanaa Mihgo in ", location = "Windurst Woods (J-3)", detail = "for Rogue's Bonnet" },
                    },
                    notes = {
                        "Must remove ALL equipment before trading Grapnel at tower",
                        "If Gambilox (???) says 'smells like a Goblin' wait a few minutes and retry"
                    }
                },
                {
                    name = "AF3 - Hitting the Marquisate (THF 50+)",
                    reward = "Rogue's Poulaines",
                    steps = {
                        { text = "   Must zone after As Thick as Thieves before starting" },
                        { text = "   Items needed: Quake Grenade x4, Pickaxe" },
                        { text = "1. Speak to Nanaa Mihgo in ", location = "Windurst Woods (J-3)", detail = "receive Cat Burglar's note" },
                        { text = "2. Go to Lower Jeuno (G-10) - speak to Yatniel on top floor" },
                        { text = "   - Trade 4x Quake Grenades to him for a clue" },
                        { text = "   - MUST trade grenades even if you skip ahead - needed to clear KI from Nanaa" },
                        { text = "3. Go to Mhaura (H-8) - speak to Hagain upstairs in Sailor's Stay" },
                        { text = "   - Receive Bomb incense key item" },
                        { text = "4. Go to Garlaige Citadel - examine 7 (???) in order using Bomb incense:" },
                        { text = "   - Tip: Switch to first person view and lock on to targets - (???) are in the ceiling" },
                        { text = "   1) (I-9) near first banishing gate" },
                        { text = "   2) (H-9) just west" },
                        { text = "   3) (F-9) west of intersection past first Banishing Gate" },
                        { text = "   4) (F/G-9) across the hall to the east" },
                        { text = "   5) (G-8/9) back toward Banishing Gate #1" },
                        { text = "   6) (G-7) north of that area" },
                        { text = "   7) (I-6) - spawns NM: Chandelier (READ NOTES BEFORE THIS STEP)" },
                        { text = "5. After cutscene use Hide or Spectral Jig IMMEDIATELY before Chandelier spawns" },
                        { text = "   - If Chandelier is not claimed before it aggros it self-destructs" },
                        { text = "   - 10 min (???) respawn if it self-destructs (no need to recheck other ???)" },
                        { text = "   - If you LEAVE the zone you must recheck ALL ??? again" },
                        { text = "6. Defeat Chandelier for Chandelier Coal" },
                        { text = "7. Return to Mhaura - trade Chandelier Coal to Hagain" },
                        { text = "8. Return to Nanaa Mihgo in ", location = "Windurst Woods (J-3)" },
                        { text = "   - Answer: Blank (any answer progresses quest)" },
                        { text = "9. Go to Ordelle's Caves - enter from ", location = "La Theine Plateau (F-7)", detail = "or Survival Guide warp" },
                        { text = "   - Take east path at (H-3) to new map" },
                        { text = "   - Go to (H-9) path back to first map" },
                        { text = "   - Follow to hole at (H-11/12) - drop down, head east to tunnel at (I-11)" },
                        { text = "   - Follow stairs to (I-6) intersection, take left south, then west tunnel at (H-9)" },
                        { text = "   - Zone back into La Theine Plateau" },
                        { text = "10. Find (???) at (H-10) SW corner of valley - trade Pickaxe for cutscene and reward" },
                        { text = "   - Only standard Pickaxe works - no other varieties" },
                    },
                    notes = {
                        "If using Proto-Waypoint in La Theine, still zone into and back out of Ordelle's Caves first",
                        "Spectral Jig immediately after cutscene is the safest way to claim Chandelier"
                    }
                },
                {
                    name = "AF4 - Borghertz's Sneaky Hands (THF 50+)",
                    reward = "Rogue's Armlets + Culottes + Vest",
                    steps = {
                        { text = "   Requires: Started As Thick as Thieves" },
                        { text = "   Items needed: Davoi Coffer Key (or Thief's Tools)" },
                        { text = "1. Talk to Guslam at ", location = "Upper Jeuno (H-8)", detail = "Durable Shields shop - must be on THF" },
                        { text = "2. Go to Davoi then travel to Monastic Cavern - find Treasure Coffer" },
                        { text = "   - Farm or buy Davoi Coffer Key, or pick lock as THF" },
                        { text = "   - Does NOT need to be on THF to open coffer" },
                        { text = "   - Receive: Old gauntlets (key item)" },
                        { text = "3. Return to Guslam in ", location = "Upper Jeuno (H-8)" },
                        { text = "4. First time only - speak to Deadly Minnow inside Durable Shields shop" },
                        { text = "   - Go to Lower Jeuno Tenshodo - speak to Yin Pocanakhu at (J-8)" },
                        { text = "   - Trade 1,000 gil to continue" },
                        { text = "5. Go to Port Jeuno - click (???) toolbox atop crates near AH and Duty-Free at ", location = "(H-8)" },
                        { text = "6. Click (???) for cutscene" },
                        { text = "7. Travel to Castle Zvahl Baileys (F-8) on first map" },
                        { text = "   - Click torch to spawn NM: Dark Spark - defeat it" },
                        { text = "   - Examine torch for Shadow flames (key item)" },
                        { text = "8. Return to Port Jeuno and examine (???) again for final cutscene" },
                        { text = "Additional AF pieces from coffers (THF must be main job):" },
                        { text = "   - Castle Oztroja coffer > Rogue's Culottes" },
                        { text = "   - Castle Zvahl Baileys coffer > Rogue's Vest" },
                    },
                    notes = {
                        "Cannot have another Borghertz's Hands quest active at same time",
                        "Coffer pieces not required to complete the quest"
                    }
                }
            }
        },

    } -- End of jobs table
}; -- End of jobhelper table

--[[
* Renders a separator
--]]
local function fancy_separator()
    imgui.Separator();
    imgui.Spacing();
end

--[[
* Renders weather requirements for SMN unlock
--]]
local function render_weather_requirements(weather_data)
    imgui.TextColored(colors.header, 'Weather Requirements:');
    imgui.Indent(10);
    
    for _, weather in ipairs(weather_data) do
        -- Color and weather type
        imgui.TextColored(colors.requirement, weather.color);
        imgui.SameLine();
        imgui.TextColored(colors.step, string.format(" (%s) - %s", weather.element, weather.weather));
        
        -- Areas
        imgui.TextColored(colors.location, "    Areas: " .. weather.areas);
    end
    
    imgui.Unindent(10);
    fancy_separator();
end

--[[
* Renders the quest series for jobs like PLD
--]]
local function render_quest_series(quest_series)
    -- Define the correct order of quests
    local quest_order = {
        "squire_test_1",
        "squire_test_2",
        "knights_test"
    };

    -- Iterate through quests in the defined order
    for _, quest_name in ipairs(quest_order) do
        local quest_data = quest_series[quest_name];
        if quest_data then
            imgui.TextColored(colors.header, quest_name .. " (Level " .. quest_data.level .. ")");
            
            if quest_data.items_needed then
                imgui.TextColored(colors.requirement, "Items Needed:");
                imgui.Indent(10);
                for _, item in ipairs(quest_data.items_needed) do
                    imgui.TextColored(colors.step, "- " .. item);
                end
                imgui.Unindent(10);
                imgui.Spacing();
            end

            for _, step in ipairs(quest_data.steps) do
                imgui.TextColored(colors.step, step.text);
                if step.location then
                    imgui.SameLine();
                    imgui.TextColored(colors.location, step.location);
                    if step.detail then
                        imgui.SameLine();
                        imgui.TextColored(colors.step, step.detail);
                    end
                end
            end

            if quest_data.notes then
                imgui.Spacing();
                imgui.TextColored(colors.note, "Notes:");
                imgui.Indent(10);
                for _, note in ipairs(quest_data.notes) do
                    imgui.TextColored(colors.step, "- " .. note);
                end
                imgui.Unindent(10);
            end

            fancy_separator();
        end
    end
end

--[[
* Renders AF quests as collapsible sections
--]]
local function render_af_quests(af_quests)
    imgui.TextColored(colors.header, 'Artifact Armor Quests:');
    fancy_separator();

    for _, quest in ipairs(af_quests) do
        imgui.PushStyleColor(ImGuiCol_Header, { 0.4, 0.25, 0.05, 1.0 });
        imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.55, 0.35, 0.1, 1.0 });
        imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.65, 0.45, 0.15, 1.0 });

        local header_label = quest.name;
        if quest.reward then
            header_label = quest.name .. '  [' .. quest.reward .. ']';
        end

        if imgui.CollapsingHeader(header_label) then
            imgui.Indent(10);

            for _, step in ipairs(quest.steps) do
                imgui.TextColored(colors.step, step.text);
                if step.location then
                    imgui.SameLine();
                    imgui.TextColored(colors.location, step.location);
                    if step.detail then
                        imgui.SameLine();
                        imgui.TextColored(colors.step, '(' .. step.detail .. ')');
                    end
                end
            end

            if quest.notes then
                imgui.Spacing();
                imgui.TextColored(colors.note, 'Notes:');
                imgui.Indent(10);
                for _, note in ipairs(quest.notes) do
                    imgui.TextColored(colors.note, '- ' .. note);
                end
                imgui.Unindent(10);
            end

            imgui.Unindent(10);
            imgui.Spacing();
        end

        imgui.PopStyleColor(3);
    end

    fancy_separator();
end

--[[
* Renders prerequisite quests as collapsible sections (e.g. BST)
--]]
local function render_prereq_quests(prereq_quests)
    imgui.TextColored(colors.header, 'Prerequisite Quests (complete in order):');
    fancy_separator();

    for _, quest in ipairs(prereq_quests) do
        imgui.PushStyleColor(ImGuiCol_Header, { 0.2, 0.35, 0.2, 1.0 });
        imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.3, 0.5, 0.3, 1.0 });
        imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.4, 0.6, 0.4, 1.0 });

        if imgui.CollapsingHeader(quest.name) then
            imgui.Indent(10);

            for _, step in ipairs(quest.steps) do
                imgui.TextColored(colors.step, step.text);
                if step.location then
                    imgui.SameLine();
                    imgui.TextColored(colors.location, step.location);
                    if step.detail then
                        imgui.SameLine();
                        imgui.TextColored(colors.step, '(' .. step.detail .. ')');
                    end
                end
            end

            if quest.notes then
                imgui.Spacing();
                imgui.TextColored(colors.note, 'Notes:');
                imgui.Indent(10);
                for _, note in ipairs(quest.notes) do
                    imgui.TextColored(colors.note, '- ' .. note);
                end
                imgui.Unindent(10);
            end

            imgui.Unindent(10);
            imgui.Spacing();
        end

        imgui.PopStyleColor(3);
    end

    fancy_separator();
end

--[[
* Renders the job guide
--]]
local function render_job_guide(job_data)
    local title_text = job_data.starter_job and (job_data.name .. ' Guide') or (job_data.name .. ' Unlock Guide');

    -- Unlock section as collapsing header (purple style)
    imgui.PushStyleColor(ImGuiCol_Header, { 0.25, 0.1, 0.4, 1.0 });
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.35, 0.15, 0.55, 1.0 });
    imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.45, 0.2, 0.65, 1.0 });

    if imgui.CollapsingHeader(title_text) then
        imgui.Indent(10);

        -- Requirements
        imgui.TextColored(colors.header, 'Requirements:');
        imgui.Indent(10);
        for _, req in ipairs(job_data.requirements) do
            imgui.TextColored(colors.requirement, '□ ' .. req);
        end
        imgui.Unindent(10);
        fancy_separator();

        -- Prerequisite quests (e.g. BST)
        if job_data.prereq_quests then
            render_prereq_quests(job_data.prereq_quests);
        elseif job_data.quest_series then
            render_quest_series(job_data.quest_series);
        elseif not job_data.starter_job then
            -- Standard steps
            imgui.TextColored(colors.header, 'Quest Steps:');
            imgui.Indent(10);
            for i, step in ipairs(job_data.steps) do
                imgui.TextColored(colors.step, step.text);
                if step.location then
                    imgui.SameLine();
                    imgui.TextColored(colors.location, step.location);
                    if step.detail then
                        imgui.SameLine();
                        imgui.TextColored(colors.step, '(' .. step.detail .. ')');
                    end
                end
            end
            imgui.Unindent(10);
            fancy_separator();
        end

        -- Weather Requirements (SMN only)
        if job_data.weather_requirements then
            render_weather_requirements(job_data.weather_requirements);
        end

        -- Warnings
        if job_data.warnings then
            imgui.TextColored(colors.header, 'Warnings:');
            imgui.Indent(10);
            for _, warning in ipairs(job_data.warnings) do
                imgui.TextColored(colors.warning, '! ' .. warning);
            end
            imgui.Unindent(10);
            fancy_separator();
        end

        -- Notes
        if job_data.notes then
            imgui.TextColored(colors.header, 'Notes:');
            imgui.Indent(10);
            for _, note in ipairs(job_data.notes) do
                imgui.TextColored(colors.note, '- ' .. note);
            end
            imgui.Unindent(10);
            fancy_separator();
        end

        imgui.Unindent(10);
    end

    imgui.PopStyleColor(3);

    -- AF Quests always visible below the unlock header
    if job_data.af_quests then
        render_af_quests(job_data.af_quests);
    end
end

--[[
* Renders the UI.
--]]
local function render_ui()
    if (not jobhelper.is_open[1]) then
        return;
    end

    -- Set window style
    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.1, 0.1, 0.15, 0.95 });
    imgui.PushStyleColor(ImGuiCol_TitleBg, { 0.2, 0.2, 0.3, 1.0 });
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, { 0.3, 0.3, 0.4, 1.0 });
    imgui.PushStyleColor(ImGuiCol_Border, { 0.5, 0.5, 0.8, 0.5 });
    imgui.PushStyleColor(ImGuiCol_Separator, { 0.5, 0.5, 0.8, 0.5 });
    
    -- Increased maximum window size constraints
    imgui.SetNextWindowSizeConstraints(
        { 400, 500 },
        { 1920, 1080 }
    );
    
    -- Set initial window size if not already set
    imgui.SetNextWindowSize({ 800, 900 }, ImGuiCond_FirstUseEver);
    
    if (imgui.Begin('JobHelper', jobhelper.is_open, ImGuiWindowFlags_None)) then
        -- Job selection buttons with better layout
        local button_width = 100;
        local window_width = imgui.GetWindowWidth();
        local buttons_per_row = math.floor((window_width - 20) / (button_width + 5));
        local button_count = 0;

        -- Build sorted job list alphabetically by name
        local sorted_jobs = {};
        for job_key, job_data in pairs(jobhelper.jobs) do
            table.insert(sorted_jobs, { key = job_key, name = job_data.name });
        end
        table.sort(sorted_jobs, function(a, b) return a.name < b.name; end);

        for _, job_entry in ipairs(sorted_jobs) do
            if button_count > 0 and button_count % buttons_per_row ~= 0 then
                imgui.SameLine();
            end
            
            imgui.SetNextItemWidth(button_width);
            if imgui.Button(job_entry.name, { button_width, 0 }) then
                jobhelper.selected_job = job_entry.key;
            end
            
            button_count = button_count + 1;
        end

        imgui.NewLine();
        fancy_separator();
        
        -- Render selected job guide
        if jobhelper.selected_job then
            render_job_guide(jobhelper.jobs[jobhelper.selected_job]);
        else
            imgui.TextColored(colors.header, 'Select a job above to view unlock guide');
        end

        -- Store the window position
        local pos = { imgui.GetWindowPos() };
        jobhelper.settings.position_x = pos[1];
        jobhelper.settings.position_y = pos[2];
    end

    imgui.End();

    -- Pop window style colors
    imgui.PopStyleColor(5);
end


--[[
* Registers events when the addon is loaded.
--]]
ashita.events.register('d3d_present', 'present_cb', render_ui);

--[[
* Handles addon commands.
--]]
ashita.events.register('command', 'command_cb', function (e)
    -- Get the command arguments..
    local args = e.command:args();
    if (#args == 0) then
        return;
    end

    -- Handle: /jobhelper
    if (args[1] == '/jobhelper') then
        -- Block the command from being processed by the game..
        e.blocked = true;

        -- Toggle the UI visibility..
        jobhelper.is_open[1] = not jobhelper.is_open[1];
        
        -- Set the window position when opening
        if jobhelper.is_open[1] then
            imgui.SetNextWindowPos({ jobhelper.settings.position_x, jobhelper.settings.position_y }, ImGuiCond_FirstUseEver);
        end
    end
end);


--[[
* event: load
* desc : Event called when the addon is being loaded.
--]]
ashita.events.register('load', 'load_cb', function()
    imgui.SetNextWindowPos({ jobhelper.settings.position_x, jobhelper.settings.position_y }, ImGuiCond_FirstUseEver);
end);

--[[
* event: unload
* desc : Event called when the addon is being unloaded.
--]]
ashita.events.register('unload', 'unload_cb', function()
    -- Add any cleanup code here if needed
end);

--[[
* Returns the addon object.
--]]
return jobhelper;

