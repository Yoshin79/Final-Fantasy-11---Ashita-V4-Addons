--[[
* Addons - Copyright (c) 2021 Ashita Development Team
* Contact: https://www.ashitaxi.com/
* Contact: https://discord.gg/Ashita
*
* This file is part of Ashita.
*
* Ashita is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Ashita is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with Ashita.  If not, see <https://www.gnu.org/licenses/>.
--]]

addon.name      = 'petinfo';
addon.author    = 'atom0s & Tornac - Modified by Oneword';
addon.version   = '1.8.1';
addon.desc      = 'Displays information about the players pet - Now Able to Seperate Windows and imgui added and color adjustment and no borders.';
addon.link      = '';

require('common');
local imgui = require('imgui');
local settings = require('settings');
local chat = require('chat');

-- PetInfo Variables
local petinfo = T{
    is_open = { true, },
    target  = nil,
    target_open = { true, },
    force_pet_position = false,
    force_target_position = false
};

-- Configuration variables
local config = T{
    is_open = { true, },
    show_config = { false, },
    pet_window = {
        position = { 100, 100 },
        show_hp = true,
        show_mp = true,
        show_tp = true,
        font_scale = 1.0,      -- Font size multiplier (0.5 to 2.0)
        bar_height = 16,       -- Height of HP/MP/TP bars in pixels
        window_width = 250     -- Width of the windows in pixels
    },
    target_window = {
        position = { 100, 250 },
        show_window = true,
        font_scale = 1.0,      -- Font size multiplier (0.5 to 2.0)
        bar_height = 16,       -- Height of HP bar in pixels
        window_width = 250     -- Width of the window in pixels
    },
    colors = {
        hp = { 0.0, 1.0, 0.0, 1.0 },     -- Green (from 4278255360)
        mp = { 0.8, 0.0, 1.0, 1.0 },     -- Purple (from 4290996735)
        tp = { 0.0, 0.7, 1.0, 1.0 },     -- Blue (from 4278234111)
        target_hp = { 1.0, 0.0, 0.0, 1.0 } -- Red for target HP
    }
};

-- Default positions for reset functionality
local default_positions = {
    pet = { 100, 100 },
    target = { 100, 250 }
};

-- Helper function to calculate content height based on settings
local function calculate_pet_content_height()
    local base_height = 16 * config.pet_window.font_scale; -- Name height
    base_height = base_height + (5 * config.pet_window.font_scale); -- Separator
    
    if (config.pet_window.show_hp) then
        base_height = base_height + config.pet_window.bar_height + (4 * config.pet_window.font_scale);
    end
    
    if (config.pet_window.show_mp) then
        base_height = base_height + config.pet_window.bar_height + (4 * config.pet_window.font_scale);
    end
    
    if (config.pet_window.show_tp) then
        base_height = base_height + config.pet_window.bar_height + (4 * config.pet_window.font_scale);
    end
    
    -- Add padding
    base_height = base_height + (16 * config.pet_window.font_scale);
    
    return base_height;
end

-- Helper function to calculate target window content height
local function calculate_target_content_height()
    local base_height = 16 * config.target_window.font_scale; -- Name height
    base_height = base_height + (5 * config.target_window.font_scale); -- Separator
    base_height = base_height + config.target_window.bar_height + (4 * config.target_window.font_scale); -- HP bar
    base_height = base_height + (16 * config.target_window.font_scale); -- Padding
    
    return base_height;
end

--[[
* Returns the entity that matches the given server id.
*
* @param {number} sid - The entity server id.
* @return {object | nil} The entity on success, nil otherwise.
--]]
local function GetEntityByServerId(sid)
    for x = 0, 2303 do
        local ent = GetEntity(x);
        if (ent ~= nil and ent.ServerId == sid) then
            return ent;
        end
    end
    return nil;
end

--[[
* Saves the current positions to settings.
--]]
local function save_positions()
    settings.save();
    print(chat.header(addon.name) .. chat.message('Positions saved.'));
end

--[[
* Resets the pet window position to default.
--]]
local function reset_pet_position()
    config.pet_window.position = { default_positions.pet[1], default_positions.pet[2] };
    petinfo.force_pet_position = true;
    settings.save();
    print(chat.header(addon.name) .. chat.message('Pet window position reset to default.'));
end

--[[
* Resets the target window position to default.
--]]
local function reset_target_position()
    config.target_window.position = { default_positions.target[1], default_positions.target[2] };
    petinfo.force_target_position = true;
    settings.save();
    print(chat.header(addon.name) .. chat.message('Target window position reset to default.'));
end

--[[
* Displays the configuration window.
--]]
local function display_config_window()
    if (not config.show_config[1]) then
        return;
    end
    
    if (imgui.Begin('PetInfo Configuration', config.show_config)) then
        -- Pet window settings
        if (imgui.CollapsingHeader('Pet Window Settings')) then
            local changed = false;
            
            -- Create temporary variables to hold checkbox states
            local show_hp = { config.pet_window.show_hp };
            local show_mp = { config.pet_window.show_mp };
            local show_tp = { config.pet_window.show_tp };
            
            -- Use the temporary variables with the checkboxes
            changed = imgui.Checkbox('Show HP Bar', show_hp) or changed;
            changed = imgui.Checkbox('Show MP Bar', show_mp) or changed;
            changed = imgui.Checkbox('Show TP Bar', show_tp) or changed;
            
            -- Update the config if any checkbox was changed
            if (changed) then
                config.pet_window.show_hp = show_hp[1];
                config.pet_window.show_mp = show_mp[1];
                config.pet_window.show_tp = show_tp[1];
                settings.save();
            end
            
            -- Add size controls
            imgui.Separator();
            imgui.Text('Size Settings:');
            
            -- Font scale slider
            local font_scale = { config.pet_window.font_scale };
            if (imgui.SliderFloat('Font Size##pet', font_scale, 0.5, 2.0, "%.2f")) then
                config.pet_window.font_scale = font_scale[1];
                settings.save();
            end
            imgui.SameLine();
            imgui.TextDisabled("(?)");
            if (imgui.IsItemHovered()) then
                imgui.BeginTooltip();
                imgui.Text("Adjusts the text size. 1.0 is normal, 0.5 is half size, 2.0 is double size.");
                imgui.EndTooltip();
            end
            
            -- Bar height slider
            local bar_height = { config.pet_window.bar_height };
            if (imgui.SliderInt('Bar Height##pet', bar_height, 8, 32)) then
                config.pet_window.bar_height = bar_height[1];
                settings.save();
            end
            imgui.SameLine();
            imgui.TextDisabled("(?)");
            if (imgui.IsItemHovered()) then
                imgui.BeginTooltip();
                imgui.Text("Adjusts the height of HP/MP/TP bars in pixels.");
                imgui.EndTooltip();
            end
            
            -- Window width slider
            local window_width = { config.pet_window.window_width };
            if (imgui.SliderInt('Window Width##pet', window_width, 150, 400)) then
                config.pet_window.window_width = window_width[1];
                settings.save();
            end
            
            -- Add position controls
            imgui.Separator();
            imgui.Text('Position: X=' .. tostring(config.pet_window.position[1]) .. 
                      ', Y=' .. tostring(config.pet_window.position[2]));
            
            if (imgui.Button('Reset Pet Position')) then
                reset_pet_position();
            end
        end
        
        -- Target window settings
        if (imgui.CollapsingHeader('Target Window Settings')) then
            local changed = false;
            
            -- Create temporary variable to hold checkbox state
            local show_window = { config.target_window.show_window };
            
            -- Use the temporary variable with the checkbox
            changed = imgui.Checkbox('Show Pet Target', show_window) or changed;
            
            -- Update the config if the checkbox was changed
            if (changed) then
                config.target_window.show_window = show_window[1];
                settings.save();
            end
            
            -- Add size controls
            imgui.Separator();
            imgui.Text('Size Settings:');
            
            -- Font scale slider
            local font_scale = { config.target_window.font_scale };
            if (imgui.SliderFloat('Font Size##target', font_scale, 0.5, 2.0, "%.2f")) then
                config.target_window.font_scale = font_scale[1];
                settings.save();
            end
            imgui.SameLine();
            imgui.TextDisabled("(?)");
            if (imgui.IsItemHovered()) then
                imgui.BeginTooltip();
                imgui.Text("Adjusts the text size. 1.0 is normal, 0.5 is half size, 2.0 is double size.");
                imgui.EndTooltip();
            end
            
            -- Bar height slider
            local bar_height = { config.target_window.bar_height };
            if (imgui.SliderInt('Bar Height##target', bar_height, 8, 32)) then
                config.target_window.bar_height = bar_height[1];
                settings.save();
            end
            
            -- Window width slider
            local window_width = { config.target_window.window_width };
            if (imgui.SliderInt('Window Width##target', window_width, 150, 400)) then
                config.target_window.window_width = window_width[1];
                settings.save();
            end
            
            -- Add position controls
            imgui.Separator();
            imgui.Text('Position: X=' .. tostring(config.target_window.position[1]) .. 
                      ', Y=' .. tostring(config.target_window.position[2]));
            
            if (imgui.Button('Reset Target Position')) then
                reset_target_position();
            end
        end
        
        -- Color settings
        if (imgui.CollapsingHeader('Color Settings')) then
            local changed = false;
            
            changed = imgui.ColorEdit4('Pet HP Color', config.colors.hp) or changed;
            changed = imgui.ColorEdit4('Pet MP Color', config.colors.mp) or changed;
            changed = imgui.ColorEdit4('Pet TP Color', config.colors.tp) or changed;
            changed = imgui.ColorEdit4('Target HP Color', config.colors.target_hp) or changed;
            
            if (changed) then
                settings.save();
            end
        end
        
        -- Add a save button at the bottom of the config window
        imgui.Separator();
        if (imgui.Button('Save Settings')) then
            save_positions();
        end
    end
    imgui.End();
end

--[[
* event: load
* desc : Event called when the addon is loaded.
--]]
ashita.events.register('load', 'load_cb', function()
    -- Load the configuration..
    config = settings.load(config) or config;
end);

--[[
* event: unload
* desc : Event called when the addon is unloaded.
--]]
ashita.events.register('unload', 'unload_cb', function()
    -- Save the configuration..
    settings.save();
end);

--[[
* event: command
* desc : Event called when the addon is processing a command.
--]]
ashita.events.register('command', 'command_cb', function (e)
    -- Parse the command arguments..
    local args = e.command:args();
    if (#args == 0 or args[1] ~= '/petinfo') then
        return;
    end

    -- Block all related commands..
    e.blocked = true;

    -- Handle: /petinfo config - Shows the configuration window
    if (#args >= 2 and args[2]:lower() == 'config') then
        config.show_config[1] = not config.show_config[1];
        return;
    end
    
    -- Handle: /petinfo save - Saves the current positions
    if (#args >= 2 and args[2]:lower() == 'save') then
        save_positions();
        return;
    end
    
    -- Handle: /petinfo resetpet - Resets the pet window position
    if (#args >= 2 and args[2]:lower() == 'resetpet') then
        reset_pet_position();
        return;
    end
    
    -- Handle: /petinfo resettarget - Resets the target window position
    if (#args >= 2 and args[2]:lower() == 'resettarget') then
        reset_target_position();
        return;
    end
    
    -- Handle: /petinfo - Toggles the main display
    petinfo.is_open[1] = not petinfo.is_open[1];
end);

--[[
* event: packet_in
* desc : Event called when the addon is processing incoming packets.
--]]
ashita.events.register('packet_in', 'packet_in_cb', function (e)
    -- Packet: Action
    if (e.id == 0x0028) then
        -- Obtain the player entitiy..
        local player = GetPlayerEntity();
        if (player == nil or player.PetTargetIndex == 0) then
            petinfo.target = nil;
            return;
        end

        -- Obtain the player pet entity..
        local pet = GetEntity(player.PetTargetIndex);
        if (pet == nil) then
            petinfo.target = nil;
            return;
        end

        -- Obtain the action main target id if the actor is the player pet..
        local aid = struct.unpack('I', e.data_modified, 0x05 + 0x01);
        if (aid ~= 0 and aid == pet.ServerId) then
            petinfo.target = ashita.bits.unpack_be(e.data_modified:totable(), 0x96, 0x20);
            return;
        end

        return;
    end

    -- Packet: Pet Sync
    if (e.id == 0x0068) then
        -- Obtain the player entitiy..
        local player = GetPlayerEntity();
        if (player == nil) then
            petinfo.target = nil;
            return;
        end

        -- Update the players pet target..
        local owner = struct.unpack('I', e.data_modified, 0x08 + 0x01);
        if (owner == player.ServerId) then
            petinfo.target = struct.unpack('I', e.data_modified, 0x14 + 0x01);
        end

        return;
    end
end);

--[[
* event: d3d_present
* desc : Event called when the Direct3D device is presenting a scene.
--]]
ashita.events.register('d3d_present', 'present_cb', function ()
    -- Obtain the player entity..
    local player = GetPlayerEntity();
    if (player == nil) then
        petinfo.target = nil;
        return;
    end

    -- Display configuration window
    display_config_window();

    -- Check if main display is enabled
    if (not petinfo.is_open[1]) then
        return;
    end

    -- Obtain the player pet entity..
    local pet = GetEntity(player.PetTargetIndex);
    if (pet == nil or pet.Name == nil) then
        petinfo.target = nil;
        return;
    end

    -- Calculate content height for pet window
    local content_height = calculate_pet_content_height();
    
    -- Pet Window
    if (petinfo.force_pet_position) then
        imgui.SetNextWindowPos({ config.pet_window.position[1], config.pet_window.position[2] });
        petinfo.force_pet_position = false;
    else
        imgui.SetNextWindowPos({ config.pet_window.position[1], config.pet_window.position[2] }, ImGuiCond_FirstUseEver);
    end
    imgui.SetNextWindowSize({ config.pet_window.window_width, content_height });
    
    if (imgui.Begin('PetInfo', petinfo.is_open, ImGuiWindowFlags_NoDecoration)) then
        -- Apply font scale
        if (config.pet_window.font_scale ~= 1.0) then
            imgui.SetWindowFontScale(config.pet_window.font_scale);
        end
        -- Handle double-click to close window
        if (imgui.IsWindowFocused()) then
            if (imgui.IsMouseDoubleClicked(ImGuiMouseButton_Left)) then
                petinfo.is_open[1] = not petinfo.is_open[1];
            end
        end
        
        -- Save position if window is moved
        local pos = { imgui.GetWindowPos() };
        if (pos[1] ~= config.pet_window.position[1] or pos[2] ~= config.pet_window.position[2]) then
            config.pet_window.position = pos;
            settings.save();
        end
        
        -- Obtain and prepare pet information..
        local petmp = AshitaCore:GetMemoryManager():GetPlayer():GetPetMPPercent();
        local pettp = AshitaCore:GetMemoryManager():GetPlayer():GetPetTP();
        local dist  = ('%.1f'):fmt(math.sqrt(pet.Distance));
        local x, _  = imgui.CalcTextSize(dist);

        -- Display the pets information..
        imgui.Text(pet.Name);
        imgui.SameLine();
        imgui.SetCursorPosX(imgui.GetCursorPosX() + imgui.GetColumnWidth() - x - imgui.GetStyle().FramePadding.x);
        imgui.Text(dist);
        imgui.Separator();
        
        -- Show HP bar if enabled
        if (config.pet_window.show_hp) then
            imgui.Text('HP:');
            imgui.SameLine();
            imgui.PushStyleColor(ImGuiCol_PlotHistogram, config.colors.hp);
            imgui.ProgressBar(pet.HPPercent / 100, { -1, config.pet_window.bar_height });
            imgui.PopStyleColor(1);
        end
        
        -- Show MP bar if enabled
        if (config.pet_window.show_mp) then
            imgui.Text('MP:');
            imgui.SameLine();
            imgui.PushStyleColor(ImGuiCol_PlotHistogram, config.colors.mp);
            imgui.ProgressBar(petmp / 100, { -1, config.pet_window.bar_height });
            imgui.PopStyleColor(1);
        end
        
        -- Show TP bar if enabled
        if (config.pet_window.show_tp) then
            imgui.Text('TP:');
            imgui.SameLine();
            imgui.PushStyleColor(ImGuiCol_PlotHistogram, config.colors.tp);
            imgui.ProgressBar(pettp / 3000, { -1, config.pet_window.bar_height }, tostring(pettp));
            imgui.PopStyleColor(1);
        end
        
        -- Reset font scale for other windows
        if (config.pet_window.font_scale ~= 1.0) then
            imgui.SetWindowFontScale(1.0);
        end
    end
    imgui.End();

    -- Target Window (only show if pet has a target and target window is enabled)
    if (petinfo.target ~= nil and config.target_window.show_window) then
        local target = GetEntityByServerId(petinfo.target);
        if (target == nil or target.ActorPointer == 0 or target.HPPercent == 0) then
            petinfo.target = nil;
        else
            -- Calculate content height for target window
            local target_height = calculate_target_content_height();
            
            if (petinfo.force_target_position) then
                imgui.SetNextWindowPos({ config.target_window.position[1], config.target_window.position[2] });
                petinfo.force_target_position = false;
            else
                imgui.SetNextWindowPos({ config.target_window.position[1], config.target_window.position[2] }, ImGuiCond_FirstUseEver);
            end
            imgui.SetNextWindowSize({ config.target_window.window_width, target_height });
            
            if (imgui.Begin('PetTarget', petinfo.target_open, ImGuiWindowFlags_NoDecoration)) then
                -- Apply font scale
                if (config.target_window.font_scale ~= 1.0) then
                    imgui.SetWindowFontScale(config.target_window.font_scale);
                end
                -- Handle double-click to close window
                if (imgui.IsWindowFocused()) then
                    if (imgui.IsMouseDoubleClicked(ImGuiMouseButton_Left)) then
                        config.target_window.show_window = false;
                        settings.save();
                    end
                end
                
                -- Save position if window is moved
                local pos = { imgui.GetWindowPos() };
                if (pos[1] ~= config.target_window.position[1] or pos[2] ~= config.target_window.position[2]) then
                    config.target_window.position = pos;
                    settings.save();
                end
                
                dist = ('%.1f'):fmt(math.sqrt(target.Distance));
                x, _ = imgui.CalcTextSize(dist);

                local tname = target.Name;
                if (tname == nil) then
                    tname = '';
                end

                imgui.Text(tname);
                imgui.SameLine();
                imgui.SetCursorPosX(imgui.GetCursorPosX() + imgui.GetColumnWidth() - x - imgui.GetStyle().FramePadding.x);
                imgui.Text(dist);
                imgui.Separator();
                
                -- Always show HP bar for target (no config option) - using red color
                imgui.Text('HP:');
                imgui.SameLine();
                imgui.PushStyleColor(ImGuiCol_PlotHistogram, config.colors.target_hp);
                imgui.ProgressBar(target.HPPercent / 100, { -1, config.target_window.bar_height });
                imgui.PopStyleColor(1);
                
                -- Reset font scale for other windows
                if (config.target_window.font_scale ~= 1.0) then
                    imgui.SetWindowFontScale(1.0);
                end
            end
            imgui.End();
        end
    end
end);
