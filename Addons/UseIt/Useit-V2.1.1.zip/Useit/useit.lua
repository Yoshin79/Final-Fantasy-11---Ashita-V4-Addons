--[[
* useit.lua
* Ashita V4 Addon
*
* Two tabs in one:
*   UseIt    — Auto-uses Silt Pouches, Bead Pouches, and Unity NM Coffers
*   LazyTome — Auto-uses skill-up tomes from inventory
*
* Commands:
*   /useit  (or /ui)  - Toggle the UI window
*   /ui toggle        - Enable/disable active tab
--]]

addon.name    = 'useit';
addon.author  = 'Oneword';
addon.version = '2.1.1';
addon.desc    = 'Auto-uses pouches, coffers, and skill-up tomes.';
addon.link    = 'https://github.com/Yoshin79';

require('common');
local imgui = require('imgui');
local chat  = require('chat');

----------------------------------------------------------------------------------------------------
-- Shared colors
----------------------------------------------------------------------------------------------------
local colors = {
    header  = { 1.0,  0.75, 0.25, 1.0 },
    active  = { 0.2,  0.85, 0.4,  1.0 },
    idle    = { 0.65, 0.65, 0.65, 1.0 },
    warn    = { 1.0,  0.85, 0.2,  1.0 },
    error   = { 1.0,  0.35, 0.35, 1.0 },
    dim     = { 0.5,  0.5,  0.5,  1.0 },
    white   = { 1.0,  1.0,  1.0,  1.0 },
    pouch   = { 0.3,  0.7,  1.0,  1.0 },
    coffer  = { 1.0,  0.7,  0.3,  1.0 },
    tome    = { 0.7,  0.4,  1.0,  1.0 },
};

local ui = {
    is_open = { true },
};

----------------------------------------------------------------------------------------------------
-- Shared helper: count item by ID in main inventory
----------------------------------------------------------------------------------------------------
local function count_id(item_id)
    local inv   = AshitaCore:GetMemoryManager():GetInventory();
    local total = 0;
    for i = 0, 81 do
        local slot = inv:GetContainerItem(0, i);
        if (slot ~= nil and slot.Id == item_id) then
            total = total + slot.Count;
        end
    end
    return total;
end

----------------------------------------------------------------------------------------------------
-- Shared safety checks
----------------------------------------------------------------------------------------------------
local bad_buffs = T{ 'Mounted', 'Weakness', 'Sleep', 'Charm', 'Terror', 'Paralysis', 'Stun', 'Petrification' };

local function is_safe()
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    local party  = AshitaCore:GetMemoryManager():GetParty();
    if (player:GetIsZoning() ~= 0) then return false; end
    if (party:GetMemberHP(0) < 1) then return false; end
    local buffs = player:GetBuffs();
    for _, buff in pairs(buffs) do
        local bname = AshitaCore:GetResourceManager():GetString('buffs.names', buff);
        if (bname and bad_buffs:contains(bname)) then return false; end
    end
    if (AshitaCore:GetMemoryManager():GetTarget():GetIsPlayerMoving() ~= 0) then return false; end
    return true;
end

----------------------------------------------------------------------------------------------------
-- TAB 1: UseIt — Pouches & Coffers
----------------------------------------------------------------------------------------------------
local KNOWN_ITEMS = T{
    { id = 6391, name = 'Silt Pouch', category = 'Pouch' },
    { id = 6392, name = 'Bead Pouch', category = 'Pouch' },
};
local COFFER_KEYWORDS = T{ 'coffer', 'grab bag' };

local useit = T{
    enabled      = false,
    menu_sel     = { -1 },
    current_item = nil,
    inventory    = T{ },
    list_str     = 'None\0',
    last_use     = os.time() - 3,
    use_delay    = 2.2,
};

local function ui_find_items()
    local found = T{ };
    local lst   = 'None\0';
    for _, known in ipairs(KNOWN_ITEMS) do
        local count = count_id(known.id);
        if (count > 0) then
            found:append({ name = known.name, id = known.id, count = count, category = known.category });
            lst = lst .. known.name .. '\0';
        end
    end
    local inv  = AshitaCore:GetMemoryManager():GetInventory();
    local seen = T{ };
    for i = 0, 81 do
        local slot = inv:GetContainerItem(0, i);
        if (slot ~= nil and slot.Id > 0 and not seen:contains(slot.Id)) then
            local res = AshitaCore:GetResourceManager():GetItemById(slot.Id);
            if (res ~= nil and res.Name[1] ~= nil and res.Name[1]:len() > 1) then
                local name  = res.Name[1];
                local lower = name:lower();
                local is_c  = false;
                for _, kw in ipairs(COFFER_KEYWORDS) do
                    if lower:contains(kw) then is_c = true; break; end
                end
                if (is_c) then
                    seen:append(slot.Id);
                    found:append({ name = name, id = slot.Id, count = count_id(slot.Id), category = 'Coffer' });
                    lst = lst .. name .. '\0';
                end
            end
        end
    end
    useit.inventory = found;
    useit.list_str  = lst;
end

local function useit_recount()
    local sel = useit.menu_sel[1];
    if (sel >= 0 and useit.inventory[sel + 1]) then
        useit.inventory[sel + 1].count = count_id(useit.inventory[sel + 1].id);
    end
end

----------------------------------------------------------------------------------------------------
-- TAB 2: LazyTome — Skill-up Tomes
----------------------------------------------------------------------------------------------------
local ALL_TOMES = T{
    { id = 6147, name = "Mikhe's Memo",         skill = 'Hand-to-Hand'    },
    { id = 6148, name = 'Dgr. Enchiridion',      skill = 'Dagger'          },
    { id = 6149, name = 'Swing and Stab',        skill = 'Sword'           },
    { id = 6150, name = "Mieuseloir's Diary",    skill = 'Great Sword'     },
    { id = 6151, name = "Bull's Diary",          skill = 'Axe'             },
    { id = 6152, name = 'Death for Dim.',     skill = 'Great Axe'       },
    { id = 6153, name = "Ludwig's Report",       skill = 'Scythe'          },
    { id = 6154, name = 'Clash of Titans',       skill = 'Polearm'         },
    { id = 6155, name = "Kagetora's Diary",      skill = 'Katana'          },
    { id = 6156, name = "Noillurie's Log",       skill = 'Great Katana'    },
    { id = 6157, name = "Ferreous's Diary",      skill = 'Club'            },
    { id = 6158, name = "K-P's Memoirs",         skill = 'Staff'           },
    { id = 6159, name = "Perih's Primer",        skill = 'Archery'         },
    { id = 6160, name = 'Barrels of Fun',        skill = 'Marksmanship'    },
    { id = 6161, name = 'T.W. Enchiridion',      skill = 'Throwing'        },
    { id = 6162, name = "Mikhe's Note",          skill = 'Guarding'        },
    { id = 6163, name = "Sonia's Diary",         skill = 'Evasion'         },
    { id = 6164, name = 'The Successor',         skill = 'Shield'          },
    { id = 6165, name = "Kage. Journal",         skill = 'Parry'           },
    { id = 6166, name = "Altana's Hymn",         skill = 'Divine Magic'    },
    { id = 6167, name = 'Coveffe Musings',       skill = 'Healing Magic'   },
    { id = 6168, name = 'Aid for All',           skill = 'Enhancing Magic' },
    { id = 6169, name = 'Inv. Report',           skill = 'Enfeebling Magic'},
    { id = 6170, name = 'Bounty List',           skill = 'Elemental Magic' },
    { id = 6171, name = 'Dark Deeds',            skill = 'Dark Magic'      },
    { id = 6172, name = 'Breezy Libretto',       skill = 'Singing'         },
    { id = 6173, name = 'Cavernous Score',       skill = 'String Instr.'   },
    { id = 6174, name = 'Beaming Score',         skill = 'Wind Instr.'     },
    { id = 6175, name = "Yomi's Diagram",        skill = 'Ninjutsu'        },
    { id = 6176, name = 'Astral Homeland',       skill = 'Summoning'       },
    { id = 6177, name = 'Life-form Study',       skill = 'Blue Magic'      },
    { id = 6178, name = "Hrohj's Record",        skill = 'Geomancy'        },
    { id = 6179, name = 'The Bell Tolls',        skill = 'Handbell'        },
};

local lazytome = T{
    enabled      = false,
    menu_sel     = { -1 },
    current_tome = nil,
    inventory    = T{ },
    list_str     = 'None\0',
    last_use     = os.time() - 3,
    use_delay    = 2.2,
};

local function lt_find_tomes()
    local found = T{ };
    local lst   = 'None\0';
    for _, tome in ipairs(ALL_TOMES) do
        local count = count_id(tome.id);
        if (count > 0) then
            found:append({ name = tome.name, skill = tome.skill, id = tome.id, count = count });
            lst = lst .. tome.name .. ' (' .. tome.skill .. ')' .. '\0';
        end
    end
    lazytome.inventory = found;
    lazytome.list_str  = lst;
end

local function lt_recount()
    local sel = lazytome.menu_sel[1];
    if (sel >= 0 and lazytome.inventory[sel + 1]) then
        lazytome.inventory[sel + 1].count = count_id(lazytome.inventory[sel + 1].id);
    end
end

----------------------------------------------------------------------------------------------------
-- Load
----------------------------------------------------------------------------------------------------
ashita.events.register('load', 'load_cb', function ()
    ui_find_items();
    lt_find_tomes();
end);

----------------------------------------------------------------------------------------------------
-- Main loop
----------------------------------------------------------------------------------------------------
ashita.events.register('d3d_present', 'present_cb', function ()
    local now    = os.time();
    local party  = AshitaCore:GetMemoryManager():GetParty();
    local safe   = is_safe();
    local player = AshitaCore:GetMemoryManager():GetPlayer();

    -- Handle zoning — disable both
    if (player:GetIsZoning() ~= 0) then
        useit.enabled   = false;
        useit.menu_sel  = { -1 };
        lazytome.enabled = false;
        lazytome.menu_sel = { -1 };
        ui_find_items();
        lt_find_tomes();
        goto render;
    end

    -- UseIt logic
    if (useit.enabled and safe) then
        local sel = useit.menu_sel[1];
        if (sel >= 0 and useit.inventory[sel + 1]) then
            useit_recount();
            local entry = useit.inventory[sel + 1];
            if (entry.count <= 0) then
                print(chat.header(addon.name):append(chat.message('Out of ' .. entry.name .. '! Disabling.')));
                useit.enabled      = false;
                useit.menu_sel     = { -1 };
                useit.current_item = nil;
                ui_find_items();
            else
                local status = AshitaCore:GetMemoryManager():GetEntity():GetStatus(party:GetMemberIndex(0));
                if ((now - useit.last_use) >= useit.use_delay and status == 0) then
                    AshitaCore:GetChatManager():QueueCommand(1, '/item "' .. entry.name .. '" <me>');
                    useit.last_use = now;
                end
            end
        end
    end

    -- LazyTome logic
    if (lazytome.enabled and safe) then
        local sel = lazytome.menu_sel[1];
        if (sel >= 0 and lazytome.inventory[sel + 1]) then
            lt_recount();
            local entry = lazytome.inventory[sel + 1];
            if (entry.count <= 0) then
                print(chat.header(addon.name):append(chat.message('Out of ' .. entry.name .. '! Disabling.')));
                lazytome.enabled      = false;
                lazytome.menu_sel     = { -1 };
                lazytome.current_tome = nil;
                lt_find_tomes();
            else
                local status = AshitaCore:GetMemoryManager():GetEntity():GetStatus(party:GetMemberIndex(0));
                if ((now - lazytome.last_use) >= lazytome.use_delay and status == 0) then
                    AshitaCore:GetChatManager():QueueCommand(1, '/item "' .. entry.name .. '" <me>');
                    lazytome.last_use = now;
                end
            end
        end
    end

    ::render::
    if (not ui.is_open[1]) then return; end

    imgui.SetNextWindowSize({ 420, 0 }, ImGuiCond_FirstUseEver);
    imgui.SetNextWindowSizeConstraints({ 360, 0 }, { 600, 700 });

    if (imgui.Begin('UseIt', ui.is_open, ImGuiWindowFlags_None)) then

        imgui.TextColored(colors.header, 'UseIt');
        imgui.SameLine();
        imgui.TextDisabled('v2.0');
        imgui.Separator();
        imgui.Spacing();

        if (imgui.BeginTabBar('##useit_tabs', ImGuiTabBarFlags_None)) then

            ------------------------------------------------------------
            -- Tab 1: UseIt (Pouches & Coffers)
            ------------------------------------------------------------
            imgui.PushStyleColor(ImGuiCol_Tab,        { 0.1,  0.25, 0.45, 1.0 });
            imgui.PushStyleColor(ImGuiCol_TabHovered, { 0.15, 0.35, 0.6,  1.0 });
            imgui.PushStyleColor(ImGuiCol_TabActive,  { 0.15, 0.35, 0.6,  1.0 });
            imgui.PushStyleColor(ImGuiCol_Text,       { 1.0,  1.0,  1.0,  1.0 });
            local tab1 = imgui.BeginTabItem('Pouches & Coffers##t1');
            imgui.PopStyleColor(4);

            if (tab1) then
                imgui.Spacing();

                -- Status
                imgui.Text('Status:');
                imgui.SameLine();
                if (useit.enabled) then
                    imgui.TextColored(colors.active, 'Enabled');
                    if (useit.current_item) then
                        imgui.SameLine();
                        imgui.TextDisabled('- ' .. useit.current_item);
                    end
                else
                    imgui.TextColored(colors.idle, 'Disabled');
                end

                imgui.Spacing();
                imgui.Separator();
                imgui.Spacing();

                -- Item selector
                imgui.Text('Select Item:');
                imgui.Spacing();
                local sel_display = { useit.menu_sel[1] + 1 };
                if (imgui.Combo('##itemcombo', sel_display, useit.list_str)) then
                    useit.menu_sel[1] = sel_display[1] - 1;
                    local idx = useit.menu_sel[1];
                    if (idx < 0) then
                        useit.enabled      = false;
                        useit.current_item = nil;
                    else
                        useit.current_item = useit.inventory[idx + 1].name;
                    end
                end

                -- Stock badge
                local idx = useit.menu_sel[1];
                if (idx >= 0 and useit.inventory[idx + 1]) then
                    local e = useit.inventory[idx + 1];
                    local cat_color = (e.category == 'Pouch') and colors.pouch or colors.coffer;
                    imgui.Text('  Stock:');
                    imgui.SameLine();
                    imgui.TextColored(e.count > 0 and colors.active or colors.warn, tostring(e.count));
                    imgui.SameLine();
                    imgui.TextColored(cat_color, '  [' .. e.category .. ']');
                else
                    imgui.TextDisabled('  No item selected.');
                end

                imgui.Spacing();
                imgui.Separator();
                imgui.Spacing();

                -- Inventory summary
                local has_pouches, has_coffers = false, false;
                for _, e in ipairs(useit.inventory) do
                    if (e.category == 'Pouch')  then has_pouches = true; end
                    if (e.category == 'Coffer') then has_coffers = true; end
                end
                if (has_pouches or has_coffers) then
                    imgui.TextColored(colors.dim, 'In inventory:');
                    if (has_pouches) then
                        imgui.TextColored(colors.pouch, '  Pouches:');
                        for _, e in ipairs(useit.inventory) do
                            if (e.category == 'Pouch') then
                                imgui.SameLine();
                                imgui.Text(e.name .. ' x' .. e.count .. '  ');
                            end
                        end
                    end
                    if (has_coffers) then
                        imgui.TextColored(colors.coffer, '  Coffers:');
                        for _, e in ipairs(useit.inventory) do
                            if (e.category == 'Coffer') then
                                imgui.Text('    ' .. e.name .. ' x' .. e.count);
                            end
                        end
                    end
                    imgui.Spacing();
                    imgui.Separator();
                    imgui.Spacing();
                end

                -- Delay slider
                local dv = { useit.use_delay };
                if (imgui.SliderFloat('Use Delay (s)##ud', dv, 1.0, 5.0, '%.1f')) then
                    useit.use_delay = dv[1];
                end
                imgui.ShowHelp('Time between each item use. 2.2s matches the game cooldown.');

                imgui.Spacing();
                imgui.Separator();
                imgui.Spacing();

                if (imgui.Button('Refresh##ui')) then
                    useit.menu_sel     = { -1 };
                    useit.current_item = nil;
                    useit.enabled      = false;
                    ui_find_items();
                    print(chat.header(addon.name):append(chat.message('Item list refreshed.')));
                end
                imgui.ShowHelp('Rescans inventory for pouches and coffers.');
                imgui.SameLine();

                if (useit.enabled) then
                    imgui.PushStyleColor(ImGuiCol_Button,        { 0.65, 0.12, 0.12, 1.0 });
                    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.85, 0.18, 0.18, 1.0 });
                    imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.45, 0.08, 0.08, 1.0 });
                    if (imgui.Button('Disable##ui')) then
                        useit.enabled = false;
                        print(chat.header(addon.name):append(chat.message('UseIt disabled.')));
                    end
                    imgui.PopStyleColor(3);
                else
                    imgui.PushStyleColor(ImGuiCol_Button,        { 0.15, 0.5,  0.2,  1.0 });
                    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.2,  0.7,  0.28, 1.0 });
                    imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.1,  0.35, 0.15, 1.0 });
                    if (imgui.Button('Enable##ui')) then
                        if (useit.menu_sel[1] < 0) then
                            print(chat.header(addon.name):append(chat.error('Select an item first!')));
                        else
                            useit.enabled = true;
                            print(chat.header(addon.name):append(chat.message('UseIt enabled: ' .. (useit.current_item or '?'))));
                        end
                    end
                    imgui.PopStyleColor(3);
                end

                imgui.Spacing();
                imgui.EndTabItem();
            end

            ------------------------------------------------------------
            -- Tab 2: LazyTome
            ------------------------------------------------------------
            imgui.PushStyleColor(ImGuiCol_Tab,        { 0.3,  0.1,  0.45, 1.0 });
            imgui.PushStyleColor(ImGuiCol_TabHovered, { 0.42, 0.15, 0.62, 1.0 });
            imgui.PushStyleColor(ImGuiCol_TabActive,  { 0.42, 0.15, 0.62, 1.0 });
            imgui.PushStyleColor(ImGuiCol_Text,       { 1.0,  1.0,  1.0,  1.0 });
            local tab2 = imgui.BeginTabItem('LazyTome##t2');
            imgui.PopStyleColor(4);

            if (tab2) then
                imgui.Spacing();

                -- Status
                imgui.Text('Status:');
                imgui.SameLine();
                if (lazytome.enabled) then
                    imgui.TextColored(colors.active, 'Enabled');
                else
                    imgui.TextColored(colors.idle, 'Disabled');
                end

                imgui.Spacing();
                imgui.Separator();
                imgui.Spacing();

                -- Tome selector
                local sel_display = { lazytome.menu_sel[1] + 1 };
                if (imgui.Combo('Select Tome##lt', sel_display, lazytome.list_str)) then
                    lazytome.menu_sel[1] = sel_display[1] - 1;
                    local idx = lazytome.menu_sel[1];
                    if (idx < 0) then
                        lazytome.enabled      = false;
                        lazytome.current_tome = nil;
                    else
                        lazytome.current_tome = lazytome.inventory[idx + 1].name;
                    end
                end

                -- Stock display
                local idx = lazytome.menu_sel[1];
                if (idx >= 0 and lazytome.inventory[idx + 1]) then
                    local e = lazytome.inventory[idx + 1];
                    imgui.Text('  Stock:');
                    imgui.SameLine();
                    imgui.TextColored(e.count > 0 and colors.active or colors.warn, tostring(e.count));
                    imgui.SameLine();
                    imgui.TextColored(colors.dim, '  |  Skill: ' .. e.skill);
                else
                    imgui.TextDisabled('  No tome selected.');
                end

                imgui.Spacing();
                imgui.Separator();
                imgui.Spacing();

                -- Delay slider
                local dv = { lazytome.use_delay };
                if (imgui.SliderFloat('Use Delay (s)##lt', dv, 1.5, 5.0, '%.1f')) then
                    lazytome.use_delay = dv[1];
                end
                imgui.ShowHelp('Time between each tome use. 2.2s matches the game cooldown.');

                imgui.Spacing();
                imgui.Separator();
                imgui.Spacing();

                if (imgui.Button('Refresh##lt')) then
                    lazytome.menu_sel     = { -1 };
                    lazytome.current_tome = nil;
                    lazytome.enabled      = false;
                    lt_find_tomes();
                    print(chat.header(addon.name):append(chat.message('Tome list refreshed.')));
                end
                imgui.ShowHelp('Rescans inventory for tomes.');
                imgui.SameLine();

                if (lazytome.enabled) then
                    imgui.PushStyleColor(ImGuiCol_Button,        { 0.65, 0.12, 0.12, 1.0 });
                    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.85, 0.18, 0.18, 1.0 });
                    imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.45, 0.08, 0.08, 1.0 });
                    if (imgui.Button('Disable##lt')) then
                        lazytome.enabled = false;
                        print(chat.header(addon.name):append(chat.message('LazyTome disabled.')));
                    end
                    imgui.PopStyleColor(3);
                else
                    imgui.PushStyleColor(ImGuiCol_Button,        { 0.15, 0.5,  0.2,  1.0 });
                    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.2,  0.7,  0.28, 1.0 });
                    imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.1,  0.35, 0.15, 1.0 });
                    if (imgui.Button('Enable##lt')) then
                        if (lazytome.menu_sel[1] < 0) then
                            print(chat.header(addon.name):append(chat.error('Select a tome first!')));
                        else
                            lazytome.enabled = true;
                            print(chat.header(addon.name):append(chat.message('LazyTome enabled: ' .. (lazytome.current_tome or '?'))));
                        end
                    end
                    imgui.PopStyleColor(3);
                end

                imgui.Spacing();
                imgui.EndTabItem();
            end

            imgui.EndTabBar();
        end
    end
    imgui.End();
end);

----------------------------------------------------------------------------------------------------
-- Command handler
----------------------------------------------------------------------------------------------------
ashita.events.register('command', 'command_cb', function (e)
    local args = e.command:args();
    if (#args == 0 or not args[1]:any('/useit', '/ui')) then
        return;
    end

    e.blocked = true;

    if (#args == 1) then
        ui.is_open[1] = not ui.is_open[1];
        return;
    end

    local sub = args[2]:lower();
    if (sub == 'toggle') then
        -- Toggle whichever is currently active, or useit by default
        if (useit.enabled or lazytome.enabled) then
            useit.enabled    = false;
            lazytome.enabled = false;
            print(chat.header(addon.name):append(chat.message('All disabled.')));
        else
            print(chat.header(addon.name):append(chat.error('Select an item or tome in the UI first.')));
        end
    elseif (sub == 'help') then
        print(chat.header(addon.name):append(chat.message('/useit or /ui - toggle window')));
        print(chat.header(addon.name):append(chat.message('/ui toggle - disable all')));
    end
end);

----------------------------------------------------------------------------------------------------
-- Cleanup
----------------------------------------------------------------------------------------------------
ashita.events.register('unload', 'unload_cb', function ()
    useit.enabled    = false;
    lazytome.enabled = false;
end);
