-- kit_recipes.lua
-- All crafting kit recipes for all 8 crafts

local kit_recipes = {

    -- WOODWORKING (skill index 1)
    { result = 2775,  count = 1,  crystal = 4099, ingredients = { 8805 }, skills = { 5,  0,0,0,0,0,0,0 } }, -- Padded Box
    { result = 17088, count = 1,  crystal = 4098, ingredients = { 8806 }, skills = { 10, 0,0,0,0,0,0,0 } }, -- Ash Staff
    { result = 17389, count = 1,  crystal = 4098, ingredients = { 8807 }, skills = { 15, 0,0,0,0,0,0,0 } }, -- Bamboo Fishing Rod
    { result = 17347, count = 1,  crystal = 4098, ingredients = { 8808 }, skills = { 20, 0,0,0,0,0,0,0 } }, -- Piccolo
    { result = 92,    count = 1,  crystal = 4099, ingredients = { 8809 }, skills = { 25, 0,0,0,0,0,0,0 } }, -- Tarutaru Stool
    { result = 17321, count = 33, crystal = 4099, ingredients = { 8810 }, skills = { 30, 0,0,0,0,0,0,0 } }, -- Silver Arrow
    { result = 19200, count = 33, crystal = 4099, ingredients = { 8811 }, skills = { 35, 0,0,0,0,0,0,0 } }, -- Black Bolt
    { result = 359,   count = 1,  crystal = 4099, ingredients = { 8812 }, skills = { 40, 0,0,0,0,0,0,0 } }, -- Bahut
    { result = 718,   count = 1,  crystal = 4098, ingredients = { 8813 }, skills = { 45, 0,0,0,0,0,0,0 } }, -- Rosewood Lumber
    { result = 18158, count = 33, crystal = 4099, ingredients = { 8814 }, skills = { 50, 0,0,0,0,0,0,0 } }, -- Sleep Arrow

    -- SMITHING (skill index 2)
    { result = 16465, count = 1, crystal = 4096, ingredients = { 8819 }, skills = { 0,5,  0,0,0,0,0,0 } }, -- Bronze Knife
    { result = 17034, count = 1, crystal = 4096, ingredients = { 8820 }, skills = { 0,10, 0,0,0,0,0,0 } }, -- Bronze Mace
    { result = 659,   count = 1, crystal = 4096, ingredients = { 8821 }, skills = { 0,15, 0,0,0,0,0,0 } }, -- Tin Ingot
    { result = 1216,  count = 6, crystal = 4098, ingredients = { 8822 }, skills = { 0,20, 0,0,0,0,0,0 } }, -- Handful of Iron Arrowheads
    { result = 16565, count = 1, crystal = 4096, ingredients = { 8823 }, skills = { 0,25, 0,0,0,0,0,0 } }, -- Spatha
    { result = 17298, count = 8, crystal = 4098, ingredients = { 8824 }, skills = { 0,30, 0,0,0,0,0,0 } }, -- Tathlum
    { result = 12300, count = 1, crystal = 4096, ingredients = { 8825 }, skills = { 0,35, 0,0,0,0,0,0 } }, -- Targe
    { result = 676,   count = 1, crystal = 4098, ingredients = { 8826 }, skills = { 0,40, 0,0,0,0,0,0 } }, -- Handful of Steel Scales
    { result = 17061, count = 1, crystal = 4096, ingredients = { 8827 }, skills = { 0,45, 0,0,0,0,0,0 } }, -- Mythril Rod
    { result = 12306, count = 1, crystal = 4099, ingredients = { 8828 }, skills = { 0,50, 0,0,0,0,0,0 } }, -- Kite Shield
    { result = 12416, count = 1, crystal = 4096, ingredients = { 8829 }, skills = { 0,55, 0,0,0,0,0,0 } }, -- Sallet
    { result = 17037, count = 1, crystal = 4096, ingredients = { 8830 }, skills = { 0,60, 0,0,0,0,0,0 } }, -- Darksteel Mace
    { result = 16476, count = 1, crystal = 4096, ingredients = { 8831 }, skills = { 0,65, 0,0,0,0,0,0 } }, -- Darksteel Kukri
    { result = 16915, count = 1, crystal = 4096, ingredients = { 8832 }, skills = { 0,70, 0,0,0,0,0,0 } }, -- Hien

    -- GOLDSMITHING (skill index 3)
    { result = 13454, count = 1, crystal = 4096, ingredients = { 8833 }, skills = { 0,0,5,  0,0,0,0,0 } }, -- Copper Ring
    { result = 650,   count = 1, crystal = 4096, ingredients = { 8834 }, skills = { 0,0,10, 0,0,0,0,0 } }, -- Brass Ingot
    { result = 16769, count = 1, crystal = 4096, ingredients = { 8835 }, skills = { 0,0,15, 0,0,0,0,0 } }, -- Brass Zaghnal
    { result = 744,   count = 1, crystal = 4096, ingredients = { 8836 }, skills = { 0,0,20, 0,0,0,0,0 } }, -- Silver Ingot
    { result = 13196, count = 1, crystal = 4099, ingredients = { 8837 }, skills = { 0,0,25, 0,0,0,0,0 } }, -- Silver Belt
    { result = 12689, count = 1, crystal = 4099, ingredients = { 8838 }, skills = { 0,0,30, 0,0,0,0,0 } }, -- Brass Finger Gauntlets
    { result = 15801, count = 1, crystal = 4099, ingredients = { 8839 }, skills = { 0,0,35, 0,0,0,0,0 } }, -- Tigereye Ring
    { result = 653,   count = 1, crystal = 4096, ingredients = { 8840 }, skills = { 0,0,40, 0,0,0,0,0 } }, -- Mythril Ingot
    { result = 13319, count = 1, crystal = 4099, ingredients = { 8841 }, skills = { 0,0,45, 0,0,0,0,0 } }, -- Peridot Earring
    { result = 670,   count = 1, crystal = 4096, ingredients = { 8842 }, skills = { 0,0,50, 0,0,0,0,0 } }, -- Aluminum Sheet
    { result = 12307, count = 1, crystal = 4099, ingredients = { 8843 }, skills = { 0,0,55, 0,0,0,0,0 } }, -- Heater Shield
    { result = 12801, count = 1, crystal = 4099, ingredients = { 8844 }, skills = { 0,0,60, 0,0,0,0,0 } }, -- Mythril Cuisses
    { result = 13350, count = 1, crystal = 4099, ingredients = { 8845 }, skills = { 0,0,65, 0,0,0,0,0 } }, -- Moon Earring
    { result = 13983, count = 1, crystal = 4096, ingredients = { 8846 }, skills = { 0,0,70, 0,0,0,0,0 } }, -- Gold Bangles

    -- CLOTHCRAFT (skill index 4)
    { result = 12464, count = 1, crystal = 4098, ingredients = { 8847 }, skills = { 0,0,0,5,  0,0,0,0 } }, -- Headgear
    { result = 12592, count = 1, crystal = 4099, ingredients = { 8848 }, skills = { 0,0,0,10, 0,0,0,0 } }, -- Doublet
    { result = 1828,  count = 1, crystal = 4100, ingredients = { 8849 }, skills = { 0,0,0,15, 0,0,0,0 } }, -- Spool of Red Grass Thread
    { result = 12498, count = 1, crystal = 4099, ingredients = { 8850 }, skills = { 0,0,0,20, 0,0,0,0 } }, -- Cotton Headband
    { result = 12722, count = 1, crystal = 4099, ingredients = { 8851 }, skills = { 0,0,0,25, 0,0,0,0 } }, -- Bracers
    { result = 13808, count = 1, crystal = 4099, ingredients = { 8852 }, skills = { 0,0,0,30, 0,0,0,0 } }, -- Fisherman's Tunica
    { result = 820,   count = 1, crystal = 4100, ingredients = { 8853 }, skills = { 0,0,0,35, 0,0,0,0 } }, -- Spool of Wool Thread
    { result = 2400,  count = 3, crystal = 4099, ingredients = { 8854 }, skills = { 0,0,0,40, 0,0,0,0 } }, -- Shadow Roll
    { result = 12467, count = 1, crystal = 4099, ingredients = { 8855 }, skills = { 0,0,0,45, 0,0,0,0 } }, -- Wool Cap
    { result = 828,   count = 1, crystal = 4099, ingredients = { 8856 }, skills = { 0,0,0,50, 0,0,0,0 } }, -- Square of Velvet Cloth
    { result = 16261, count = 1, crystal = 4099, ingredients = { 8857 }, skills = { 0,0,0,55, 0,0,0,0 } }, -- Mohbwa Scarf
    { result = 12739, count = 1, crystal = 4099, ingredients = { 8858 }, skills = { 0,0,0,60, 0,0,0,0 } }, -- Black Mitts
    { result = 13585, count = 1, crystal = 4099, ingredients = { 8859 }, skills = { 0,0,0,64, 0,0,0,0 } }, -- White Cape
    { result = 13206, count = 1, crystal = 4099, ingredients = { 8860 }, skills = { 0,0,0,70, 0,0,0,0 } }, -- Gold Obi

    -- LEATHERCRAFT (skill index 5)
    { result = 12440, count = 1, crystal = 4098, ingredients = { 8861 }, skills = { 0,0,0,0,5,  0,0,0 } }, -- Leather Bandana
    { result = 12568, count = 1, crystal = 4099, ingredients = { 8862 }, skills = { 0,0,0,0,10, 0,0,0 } }, -- Leather Vest
    { result = 12441, count = 1, crystal = 4099, ingredients = { 8863 }, skills = { 0,0,0,0,15, 0,0,0 } }, -- Lizard Helm
    { result = 14171, count = 1, crystal = 4099, ingredients = { 8864 }, skills = { 0,0,0,0,20, 0,0,0 } }, -- Fisherman's Boots
    { result = 13194, count = 1, crystal = 4098, ingredients = { 8865 }, skills = { 0,0,0,0,25, 0,0,0 } }, -- Warrior's Belt
    { result = 12826, count = 1, crystal = 4099, ingredients = { 8866 }, skills = { 0,0,0,0,30, 0,0,0 } }, -- Studded Trousers
    { result = 851,   count = 1, crystal = 4103, ingredients = { 8867 }, skills = { 0,0,0,0,35, 0,0,0 } }, -- Square of Ram Leather
    { result = 14176, count = 1, crystal = 4099, ingredients = { 8868 }, skills = { 0,0,0,0,40, 0,0,0 } }, -- Field Boots
    { result = 12827, count = 1, crystal = 4101, ingredients = { 8869 }, skills = { 0,0,0,0,45, 0,0,0 } }, -- Cuir Trousers
    { result = 12294, count = 1, crystal = 4099, ingredients = { 8870 }, skills = { 0,0,0,0,50, 0,0,0 } }, -- Leather Shield
    { result = 12700, count = 1, crystal = 4099, ingredients = { 8871 }, skills = { 0,0,0,0,55, 0,0,0 } }, -- Raptor Gloves
    { result = 13546, count = 1, crystal = 4098, ingredients = { 8872 }, skills = { 0,0,0,0,60, 0,0,0 } }, -- Hard Leather Ring
    { result = 12980, count = 1, crystal = 4099, ingredients = { 8873 }, skills = { 0,0,0,0,66, 0,0,0 } }, -- Battle Boots
    { result = 13591, count = 1, crystal = 4097, ingredients = { 8874 }, skills = { 0,0,0,0,70, 0,0,0 } }, -- Behemoth Mantle

    -- BONECRAFT (skill index 6)
    { result = 1883,  count = 1, crystal = 4098, ingredients = { 8875 }, skills = { 0,0,0,0,0,5,  0,0 } }, -- Ponze of Shell Powder
    { result = 1215,  count = 6, crystal = 4098, ingredients = { 8876 }, skills = { 0,0,0,0,0,10, 0,0 } }, -- Handful of Bone Arrowheads
    { result = 13076, count = 1, crystal = 4099, ingredients = { 8877 }, skills = { 0,0,0,0,0,15, 0,0 } }, -- Fang Necklace
    { result = 16642, count = 1, crystal = 4098, ingredients = { 8878 }, skills = { 0,0,0,0,0,20, 0,0 } }, -- Bone Axe
    { result = 13457, count = 1, crystal = 4098, ingredients = { 8879 }, skills = { 0,0,0,0,0,25, 0,0 } }, -- Beetle Ring
    { result = 12455, count = 1, crystal = 4098, ingredients = { 8880 }, skills = { 0,0,0,0,0,30, 0,0 } }, -- Beetle Mask
    { result = 12414, count = 1, crystal = 4099, ingredients = { 8881 }, skills = { 0,0,0,0,0,35, 0,0 } }, -- Turtle Shield
    { result = 17026, count = 1, crystal = 4098, ingredients = { 8882 }, skills = { 0,0,0,0,0,40, 0,0 } }, -- Bone Cudgel
    { result = 13711, count = 1, crystal = 4099, ingredients = { 8883 }, skills = { 0,0,0,0,0,45, 0,0 } }, -- Carapace Mask
    { result = 17062, count = 1, crystal = 4096, ingredients = { 8884 }, skills = { 0,0,0,0,0,50, 0,0 } }, -- Bone Rod
    { result = 13324, count = 1, crystal = 4098, ingredients = { 8885 }, skills = { 0,0,0,0,0,55, 0,0 } }, -- Tortoise Earring
    { result = 13458, count = 1, crystal = 4098, ingredients = { 8886 }, skills = { 0,0,0,0,0,60, 0,0 } }, -- Scorpion Ring
    { result = 15815, count = 1, crystal = 4098, ingredients = { 8887 }, skills = { 0,0,0,0,0,65, 0,0 } }, -- Ladybug Ring
    { result = 13464, count = 1, crystal = 4098, ingredients = { 8888 }, skills = { 0,0,0,0,0,70, 0,0 } }, -- Demon's Ring

    -- ALCHEMY (skill index 7)
    { result = 929,   count = 2,  crystal = 4103, ingredients = { 8889 }, skills = { 0,0,0,0,0,0,5,  0 } }, -- Jar of Black Ink
    { result = 4166,  count = 1,  crystal = 4098, ingredients = { 8890 }, skills = { 0,0,0,0,0,0,10, 0 } }, -- Flask of Deodorizer
    { result = 4167,  count = 33, crystal = 4099, ingredients = { 8891 }, skills = { 0,0,0,0,0,0,15, 0 } }, -- Cracker
    { result = 18355, count = 1,  crystal = 4101, ingredients = { 8892 }, skills = { 0,0,0,0,0,0,20, 0 } }, -- Hushed Baghnakhs
    { result = 16458, count = 1,  crystal = 4101, ingredients = { 8893 }, skills = { 0,0,0,0,0,0,25, 0 } }, -- Poison Baselard
    { result = 1886,  count = 1,  crystal = 4099, ingredients = { 8894 }, skills = { 0,0,0,0,0,0,30, 0 } }, -- Bottle of Sieglinde Putty
    { result = 16410, count = 1,  crystal = 4101, ingredients = { 8895 }, skills = { 0,0,0,0,0,0,35, 0 } }, -- Poison Baghnakhs
    { result = 947,   count = 2,  crystal = 4099, ingredients = { 8896 }, skills = { 0,0,0,0,0,0,40, 0 } }, -- Jar of Firesand
    { result = 932,   count = 3,  crystal = 4100, ingredients = { 8897 }, skills = { 0,0,0,0,0,0,45, 0 } }, -- Loop of Carbon Fiber
    { result = 4128,  count = 1,  crystal = 4101, ingredients = { 8898 }, skills = { 0,0,0,0,0,0,50, 0 } }, -- Ether
    { result = 16908, count = 1,  crystal = 4101, ingredients = { 8899 }, skills = { 0,0,0,0,0,0,55, 0 } }, -- Yoto
    { result = 4116,  count = 1,  crystal = 4101, ingredients = { 8900 }, skills = { 0,0,0,0,0,0,60, 0 } }, -- Hi-Potion
    { result = 18012, count = 1,  crystal = 4101, ingredients = { 8901 }, skills = { 0,0,0,0,0,0,65, 0 } }, -- Melt Baselard
    { result = 16568, count = 1,  crystal = 4096, ingredients = { 8902 }, skills = { 0,0,0,0,0,0,70, 0 } }, -- Saber

    -- COOKING (skill index 8)
    { result = 4455,  count = 1,  crystal = 4096, ingredients = { 8903 }, skills = { 0,0,0,0,0,0,0,5  } }, -- Bowl of Pebble Soup
    { result = 4422,  count = 1,  crystal = 4101, ingredients = { 8904 }, skills = { 0,0,0,0,0,0,0,10 } }, -- Bottle of Orange Juice
    { result = 16992, count = 4,  crystal = 4098, ingredients = { 8905 }, skills = { 0,0,0,0,0,0,0,15 } }, -- Slice of Bluetail
    { result = 4423,  count = 1,  crystal = 4101, ingredients = { 8906 }, skills = { 0,0,0,0,0,0,0,20 } }, -- Bottle of Apple Juice
    { result = 4560,  count = 1,  crystal = 4096, ingredients = { 8907 }, skills = { 0,0,0,0,0,0,0,25 } }, -- Bowl of Vegetable Soup
    { result = 4442,  count = 1,  crystal = 4101, ingredients = { 8908 }, skills = { 0,0,0,0,0,0,0,30 } }, -- Bottle of Pineapple Juice
    { result = 17000, count = 12, crystal = 4099, ingredients = { 8909 }, skills = { 0,0,0,0,0,0,0,35 } }, -- Meatball
    { result = 4424,  count = 1,  crystal = 4101, ingredients = { 8910 }, skills = { 0,0,0,0,0,0,0,40 } }, -- Bottle of Melon Juice
    { result = 5586,  count = 1,  crystal = 4096, ingredients = { 8911 }, skills = { 0,0,0,0,0,0,0,45 } }, -- Serving of Menemen
    { result = 4413,  count = 4,  crystal = 4096, ingredients = { 8912 }, skills = { 0,0,0,0,0,0,0,50 } }, -- Apple Pie
    { result = 4572,  count = 1,  crystal = 4096, ingredients = { 8913 }, skills = { 0,0,0,0,0,0,0,55 } }, -- Serving of Beaugreen Saute
    { result = 5170,  count = 1,  crystal = 4096, ingredients = { 8914 }, skills = { 0,0,0,0,0,0,0,60 } }, -- Green Quiche
    { result = 5731,  count = 1,  crystal = 4096, ingredients = { 8915 }, skills = { 0,0,0,0,0,0,0,65 } }, -- Plate of Ratatouille
    { result = 4494,  count = 1,  crystal = 4096, ingredients = { 8916 }, skills = { 0,0,0,0,0,0,0,70 } }, -- Pot of San d'Orian Tea
}

return kit_recipes
