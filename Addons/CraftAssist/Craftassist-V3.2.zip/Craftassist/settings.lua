-- settings.lua
local settings = {}

-- Default settings
settings.default = {
    show_notifications = true,
    show_gui = true,
    notification_color = true,
    track_skillups = true,
    track_history = true,
    max_history = 100,
    show_recipe_search = true,
    auto_update_skills = true,
}

-- Simple JSON encoder for our data types (bool, number, string, table)
local function encode_json(val, indent)
    indent = indent or 0
    local t = type(val)
    if t == 'boolean' then
        return val and 'true' or 'false'
    elseif t == 'number' then
        return tostring(val)
    elseif t == 'string' then
        return '"' .. val:gsub('\\', '\\\\'):gsub('"', '\\"') .. '"'
    elseif t == 'table' then
        local pad = string.rep('    ', indent + 1)
        local close_pad = string.rep('    ', indent)
        -- Check if array-like (all numeric keys)
        local is_array = true
        local max_n = 0
        for k, _ in pairs(val) do
            if type(k) ~= 'number' then is_array = false; break end
            if k > max_n then max_n = k end
        end
        if is_array and max_n == 0 then
            return '[]'
        elseif is_array then
            local parts = {}
            for i = 1, max_n do
                table.insert(parts, pad .. encode_json(val[i], indent + 1))
            end
            return '[\n' .. table.concat(parts, ',\n') .. '\n' .. close_pad .. ']'
        else
            local parts = {}
            for k, v in pairs(val) do
                table.insert(parts, pad .. '"' .. tostring(k) .. '": ' .. encode_json(v, indent + 1))
            end
            return '{\n' .. table.concat(parts, ',\n') .. '\n' .. close_pad .. '}'
        end
    else
        return 'null'
    end
end

-- Simple JSON decoder (relies on Lua's loadstring trick)
local function decode_json(str)
    -- Replace JSON booleans/null with Lua equivalents
    str = str:gsub(': true', ': true'):gsub(':true', ':true')
    local f = loadstring('return ' .. str
        :gsub('%[', '{'):gsub('%]', '}')
        :gsub('"(%w[%w%s_%-]*)"%s*:', '["%1"]=')
        :gsub(': true', '= true'):gsub(':true', '=true')
        :gsub(': false', '= false'):gsub(':false', '=false')
        :gsub(': null', '= nil'):gsub(':null', '=nil')
        :gsub(',%s*}', '}'):gsub(',%s*%)', ')')
    )
    if f then return f() end
    return nil
end

local function get_save_path()
    local install = AshitaCore:GetInstallPath()
    local char = AshitaCore:GetMemoryManager():GetParty():GetMemberName(0)
    if not char or char == '' then char = 'default' end
    local dir = install .. 'config\\addons\\craftassist\\'
    if not ashita.fs.exists(dir) then
        ashita.fs.create_dir(dir)
    end
    return dir .. char .. '.json'
end

function settings.load()
    local ok, path = pcall(get_save_path)
    if not ok then path = addon.path .. 'craftassist.json' end

    local f = io.open(path, 'r')
    if not f then return end
    local data = f:read('*all')
    f:close()
    if not data or data == '' then return end

    local ok2, t = pcall(decode_json, data)
    if not ok2 or not t then return end

    for k, v in pairs(t) do
        if k ~= 'skills' and k ~= 'history' then
            _G.craftassist.settings[k] = v
        end
    end
    if t.skills then
        for k, v in pairs(t.skills) do
            _G.craftassist.skills[tonumber(k)] = v
        end
    end
    if t.guild_points then
        if not _G.craftassist.guild_points then
            _G.craftassist.guild_points = {}
        end
        for k, v in pairs(t.guild_points) do
            _G.craftassist.guild_points[tonumber(k)] = v
        end
    end
    if t.current_guild then
        _G.craftassist.current_guild = t.current_guild
    end
    if t.history then
        _G.craftassist.history = t.history
    end
end

function settings.save()
    if not _G.craftassist or not _G.craftassist.settings then return end

    local ok, path = pcall(get_save_path)
    if not ok then path = addon.path .. 'craftassist.json' end

    local t = {
        show_notifications  = _G.craftassist.settings.show_notifications,
        show_gui            = _G.craftassist.settings.show_gui,
        notification_color  = _G.craftassist.settings.notification_color,
        track_skillups      = _G.craftassist.settings.track_skillups,
        track_history       = _G.craftassist.settings.track_history,
        max_history         = _G.craftassist.settings.max_history,
        show_recipe_search  = _G.craftassist.settings.show_recipe_search,
        auto_update_skills  = _G.craftassist.settings.auto_update_skills,
        skills              = _G.craftassist.skills,
        guild_points        = _G.craftassist.guild_points,
        current_guild       = _G.craftassist.current_guild,
    }

    local f = io.open(path, 'w+')
    if not f then return end
    f:write(encode_json(t))
    f:close()
end

return settings
