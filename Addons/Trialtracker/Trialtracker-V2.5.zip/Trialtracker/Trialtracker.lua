addon.name    = 'trialtracker'
addon.author  = 'Oneword'
addon.version = '2.5'
addon.desc    = 'Track Magian Trial objectives'

require('common')
local bit = require('bit')
local imgui = require('imgui')
local settings = require('settings')

-- Weapon categories and their trials
local weapon_categories = {

	['Sword - Machaera'] = {
        trials = {
            ['1241'] = 'Burning Blade 100 times on any experience-yielding monsters',
            ['1242'] = 'Shining Blade 200 times on any experience-yielding monsters.',
            ['1243'] = 'Circle Blade 300 times on experience-yielding Birds.',
            ['1244'] = 'Savage Blade 500 times on experience-yielding Beasts.',
            ['1961'] = 'Finishing blow with Savage Blade 300 times on experience-yielding Plantoids.',
            ['2361'] = 'Weapon Skills dealing FourHundred + damage 500 times on experience-yielding Demons.',
            ['2794'] = 'Weapon Skills dealing 401+ damage 500 times on experience-yielding Birds',
            ['3257'] = 'Weapon Skills dealing 401+ damage 500 times on experience-yielding Vermin.',
            ['Done'] = 'Finished Weapon Thibron',
        }
	},	
		
	['Gun - Anarchy'] = {
        trials = {
            ['1783'] = 'Use Hot Shot x100 on any experience point granting enemy. The weaponskill must hit order to count',
            ['1784'] = 'Use Split Shot x200 on any experience point granting enemy.',
            ['1785'] = 'Use Sniper Shot x300 on any experience point granting enemy of the Lizard family.',
            ['1786'] = 'Use Detonator x500 on any experience point granting enemy of the Vermin family.',
            ['2247'] = 'Use Detonator x300 to deliver the killing blow on any experience point granting enemy of the Beast family.',
            ['2658'] = 'Use any Marksmanship WS that deals FourHundred + damage 500 times on any experience point granting enemy of the Undead family.',
            ['3091'] = 'Use any Marksmanship weaponskill that deals more than 400 damage x500 on any experience point granting enemy of the Lizard family.',
            ['3554'] = 'Use any Marksmanship weaponskill that deals more than 400 damage x500 on any experience point granting enemy of the Plantoid family.',
            ['Done'] = 'Finished Weapon Ataktos',
        }
		
	},	
	
	['Sword - Excalibur'] = {
        trials = {
            ['1012'] = 'Knights of Round 200 times on: Aquans',
            ['1013'] = 'Knights of Round killing blow on: 200 Undead',
            ['1832'] = 'Knights of Round killing blow on: 300 Lizards',
            ['1833'] = 'Knights of Round killing blow on: 300 Dragons',
            ['2256'] = 'Knights of Round killing blow on: 400 Birds',
            ['2667'] = 'Defeat: 5 Goublefaupe (Trade Despot\'s Fortune to ??? at I-7, drops from Hydra Paladin/Red Mage/Warriors)',
            ['3100'] = 'Defeat Notorious Monsters: 10 Animated Longsword',
            ['3563'] = 'Collect: 5 Umbral Marrow',
            ['3702'] = 'Trade: 300 Plutons to Oboro',
        }
	},	
	
    ['Great Axe - Bravura'] = {
        trials = {
            ['1033'] = 'Metatron Torment 200 times on: Lizards',
            ['1034'] = 'Metatron Torment killing blow on: 200 Plantoids',
            ['1846'] = 'Metatron Torment killing blow on: 300 Undead',
            ['1847'] = 'Metatron Torment killing blow on: 300 Plantoids',
            ['2263'] = 'Metatron Torment killing blow on: 400 Dragons',
            ['2674'] = 'Defeat Notorious Monster: 5 Gobblelaupe',
            ['3107'] = 'Defeat Notorious Monsters: 10 Animated Great Axe',
            ['3570'] = 'Collect: 5 Umbral Marrow',
            ['3708'] = 'Trade: 300 Plutons to Oboro',
        }		
    },
	
    ['Instrument - Gjallarhorn'] = {
        trials = {
            ['2713'] = 'Defeat Notorious Monster: 3 Goblin Golem.',
            ['2714'] = 'Defeat Notorious Monster: 3 Tzee Xicu Idol.',
            ['2715'] = 'Defeat Notorious Monster: 5 Quiebitiel.',
            ['3128'] = 'Defeat Notorious Monsters: 10 Animated Horn.',
            ['3591'] = 'Collect: 5 Umbral Marrow.',
            ['3641'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Gjallarhorn (99)',
        }
    },

    ['Marksmanship - Annihilator'] = {
        trials = {
            ['1081'] = 'Coronach 200 times on experience-yielding Beasts.',
            ['1082'] = 'Coronach killing blow on: 200 Aquans.',
            ['1878'] = 'Coronach killing blow on: 300 Arcana.',
            ['1879'] = 'Coronach killing blow on: 300 Plantoids.',
            ['2280'] = 'Coronach killing blow on: 400 Undead.',
            ['2691'] = 'Defeat Notorious Monster: 5 Mildaunegeux.',
            ['3124'] = 'Defeat Notorious Monsters: 10 Animated Gun.',
            ['3587'] = 'Collect: 5 Umbral Marrow.',
            ['3637'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Annihilator (99)',
        }
    },

    ['Archery - Yoichinoyumi'] = {
        trials = {
            ['1090'] = 'Namas Arrow 200 times on experience-yielding Amorphs.',
            ['1091'] = 'Namas Arrow killing blow on: 200 Beasts.',
            ['1884'] = 'Namas Arrow killing blow on: 300 Lizards.',
            ['1885'] = 'Namas Arrow killing blow on: 300 Aquans.',
            ['2279'] = 'Namas Arrow killing blow on: 400 Vermin.',
            ['2690'] = 'Defeat Notorious Monster: 5 Velosareon.',
            ['3123'] = 'Defeat Notorious Monsters: 10 Animated Longbow.',
            ['3586'] = 'Collect: 5 Umbral Marrow.',
            ['3636'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Yoichinoyumi (99)',
        }
    },

    ['Staff - Claustrum'] = {
        trials = {
            ['1069'] = 'Gate of Tartarus 200 times on experience-yielding Aquans.',
            ['1070'] = 'Gate of Tartarus killing blow on: 200 Lizards.',
            ['1870'] = 'Gate of Tartarus killing blow on: 300 Undead.',
            ['1871'] = 'Gate of Tartarus killing blow on: 300 Beasts.',
            ['2275'] = 'Gate of Tartarus killing blow on: 400 Plantoids.',
            ['2686'] = 'Defeat Notorious Monster: 5 Dagourmarche.',
            ['3119'] = 'Defeat Notorious Monsters: 10 Animated Staff.',
            ['3582'] = 'Collect: 5 Umbral Marrow.',
            ['3632'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Claustrum (99)',
        }
    },

    ['Club - Mjollnir'] = {
        trials = {
            ['1063'] = 'Randgrith 200 times on experience-yielding Lizards.',
            ['1064'] = 'Randgrith killing blow on: 200 Beasts.',
            ['1866'] = 'Randgrith killing blow on: 300 Amorphs.',
            ['1867'] = 'Randgrith killing blow on: 300 Vermin.',
            ['2273'] = 'Randgrith killing blow on: 400 Birds.',
            ['2684'] = 'Defeat Notorious Monster: 5 Quiebitiel.',
            ['3117'] = 'Defeat Notorious Monsters: 10 Animated Hammer.',
            ['3580'] = 'Collect: 5 Umbral Marrow.',
            ['3630'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Mjollnir (99)',
        }
    },

    ['Katana - Kikoku'] = {
        trials = {
            ['1051'] = 'Blade: Metsu 200 times on experience-yielding Birds.',
            ['1052'] = 'Blade: Metsu killing blow on: 200 Arcana.',
            ['1858'] = 'Blade: Metsu killing blow on: 300 Amorphs.',
            ['1859'] = 'Blade: Metsu killing blow on: 300 Aquans.',
            ['2269'] = 'Blade: Metsu killing blow on: 400 Undead.',
            ['2680'] = 'Defeat Notorious Monster: 5 Mildaunegeux.',
            ['3113'] = 'Defeat Notorious Monsters: 10 Animated Kunai.',
            ['3576'] = 'Collect: 5 Umbral Marrow.',
            ['3626'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Kikoku (99)',
        }
    },

    ['Polearm - Gungnir'] = {
        trials = {
            ['1039'] = 'Geirskogul 200 times on experience-yielding Amorphs.',
            ['1040'] = 'Geirskogul killing blow on: 200 Lizards.',
            ['1850'] = 'Geirskogul killing blow on: 300 Arcana.',
            ['1851'] = 'Geirskogul killing blow on: 300 Vermin.',
            ['2267'] = 'Geirskogul killing blow on: 400 Aquans.',
            ['2678'] = 'Defeat Notorious Monster: 5 Dagourmarche.',
            ['3111'] = 'Defeat Notorious Monsters: 10 Animated Spear.',
            ['3574'] = 'Collect: 5 Umbral Marrow.',
            ['3624'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Gungnir (99)',
        }
    },

    ['Scythe - Apocalypse'] = {
        trials = {
            ['1045'] = 'Catastrophe 200 times on experience-yielding Undead.',
            ['1046'] = 'Catastrophe killing blow on: 200 Aquans.',
            ['1854'] = 'Catastrophe killing blow on: 300 Lizards.',
            ['1855'] = 'Catastrophe killing blow on: 300 Birds.',
            ['2265'] = 'Catastrophe killing blow on: 400 Beasts.',
            ['2676'] = 'Defeat Notorious Monster: 5 Velosareon.',
            ['3109'] = 'Defeat Notorious Monsters: 10 Animated Scythe.',
            ['3572'] = 'Collect: 5 Umbral Marrow.',
            ['3622'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Apocalypse (99)',
        }
    },

    ['Axe - Guttler'] = {
        trials = {
            ['1027'] = 'Onslaught 200 times on experience-yielding Undead.',
            ['1028'] = 'Onslaught killing blow on: 200 Arcana.',
            ['1842'] = 'Onslaught killing blow on: 300 Beasts.',
            ['1843'] = 'Onslaught killing blow on: 300 Amorphs.',
            ['2261'] = 'Onslaught killing blow on: 400 Birds.',
            ['2672'] = 'Defeat Notorious Monster: 5 Dagourmarche.',
            ['3105'] = 'Defeat Notorious Monsters: 10 Animated Tabar.',
            ['3568'] = 'Collect: 5 Umbral Marrow.',
            ['3618'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Guttler (99)',
        }
    },

    ['Great Sword - Ragnarok'] = {
        trials = {
            ['1024'] = 'Scourge 200 times on experience-yielding Birds.',
            ['1025'] = 'Scourge killing blow on: 200 Beasts.',
            ['1840'] = 'Scourge killing blow on: 300 Aquans.',
            ['1841'] = 'Scourge killing blow on: 300 Undead.',
            ['2260'] = 'Scourge killing blow on: 400 Arcana.',
            ['2671'] = 'Defeat Notorious Monster: 5 Goublefaupe.',
            ['3104'] = 'Defeat Notorious Monsters: 10 Animated Claymore.',
            ['3567'] = 'Collect: 5 Umbral Marrow.',
            ['3617'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Ragnarok (99)',
        }
    },

    ['Dagger - Mandau'] = {
        trials = {
            ['991']  = 'Mercy Stroke 200 times on experience-yielding Beasts.',
            ['992']  = 'Mercy Stroke killing blow on: 200 Vermin.',
            ['1818'] = 'Mercy Stroke killing blow on: 300 Plantoids.',
            ['1819'] = 'Mercy Stroke killing blow on: 300 Birds.',
            ['2249'] = 'Mercy Stroke killing blow on: 400 Dragons.',
            ['2660'] = 'Defeat Notorious Monster: 5 Quiebitiel.',
            ['3093'] = 'Defeat Notorious Monsters: 10 Animated Dagger.',
            ['3556'] = 'Collect: 5 Umbral Marrow.',
            ['3606'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Mandau (99)',
        }
    },

    ['Hand-to-Hand - Spharai'] = {
        trials = {
            ['1003'] = 'Final Heaven 200 times on experience-yielding Vermin.',
            ['1004'] = 'Final Heaven killing blow on: 200 Plantoids.',
            ['1826'] = 'Final Heaven killing blow on: 300 Beasts.',
            ['1827'] = 'Final Heaven killing blow on: 300 Amorphs.',
            ['2253'] = 'Final Heaven killing blow on: 400 Arcana.',
            ['2664'] = 'Defeat Notorious Monster: 5 Mildaunegeux.',
            ['3097'] = 'Defeat Notorious Monsters: 10 Animated Knuckles.',
            ['3560'] = 'Collect: 5 Umbral Marrow.',
            ['3610'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Spharai (99)',
        }
    },

    ['Great Katana - Amanomurakumo'] = {
        trials = {
            ['1057'] = 'Tachi: Kaiten 200 times on experience-yielding Beasts.',
            ['1058'] = 'Tachi: Kaiten killing blow on: 200 Vermin.',
            ['1862'] = 'Tachi: Kaiten killing blow on: 300 Arcana.',
            ['1863'] = 'Tachi: Kaiten killing blow on: 300 Birds.',
            ['2271'] = 'Tachi: Kaiten killing blow on: 400 Aquans.',
            ['2682'] = 'Defeat Notorious Monster: 5 Velosareon.',
            ['3115'] = 'Defeat Notorious Monsters: 10 Animated Tachi.',
            ['3578'] = 'Collect: 5 Umbral Marrow.',
            ['3628'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
            ['Done'] = 'Finished Weapon Amanomurakumo (99)',
        }
    },

    ['Shield - Aegis'] = {
        trials = {
            ['4401'] = 'Defeat: 3 Gu\'Dha Effigy (Zone boss in Dynamis - Bastok)',
            ['4402'] = 'Defeat: 3 Overlord\'s Tombstone (Zone boss in Dynamis - San d\'Oria)',
            ['4403'] = 'Defeat: 5 Goublefaupe (Trade Despot\'s Fortune to ??? at I-7, drops from Hydra Paladin/Red Mage/Warriors)',
            ['4448'] = 'Defeat: 10 Animated Shield H-9 Use Supernal Goad to Pop from Satelite Shields)',
            ['4453'] = 'Obtain: 5 Umbral Marrow (Drops from Arch Dynamis Lord in Dynamis - Xarcabard or purchase from Gorpa-Masorpa in Mhaura G-9)',
        }
    },
}

-- Create a combined trial descriptions table for the parser
local trial_descriptions = {}
for _, category in pairs(weapon_categories) do
    for trial_num, desc in pairs(category.trials) do
        trial_descriptions[trial_num] = desc
    end
end

local defaultConfig = T{
    isVisible = { true },
    trials = T{},
}

local config = settings.load(defaultConfig)

-- Function to manually add a trial
local function AddTrial(trial_num)
    if trial_descriptions[trial_num] then
        local trial_name = "Trial " .. trial_num
        if not config.trials[trial_name] then
            config.trials[trial_name] = {
                Name = trial_name,
                Current = 0,
                Description = trial_descriptions[trial_num]
            }
            settings.save()
            print(string.format('[TrialTracker] Added %s: %s', trial_name, trial_descriptions[trial_num]))
        end
    end
end

-- Function to parse chat messages for trial information
local function ParseTrialMessage(message)
    if not message then return end
    
    local status, result = pcall(function()
        -- Check for completion message first
        local completed_trial = message:match("You have completed Trial (%d+)")
        if completed_trial then
            local trial_name = "Trial " .. completed_trial
            if config.trials[trial_name] then
                local trial = config.trials[trial_name]
                local max = tonumber(trial.Description:match("(%d+)") or "300")
                trial.Current = max  -- Set to maximum when complete
                settings.save()
            end
            return
        end

        -- Handle regular progress updates
        local trial_num, remaining = message:match("Trial (%d+): (%d+) objectives? remain")
        if trial_num and remaining then
            local trial_name = "Trial " .. trial_num
            if not config.trials[trial_name] then
                config.trials[trial_name] = {
                    Name = trial_name,
                    Current = 0,
                    Description = trial_descriptions[trial_num] or "Unknown Trial Type"
                }
            end
            
            local trial = config.trials[trial_name]
            local max = 300
            if trial.Description then
                max = tonumber(trial.Description:match("(%d+)") or "300")
            end
            
            -- If remaining is 0, set to max, otherwise calculate normally
            if tonumber(remaining) == 0 then
                trial.Current = max
            else
                trial.Current = max - tonumber(remaining)
            end
            settings.save()
        end
    end)
    
    if not status then
        print('[TrialTracker] Error parsing message: ' .. tostring(result))
    end
end

settings.register('settings', 'settings_update', function (s)
    if s then config = s end
end)

ashita.events.register('load', 'load', function()
    config = settings.load(defaultConfig)
end)

ashita.events.register('unload', 'unload', function()
    settings.save()
end)

-- GUI Display with categorized dropdown
ashita.events.register('d3d_present', 'd3d_present', function()
    if not config.isVisible[1] then return end

    -- Push blue style colors for just this window
    imgui.PushStyleColor(ImGuiCol_TitleBg, { 0.0, 0.0, 0.6, 1.0 })
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, { 0.0, 0.0, 0.8, 1.0 })
    imgui.PushStyleColor(ImGuiCol_TitleBgCollapsed, { 0.0, 0.0, 0.4, 1.0 })
    imgui.PushStyleColor(ImGuiCol_Button, { 0.0, 0.0, 0.6, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.0, 0.0, 0.8, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ButtonActive, { 0.0, 0.0, 1.0, 1.0 })

    if imgui.Begin('Trial Tracker', config.isVisible) then
        -- Add Clear Button with explicit width
        if imgui.Button('Clear Trials', { 100, 20 }) then
            config.trials = T{}
            settings.save()
            print('[TrialTracker] Cleared all tracked trials.')
        end
        
        imgui.SameLine() -- Put dropdown on same line as clear button
        
        -- Add Trial Dropdown with categories
        local combo_label = 'Add Trial'
        if imgui.BeginCombo('##TrialSelect', combo_label, ImGuiComboFlags_None) then
            for category_name, category_data in pairs(weapon_categories) do
                if imgui.BeginMenu(category_name) then
                    -- Sort trial numbers for this category
                    local sorted_trials = {}
                    for trial_num in pairs(category_data.trials) do
                        table.insert(sorted_trials, trial_num)
                    end
                    table.sort(sorted_trials)
                    
                    -- Display trials in this category
                    for _, trial_num in ipairs(sorted_trials) do
                        local label = string.format('Trial %s - %s', trial_num, category_data.trials[trial_num])
                        if imgui.Selectable(label, false) then
                            AddTrial(trial_num)
                        end
                    end
                    imgui.EndMenu()
                end
            end
            imgui.EndCombo()
        end
        
        imgui.Separator()
        
        -- Display current trials
        if next(config.trials) then
            for trial_name, trial_data in pairs(config.trials) do
                if trial_data then
                    local max = 300
                    if trial_data.Description then
                        max = tonumber(trial_data.Description:match("(%d+)") or "300")
                    end
                    
                    imgui.Text(string.format('%s: %d/%d', 
                        trial_data.Name or trial_name,
                        trial_data.Current or 0,
                        max))
                        
                    if trial_data.Description then
                        imgui.Text(trial_data.Description)
                    end
                    imgui.Separator()
                end
            end
        else
            imgui.Text('No active trials')
        end
        imgui.End()
    end

    -- Pop the style colors after the window is done
    imgui.PopStyleColor(6)
end)

ashita.events.register('text_in', 'text_in', function(e)
    if e and e.message and e.message:find("Trial") then
        ParseTrialMessage(e.message)
    end
end)

ashita.events.register('command', 'command', function(e)
    if not e or not e.command then return end
    
    local args = e.command:args()
    if args[1] == '/trialtracker' then
        config.isVisible[1] = not config.isVisible[1]
    elseif args[1] == '/trial' and args[2] == 'clear' then
        config.trials = T{}
        settings.save()
        print('[TrialTracker] Cleared all tracked trials.')
    elseif args[1] == '/trial' and args[2] == 'add' and args[3] then
        AddTrial(args[3])
    end
end)
