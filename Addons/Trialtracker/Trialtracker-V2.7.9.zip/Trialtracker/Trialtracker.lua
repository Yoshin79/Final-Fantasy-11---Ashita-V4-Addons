addon.name    = 'trialtracker'
addon.author  = 'Oneword'
addon.version = '2.7.9'
addon.desc    = 'Track Magian Trial objectives'

require('common')
local bit = require('bit')
local imgui = require('imgui')
local settings = require('settings')

-- Weapon groups organized by type: Relic, Empyrean, Mythic
-- Structure: weapon_groups[type][weapon_name].trials[trial_num] = description
local weapon_groups = {

    ['Relic'] = {
        ['Archery - Yoichinoyumi'] = {
            trials = {
                ['1090'] = 'Namas Arrow 200 times on experience-yielding Amorphs.',
                ['1091'] = 'Namas Arrow killing blow on: 200 Beasts.',
                ['1884'] = 'Namas Arrow killing blow on: 300 Lizards.',
                ['1885'] = 'Namas Arrow killing blow on: 300 Aquans.',
                ['2279'] = 'Namas Arrow killing blow on: 400 Vermin.',
                ['2690'] = 'Defeat Notorious Monster: 5 Velosareon.',
                ['3123'] = 'Defeat Notorious Monsters: 10 Animated Longbow.',
                ['3586'] = 'Collect: 5 Umbral Marrow.',
                ['3636'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Yoichinoyumi (99)',
            }
        },
        ['Axe - Guttler'] = {
            trials = {
                ['1027'] = 'Onslaught 200 times on experience-yielding Undead.',
                ['1028'] = 'Onslaught killing blow on: 200 Arcana.',
                ['1842'] = 'Onslaught killing blow on: 300 Beasts.',
                ['1843'] = 'Onslaught killing blow on: 300 Amorphs.',
                ['2261'] = 'Onslaught killing blow on: 400 Birds.',
                ['2672'] = 'Defeat Notorious Monster: 5 Dagourmarche.',
                ['3105'] = 'Defeat Notorious Monsters: 10 Animated Tabar.',
                ['3568'] = 'Collect: 5 Umbral Marrow.',
                ['3618'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Guttler (99)',
            }
        },
        ['Club - Mjollnir'] = {
            trials = {
                ['1063'] = 'Randgrith 200 times on experience-yielding Lizards.',
                ['1064'] = 'Randgrith killing blow on: 200 Beasts.',
                ['1866'] = 'Randgrith killing blow on: 300 Amorphs.',
                ['1867'] = 'Randgrith killing blow on: 300 Vermin.',
                ['2273'] = 'Randgrith killing blow on: 400 Birds.',
                ['2684'] = 'Defeat Notorious Monster: 5 Quiebitiel.',
                ['3117'] = 'Defeat Notorious Monsters: 10 Animated Hammer.',
                ['3580'] = 'Collect: 5 Umbral Marrow.',
                ['3630'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Mjollnir (99)',
            }
        },
        ['Dagger - Mandau'] = {
            trials = {
                ['991']  = 'Mercy Stroke 200 times on experience-yielding Beasts.',
                ['992']  = 'Mercy Stroke killing blow on: 200 Vermin.',
                ['1818'] = 'Mercy Stroke killing blow on: 300 Plantoids.',
                ['1819'] = 'Mercy Stroke killing blow on: 300 Birds.',
                ['2249'] = 'Mercy Stroke killing blow on: 400 Dragons.',
                ['2660'] = 'Defeat Notorious Monster: 5 Quiebitiel.',
                ['3093'] = 'Defeat Notorious Monsters: 10 Animated Dagger.',
                ['3556'] = 'Collect: 5 Umbral Marrow.',
                ['3606'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Mandau (99)',
            }
        },
        ['Great Axe - Bravura'] = {
            trials = {
                ['1033'] = 'Metatron Torment 200 times on experience-yielding Lizards.',
                ['1034'] = 'Metatron Torment killing blow on: 200 Plantoids.',
                ['1846'] = 'Metatron Torment killing blow on: 300 Undead.',
                ['1847'] = 'Metatron Torment killing blow on: 300 Plantoids.',
                ['2263'] = 'Metatron Torment killing blow on: 400 Dragons.',
                ['2674'] = 'Defeat Notorious Monster: 5 Gobblelaupe.',
                ['3107'] = 'Defeat Notorious Monsters: 10 Animated Great Axe.',
                ['3570'] = 'Collect: 5 Umbral Marrow.',
                ['3708'] = 'Trade: 300 Plutons to Oboro.',
            }
        },
        ['Great Katana - Amanomurakumo'] = {
            trials = {
                ['1057'] = 'Tachi: Kaiten 200 times on experience-yielding Beasts.',
                ['1058'] = 'Tachi: Kaiten killing blow on: 200 Vermin.',
                ['1862'] = 'Tachi: Kaiten killing blow on: 300 Arcana.',
                ['1863'] = 'Tachi: Kaiten killing blow on: 300 Birds.',
                ['2271'] = 'Tachi: Kaiten killing blow on: 400 Aquans.',
                ['2682'] = 'Defeat Notorious Monster: 5 Velosareon.',
                ['3115'] = 'Defeat Notorious Monsters: 10 Animated Tachi.',
                ['3578'] = 'Collect: 5 Umbral Marrow.',
                ['3628'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Amanomurakumo (99)',
            }
        },
        ['Great Sword - Ragnarok'] = {
            trials = {
                ['1024'] = 'Scourge 200 times on experience-yielding Birds.',
                ['1025'] = 'Scourge killing blow on: 200 Beasts.',
                ['1840'] = 'Scourge killing blow on: 300 Aquans.',
                ['1841'] = 'Scourge killing blow on: 300 Undead.',
                ['2260'] = 'Scourge killing blow on: 400 Arcana.',
                ['2671'] = 'Defeat Notorious Monster: 5 Goublefaupe.',
                ['3104'] = 'Defeat Notorious Monsters: 10 Animated Claymore.',
                ['3567'] = 'Collect: 5 Umbral Marrow.',
                ['3617'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Ragnarok (99)',
            }
        },
        ['Gun - Anarchy'] = {
            trials = {
                ['1783'] = 'Use Hot Shot x100 on any experience point granting enemy.',
                ['1784'] = 'Use Split Shot x200 on any experience point granting enemy.',
                ['1785'] = 'Use Sniper Shot x300 on experience-yielding Lizards.',
                ['1786'] = 'Use Detonator x500 on experience-yielding Vermin.',
                ['2247'] = 'Use Detonator x300 killing blow on experience-yielding Beasts.',
                ['2658'] = 'Marksmanship WS dealing 400+ damage x500 on experience-yielding Undead.',
                ['3091'] = 'Marksmanship WS dealing 400+ damage x500 on experience-yielding Lizards.',
                ['3554'] = 'Marksmanship WS dealing 400+ damage x500 on experience-yielding Plantoids.',
                ['Done'] = 'Finished Weapon Ataktos',
            }
        },
        ['Hand-to-Hand - Spharai'] = {
            trials = {
                ['1003'] = 'Final Heaven 200 times on experience-yielding Vermin.',
                ['1004'] = 'Final Heaven killing blow on: 200 Plantoids.',
                ['1826'] = 'Final Heaven killing blow on: 300 Beasts.',
                ['1827'] = 'Final Heaven killing blow on: 300 Amorphs.',
                ['2253'] = 'Final Heaven killing blow on: 400 Arcana.',
                ['2664'] = 'Defeat Notorious Monster: 5 Mildaunegeux.',
                ['3097'] = 'Defeat Notorious Monsters: 10 Animated Knuckles.',
                ['3560'] = 'Collect: 5 Umbral Marrow.',
                ['3610'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Spharai (99)',
            }
        },
        ['Instrument - Gjallarhorn'] = {
            trials = {
                ['2713'] = 'Defeat Notorious Monster: 3 Goblin Golem.',
                ['2714'] = 'Defeat Notorious Monster: 3 Tzee Xicu Idol.',
                ['2715'] = 'Defeat Notorious Monster: 5 Quiebitiel.',
                ['3128'] = 'Defeat Notorious Monsters: 10 Animated Horn.',
                ['3591'] = 'Collect: 5 Umbral Marrow.',
                ['3641'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Gjallarhorn (99)',
            }
        },
        ['Katana - Kikoku'] = {
            trials = {
                ['1051'] = 'Blade: Metsu 200 times on experience-yielding Birds.',
                ['1052'] = 'Blade: Metsu killing blow on: 200 Arcana.',
                ['1858'] = 'Blade: Metsu killing blow on: 300 Amorphs.',
                ['1859'] = 'Blade: Metsu killing blow on: 300 Aquans.',
                ['2269'] = 'Blade: Metsu killing blow on: 400 Undead.',
                ['2680'] = 'Defeat Notorious Monster: 5 Mildaunegeux.',
                ['3113'] = 'Defeat Notorious Monsters: 10 Animated Kunai.',
                ['3576'] = 'Collect: 5 Umbral Marrow.',
                ['3626'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Kikoku (99)',
            }
        },
        ['Marksmanship - Annihilator'] = {
            trials = {
                ['1081'] = 'Coronach 200 times on experience-yielding Beasts.',
                ['1082'] = 'Coronach killing blow on: 200 Aquans.',
                ['1878'] = 'Coronach killing blow on: 300 Arcana.',
                ['1879'] = 'Coronach killing blow on: 300 Plantoids.',
                ['2280'] = 'Coronach killing blow on: 400 Undead.',
                ['2691'] = 'Defeat Notorious Monster: 5 Mildaunegeux.',
                ['3124'] = 'Defeat Notorious Monsters: 10 Animated Gun.',
                ['3587'] = 'Collect: 5 Umbral Marrow.',
                ['3637'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Annihilator (99)',
            }
        },
        ['Polearm - Gungnir'] = {
            trials = {
                ['1039'] = 'Geirskogul 200 times on experience-yielding Amorphs.',
                ['1040'] = 'Geirskogul killing blow on: 200 Lizards.',
                ['1850'] = 'Geirskogul killing blow on: 300 Arcana.',
                ['1851'] = 'Geirskogul killing blow on: 300 Vermin.',
                ['2267'] = 'Geirskogul killing blow on: 400 Aquans.',
                ['2678'] = 'Defeat Notorious Monster: 5 Dagourmarche.',
                ['3111'] = 'Defeat Notorious Monsters: 10 Animated Spear.',
                ['3574'] = 'Collect: 5 Umbral Marrow.',
                ['3624'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Gungnir (99)',
            }
        },
        ['Scythe - Apocalypse'] = {
            trials = {
                ['1045'] = 'Catastrophe 200 times on experience-yielding Undead.',
                ['1046'] = 'Catastrophe killing blow on: 200 Aquans.',
                ['1854'] = 'Catastrophe killing blow on: 300 Lizards.',
                ['1855'] = 'Catastrophe killing blow on: 300 Birds.',
                ['2265'] = 'Catastrophe killing blow on: 400 Beasts.',
                ['2676'] = 'Defeat Notorious Monster: 5 Velosareon.',
                ['3109'] = 'Defeat Notorious Monsters: 10 Animated Scythe.',
                ['3572'] = 'Collect: 5 Umbral Marrow.',
                ['3622'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Apocalypse (99)',
            }
        },
        ['Shield - Aegis'] = {
            trials = {
                ['4401'] = 'Defeat: 3 Gu\'Dha Effigy (Zone boss in Dynamis - Bastok)',
                ['4402'] = 'Defeat: 3 Overlord\'s Tombstone (Zone boss in Dynamis - San d\'Oria)',
                ['4403'] = 'Defeat: 5 Goublefaupe (Trade Despot\'s Fortune to ??? at I-7)',
                ['4448'] = 'Defeat: 10 Animated Shield (H-9, Use Supernal Goad to Pop from Satellite Shields)',
                ['4453'] = 'Obtain: 5 Umbral Marrow (Drops from Arch Dynamis Lord in Dynamis - Xarcabard)',
            }
        },
        ['Staff - Claustrum'] = {
            trials = {
                ['1069'] = 'Gate of Tartarus 200 times on experience-yielding Aquans.',
                ['1070'] = 'Gate of Tartarus killing blow on: 200 Lizards.',
                ['1870'] = 'Gate of Tartarus killing blow on: 300 Undead.',
                ['1871'] = 'Gate of Tartarus killing blow on: 300 Beasts.',
                ['2275'] = 'Gate of Tartarus killing blow on: 400 Plantoids.',
                ['2686'] = 'Defeat Notorious Monster: 5 Dagourmarche.',
                ['3119'] = 'Defeat Notorious Monsters: 10 Animated Staff.',
                ['3582'] = 'Collect: 5 Umbral Marrow.',
                ['3632'] = 'Trade: 300 Plutons to Oboro (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Claustrum (99)',
            }
        },
        ['Sword - Excalibur'] = {
            trials = {
                ['1012'] = 'Knights of Round 200 times on experience-yielding Aquans.',
                ['1013'] = 'Knights of Round killing blow on: 200 Undead.',
                ['1832'] = 'Knights of Round killing blow on: 300 Lizards.',
                ['1833'] = 'Knights of Round killing blow on: 300 Dragons.',
                ['2256'] = 'Knights of Round killing blow on: 400 Birds.',
                ['2667'] = 'Defeat: 5 Goublefaupe (Trade Despot\'s Fortune to ??? at I-7)',
                ['3100'] = 'Defeat Notorious Monsters: 10 Animated Longsword.',
                ['3563'] = 'Collect: 5 Umbral Marrow.',
                ['3702'] = 'Trade: 300 Plutons to Oboro.',
            }
        },
        ['Sword - Machaera'] = {
            trials = {
                ['1241'] = 'Burning Blade 100 times on any experience-yielding monsters.',
                ['1242'] = 'Shining Blade 200 times on any experience-yielding monsters.',
                ['1243'] = 'Circle Blade 300 times on experience-yielding Birds.',
                ['1244'] = 'Savage Blade 500 times on experience-yielding Beasts.',
                ['1961'] = 'Finishing blow with Savage Blade 300 times on experience-yielding Plantoids.',
                ['2361'] = 'Weapon Skills dealing 400+ damage 500 times on experience-yielding Demons.',
                ['2794'] = 'Weapon Skills dealing 401+ damage 500 times on experience-yielding Birds.',
                ['3257'] = 'Weapon Skills dealing 401+ damage 500 times on experience-yielding Vermin.',
                ['Done'] = 'Finished Weapon Thibron',
            }
        },
    },

    ['Empyrean'] = {
        ['Great Katana - Masamune'] = {
            trials = {
                ['643']  = 'Defeat Notorious Monster: 1 Donto (start - trade Donto to Magian Moogle).',
                ['644']  = 'Defeat Notorious Monster: 3 Vuu Puqu the Beguiler (Giddeus).',
                ['645']  = 'Defeat Notorious Monster: 3 Buburimboo (Buburimu Peninsula).',
                ['646']  = 'Defeat Notorious Monster: 3 Zo\'Khu Blackcloud (Beadeaux).',
                ['647']  = 'Defeat Notorious Monster: 4 Seww the Squidlimbed (Sea Serpent Grotto).',
                ['648']  = 'Defeat Notorious Monster: 4 Ankabut (North Gustaberg (S)).',
                ['649']  = 'Defeat Notorious Monster: 4 Okyupete (Misareaux Coast).',
                ['650']  = 'Defeat Notorious Monster: 6 Urd (Abyssea - La Theine).',
                ['651']  = 'Defeat Notorious Monster: 6 Lamprey Lord (Abyssea - Misareaux).',
                ['1554'] = 'Defeat Notorious Monster: 8 Chesma (Abyssea - Uleguerand).',
                ['1555'] = 'Trade: 50 Carabosse\'s Gem to Delivery Crate.',
                ['2117'] = 'Trade: 50 Cirein-croin\'s Lantern to Delivery Crate.',
                ['2523'] = 'Trade: 75 Isgebind\'s Heart to Delivery Crate.',
                ['2956'] = 'Trade: 1500 Heavy Metal to Delivery Crate.',
                ['3419'] = 'Trade: 60 Riftcinder to Delivery Crate.',
                ['3601'] = 'Trade: 3000 Riftcinder to Delivery Crate (Afterglow path - optional).',
                ['Done'] = 'Finished Weapon Masamune (99)',
            }
        },
    },

    ['Mythic'] = {
        -- Mythic weapons to be added
    },
}

-- Ordered list for consistent top-level menu display
local group_order = { 'Relic', 'Empyrean', 'Mythic' }

-- Build a combined flat trial descriptions table for the chat parser
local trial_descriptions = {}
for _, group_data in pairs(weapon_groups) do
    for _, category_data in pairs(group_data) do
        if category_data.trials then
            for trial_num, desc in pairs(category_data.trials) do
                trial_descriptions[trial_num] = desc
            end
        end
    end
end

local defaultConfig = T{
    isVisible = { true },
    trials = T{},
}

-- Track which weapon tab is currently selected (runtime only, resets on reload)
local selectedWeaponTab = nil

local config = settings.load(defaultConfig)

-- Function to manually add a trial
local function AddTrial(trial_num)
    if trial_descriptions[trial_num] then
        local trial_name = "Trial " .. trial_num
        if not config.trials[trial_name] then
            config.trials[trial_name] = {
                Name = trial_name,
                Current = 0,
                Description = trial_descriptions[trial_num]
            }
            settings.save()
            print(string.format('[TrialTracker] Added %s: %s', trial_name, trial_descriptions[trial_num]))
        end
    end
end

-- Function to parse chat messages for trial information
local function ParseTrialMessage(message)
    if not message then return end
    
    local status, result = pcall(function()
        -- Check for completion message first
        local completed_trial = message:match("You have completed Trial (%d+)")
        if completed_trial then
            local trial_name = "Trial " .. completed_trial
            if config.trials[trial_name] then
                local trial = config.trials[trial_name]
                local max = tonumber(trial.Description:match("(%d+)") or "300")
                trial.Current = max
                settings.save()
            end
            return
        end

        -- Handle regular progress updates
        local trial_num, remaining = message:match("Trial (%d+): (%d+) objectives? remain")
        if trial_num and remaining then
            local trial_name = "Trial " .. trial_num
            if not config.trials[trial_name] then
                config.trials[trial_name] = {
                    Name = trial_name,
                    Current = 0,
                    Description = trial_descriptions[trial_num] or "Unknown Trial Type"
                }
            end
            
            local trial = config.trials[trial_name]
            local max = 300
            if trial.Description then
                max = tonumber(trial.Description:match("(%d+)") or "300")
            end
            
            if tonumber(remaining) == 0 then
                trial.Current = max
            else
                trial.Current = max - tonumber(remaining)
            end
            settings.save()
        end
    end)
    
    if not status then
        print('[TrialTracker] Error parsing message: ' .. tostring(result))
    end
end

settings.register('settings', 'settings_update', function (s)
    if s then config = s end
end)

ashita.events.register('load', 'load', function()
    config = settings.load(defaultConfig)
end)

ashita.events.register('unload', 'unload', function()
    settings.save()
end)

-- GUI Display: 3-level dropdown (Type > Weapon > Trial)
ashita.events.register('d3d_present', 'd3d_present', function()
    if not config.isVisible[1] then return end

    imgui.PushStyleColor(ImGuiCol_TitleBg,          { 0.0, 0.0, 0.6, 1.0 })
    imgui.PushStyleColor(ImGuiCol_TitleBgActive,    { 0.0, 0.0, 0.8, 1.0 })
    imgui.PushStyleColor(ImGuiCol_TitleBgCollapsed, { 0.0, 0.0, 0.4, 1.0 })
    imgui.PushStyleColor(ImGuiCol_Button,           { 0.0, 0.0, 0.6, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ButtonHovered,    { 0.0, 0.0, 0.8, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ButtonActive,     { 0.0, 0.0, 1.0, 1.0 })

    if imgui.Begin('Trial Tracker', config.isVisible) then
        -- Clear button
        if imgui.Button('Clear Trials', { 100, 20 }) then
            config.trials = T{}
            settings.save()
            print('[TrialTracker] Cleared all tracked trials.')
        end

        imgui.SameLine()

        -- 3-level dropdown: Type > Weapon > Trial
        if imgui.BeginCombo('##TrialSelect', 'Add Trial', ImGuiComboFlags_None) then
            for _, group_name in ipairs(group_order) do
                local group_data = weapon_groups[group_name]
                if group_data and next(group_data) then
                    if imgui.BeginMenu(group_name) then
                        -- Sort weapon names alphabetically
                        local sorted_weapons = {}
                        for weapon_name in pairs(group_data) do
                            table.insert(sorted_weapons, weapon_name)
                        end
                        table.sort(sorted_weapons)

                        for _, weapon_name in ipairs(sorted_weapons) do
                            local category_data = group_data[weapon_name]
                            if category_data and category_data.trials then
                                if imgui.BeginMenu(weapon_name) then
                                    -- Sort trial numbers numerically, non-numeric keys last
                                    local sorted_trials = {}
                                    for trial_num in pairs(category_data.trials) do
                                        table.insert(sorted_trials, trial_num)
                                    end
                                    table.sort(sorted_trials, function(a, b)
                                        local na, nb = tonumber(a), tonumber(b)
                                        if na and nb then return na < nb end
                                        if na then return true end
                                        if nb then return false end
                                        return a < b
                                    end)

                                    for _, trial_num in ipairs(sorted_trials) do
                                        local label = string.format('Trial %s - %s', trial_num, category_data.trials[trial_num])
                                        if imgui.Selectable(label, false) then
                                            AddTrial(trial_num)
                                        end
                                    end
                                    imgui.EndMenu()
                                end
                            end
                        end
                        imgui.EndMenu()
                    end
                end
            end
            imgui.EndCombo()
        end

        imgui.Separator()

        -- Build a map of weapon -> sorted trial list from active trials
        -- so we know which weapon tabs to show
        local weapon_trial_map = {}  -- weapon_name -> { trial_name, ... }

        -- Helper: find which weapon a trial belongs to
        local function FindWeaponForTrial(trial_num_str)
            for _, group_data in pairs(weapon_groups) do
                for weapon_name, category_data in pairs(group_data) do
                    if category_data.trials and category_data.trials[trial_num_str] then
                        return weapon_name
                    end
                end
            end
            return 'Unknown'
        end

        for trial_name, trial_data in pairs(config.trials) do
            if trial_data then
                local trial_num_str = trial_name:match("Trial (%S+)")
                local weapon_name = FindWeaponForTrial(trial_num_str or '')
                if not weapon_trial_map[weapon_name] then
                    weapon_trial_map[weapon_name] = {}
                end
                table.insert(weapon_trial_map[weapon_name], trial_name)
            end
        end

        if not next(weapon_trial_map) then
            imgui.Text('No active trials. Use Add Trial to begin.')
        else
            -- Sort weapon tab names alphabetically
            local sorted_weapons = {}
            for weapon_name in pairs(weapon_trial_map) do
                table.insert(sorted_weapons, weapon_name)
            end
            table.sort(sorted_weapons)

            -- Auto-select first tab if none selected or selected tab no longer exists
            if not selectedWeaponTab or not weapon_trial_map[selectedWeaponTab] then
                selectedWeaponTab = sorted_weapons[1]
            end

            -- Draw weapon tabs
            for _, weapon_name in ipairs(sorted_weapons) do
                -- Strip "WeaponType - " prefix for shorter tab label (e.g. "Amanomurakumo")
                local short_name = weapon_name:match('.- %- (.+)') or weapon_name
                local is_selected = (weapon_name == selectedWeaponTab)

                if is_selected then
                    imgui.PushStyleColor(ImGuiCol_Button,        { 0.0, 0.2, 0.8, 1.0 })
                    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.0, 0.3, 1.0, 1.0 })
                    imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.0, 0.1, 0.6, 1.0 })
                end

                if imgui.Button(short_name, { 0, 20 }) then
                    selectedWeaponTab = weapon_name
                end

                if is_selected then
                    imgui.PopStyleColor(3)
                end

                imgui.SameLine()
            end
            imgui.NewLine()
            imgui.Separator()

            -- Split trials for selected weapon into active and completed
            local trial_list = weapon_trial_map[selectedWeaponTab] or {}
            table.sort(trial_list, function(a, b)
                local na = tonumber(a:match("Trial (%d+)"))
                local nb = tonumber(b:match("Trial (%d+)"))
                if na and nb then return na < nb end
                return a < b
            end)

            local active_trials    = {}
            local completed_trials = {}
            for _, trial_name in ipairs(trial_list) do
                local trial_data = config.trials[trial_name]
                if trial_data then
                    -- Safety: if marked complete but has no progress, unmark it
                    if trial_data.Completed and (not trial_data.Current or trial_data.Current == 0) then
                        trial_data.Completed = false
                    end
                    if trial_data.Completed then
                        table.insert(completed_trials, trial_name)
                    else
                        table.insert(active_trials, trial_name)
                    end
                end
            end

            -- Active trials
            for _, trial_name in ipairs(active_trials) do
                local trial_data = config.trials[trial_name]
                if trial_data then
                    local max = 300
                    if trial_data.Description then
                        max = tonumber(trial_data.Description:match("(%d+)") or "300")
                    end
                    local progress = (max > 0) and (trial_data.Current / max) or 0

                    -- Label line first
                    local label = string.format('%s: %d/%d', trial_data.Name or trial_name, trial_data.Current or 0, max)
                    imgui.Text(label)

                    -- Bar on next line: [✓] [===green===][---dark---]
                    imgui.PushStyleColor(ImGuiCol_Button,        { 0.0, 0.5, 0.0, 1.0 })
                    imgui.PushStyleColor(ImGuiCol_ButtonHovered,  { 0.0, 0.7, 0.0, 1.0 })
                    imgui.PushStyleColor(ImGuiCol_ButtonActive,   { 0.0, 0.3, 0.0, 1.0 })
                    if imgui.Button(string.format('✓##%s', trial_name), { 24, 16 }) then
                        trial_data.Completed = true
                        trial_data.Current   = max
                        settings.save()
                        print(string.format('[TrialTracker] Marked %s as complete.', trial_name))
                    end
                    imgui.PopStyleColor(3)

                    imgui.SameLine(0, 2)

                    local avail    = imgui.GetContentRegionAvail()
                    local bar_h    = 16
                    local filled_w = avail * progress
                    local empty_w  = avail - filled_w

                    imgui.PushStyleColor(ImGuiCol_Button,        { 0.2, 0.75, 0.2, 1.0 })
                    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.2, 0.75, 0.2, 1.0 })
                    imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.2, 0.75, 0.2, 1.0 })
                    if filled_w > 0 then
                        imgui.Button(string.format('##fill_%s', trial_name), { filled_w, bar_h })
                        if empty_w > 0 then imgui.SameLine(0, 0) end
                    end
                    imgui.PopStyleColor(3)

                    if empty_w > 0 then
                        imgui.PushStyleColor(ImGuiCol_Button,        { 0.15, 0.15, 0.15, 1.0 })
                        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.15, 0.15, 0.15, 1.0 })
                        imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.15, 0.15, 0.15, 1.0 })
                        imgui.Button(string.format('##empty_%s', trial_name), { empty_w, bar_h })
                        imgui.PopStyleColor(3)
                    end

                    if trial_data.Description then
                        imgui.TextDisabled(trial_data.Description)
                    end
                    imgui.Spacing()
                end
            end

            -- Completed trials collapsible section
            if #completed_trials > 0 then
                imgui.Separator()
                if imgui.CollapsingHeader(string.format('Completed (%d)##completed_%s', #completed_trials, selectedWeaponTab)) then
                    for _, trial_name in ipairs(completed_trials) do
                        local trial_data = config.trials[trial_name]
                        if trial_data then
                            local max = 300
                            if trial_data.Description then
                                max = tonumber(trial_data.Description:match("(%d+)") or "300")
                            end

                            -- Label line first
                            local label_c = string.format('%s: %d/%d', trial_data.Name or trial_name, max, max)
                            imgui.Text(label_c)

                            -- Bar line: [↩] [===red===]
                            imgui.PushStyleColor(ImGuiCol_Button,       { 0.5, 0.2, 0.0, 1.0 })
                            imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.7, 0.3, 0.0, 1.0 })
                            imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.3, 0.1, 0.0, 1.0 })
                            if imgui.Button(string.format('↩##%s', trial_name), { 24, 16 }) then
                                trial_data.Completed = false
                                trial_data.Current   = 0
                                settings.save()
                                print(string.format('[TrialTracker] Unmarked %s as complete.', trial_name))
                            end
                            imgui.PopStyleColor(3)

                            imgui.SameLine(0, 2)

                            local avail_c = imgui.GetContentRegionAvail()
                            imgui.PushStyleColor(ImGuiCol_Button,        { 0.75, 0.1, 0.1, 1.0 })
                            imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.75, 0.1, 0.1, 1.0 })
                            imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.75, 0.1, 0.1, 1.0 })
                            imgui.Button(string.format('##done_%s', trial_name), { avail_c, 16 })
                            imgui.PopStyleColor(3)

                            if trial_data.Description then
                                imgui.TextDisabled(trial_data.Description)
                            end
                            imgui.Spacing()
                        end
                    end
                end
            end
        end
    end
    imgui.End()

    imgui.PopStyleColor(6)
end)

ashita.events.register('text_in', 'text_in', function(e)
    if e and e.message and e.message:find("Trial") then
        ParseTrialMessage(e.message)
    end
end)

ashita.events.register('command', 'command', function(e)
    if not e or not e.command then return end

    local args = e.command:args()
    if args[1] == '/trialtracker' then
        config.isVisible[1] = not config.isVisible[1]
    elseif args[1] == '/trial' and args[2] == 'clear' then
        config.trials = T{}
        settings.save()
        print('[TrialTracker] Cleared all tracked trials.')
    elseif args[1] == '/trial' and args[2] == 'add' and args[3] then
        AddTrial(args[3])
    elseif args[1] == '/trial' and args[2] == 'fix' then
        -- Reset any trials incorrectly marked complete with 0 progress
        local fixed = 0
        for _, trial_data in pairs(config.trials) do
            if trial_data and trial_data.Completed and (not trial_data.Current or trial_data.Current == 0) then
                trial_data.Completed = false
                fixed = fixed + 1
            end
        end
        settings.save()
        print(string.format('[TrialTracker] Fixed %d incorrectly completed trials.', fixed))
    end
end)
