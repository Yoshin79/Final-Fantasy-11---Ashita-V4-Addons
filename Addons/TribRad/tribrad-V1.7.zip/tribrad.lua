addon.name    = 'Tribrad'
   addon.author  = 'Oneword'
   addon.version = '1.7'
   addon.desc    = '[Tribs] [Rads] Icons in (Escha only).'
   
   require('common')
   local imgui = require('imgui')
   local settings_lib = require('settings')
   
   -- IDs
   local tribulens_id = 2894
   local radialens_id = 3031
   
   -- Escha Zones
   local allowed_zones = {
       [288] = true, -- Escha - Zi'Tah
       [289] = true, -- Escha - Ru'Aun
       [291] = true, -- Reisenjima
   }
   
   -- Default Settings
   local default_settings = T{
       pos_x = 400,
       pos_y = 300,
   }
   
   -- Settings
   local settings = settings_lib.load(default_settings)
   
   -- Dragging state
   local dragging = false
   local drag_offset_x = 0
   local drag_offset_y = 0
   
   -- Colors
   local color_have = { 0.0, 1.0, 0.0, 1.0 }    -- Green (you have the KI)
   local color_missing = { 1.0, 0.0, 0.0, 1.0 } -- Red (missing the KI)
   
   -- Save settings
   local function save_settings()
       settings_lib.save()
   end
   
   -- Reset position to default center screen
   local function reset_position()
       settings.pos_x = 400
       settings.pos_y = 300
       save_settings()
       print('[Tribrad] Position reset to center screen (400, 300).')
   end
   
   -- Check if in Escha
   local function is_in_escha_zone()
       local zone_id = AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0)
       return allowed_zones[zone_id] or false
   end
   
   -- Load event
   ashita.events.register('load', 'tribrad_load_cb', function()
       settings = settings_lib.load(default_settings)
       print('[Tribrad] Loaded. Use /tribrad reset to reset position.')
   end)
   
   -- Unload event
   ashita.events.register('unload', 'tribrad_unload_cb', function()
       save_settings()
   end)
   
   -- Command handler
   ashita.events.register('command', 'tribrad_command_cb', function(e)
       local args = e.command:args()
       if #args == 0 or args[1] ~= '/tribrad' then
           return
       end
       
       e.blocked = true
       
       if #args == 1 then
           print('[Tribrad] Commands:')
           print('  /tribrad reset - Reset position to center screen')
           print('  /tribrad save - Save current position')
           print('  /tribrad debug - Show debug information')
           print('  /tribrad scan - Scan for Tribulens/Radialens key items')
           return
       end
       
       if args[2]:lower() == 'reset' then
           reset_position()
       elseif args[2]:lower() == 'save' then
           save_settings()
           print('[Tribrad] Position saved.')
       elseif args[2]:lower() == 'debug' then
           local player = AshitaCore:GetMemoryManager():GetPlayer()
           if player then
               print('[Tribrad] Debug Info:')
               print('  Checking Tribulens (ID: ' .. tribulens_id .. '): ' .. tostring(player:HasKeyItem(tribulens_id)))
               print('  Checking Radialens (ID: ' .. radialens_id .. '): ' .. tostring(player:HasKeyItem(radialens_id)))
               print('  Current Zone: ' .. AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0))
               print('  In Escha Zone: ' .. tostring(is_in_escha_zone()))
           end
       elseif args[2]:lower() == 'scan' then
           local player = AshitaCore:GetMemoryManager():GetPlayer()
           if player then
               print('[Tribrad] Scanning for key items with "Tribulens" or "Radialens" in name...')
               local resMgr = AshitaCore:GetResourceManager()
               for i = 0, 4096 do
                   if player:HasKeyItem(i) then
                       local keyItem = resMgr:GetKeyItemById(i)
                       if keyItem and keyItem.Name then
                           local name = keyItem.Name[1] -- English name
                           if name and (name:lower():find('tribulens') or name:lower():find('radialens')) then
                               print('  Found: ' .. name .. ' (ID: ' .. i .. ')')
                           end
                       end
                   end
               end
               print('[Tribrad] Scan complete.')
           end
       else
           print('[Tribrad] Unknown command. Use /tribrad for help.')
       end
   end)
   
   ashita.events.register('d3d_present', 'tribrad_present_cb', function()
   
       if not is_in_escha_zone() then
           return
       end
   
       if not AshitaCore:GetMemoryManager():GetParty():GetMemberIsActive(0) then
           return
       end
   
       local player = AshitaCore:GetMemoryManager():GetPlayer()
       if (player == nil) then
           return
       end
       
       -- Check key items directly (same method as working Ambu addon)
       local has_tribulens = player:HasKeyItem(tribulens_id)
       local has_radialens = player:HasKeyItem(radialens_id)
   
       local draw = imgui.GetBackgroundDrawList()
       local io = imgui.GetIO()
   
       -- Dragging logic
       if imgui.IsMouseDown(0) then
           local mx, my = io.MousePos.x, io.MousePos.y
           if dragging then
               settings.pos_x = mx - drag_offset_x
               settings.pos_y = my - drag_offset_y
           elseif (mx >= settings.pos_x and mx <= settings.pos_x + 200) and (my >= settings.pos_y and my <= settings.pos_y + 20) then
               dragging = true
               drag_offset_x = mx - settings.pos_x
               drag_offset_y = my - settings.pos_y
           end
       else
           if dragging then
               -- Save position when drag ends
               save_settings()
           end
           dragging = false
       end
   
       -- Draw [Tribs]
       draw:AddText(
           { settings.pos_x, settings.pos_y },
           imgui.ColorConvertFloat4ToU32(has_tribulens and color_have or color_missing),
           "[ Tribs ]"
       )
   
       -- Draw [Rads] next to it
       draw:AddText(
           { settings.pos_x + 90, settings.pos_y },
           imgui.ColorConvertFloat4ToU32(has_radialens and color_have or color_missing),
           "[ Rads ]"
       )
   
   end)