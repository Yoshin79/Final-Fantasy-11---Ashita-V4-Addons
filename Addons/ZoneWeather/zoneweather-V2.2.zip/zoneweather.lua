----------------------------------------------------------------------------------------------------
-- ZoneWeather - Ashita v4 Addon
-- SMN Quest Helper: "I Can Hear a Rainbow"
-- Tracks current zone weather and which of the 7 quest weathers you still need.
--
-- Install: Place 'zoneweather' folder in Ashita/addons/
-- Load:    /addon load zoneweather
-- Toggle:  /zw
-- Reset:   /zw reset
----------------------------------------------------------------------------------------------------
addon = {};
addon.name    = 'ZoneWeather';
addon.author  = 'Oneword';
addon.version = '2.2';
addon.desc    = 'SMN Quest Weather Tracker ';
addon.link    = '';

local imgui = nil;
pcall(function() imgui = require('imgui'); end);

----------------------------------------------------------------------------------------------------
-- Weather memory pointer - reads directly from FFXiMain.dll
-- Credit to community for this pattern
----------------------------------------------------------------------------------------------------
local pWeather = nil;
pcall(function()
    pWeather = ashita.memory.find('FFXiMain.dll', 0, '66A1????????663D????72', 0, 0);
end);

local function GetWeather()
    if not pWeather or pWeather == 0 then return 0; end
    local ok, result = pcall(function()
        local pointer = ashita.memory.read_uint32(pWeather + 0x02);
        return ashita.memory.read_uint8(pointer + 0);
    end);
    if ok then return result; end
    return 0;
end

local function GetZoneId()
    local ok, result = pcall(function()
        return AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0);
    end);
    if ok then return result; end
    return 0;
end

local function GetZoneName(id)
    if not id or id == 0 then return 'Unknown'; end
    local ok, result = pcall(function()
        return AshitaCore:GetResourceManager():GetString('zones.names', id);
    end);
    if ok and result and result ~= '' then return result; end
    return 'Zone ' .. tostring(id);
end

----------------------------------------------------------------------------------------------------
-- Weather ID to display info
-- Using the correct lookup from community documentation
----------------------------------------------------------------------------------------------------
local weatherInfo = {
    [0]  = { name = 'Clear',          color = { 1.0, 1.0, 0.8, 1.0 } },
    [1]  = { name = 'Sunshine',       color = { 1.0, 1.0, 0.7, 1.0 } },
    [2]  = { name = 'Clouds',         color = { 0.8, 0.8, 0.8, 1.0 } },
    [3]  = { name = 'Fog',            color = { 0.7, 0.7, 0.7, 1.0 } },
    [4]  = { name = 'Fire',           color = { 1.0, 0.4, 0.1, 1.0 } },
    [5]  = { name = 'Fire x2',        color = { 1.0, 0.2, 0.0, 1.0 } },
    [6]  = { name = 'Water',          color = { 0.3, 0.6, 1.0, 1.0 } },
    [7]  = { name = 'Water x2',       color = { 0.1, 0.4, 1.0, 1.0 } },
    [8]  = { name = 'Earth',          color = { 0.7, 0.5, 0.2, 1.0 } },
    [9]  = { name = 'Earth x2',       color = { 0.6, 0.4, 0.1, 1.0 } },
    [10] = { name = 'Wind',           color = { 0.6, 1.0, 0.6, 1.0 } },
    [11] = { name = 'Wind x2',        color = { 0.4, 0.9, 0.4, 1.0 } },
    [12] = { name = 'Ice',            color = { 0.6, 0.8, 1.0, 1.0 } },
    [13] = { name = 'Ice x2',         color = { 0.4, 0.6, 1.0, 1.0 } },
    [14] = { name = 'Thunder',        color = { 1.0, 1.0, 0.3, 1.0 } },
    [15] = { name = 'Thunder x2',     color = { 0.9, 0.9, 0.1, 1.0 } },
    [16] = { name = 'Light',          color = { 1.0, 1.0, 0.9, 1.0 } },
    [17] = { name = 'Light x2',       color = { 1.0, 1.0, 0.7, 1.0 } },
    [18] = { name = 'Dark',           color = { 0.5, 0.3, 0.7, 1.0 } },
    [19] = { name = 'Dark x2',        color = { 0.3, 0.1, 0.5, 1.0 } },
};

local function getWeatherInfo(id)
    return weatherInfo[id] or { name = 'Unknown (' .. tostring(id) .. ')', color = { 0.8, 0.8, 0.8, 1.0 } };
end

----------------------------------------------------------------------------------------------------
-- The 7 quest weather colors needed for "I Can Hear a Rainbow"
-- Note: Light and Dark do NOT count for this quest
----------------------------------------------------------------------------------------------------
local questWeathers = {
    {
        key   = 'clear',
        name  = 'Clear / Sunshine',
        color = { 1.0, 1.0, 0.7, 1.0 },
        ids   = { 0, 1 },
        zones = 'Any outdoor enemy zone with no weather',
        tip   = 'Zone into any field area on a clear day.',
    },
    {
        key   = 'fire',
        name  = 'Fire / Heat',
        color = { 1.0, 0.4, 0.1, 1.0 },
        ids   = { 4, 5 },
        zones = 'E. Altepa Desert, W. Altepa Desert, Valkurm Dunes',
        tip   = 'Try on Firesday. Altepa deserts have highest fire rate.',
    },
    {
        key   = 'water',
        name  = 'Water / Rain',
        color = { 0.3, 0.6, 1.0, 1.0 },
        ids   = { 6, 7 },
        zones = 'La Theine Plateau, Batallia Downs, Jugner Forest',
        tip   = 'La Theine often gets rain after wind. Try on Watersday.',
    },
    {
        key   = 'wind',
        name  = 'Wind',
        color = { 0.6, 1.0, 0.6, 1.0 },
        ids   = { 10, 11 },
        zones = 'La Theine Plateau, Konschtat Highlands, Tahrongi Canyon',
        tip   = 'Common in La Theine. Try on Windsday.',
    },
    {
        key   = 'ice',
        name  = 'Ice / Snow',
        color = { 0.6, 0.8, 1.0, 1.0 },
        ids   = { 12, 13 },
        zones = 'Beaucedine Glacier, Xarcabard, Ranguemont Pass',
        tip   = 'Beaucedine has frequent ice weather. Try on Iceday.',
    },
    {
        key   = 'thunder',
        name  = 'Thunder / Lightning',
        color = { 1.0, 1.0, 0.3, 1.0 },
        ids   = { 14, 15 },
        zones = 'Pashhow Marshlands, Rolanberry Fields, Sauromugue Champaign',
        tip   = 'Pashhow Marshlands is best. Try on Lightningday.',
    },
    {
        key   = 'earth',
        name  = 'Earth / Sand',
        color = { 0.8, 0.6, 0.2, 1.0 },
        ids   = { 8, 9 },
        zones = 'E. Altepa Desert, W. Altepa Desert, Tahrongi Canyon',
        tip   = 'Altepa deserts get sand storms. Try on Earthsday.',
    },
};

-- Build lookup: weatherId -> questWeather key
local weatherIdToKey = {};
for _, qw in ipairs(questWeathers) do
    for _, id in ipairs(qw.ids) do
        weatherIdToKey[id] = qw.key;
    end
end

----------------------------------------------------------------------------------------------------
-- State
----------------------------------------------------------------------------------------------------
local visible        = { true };
local collected      = {};
local saveFile       = 'settings/zoneweather_smn.lua';

----------------------------------------------------------------------------------------------------
-- Save / Load
----------------------------------------------------------------------------------------------------
local function saveCollected()
    pcall(function()
        if not ashita.fs.exists('settings') then
            ashita.fs.create_directory('settings');
        end
        local f = io.open(saveFile, 'w');
        if f then
            f:write('return {\n');
            for key, val in pairs(collected) do
                f:write(string.format('    ["%s"] = %s,\n', key, tostring(val)));
            end
            f:write('}\n');
            f:close();
        end
    end);
end

local function loadCollected()
    pcall(function()
        if ashita.fs.exists(saveFile) then
            local ok, data = pcall(dofile, saveFile);
            if ok and type(data) == 'table' then
                collected = data;
            end
        end
    end);
end

local function countCollected()
    local n = 0;
    for _, v in pairs(collected) do
        if v then n = n + 1; end
    end
    return n;
end

----------------------------------------------------------------------------------------------------
-- Load
----------------------------------------------------------------------------------------------------
ashita.events.register('load', 'zw_load', function()
    print('[ZoneWeather] Loaded! Type /zw to toggle.');
    loadCollected();
end);

----------------------------------------------------------------------------------------------------
-- Unload
----------------------------------------------------------------------------------------------------
ashita.events.register('unload', 'zw_unload', function()
    saveCollected();
    print('[ZoneWeather] Unloaded.');
end);

----------------------------------------------------------------------------------------------------
-- Commands
----------------------------------------------------------------------------------------------------
ashita.events.register('command', 'zw_command', function(e)
    if not e or not e.command then return; end
    local args = {};
    for arg in e.command:gmatch('%S+') do
        args[#args+1] = arg;
    end
    if args[1] ~= '/zw' and args[1] ~= '/zoneweather' then return; end
    e.blocked = true;

    if args[2] == 'reset' then
        collected = {};
        saveCollected();
        print('[ZoneWeather] Progress reset!');
    else
        visible[1] = not visible[1];
    end
end);

----------------------------------------------------------------------------------------------------
-- Render
----------------------------------------------------------------------------------------------------
ashita.events.register('d3d_present', 'zw_present', function()
    if not imgui then return; end
    if not visible[1] then return; end

    -- Read current state every frame via memory
    local zoneId     = GetZoneId();
    local weatherId  = GetWeather();
    local zoneName   = GetZoneName(zoneId);
    local wInfo      = getWeatherInfo(weatherId);
    local currentKey = weatherIdToKey[weatherId];

    imgui.SetNextWindowSize({ 420, 180 }, ImGuiCond_FirstUseEver);
    imgui.SetNextWindowPos({ 100, 100 }, ImGuiCond_FirstUseEver);

    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.1, 0.1, 0.18, 1.0 });
    imgui.PushStyleColor(ImGuiCol_TitleBg, { 0.3, 0.1, 0.5, 1.0 });
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, { 0.5, 0.2, 0.8, 1.0 });

    if imgui.Begin('ZoneWeather v2.2##zw', visible, ImGuiWindowFlags_None) then

        -- Current zone/weather always visible at top
        imgui.Text('Zone:    '); imgui.SameLine();
        imgui.Text(zoneName);

        imgui.Text('Weather: '); imgui.SameLine();
        imgui.TextColored(wInfo.color, wInfo.name);

        imgui.Separator();

        -- SMN Quest collapsing section
        imgui.PushStyleColor(ImGuiCol_Header, { 0.3, 0.1, 0.5, 1.0 });
        imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.4, 0.2, 0.6, 1.0 });
        imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.5, 0.2, 0.8, 1.0 });

        if imgui.CollapsingHeader('SMN Quest - I Can Hear a Rainbow') then

            -- Progress
            local done = countCollected();
            imgui.TextColored({ 0.8, 0.8, 0.3, 1.0 }, string.format('Progress: %d / 7 colors collected', done));
            imgui.ProgressBar(done / 7, { -1, 0 }, string.format('%d/7', done));
            imgui.Separator();
            imgui.TextColored({ 0.7, 0.7, 0.7, 1.0 }, 'The 7 Colors of Light:');
            imgui.Separator();

            -- Quest checklist
            for _, qw in ipairs(questWeathers) do
                local isDone = collected[qw.key] == true;
                local checkVal = { isDone };

                if imgui.Checkbox('##check' .. qw.key, checkVal) then
                    collected[qw.key] = checkVal[1];
                    saveCollected();
                end
                imgui.SameLine();

                if isDone then
                    imgui.TextColored({ 0.5, 0.5, 0.5, 1.0 }, qw.name);
                else
                    imgui.TextColored(qw.color, qw.name);

                    if currentKey == qw.key then
                        imgui.SameLine();
                        imgui.TextColored({ 0.3, 1.0, 0.3, 1.0 }, '<-- YOU ARE HERE!');
                    end

                    imgui.Indent(20);
                    imgui.TextColored({ 0.5, 0.5, 0.5, 1.0 }, qw.zones);
                    imgui.TextColored({ 0.4, 0.6, 0.4, 1.0 }, qw.tip);
                    imgui.Unindent(20);
                end

                imgui.Spacing();
            end

            imgui.Separator();
            if imgui.SmallButton('Reset All Progress') then
                collected = {};
                saveCollected();
            end
        end

        imgui.PopStyleColor(3);

        imgui.End();
    end

    imgui.PopStyleColor(3);
end);

return addon;
