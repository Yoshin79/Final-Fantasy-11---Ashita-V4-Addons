-- config.lua - ImGui configuration panel for CorsairRolls addon

local imgui = require('imgui');
local data = require('data');
local display = require('display');
local tracker = require('tracker');
local autoroll = require('autoroll');

local config = {};

function config.initialize()
end

local function color_to_imgui(color)
    local a = bit.band(bit.rshift(color, 24), 0xFF) / 255;
    local r = bit.band(bit.rshift(color, 16), 0xFF) / 255;
    local g = bit.band(bit.rshift(color, 8), 0xFF) / 255;
    local b = bit.band(color, 0xFF) / 255;
    return { r, g, b, a };
end

local function imgui_to_color(color_array)
    local a = math.floor(color_array[4] * 255);
    local r = math.floor(color_array[1] * 255);
    local g = math.floor(color_array[2] * 255);
    local b = math.floor(color_array[3] * 255);
    return bit.lshift(a, 24) + bit.lshift(r, 16) + bit.lshift(g, 8) + b;
end

function config.toggle()
    local settings = data.get_settings();
    settings.config_visible = not settings.config_visible;
    data.save();
end

function config.render()
    local settings = data.get_settings();
    
    if not settings.config_visible then
        return;
    end
    
    imgui.SetNextWindowSize({ 400, 300 }, ImGuiCond_FirstUseEver);
    imgui.Begin('Corsair Rolls Configuration');
    
    if true then
        -- Visibility toggle
        local visible = settings.visible;
        if imgui.Checkbox('Display Rolls', { visible }) then
            display.toggle_visibility();
        end
        
        imgui.Separator();
        
        -- Font settings
        if imgui.CollapsingHeader('Font Settings') then
            if imgui.BeginCombo('Font Family', settings.font.family) then
                for _, family in ipairs(data.get_font_families()) do
                    if imgui.Selectable(family, family == settings.font.family) then
                        display.update_font_settings(family, nil);
                    end
                end
                imgui.EndCombo();
            end
            
            imgui.Text('Font Size: ' .. settings.font.size);
            imgui.SameLine();
            
            if imgui.Button('-') then
                if settings.font.size > 8 then
                    display.update_font_settings(nil, settings.font.size - 1);
                end
            end
            
            imgui.SameLine();
            
            if imgui.Button('+') then
                if settings.font.size < 20 then
                    display.update_font_settings(nil, settings.font.size + 1);
                end
            end
        end
        
        imgui.Separator();
        
        -- Color settings
        if imgui.CollapsingHeader('Color Settings') then
            local text_color = color_to_imgui(settings.colors.text);
            if imgui.ColorEdit4('Normal Text Color', text_color) then
                settings.colors.text = imgui_to_color(text_color);
                data.save();
            end
            
            local lucky_color = color_to_imgui(settings.colors.lucky);
            if imgui.ColorEdit4('Lucky Roll Color', lucky_color) then
                settings.colors.lucky = imgui_to_color(lucky_color);
                data.save();
            end
            
            local unlucky_color = color_to_imgui(settings.colors.unlucky);
            if imgui.ColorEdit4('Unlucky Roll Color', unlucky_color) then
                settings.colors.unlucky = imgui_to_color(unlucky_color);
                data.save();
            end
            
            local bg_color = color_to_imgui(settings.colors.background);
            if imgui.ColorEdit4('Background Color', bg_color) then
                display.update_background_color(imgui_to_color(bg_color));
            end
        end
        
        imgui.Separator();
        
        -- Test rolls section
        if imgui.CollapsingHeader('Test Rolls') then
            if imgui.Button('Test Lucky Roll') then
                local test_roll = "Hunters Roll";
                local lucky_value = data.get_roll_data()[test_roll].lucky;
                
                if #settings.active_rolls >= 2 then
                    table.remove(settings.active_rolls, 1);
                end
                
                table.insert(settings.active_rolls, {
                    name = test_roll,
                    value = lucky_value
                });
                
                data.save();
            end
            
            imgui.SameLine();
            
            if imgui.Button('Test Unlucky Roll') then
                local test_roll = "Tacticians Roll";
                local unlucky_value = data.get_roll_data()[test_roll].unlucky;
                
                if #settings.active_rolls >= 2 then
                    table.remove(settings.active_rolls, 1);
                end
                
                table.insert(settings.active_rolls, {
                    name = test_roll,
                    value = unlucky_value
                });
                
                data.save();
            end
            
            if imgui.Button('Clear Rolls') then
                tracker.clear_rolls();
            end
        end
        
        imgui.Separator();
        
        -- Auto Roll settings
        if imgui.CollapsingHeader('Auto Roll Settings') then
            local auto_enabled = settings.autoroll.enabled;
            if imgui.Checkbox('Enable Auto Roll', { auto_enabled }) then
                autoroll.toggle();
            end
            
            imgui.Separator();
            
            local roll1_enabled = settings.autoroll.roll1.enabled;
            if imgui.Checkbox('Enable Roll 1', { roll1_enabled }) then
                autoroll.toggle_roll(1);
            end
            
            imgui.SameLine();
            
            if imgui.BeginCombo('Roll 1 Type', settings.autoroll.roll1.name) then
                for roll_name, _ in pairs(data.get_roll_data()) do
                    if imgui.Selectable(roll_name, roll_name == settings.autoroll.roll1.name) then
                        autoroll.set_roll(1, roll_name);
                    end
                end
                imgui.EndCombo();
            end
            
            local roll2_enabled = settings.autoroll.roll2.enabled;
            if imgui.Checkbox('Enable Roll 2', { roll2_enabled }) then
                autoroll.toggle_roll(2);
            end
            
            imgui.SameLine();
            
            if imgui.BeginCombo('Roll 2 Type', settings.autoroll.roll2.name) then
                for roll_name, _ in pairs(data.get_roll_data()) do
                    if imgui.Selectable(roll_name, roll_name == settings.autoroll.roll2.name) then
                        autoroll.set_roll(2, roll_name);
                    end
                end
                imgui.EndCombo();
            end
            
            local action_delay = settings.autoroll.action_delay;
            imgui.Text('Action Delay (seconds): ');
            imgui.SameLine();
            if imgui.InputInt('##ActionDelay', { action_delay }) then
                if action_delay < 1 then action_delay = 1; end
                if action_delay > 30 then action_delay = 30; end
                settings.autoroll.action_delay = action_delay;
                data.save();
            end
            
            local use_fold = settings.autoroll.use_fold_on_bust;
            if imgui.Checkbox('Use Fold on Bust', { use_fold }) then
                autoroll.toggle_fold_on_bust();
            end
            
            local use_random_deal = settings.autoroll.use_random_deal;
            if imgui.Checkbox('Use Random Deal when Fold is on cooldown', { use_random_deal }) then
                autoroll.toggle_random_deal();
            end
            
            if settings.autoroll.roll1.busted then
                imgui.TextColored({ 1, 0.3, 0.3, 1 }, "Roll 1 is busted!");
            end
            
            if settings.autoroll.roll2.busted then
                imgui.TextColored({ 1, 0.3, 0.3, 1 }, "Roll 2 is busted!");
            end
        end
        
        imgui.Separator();
        
        -- Debug section
        if imgui.CollapsingHeader('Debug Options') then
            local debug_enabled = data.is_debug();
            if imgui.Checkbox('Enable Debug Messages', { debug_enabled }) then
                data.toggle_debug();
            end
        end
        
        imgui.Separator();
        
        if imgui.Button('Save Settings') then
            data.save();
            print("Corsair Rolls settings saved.");
        end
        
        imgui.SameLine();
        
        if imgui.Button('Close Configuration') then
            settings.config_visible = false;
            data.save();
        end
        
        imgui.SameLine();
        
        if imgui.Button('Reset to Defaults') then
            local pos_x = settings.position.x;
            local pos_y = settings.position.y;
            local positions = settings.positions;
            
            data.initialize();
            settings = data.get_settings();
            
            settings.position.x = pos_x;
            settings.position.y = pos_y;
            
            if positions then
                settings.positions = positions;
            end
            
            display.initialize();
            data.save();
        end
        
        imgui.SameLine();
        
        if imgui.Button('Reset Positions') then
            display.reset_positions();
        end
    end
    
    imgui.End();
end

return config;
