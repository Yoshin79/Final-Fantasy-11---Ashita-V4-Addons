# Corsair Rolls Addon - Ashita v4 Fixed

## Description
An Ashita v4 addon for tracking Corsair Phantom Rolls in Final Fantasy XI.

## Installation
1. Extract this folder to: `Ashita/addons/corsairrolls/`
2. In-game type: `/load corsairrolls`
3. Open configuration: `/corsairrolls config`

## Features
- Track active Corsair rolls
- Display lucky/unlucky values
- Color-coded roll information
- Auto-roll functionality
- Customizable font and colors
- Test roll functionality
- Reset position options

## Commands
- `/corsairrolls` - Toggle roll display
- `/corsairrolls config` - Open configuration window

## Credits
Updated for Ashita v4 compatibility - Fixed ImGui indentation issues