-- tracker.lua - Roll tracking logic for CorsairRolls addon

local data = require('data');

local tracker = {};

-- Track the last busted roll name for Fold to remove
local last_busted_roll = nil;

-- Process incoming chat messages
function tracker.process_message(message)
    if data.is_debug() then
        print("DEBUG: " .. message);
    end
    
    -- Pattern to match zone change messages
    -- Example: "=== Area: Mhaura ==="
    local area_pattern = "=== Area: ([%w%s]+) ===";
    local area_name = string.match(message, area_pattern);
    
    if area_name then
        print("CorsairRolls: Area change detected (" .. area_name .. ") - clearing all rolls and disabling auto roll");
        
        -- Clear all rolls when entering a new area
        tracker.clear_rolls();
        
        -- Clear bust status
        local autoroll = package.loaded['autoroll'];
        if autoroll then
            autoroll.set_bust_status(autoroll.config.roll1.name, false);
            autoroll.set_bust_status(autoroll.config.roll2.name, false);
            
            -- Disable auto roll when zoning
            if autoroll.config.enabled then
                autoroll.config.enabled = false;
                local settings = data.get_settings();
                settings.autoroll.enabled = false;
                data.save();
                print("CorsairRolls: Auto Roll has been disabled. Use /cor autoroll toggle to re-enable.");
            end
        end
    end
    
    -- Pattern to match roll messages
    -- Example: "Cariblou uses Samurai Roll. The total comes to 8!"
    local roll_pattern = "([%w%s']+) uses ([%w%s']+) Roll%. The total comes to (%d+)!";
    local player, roll_name, roll_value = string.match(message, roll_pattern);
    
    if player and roll_name and roll_value then
        roll_value = tonumber(roll_value);
        local full_roll_name = roll_name .. " Roll";
        
        if data.is_debug() then
            print("Roll detected: " .. player .. " used " .. full_roll_name .. " with value " .. roll_value);
        end
        
        tracker.update_roll(full_roll_name, roll_value);
    end
    
    -- Pattern to match bust messages
    -- Example: "Bust!"
    if string.match(message, "Bust!") then
        if data.is_debug() then
            print("Bust detected");
        end
        
        -- If we have a roll that was just mentioned, mark it as busted
        local settings = data.get_settings();
        if #settings.active_rolls > 0 then
            local last_roll = settings.active_rolls[#settings.active_rolls];
            -- Get autoroll module after it's loaded
            local autoroll = package.loaded['autoroll'];
            if autoroll then
                autoroll.set_bust_status(last_roll.name, true);
            end
            -- Store the busted roll name for Fold to remove
            last_busted_roll = last_roll.name;
            table.remove(settings.active_rolls, #settings.active_rolls);
            data.save();
        end
    end
    
    -- Pattern to match bust effect wearing off
    -- Example: "Cariblou's Bust effect wears off."
    local bust_wears_off_pattern = "([%w%s']+)'s Bust effect wears off%.";
    local bust_player = string.match(message, bust_wears_off_pattern);
    
    if bust_player then
        if data.is_debug() then
            print("Bust effect wore off for " .. bust_player);
        end
        
        -- Clear bust status for all rolls
        local autoroll = package.loaded['autoroll'];
        if autoroll then
            autoroll.set_bust_status(autoroll.config.roll1.name, false);
            autoroll.set_bust_status(autoroll.config.roll2.name, false);
        end
    end
    
    -- Pattern to match Fold ability
    -- Example: "Cariblou uses Fold."
    local fold_pattern = "([%w%s']+) uses Fold%.";
    local fold_player = string.match(message, fold_pattern);
    
    if fold_player then
        if data.is_debug() then
            print("Fold detected: " .. fold_player .. " used Fold");
        end
        
        -- Clear bust status for all rolls
        local autoroll = package.loaded['autoroll'];
        if autoroll then
            autoroll.set_bust_status(autoroll.config.roll1.name, false);
            autoroll.set_bust_status(autoroll.config.roll2.name, false);
        end
        
        -- Remove the busted roll specifically (not just the last roll)
        if last_busted_roll then
            local settings = data.get_settings();
            for i, roll in ipairs(settings.active_rolls) do
                if roll.name == last_busted_roll then
                    table.remove(settings.active_rolls, i);
                    if data.is_debug() then
                        print("Fold removed busted roll: " .. last_busted_roll);
                    end
                    break;
                end
            end
            data.save();
            last_busted_roll = nil; -- Clear the stored busted roll name
        else
            if data.is_debug() then
                print("Fold used but no busted roll found to remove");
            end
        end
    end
    
    -- Pattern to match double-up messages
    -- Example: "The total for Samurai Roll increases to 11!"
    local doubleup_pattern = "The total for ([%w%s']+) Roll increases to (%d+)!";
    local du_roll, du_value = string.match(message, doubleup_pattern);
    
    if du_roll and du_value then
        du_value = tonumber(du_value);
        local full_du_roll = du_roll .. " Roll";
        
        if data.is_debug() then
            print("Double-up detected: " .. full_du_roll .. " increased to " .. du_value);
        end
        
        tracker.update_roll(full_du_roll, du_value);
    end
    
    -- Pattern to match roll effect loss
    -- Example: "Cariblou loses the effect of Samurai Roll."
    local effect_loss_pattern = "([%w%s']+) loses the effect of ([%w%s']+) Roll%.";
    local loss_player, loss_roll = string.match(message, effect_loss_pattern);
    
    if loss_player and loss_roll then
        local full_loss_roll = loss_roll .. " Roll";
        
        if data.is_debug() then
            print("Roll effect lost: " .. loss_player .. " lost " .. full_loss_roll);
        end
        
        tracker.remove_roll(full_loss_roll);
        
        -- Reset roll state in autoroll
        local autoroll = package.loaded['autoroll'];
        if autoroll then
            autoroll.reset_roll_state(full_loss_roll);
        end
    end
    
    -- Pattern to match roll effect wearing off
    -- Example: "Oneword's Beast Roll effect wears off."
    local effect_wears_off_pattern = "([%w%s']+)'s ([%w%s']+) Roll effect wears off%.";
    local player_name, wears_off_roll = string.match(message, effect_wears_off_pattern);
    
    if player_name and wears_off_roll then
        local full_wears_off_roll = wears_off_roll .. " Roll";
        
        if data.is_debug() then
            print("Roll effect wore off for " .. player_name .. ": " .. full_wears_off_roll);
        end
        
        tracker.remove_roll(full_wears_off_roll);
        
        -- Reset roll state in autoroll
        local autoroll = package.loaded['autoroll'];
        if autoroll then
            autoroll.reset_roll_state(full_wears_off_roll);
        end
    end
    
    -- Pattern to match Snake Eye ability
    -- Example: "Cariblou uses Snake Eye."
    local snake_eye_pattern = "([%w%s']+) uses Snake Eye%.";
    local snake_eye_player = string.match(message, snake_eye_pattern);
    
    if snake_eye_player then
        if data.is_debug() then
            print("Snake Eye detected: " .. snake_eye_player .. " used Snake Eye");
        end
        
        -- We don't need to do anything special here, just log it for debugging
    end
    
    -- Pattern to match player death messages
    -- Example: "Cariblou was defeated by the Nostos Goobbue."
    local death_pattern = "([%w%s']+) was defeated by";
    local dead_player = string.match(message, death_pattern);
    
    if dead_player then
        -- Check if the dead player is the local player
        local player = AshitaCore:GetMemoryManager():GetParty():GetMemberName(0);
        if player and dead_player:trim() == player:trim() then
            print("CorsairRolls: Player death detected - clearing all rolls and disabling auto roll");
            
            -- Clear all rolls when the player dies
            tracker.clear_rolls();
            
            -- Clear bust status and disable auto roll
            local autoroll = package.loaded['autoroll'];
            if autoroll then
                autoroll.set_bust_status(autoroll.config.roll1.name, false);
                autoroll.set_bust_status(autoroll.config.roll2.name, false);
                
                -- Disable auto roll when player dies
                if autoroll.config.enabled then
                    autoroll.config.enabled = false;
                    local settings = data.get_settings();
                    settings.autoroll.enabled = false;
                    data.save();
                    print("CorsairRolls: Auto Roll has been disabled. Use /cor autoroll toggle to re-enable.");
                end
            end
        end
    end
    
    return false;
end

-- Update a roll
function tracker.update_roll(roll_name, roll_value)
    local settings = data.get_settings();
    
    -- Check if this roll is already active
    local found = false;
    for i, roll in ipairs(settings.active_rolls) do
        if roll.name == roll_name then
            roll.value = roll_value;
            found = true;
            break;
        end
    end
    
    -- If not found, add it as a new roll
    if not found then
        -- If we already have 2 rolls, remove the oldest one
        if #settings.active_rolls >= 2 then
            table.remove(settings.active_rolls, 1);
        end
        
        -- Add the new roll
        table.insert(settings.active_rolls, {
            name = roll_name,
            value = roll_value
        });
    end
    
    -- Save settings
    data.save();
end

-- Remove a roll
function tracker.remove_roll(roll_name)
    local settings = data.get_settings();
    
    for i, roll in ipairs(settings.active_rolls) do
        if roll.name == roll_name then
            table.remove(settings.active_rolls, i);
            break;
        end
    end
    
    data.save();
end

-- Clear all rolls
function tracker.clear_rolls()
    data.get_settings().active_rolls = T{};
    
    -- Clear bust status
    local autoroll = package.loaded['autoroll'];
    if autoroll then
        autoroll.set_bust_status(autoroll.config.roll1.name, false);
        autoroll.set_bust_status(autoroll.config.roll2.name, false);
    end
    
    data.save();
end

-- Add test rolls
function tracker.add_test_rolls()
    data.get_settings().active_rolls = T{
        { name = "Hunters Roll", value = 4 },
        { name = "Tacticians Roll", value = 8 }
    };
    data.save();
end

return tracker;