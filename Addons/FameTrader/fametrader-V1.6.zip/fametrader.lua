--[[
* fametrader.lua
* Ashita V4 Addon — Auto-trades items to NPCs with ImGui UI, organized by location.
*
* Requires: bellhop plugin (for /bh tradenpc)
*
* Commands:
*   /fametrader        - Toggle the UI window
*   /fametrader show   - Open the UI window
*   /fametrader hide   - Close the UI window
*   /fametrader stop   - Stop trading
*   /fametrader help   - Show command help
--]]

addon.name    = 'fametrader';
addon.author  = 'Oneword';
addon.version = '1.6';
addon.desc    = 'Auto-trades items to NPCs for fame, organized by location, with ImGui UI.';
addon.link    = '';

require 'common';
local chat  = require 'chat';
local imgui = require 'imgui';

----------------------------------------------------------------------------------------------------
-- Location / Item Definitions
--
-- Location fields:
--   name         : display name (shown on tab)
--   color        : tab/header color {r,g,b,a}
--   items        : list of items to trade
--   t_*          : default timing values (ms) for this location
--
-- Item fields (all optional except name/id/qty/npc):
--   name         : display name
--   id           : FFXI item ID
--   qty          : quantity per trade
--   npc          : bellhop tradenpc string
--   confirm_key  : 'Y' (default) or 'RETURN' — key used to confirm trade
--   single_confirm : true = only ONE key press to confirm (Windurst style), false/nil = two presses
--   t_*          : per-item timing overrides (fall back to location defaults if nil)
----------------------------------------------------------------------------------------------------
local LOCATIONS = T{
    T{
        name  = 'Selbina',
        color = { 0.9,  0.25, 0.2,  1.0 },   -- Sandy Red
        items = T{
            T{ name = 'Millioncorn',       id = 629,  qty = 3, npc = 'Millioncorn'       },
            T{ name = 'Boyahda Moss',      id = 919,  qty = 1, npc = 'Boyahda Moss'      },
            T{ name = 'La Theine Cabbage', id = 4366, qty = 5, npc = 'La Theine Cabbage' },
        },
        t_targeting  = 1000,
        t_trading    = 2000,
        t_confirming = 2000,
        t_settling   = 3500,
        t_waiting    = 1000,
    },
    T{
        name  = 'Bastok',
        color = { 0.2,  0.45, 0.85, 1.0 },   -- Bastok Blue
        items = T{
            T{ name = 'Zinc Ore', id = 642, qty = 4, npc = 'Zinc Ore',
               t_confirming = 3000 },
        },
        t_targeting  = 800,
        t_trading    = 1500,
        t_confirming = 3000,
        t_settling   = 3200,
        t_waiting    = 500,
    },
    T{
        name  = 'Windurst',
        color = { 0.9,  0.8,  0.1,  1.0 },   -- Windurst Yellow
        items = T{
            -- Single Enter press to confirm, no second dialog
            T{ name = 'Cornette', id = 17344, qty = 1, npc = 'Cornette',
               confirm_key    = 'RETURN',
               single_confirm = true },
        },
        t_targeting  = 800,
        t_trading    = 1500,
        t_confirming = 2000,   -- wait for trade response before second Enter
        t_settling   = 3000,   -- wait for dialogue to fully clear
        t_waiting    = 500,
    },
};

----------------------------------------------------------------------------------------------------
-- UI State
----------------------------------------------------------------------------------------------------
local ui = {
    is_open  = { true },
    tab      = 1,
    selected = T{ },
};

for i = 1, #LOCATIONS do
    ui.selected[i] = { 0 };
end

-- Base colors (non-city-specific)
local colors = {
    active  = { 0.2,  0.85, 0.4,  1.0 },
    idle    = { 0.65, 0.65, 0.65, 1.0 },
    warn    = { 1.0,  0.85, 0.2,  1.0 },
    error   = { 1.0,  0.35, 0.35, 1.0 },
    dim     = { 0.5,  0.5,  0.5,  1.0 },
    white   = { 1.0,  1.0,  1.0,  1.0 },
    header  = { 1.0,  0.65, 0.26, 1.0 },
};

----------------------------------------------------------------------------------------------------
-- Per-location timing tables (single-element for imgui SliderInt)
----------------------------------------------------------------------------------------------------
local timings = T{ };

for i = 1, #LOCATIONS do
    local loc = LOCATIONS[i];
    timings[i] = {
        t_targeting  = { loc.t_targeting  },
        t_trading    = { loc.t_trading    },
        t_confirming = { loc.t_confirming },
        t_settling   = { loc.t_settling   },
        t_waiting    = { loc.t_waiting    },
    };
end

local function get_timing(loc_idx, item, field)
    if (item[field] ~= nil) then return item[field]; end
    return timings[loc_idx][field][1];
end

----------------------------------------------------------------------------------------------------
-- Trader State Machine
----------------------------------------------------------------------------------------------------
local trader = T{
    enabled        = false,
    loc_idx        = 1,
    item           = nil,

    freq           = ashita.time.qpf(),
    phase_t        = ashita.time.qpc(),

    t_targeting    = 1000,
    t_trading      = 2000,
    t_confirming   = 2000,
    t_settling     = 3500,
    t_waiting      = 1000,

    confirm_key    = 'Y',      -- 'Y' or 'RETURN'
    single_confirm = false,    -- true = skip second key press phase

    phase       = 'idle',
    trades_done = 0,
    status_msg  = 'Ready.',
};

----------------------------------------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------------------------------------
local function cmd(str)
    AshitaCore:GetChatManager():QueueCommand(1, str);
end

local function count_item(item_id)
    local inv   = AshitaCore:GetMemoryManager():GetInventory();
    local total = 0;
    local max   = inv:GetContainerCountMax(0);
    for i = 1, max do
        local slot = inv:GetContainerItem(0, i);
        if (slot ~= nil and slot.Id == item_id) then
            total = total + slot.Count;
        end
    end
    return total;
end

local function has_enough(item)
    return count_item(item.id) >= item.qty;
end

local function stop_trading(reason)
    trader.enabled    = false;
    trader.phase      = 'idle';
    trader.status_msg = reason or 'Stopped.';
    print(chat.header(addon.name):append(chat.message(trader.status_msg)));
end

local function press_confirm(key)
    cmd(('/sendkey %s down'):format(key));
    cmd(('/sendkey %s up'):format(key));
end

local function start_trading(loc_idx, item)
    if (not has_enough(item)) then
        local have = count_item(item.id);
        trader.status_msg = ('Need %d %s, only have %d.'):format(item.qty, item.name, have);
        print(chat.header(addon.name):append(chat.error(trader.status_msg)));
        return;
    end

    trader.loc_idx        = loc_idx;
    trader.item           = item;
    trader.enabled        = true;
    trader.trades_done    = 0;
    trader.phase          = 'targeting';
    trader.phase_t        = ashita.time.qpc();
    trader.status_msg     = 'Running...';
    trader.confirm_key    = item.confirm_key    or 'Y';
    trader.single_confirm = item.single_confirm or false;

    trader.t_targeting  = get_timing(loc_idx, item, 't_targeting');
    trader.t_trading    = get_timing(loc_idx, item, 't_trading');
    trader.t_confirming = get_timing(loc_idx, item, 't_confirming');
    trader.t_settling   = get_timing(loc_idx, item, 't_settling');
    trader.t_waiting    = get_timing(loc_idx, item, 't_waiting');

    local loc = LOCATIONS[loc_idx];
    print(chat.header(addon.name):append(
        chat.message(('[%s] Trading %s x%d per cycle.'):format(loc.name, item.name, item.qty))
    ));

    cmd('/target <stnpc>');
end

----------------------------------------------------------------------------------------------------
-- Frame Update — State Machine
--
-- Standard flow (Y key, two confirms):
--   targeting → trading → confirming → settling → waiting → targeting ...
--
-- Single confirm flow (Enter key, Windurst):
--   targeting → trading → settling → waiting → targeting ...
--   (confirming phase is skipped entirely)
----------------------------------------------------------------------------------------------------
ashita.events.register('d3d_beginscene', 'beginscene_cb', function ()
    if (not trader.enabled) then return; end

    local now     = ashita.time.qpc();
    local elapsed = (now.q - trader.phase_t.q) * 1000.0 / trader.freq.q;

    if (trader.phase == 'targeting') then
        if (elapsed >= trader.t_targeting) then
            if (not has_enough(trader.item)) then
                stop_trading(('Out of %s. Done! (%d trades)'):format(trader.item.name, trader.trades_done));
                return;
            end
            cmd(('/bh tradenpc "%s" %d'):format(trader.item.npc, trader.item.qty));
            trader.phase   = 'trading';
            trader.phase_t = now;
        end

    elseif (trader.phase == 'trading') then
        if (elapsed >= trader.t_trading) then
            -- First confirm press
            press_confirm(trader.confirm_key);
            trader.phase   = 'confirming';
            trader.phase_t = now;
        end

    elseif (trader.phase == 'confirming') then
        if (elapsed >= trader.t_confirming) then
            -- Second confirm press
            press_confirm(trader.confirm_key);
            trader.trades_done = trader.trades_done + 1;
            trader.status_msg  = ('Running... (%d trades done)'):format(trader.trades_done);
            trader.phase   = 'settling';
            trader.phase_t = now;
        end

    elseif (trader.phase == 'settling') then
        if (elapsed >= trader.t_settling) then
            if (not has_enough(trader.item)) then
                stop_trading(('Out of %s! Finished %d trades.'):format(trader.item.name, trader.trades_done));
                return;
            end
            trader.phase   = 'waiting';
            trader.phase_t = now;
        end

    elseif (trader.phase == 'waiting') then
        if (elapsed >= trader.t_waiting) then
            cmd('/target <stnpc>');
            trader.phase   = 'targeting';
            trader.phase_t = now;
        end
    end
end);

----------------------------------------------------------------------------------------------------
-- ImGui Render
----------------------------------------------------------------------------------------------------
ashita.events.register('d3d_present', 'present_cb', function ()
    if (not ui.is_open[1]) then return; end

    imgui.SetNextWindowSize({ 380, 0 }, ImGuiCond_FirstUseEver);
    imgui.SetNextWindowSizeConstraints({ 300, 0 }, { 600, 800 });

    if (imgui.Begin('FameTrader', ui.is_open, ImGuiWindowFlags_None)) then

        -- Header
        imgui.TextColored(colors.header, 'FameTrader');
        imgui.SameLine();
        imgui.TextDisabled('v1.5  |  bellhop required');
        imgui.Separator();
        imgui.Spacing();

        -- Status
        local status_color;
        local msg_l = trader.status_msg:lower();
        if (trader.enabled) then
            status_color = colors.active;
        elseif (msg_l:find('out of') or msg_l:find('need') or msg_l:find('only have')) then
            status_color = colors.warn;
        else
            status_color = colors.idle;
        end
        imgui.Text('Status:');
        imgui.SameLine();
        imgui.TextColored(status_color, trader.status_msg);
        if (trader.enabled) then
            imgui.SameLine();
            imgui.TextDisabled(('[%s]'):format(trader.phase));
        end

        imgui.Spacing();
        imgui.Separator();
        imgui.Spacing();

        ----------------------------------------------------------------
        -- Location tabs with city colors
        ----------------------------------------------------------------
        if (imgui.BeginTabBar('##locations', ImGuiTabBarFlags_None)) then
            for loc_idx = 1, #LOCATIONS do
                local loc           = LOCATIONS[loc_idx];
                local is_active_loc = (trader.enabled and trader.loc_idx == loc_idx);

                -- Solid city color bg like abyproc section headers; white text always readable
                local c   = loc.color;
                local dim = 0.35;  -- inactive tabs at 35% brightness
                local act_bg  = is_active_loc and colors.active or c;
                local idle_bg = { c[1]*dim, c[2]*dim, c[3]*dim, 1.0 };
                local hvr_bg  = { c[1]*(dim+0.1), c[2]*(dim+0.1), c[3]*(dim+0.1), 1.0 };
                local sel_bg  = is_active_loc and { colors.active[1]*0.7, colors.active[2]*0.7, colors.active[3]*0.7, 1.0 } or c;
                imgui.PushStyleColor(ImGuiCol_Tab,        idle_bg);
                imgui.PushStyleColor(ImGuiCol_TabHovered, hvr_bg);
                imgui.PushStyleColor(ImGuiCol_TabActive,  hvr_bg);
                imgui.PushStyleColor(ImGuiCol_Text,       { 1.0, 1.0, 1.0, 1.0 });
                local tab_open = imgui.BeginTabItem(loc.name .. '##tab' .. loc_idx);
                imgui.PopStyleColor(4);

                if (tab_open) then
                    ui.tab = loc_idx;
                    imgui.Spacing();

                    -- Location name in city color as section header
                    imgui.TextColored(loc.color, loc.name);
                    imgui.SameLine();
                    imgui.TextDisabled('— Item to Trade:');
                    imgui.Spacing();

                    local items = loc.items;
                    for item_idx = 0, #items - 1 do
                        local item = items[item_idx + 1];
                        local have = count_item(item.id);
                        local can  = math.floor(have / item.qty);
                        local is_trading_this = (trader.enabled and trader.loc_idx == loc_idx
                                                 and trader.item == item);

                        if (imgui.RadioButton(('##r%d_%d'):format(loc_idx, item_idx), ui.selected[loc_idx], item_idx)) then
                            if (not trader.enabled) then
                                ui.selected[loc_idx][1] = item_idx;
                            end
                        end
                        imgui.SameLine();

                        local name_col  = is_trading_this and colors.active
                                          or (have >= item.qty) and colors.white
                                          or colors.dim;
                        local stock_col = (have >= item.qty) and colors.active or colors.error;

                        imgui.TextColored(name_col, item.name);
                        imgui.SameLine();
                        imgui.TextColored(stock_col, ('[%d stk | x%d per | ~%d trades]'):format(have, item.qty, can));



                        imgui.Spacing();
                    end

                    imgui.Separator();
                    imgui.Spacing();

                    -- Timing panel
                    if (imgui.TreeNode('Timing##' .. loc_idx)) then
                        imgui.Spacing();
                        imgui.TextColored(colors.dim, 'Location defaults (ms). Per-item overrides shown inline.');
                        imgui.Spacing();

                        local t = timings[loc_idx];
                        imgui.SliderInt('Target wait##ta'..loc_idx,  t.t_targeting,  200,  3000);
                        imgui.ShowHelp('After /target, before issuing the trade.');
                        imgui.SliderInt('Trade wait##tr'..loc_idx,   t.t_trading,    500,  5000);
                        imgui.ShowHelp('Trade window open, before first confirm key.');
                        imgui.SliderInt('Confirm wait##co'..loc_idx, t.t_confirming, 200,  5000);
                        imgui.ShowHelp('Confirm dialog, before second key press.\n(Skipped for single-confirm items like Cornette)');
                        imgui.SliderInt('Settle wait##se'..loc_idx,  t.t_settling,   500,  8000);
                        imgui.ShowHelp('Wait for NPC text/reward to clear.\nIncrease if you see "cannot use that command".');
                        imgui.SliderInt('Cycle gap##cy'..loc_idx,    t.t_waiting,    0,    3000);
                        imgui.ShowHelp('Brief pause before retargeting.');

                        imgui.Spacing();
                        imgui.TreePop();
                    end

                    imgui.Spacing();

                    -- Start / Stop buttons
                    if (trader.enabled and trader.loc_idx == loc_idx) then
                        imgui.BeginDisabled();
                        imgui.Button('Start Trading');
                        imgui.EndDisabled();
                        imgui.SameLine();
                        imgui.PushStyleColor(ImGuiCol_Button,        { 0.65, 0.12, 0.12, 1.0 });
                        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.85, 0.18, 0.18, 1.0 });
                        imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.45, 0.08, 0.08, 1.0 });
                        if (imgui.Button('Stop')) then
                            stop_trading('Stopped by user.');
                        end
                        imgui.PopStyleColor(3);
                    elseif (trader.enabled and trader.loc_idx ~= loc_idx) then
                        imgui.BeginDisabled();
                        imgui.Button('Start Trading');
                        imgui.SameLine();
                        imgui.Button('Stop');
                        imgui.EndDisabled();
                        imgui.SameLine();
                        imgui.TextColored(colors.warn, ('(trading in %s)'):format(LOCATIONS[trader.loc_idx].name));
                    else
                        imgui.PushStyleColor(ImGuiCol_Button,        { 0.15, 0.5,  0.2,  1.0 });
                        imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.2,  0.7,  0.28, 1.0 });
                        imgui.PushStyleColor(ImGuiCol_ButtonActive,  { 0.1,  0.35, 0.15, 1.0 });
                        if (imgui.Button('Start Trading')) then
                            local sel_item = items[ui.selected[loc_idx][1] + 1];
                            if (sel_item ~= nil) then
                                start_trading(loc_idx, sel_item);
                            end
                        end
                        imgui.PopStyleColor(3);
                        imgui.SameLine();
                        imgui.BeginDisabled();
                        imgui.Button('Stop');
                        imgui.EndDisabled();
                    end

                    -- Session counter
                    if (trader.enabled and trader.loc_idx == loc_idx and trader.trades_done > 0) then
                        imgui.Spacing();
                        imgui.Separator();
                        imgui.TextColored(colors.dim, ('Session trades: %d'):format(trader.trades_done));
                    end

                    imgui.Spacing();
                    imgui.EndTabItem();
                end
            end
            imgui.EndTabBar();
        end
    end
    imgui.End();
end);

----------------------------------------------------------------------------------------------------
-- Command Handler
----------------------------------------------------------------------------------------------------
ashita.events.register('command', 'command_cb', function (e)
    local args = e.command:args();
    if (#args == 0 or not args[1]:any('/fametrader', '/at')) then
        return;
    end

    e.blocked = true;

    if (#args == 1) then
        ui.is_open[1] = not ui.is_open[1];
        return;
    end

    local sub = args[2]:lower();

    if (sub == 'show') then
        ui.is_open[1] = true;
    elseif (sub == 'hide') then
        ui.is_open[1] = false;
    elseif (sub == 'stop') then
        stop_trading('Stopped by command.');
    elseif (sub == 'help') then
        print(chat.header(addon.name):append(chat.message('Commands:')));
        print(chat.header(addon.name):append(chat.message('  /fametrader        - Toggle UI')));
        print(chat.header(addon.name):append(chat.message('  /fametrader show   - Show UI')));
        print(chat.header(addon.name):append(chat.message('  /fametrader hide   - Hide UI')));
        print(chat.header(addon.name):append(chat.message('  /fametrader stop   - Stop trading')));
    else
        print(chat.header(addon.name):append(chat.error(('Unknown: %s'):format(sub))));
    end
end);

----------------------------------------------------------------------------------------------------
-- Cleanup
----------------------------------------------------------------------------------------------------
ashita.events.register('unload', 'unload_cb', function ()
    trader.enabled = false;
end);
