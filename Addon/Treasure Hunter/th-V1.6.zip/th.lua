-- TH.lua for Ashita v4
addon.name      = 'TH';
addon.author    = 'Oneword - Ninja AI';
addon.version   = '1.6';
addon.desc      = 'Tracks Treasure Hunter level from chat messages with ImGui configuration';

require('common');
local settings = require('settings');
local imgui = require('imgui');
local ffi = require('ffi');

-- FFI definitions for accessing target information directly
ffi.cdef[[
    typedef struct {
        uint32_t ServerId;
        uint32_t TargetIndex;
        uint16_t Unknown0000;
        uint16_t Unknown0001;
        float X;
        float Z;
        float Y;
        float Unknown0002;
        uint8_t Name[24];
    } __attribute__((packed)) entity_t;
]]

-- Default configuration
local default_config = T{
    position = T{ x = 100, y = 100 },
    current_th = 0,
    current_target = '',
    visible = true,
    colors = T{
        text = 0xFFFFFFFF,       -- White text
        background = 0xE0000066, -- Semi-transparent dark blue
        highlight = 0xFFFFAA00   -- Orange/gold for TH level
    },
    font = T{
        family = 'Arial',
        size = 11
    },
    config_visible = false
};

local th_tracker = T{
    settings = settings.load(default_config),
    last_check_time = 0,
    check_interval = 1.0, -- Check target every second
    last_position = T{ x = 0, y = 0 },
};

-- Available font families
local font_families = T{
    'Arial',
    'Consolas',
    'Courier New',
    'Georgia',
    'Tahoma',
    'Times New Roman',
    'Trebuchet MS',
    'Verdana'
};

-- Function to get current target name
local function get_target_name()
    local target = AshitaCore:GetMemoryManager():GetTarget();
    if (target == nil) then
        return nil;
    end

    local entity_id = target:GetTargetIndex(0);
    if (entity_id == 0) then
        return nil;
    end

    local entity = AshitaCore:GetMemoryManager():GetEntity();
    if (entity == nil) then
        return nil;
    end

    local ent = entity:GetRawEntity(entity_id);
    if (ent == nil) then
        return nil;
    end

    local name = ffi.string(ent.Name);
    if (name == nil or name == '') then
        return nil;
    end

    return name;
end

-- Initialize the addon
ashita.events.register('load', 'th_load', function()
    -- Create the font object
    th_tracker.font = AshitaCore:GetFontManager():Create('__th_font');
    th_tracker.font:SetPositionX(th_tracker.settings.position.x);
    th_tracker.font:SetPositionY(th_tracker.settings.position.y);
    th_tracker.font:SetColor(th_tracker.settings.colors.text);
    th_tracker.font:SetFontFamily(th_tracker.settings.font.family);
    th_tracker.font:SetFontHeight(th_tracker.settings.font.size);
    th_tracker.font:GetBackground():SetVisible(true);
    th_tracker.font:GetBackground():SetColor(th_tracker.settings.colors.background);
    th_tracker.font:SetVisible(th_tracker.settings.visible);
    
    -- Create a separate font for the TH level (highlighted)
    th_tracker.th_level = AshitaCore:GetFontManager():Create('__th_level_font');
    th_tracker.th_level:SetPositionX(th_tracker.settings.position.x + 35); -- Position will be adjusted in present
    th_tracker.th_level:SetPositionY(th_tracker.settings.position.y);
    th_tracker.th_level:SetColor(th_tracker.settings.colors.highlight);
    th_tracker.th_level:SetFontFamily(th_tracker.settings.font.family);
    th_tracker.th_level:SetFontHeight(th_tracker.settings.font.size);
    th_tracker.th_level:GetBackground():SetVisible(false);
    th_tracker.th_level:SetVisible(th_tracker.settings.visible);
    
    -- Store initial position
    th_tracker.last_position.x = th_tracker.settings.position.x;
    th_tracker.last_position.y = th_tracker.settings.position.y;
    
    -- Check if player is THF and set initial TH level
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    if player and player:GetMainJob() == 6 then -- 6 is the job ID for Thief
        th_tracker.settings.current_th = 8;
    end
end);

-- Process incoming chat messages
ashita.events.register('text_in', 'th_text_in', function(e)
    -- Pattern to match TH messages like: "12:48:17 Additional effect: Treasure Hunter effectiveness against the Hydra Thief increases to 9."
    local pattern1 = "Additional effect: Treasure Hunter effectiveness against the ([%w%s]+) increases to (%d+)";
    local target1, th_level1 = string.match(e.message, pattern1);
    
    -- Alternative pattern without "the"
    local pattern2 = "Additional effect: Treasure Hunter effectiveness against ([%w%s]+) increases to (%d+)";
    local target2, th_level2 = string.match(e.message, pattern2);
    
    if (target1 and th_level1) or (target2 and th_level2) then
        local target = target1 or target2;
        local th_level = tonumber(th_level1 or th_level2);
        
        th_tracker.settings.current_target = target;
        th_tracker.settings.current_th = th_level;
        
        -- Save the settings
        settings.save();
    end
    
    -- Add pattern to detect when you engage a target
    local engage_pattern = "You engage ([%w%s]+)%.";
    local engaged_target = string.match(e.message, engage_pattern);
    if engaged_target then
        th_tracker.settings.current_target = engaged_target;
        -- If player is THF, set initial TH level
        local player = AshitaCore:GetMemoryManager():GetPlayer();
        if player and player:GetMainJob() == 6 then -- 6 is THF
            th_tracker.settings.current_th = 8;
        end
        settings.save();
    end
    
    -- Check for messages that might indicate target death or reset
    if string.match(e.message, "defeats the ([%w%s]+)%.") or 
       string.match(e.message, "You gain (%d+) experience points%.") then
        -- Check if we had a target and reset
        if th_tracker.settings.current_target ~= '' then
            th_tracker.settings.current_th = 0;
            th_tracker.settings.current_target = '';
            settings.save();
        end
    end
    
    return false;
end);

-- Helper function to convert color from 0xAARRGGBB to ImGui format {r, g, b, a}
local function color_to_imgui(color)
    local a = bit.band(bit.rshift(color, 24), 0xFF) / 255;
    local r = bit.band(bit.rshift(color, 16), 0xFF) / 255;
    local g = bit.band(bit.rshift(color, 8), 0xFF) / 255;
    local b = bit.band(color, 0xFF) / 255;
    return { r, g, b, a };
end

-- Helper function to convert color from ImGui format {r, g, b, a} to 0xAARRGGBB
local function imgui_to_color(color_array)
    local a = math.floor(color_array[4] * 255);
    local r = math.floor(color_array[1] * 255);
    local g = math.floor(color_array[2] * 255);
    local b = math.floor(color_array[3] * 255);
    return bit.lshift(a, 24) + bit.lshift(r, 16) + bit.lshift(g, 8) + b;
end

-- Function to recreate the TH level font with the current settings
local function recreate_th_level_font()
    if th_tracker.th_level ~= nil then
        AshitaCore:GetFontManager():Delete('__th_level_font');
    end
    
    th_tracker.th_level = AshitaCore:GetFontManager():Create('__th_level_font');
    th_tracker.th_level:SetPositionX(th_tracker.settings.position.x + 35); -- Position will be adjusted in present
    th_tracker.th_level:SetPositionY(th_tracker.settings.position.y);
    th_tracker.th_level:SetColor(th_tracker.settings.colors.highlight);
    th_tracker.th_level:SetFontFamily(th_tracker.settings.font.family);
    th_tracker.th_level:SetFontHeight(th_tracker.settings.font.size);
    th_tracker.th_level:GetBackground():SetVisible(false);
    th_tracker.th_level:SetVisible(th_tracker.settings.visible);
end

-- Update the font display
ashita.events.register('d3d_present', 'th_present', function()
    -- Check for current target periodically
    local now = os.clock();
    if now - th_tracker.last_check_time > th_tracker.check_interval then
        th_tracker.last_check_time = now;
        
        -- Get current target
        local target_name = get_target_name();
        if target_name and target_name ~= '' and th_tracker.settings.current_target == '' then
            th_tracker.settings.current_target = target_name;
            
            -- If player is THF, set initial TH level when targeting
            local player = AshitaCore:GetMemoryManager():GetPlayer();
            if player and player:GetMainJob() == 6 then -- 6 is THF
                th_tracker.settings.current_th = 8;
            end
        end
    end
    
    -- Update the main display
    if th_tracker.font and th_tracker.th_level then
        local target_text = th_tracker.settings.current_target ~= '' and th_tracker.settings.current_target or 'None';
        
        -- Set the main text with balanced spacing
        th_tracker.font:SetText(string.format('TH:       |  Target: %s', target_text));
        
        -- Set the TH level with highlight color
        th_tracker.th_level:SetText(string.format('%d', th_tracker.settings.current_th));
        
        -- Position the TH level text - adjust based on font size
        local pos_x = th_tracker.font:GetPositionX();
        local pos_y = th_tracker.font:GetPositionY();
        
        -- Calculate offset based on font size for balanced spacing
        local offset = 35; -- Increased base offset
        if th_tracker.settings.font.size > 12 then
            offset = 40 + (th_tracker.settings.font.size - 12) * 2.5;
        end
        
        th_tracker.th_level:SetPositionX(pos_x + offset);
        th_tracker.th_level:SetPositionY(pos_y);
        
        -- Update position if the main font was moved
        if pos_x ~= th_tracker.settings.position.x or pos_y ~= th_tracker.settings.position.y then
            th_tracker.settings.position.x = pos_x;
            th_tracker.settings.position.y = pos_y;
            settings.save();
            
            -- Check if position has changed significantly from last saved position
            if math.abs(pos_x - th_tracker.last_position.x) > 5 or math.abs(pos_y - th_tracker.last_position.y) > 5 then
                -- Position changed significantly, refresh the font to fix color
                recreate_th_level_font();
                th_tracker.last_position.x = pos_x;
                th_tracker.last_position.y = pos_y;
            end
        end
    end
    
    -- Draw the configuration window if enabled
    if th_tracker.settings.config_visible then
        -- Begin the configuration window
        imgui.SetNextWindowSize({ 400, 250 }, ImGuiCond_FirstUseEver);
        
        -- This is the key change for the X button to work properly
        local is_open = { th_tracker.settings.config_visible };
        if imgui.Begin('Treasure Hunter Configuration', is_open) then
            -- Visibility toggle
            local visible = th_tracker.settings.visible;
            if imgui.Checkbox('Display TH Tracker', { visible }) then
                th_tracker.settings.visible = not visible;
                th_tracker.font:SetVisible(not visible);
                th_tracker.th_level:SetVisible(not visible);
                settings.save();
            end
            
            imgui.Separator();
            
            -- Font settings
            if imgui.CollapsingHeader('Font Settings') then
                -- Font family dropdown
                if imgui.BeginCombo('Font Family', th_tracker.settings.font.family) then
                    for _, family in ipairs(font_families) do
                        if imgui.Selectable(family, family == th_tracker.settings.font.family) then
                            th_tracker.settings.font.family = family;
                            th_tracker.font:SetFontFamily(family);
                            th_tracker.th_level:SetFontFamily(family);
                            settings.save();
                        end
                    end
                    imgui.EndCombo();
                end
                
                -- Font size buttons instead of slider
                imgui.Text('Font Size: ' .. th_tracker.settings.font.size);
                
                imgui.SameLine();
                
                if imgui.Button('-') then
                    if th_tracker.settings.font.size > 8 then
                        th_tracker.settings.font.size = th_tracker.settings.font.size - 1;
                        th_tracker.font:SetFontHeight(th_tracker.settings.font.size);
                        th_tracker.th_level:SetFontHeight(th_tracker.settings.font.size);
                        settings.save();
                    end
                end
                
                imgui.SameLine();
                
                if imgui.Button('+') then
                    if th_tracker.settings.font.size < 20 then
                        th_tracker.settings.font.size = th_tracker.settings.font.size + 1;
                        th_tracker.font:SetFontHeight(th_tracker.settings.font.size);
                        th_tracker.th_level:SetFontHeight(th_tracker.settings.font.size);
                        settings.save();
                    end
                end
            end
            
            imgui.Separator();
            
            -- Color settings
            if imgui.CollapsingHeader('Color Settings') then
                -- Text color
                local text_color = color_to_imgui(th_tracker.settings.colors.text);
                if imgui.ColorEdit4('Text Color', text_color) then
                    th_tracker.settings.colors.text = imgui_to_color(text_color);
                    th_tracker.font:SetColor(th_tracker.settings.colors.text);
                    settings.save();
                end
                
                -- Highlight color
                local highlight_color = color_to_imgui(th_tracker.settings.colors.highlight);
                if imgui.ColorEdit4('TH Level Color', highlight_color) then
                    th_tracker.settings.colors.highlight = imgui_to_color(highlight_color);
                    th_tracker.th_level:SetColor(th_tracker.settings.colors.highlight);
                    settings.save();
                end
                
                -- Background color
                local bg_color = color_to_imgui(th_tracker.settings.colors.background);
                if imgui.ColorEdit4('Background Color', bg_color) then
                    th_tracker.settings.colors.background = imgui_to_color(bg_color);
                    th_tracker.font:GetBackground():SetColor(th_tracker.settings.colors.background);
                    settings.save();
                end
            end
            
            imgui.Separator();
            
            -- Save and close buttons
            if imgui.Button('Close Configuration') then
                th_tracker.settings.config_visible = false;
                settings.save();
                -- Refresh the font after configuration changes
                recreate_th_level_font();
            end
            
            imgui.SameLine();
            
            if imgui.Button('Reset to Defaults') then
                -- Reset to defaults but keep position
                local pos_x = th_tracker.settings.position.x;
                local pos_y = th_tracker.settings.position.y;
                th_tracker.settings = settings.load(default_config, true);
                th_tracker.settings.position.x = pos_x;
                th_tracker.settings.position.y = pos_y;
                
                -- Update all visual elements
                th_tracker.font:SetColor(th_tracker.settings.colors.text);
                th_tracker.font:SetFontFamily(th_tracker.settings.font.family);
                th_tracker.font:SetFontHeight(th_tracker.settings.font.size);
                th_tracker.font:GetBackground():SetColor(th_tracker.settings.colors.background);
                th_tracker.font:SetVisible(th_tracker.settings.visible);
                
                -- Recreate the TH level font with new settings
                recreate_th_level_font();
                
                settings.save();
            end
            
            -- Add a manual refresh button
            imgui.Separator();
            if imgui.Button('Refresh Display') then
                recreate_th_level_font();
            end
            imgui.SameLine();
            imgui.Text('(Use if color fades)');
        end
        imgui.End();
        
        -- Check if the window was closed via the X button
        if not is_open[1] then
            th_tracker.settings.config_visible = false;
            settings.save();
            -- Refresh the font after closing configuration
            recreate_th_level_font();
        end
    end
end);

-- Handle addon unloading
ashita.events.register('unload', 'th_unload', function()
    -- Save settings
    settings.save();
    
    -- Clean up font objects
    if th_tracker.font ~= nil then
        AshitaCore:GetFontManager():Delete('__th_font');
    end
    
    if th_tracker.th_level ~= nil then
        AshitaCore:GetFontManager():Delete('__th_level_font');
    end
end);

-- Command handler for configuration
ashita.events.register('command', 'th_command', function(e)
    -- Parse the command
    local args = e.command:args();
    if (#args == 0 or args[1] ~= '/th') then
        return false;
    end

    -- Handle the command
    if (#args == 1) then
        -- Toggle configuration window
        th_tracker.settings.config_visible = not th_tracker.settings.config_visible;
        settings.save();
        -- Refresh the font when opening/closing config
        recreate_th_level_font();
    elseif (args[2] == 'reset') then
        -- Reset TH level
        th_tracker.settings.current_th = 0;
        th_tracker.settings.current_target = '';
        settings.save();
    elseif (args[2] == 'set' and args[3]) then
        -- Manually set TH level
        local level = tonumber(args[3]);
        if level then
            th_tracker.settings.current_th = level;
            settings.save();
        end
    elseif (args[2] == 'toggle') then
        -- Toggle visibility
        th_tracker.settings.visible = not th_tracker.settings.visible;
        if th_tracker.font then
            th_tracker.font:SetVisible(th_tracker.settings.visible);
        end
        if th_tracker.th_level then
            th_tracker.th_level:SetVisible(th_tracker.settings.visible);
        end
        settings.save();
    elseif (args[2] == 'refresh') then
        -- Manual refresh command
        recreate_th_level_font();
    end

    return true;
end);
