addon.name    = 'trialtracker'
addon.author  = 'Oneword - Ninja Ai'
addon.version = '1.1'
addon.desc    = 'Track Magian Trial objectives'

require('common')
local bit = require('bit')
local imgui = require('imgui')
local settings = require('settings')

-- Weapon categories and their trials
local weapon_categories = {

	['Sword - Machaera'] = {
        trials = {
            ['1241'] = 'Burning Blade 100 times on any experience-yielding monsters',
            ['1242'] = 'Shining Blade 200 times on any experience-yielding monsters.',
            ['1243'] = 'Circle Blade 300 times on experience-yielding Birds.',
            ['1244'] = 'Savage Blade 500 times on experience-yielding Beasts.',
            ['1961'] = 'Finishing blow with Savage Blade 300 times on experience-yielding Plantoids.',
            ['2361'] = 'Weapon Skills dealing FourHundred + damage 500 times on experience-yielding Demons.',
            ['2794'] = 'Weapon Skills dealing 401+ damage 500 times on experience-yielding Birds',
            ['3257'] = 'Weapon Skills dealing 401+ damage 500 times on experience-yielding Vermin.',
            ['Done'] = 'Finished Weapon Thibron',
        }
	},	
		
	['Gun - Anarchy'] = {
        trials = {
            ['1783'] = 'Use Hot Shot x100 on any experience point granting enemy. The weaponskill must hit order to count',
            ['1784'] = 'Use Split Shot x200 on any experience point granting enemy.',
            ['1785'] = 'Use Sniper Shot x300 on any experience point granting enemy of the Lizard family.',
            ['1786'] = 'Use Detonator x500 on any experience point granting enemy of the Vermin family.',
            ['2247'] = 'Use Detonator x300 to deliver the killing blow on any experience point granting enemy of the Beast family.',
            ['2658'] = 'Use any Marksmanship WS that deals FourHundred + damage 500 times on any experience point granting enemy of the Undead family.',
            ['3091'] = 'Use any Marksmanship weaponskill that deals more than 400 damage x500 on any experience point granting enemy of the Lizard family.',
            ['3554'] = 'Use any Marksmanship weaponskill that deals more than 400 damage x500 on any experience point granting enemy of the Plantoid family.',
            ['Done'] = 'Finished Weapon Ataktos',
        }
		
	},	
	
	['Sword - Excalibur'] = {
        trials = {
            ['1012'] = 'Knights of Round 200 times on: Aquans',
            ['1013'] = 'Knights of Round killing blow on: 200 Undead',
            ['1832'] = 'Knights of Round killing blow on: 300 Lizards',
            ['1833'] = 'Knights of Round killing blow on: 300 Dragons',
            ['2256'] = 'Knights of Round killing blow on: 400 Birds',
            ['2667'] = 'Defeat: 5 Goublefaupe (Trade Despot\'s Fortune to ??? at I-7, drops from Hydra Paladin/Red Mage/Warriors)',
            ['3100'] = 'Defeat Notorious Monsters: 10 Animated Longsword',
            ['3563'] = 'Collect: 5 Umbral Marrow',
            ['3702'] = 'Trade: 300 Plutons to Oboro',
        }
	},	
	
    ['Great Axe - Bravura'] = {
        trials = {
            ['1033'] = 'Metatron Torment 200 times on: Lizards',
            ['1034'] = 'Metatron Torment killing blow on: 200 Plantoids',
            ['1846'] = 'Metatron Torment killing blow on: 300 Undead',
            ['1847'] = 'Metatron Torment killing blow on: 300 Plantoids',
            ['2263'] = 'Metatron Torment killing blow on: 400 Dragons',
            ['2674'] = 'Defeat Notorious Monster: 5 Gobblelaupe',
            ['3107'] = 'Defeat Notorious Monsters: 10 Animated Great Axe',
            ['3570'] = 'Collect: 5 Umbral Marrow',
            ['3708'] = 'Trade: 300 Plutons to Oboro',
        }		
    },
	
    ['Shield - Aegis'] = {
        trials = {
            ['4401'] = 'Defeat: 3 Gu\'Dha Effigy (Zone boss in Dynamis - Bastok)',
            ['4402'] = 'Defeat: 3 Overlord\'s Tombstone (Zone boss in Dynamis - San d\'Oria)',
            ['4403'] = 'Defeat: 5 Goublefaupe (Trade Despot\'s Fortune to ??? at I-7, drops from Hydra Paladin/Red Mage/Warriors)',
            ['4448'] = 'Defeat: 10 Animated Shield H-9 Use Supernal Goad to Pop from Satelite Shields)',
            ['4453'] = 'Obtain: 5 Umbral Marrow (Drops from Arch Dynamis Lord in Dynamis - Xarcabard or purchase from Gorpa-Masorpa in Mhaura G-9)',
        }
    },
}

-- Create a combined trial descriptions table for the parser
local trial_descriptions = {}
for _, category in pairs(weapon_categories) do
    for trial_num, desc in pairs(category.trials) do
        trial_descriptions[trial_num] = desc
    end
end

local defaultConfig = T{
    isVisible = { true },
    trials = T{},
}

local config = settings.load(defaultConfig)

-- Function to manually add a trial
local function AddTrial(trial_num)
    if trial_descriptions[trial_num] then
        local trial_name = "Trial " .. trial_num
        if not config.trials[trial_name] then
            config.trials[trial_name] = {
                Name = trial_name,
                Current = 0,
                Description = trial_descriptions[trial_num]
            }
            settings.save()
            print(string.format('[TrialTracker] Added %s: %s', trial_name, trial_descriptions[trial_num]))
        end
    end
end

-- Function to parse chat messages for trial information
local function ParseTrialMessage(message)
    if not message then return end
    
    local status, result = pcall(function()
        -- Check for completion message first
        local completed_trial = message:match("You have completed Trial (%d+)")
        if completed_trial then
            local trial_name = "Trial " .. completed_trial
            if config.trials[trial_name] then
                local trial = config.trials[trial_name]
                local max = tonumber(trial.Description:match("(%d+)") or "300")
                trial.Current = max  -- Set to maximum when complete
                settings.save()
            end
            return
        end

        -- Handle regular progress updates
        local trial_num, remaining = message:match("Trial (%d+): (%d+) objectives? remain")
        if trial_num and remaining then
            local trial_name = "Trial " .. trial_num
            if not config.trials[trial_name] then
                config.trials[trial_name] = {
                    Name = trial_name,
                    Current = 0,
                    Description = trial_descriptions[trial_num] or "Unknown Trial Type"
                }
            end
            
            local trial = config.trials[trial_name]
            local max = 300
            if trial.Description then
                max = tonumber(trial.Description:match("(%d+)") or "300")
            end
            
            -- If remaining is 0, set to max, otherwise calculate normally
            if tonumber(remaining) == 0 then
                trial.Current = max
            else
                trial.Current = max - tonumber(remaining)
            end
            settings.save()
        end
    end)
    
    if not status then
        print('[TrialTracker] Error parsing message: ' .. tostring(result))
    end
end

settings.register('settings', 'settings_update', function (s)
    if s then config = s end
end)

ashita.events.register('load', 'load', function()
    config = settings.load(defaultConfig)
end)

ashita.events.register('unload', 'unload', function()
    settings.save()
end)

-- GUI Display with categorized dropdown
ashita.events.register('d3d_present', 'd3d_present', function()
    if not config.isVisible[1] then return end

    -- Push blue style colors for just this window
    imgui.PushStyleColor(ImGuiCol_TitleBg, { 0.0, 0.0, 0.6, 1.0 })
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, { 0.0, 0.0, 0.8, 1.0 })
    imgui.PushStyleColor(ImGuiCol_TitleBgCollapsed, { 0.0, 0.0, 0.4, 1.0 })
    imgui.PushStyleColor(ImGuiCol_Button, { 0.0, 0.0, 0.6, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.0, 0.0, 0.8, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ButtonActive, { 0.0, 0.0, 1.0, 1.0 })

    if imgui.Begin('Trial Tracker', config.isVisible) then
        -- Add Clear Button with explicit width
        if imgui.Button('Clear Trials', { 100, 20 }) then
            config.trials = T{}
            settings.save()
            print('[TrialTracker] Cleared all tracked trials.')
        end
        
        imgui.SameLine() -- Put dropdown on same line as clear button
        
        -- Add Trial Dropdown with categories
        local combo_label = 'Add Trial'
        if imgui.BeginCombo('##TrialSelect', combo_label, ImGuiComboFlags_None) then
            for category_name, category_data in pairs(weapon_categories) do
                if imgui.BeginMenu(category_name) then
                    -- Sort trial numbers for this category
                    local sorted_trials = {}
                    for trial_num in pairs(category_data.trials) do
                        table.insert(sorted_trials, trial_num)
                    end
                    table.sort(sorted_trials)
                    
                    -- Display trials in this category
                    for _, trial_num in ipairs(sorted_trials) do
                        local label = string.format('Trial %s - %s', trial_num, category_data.trials[trial_num])
                        if imgui.Selectable(label, false) then
                            AddTrial(trial_num)
                        end
                    end
                    imgui.EndMenu()
                end
            end
            imgui.EndCombo()
        end
        
        imgui.Separator()
        
        -- Display current trials
        if next(config.trials) then
            for trial_name, trial_data in pairs(config.trials) do
                if trial_data then
                    local max = 300
                    if trial_data.Description then
                        max = tonumber(trial_data.Description:match("(%d+)") or "300")
                    end
                    
                    imgui.Text(string.format('%s: %d/%d', 
                        trial_data.Name or trial_name,
                        trial_data.Current or 0,
                        max))
                        
                    if trial_data.Description then
                        imgui.Text(trial_data.Description)
                    end
                    imgui.Separator()
                end
            end
        else
            imgui.Text('No active trials')
        end
        imgui.End()
    end

    -- Pop the style colors after the window is done
    imgui.PopStyleColor(6)
end)

ashita.events.register('text_in', 'text_in', function(e)
    if e and e.message and e.message:find("Trial") then
        ParseTrialMessage(e.message)
    end
end)

ashita.events.register('command', 'command', function(e)
    if not e or not e.command then return end
    
    local args = e.command:args()
    if args[1] == '/trialtracker' then
        config.isVisible[1] = not config.isVisible[1]
    elseif args[1] == '/trial' and args[2] == 'clear' then
        config.trials = T{}
        settings.save()
        print('[TrialTracker] Cleared all tracked trials.')
    elseif args[1] == '/trial' and args[2] == 'add' and args[3] then
        AddTrial(args[3])
    end
end)
