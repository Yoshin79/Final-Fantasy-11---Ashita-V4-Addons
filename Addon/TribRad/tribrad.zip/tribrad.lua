addon.name    = 'Tribrad'
addon.author  = 'Oneword With Ninja AI'
addon.version = '1.6'
addon.desc    = '[Tribs] [Rads] Icons in (Escha only).'

require('common')
local imgui = require('imgui')

-- IDs
local tribulens_id = 2894
local radialens_id = 3031

-- Escha Zones
local allowed_zones = {
    [288] = true, -- Escha - Zi'Tah
    [289] = true, -- Escha - Ru'Aun
    [291] = true, -- Reisenjima
}

-- Settings
local settings = {
    pos_x = 800,
    pos_y = 100,
    dragging = false,
}

-- Colors
local color_have = { 0.0, 1.0, 0.0, 1.0 }    -- Green (you have the KI)
local color_missing = { 1.0, 0.0, 0.0, 1.0 } -- Red (missing the KI)

-- Check if in Escha
local function is_in_escha_zone()
    local zone_id = AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0)
    return allowed_zones[zone_id] or false
end

ashita.events.register('d3d_present', 'tribrad_present_cb', function()

    if not is_in_escha_zone() then
        return
    end

    if not AshitaCore:GetMemoryManager():GetParty():GetMemberIsActive(0) then
        return
    end

    local player = AshitaCore:GetMemoryManager():GetPlayer()
    local has_tribulens = player:HasKeyItem(tribulens_id)
    local has_radialens = player:HasKeyItem(radialens_id)

    local draw = imgui.GetBackgroundDrawList()
    local io = imgui.GetIO()

    -- Dragging logic
    if imgui.IsMouseDown(0) then
        local mx, my = io.MousePos.x, io.MousePos.y
        if settings.dragging then
            settings.pos_x = mx - settings.drag_offset_x
            settings.pos_y = my - settings.drag_offset_y
        elseif (mx >= settings.pos_x and mx <= settings.pos_x + 200) and (my >= settings.pos_y and my <= settings.pos_y + 20) then
            settings.dragging = true
            settings.drag_offset_x = mx - settings.pos_x
            settings.drag_offset_y = my - settings.pos_y
        end
    else
        settings.dragging = false
    end

    -- Draw [Tribs]
    draw:AddText(
        { settings.pos_x, settings.pos_y },
        imgui.ColorConvertFloat4ToU32(has_tribulens and color_have or color_missing),
        "[ Tribs ]"
    )

    -- Draw [Rads] next to it
    draw:AddText(
        { settings.pos_x + 90, settings.pos_y },
        imgui.ColorConvertFloat4ToU32(has_radialens and color_have or color_missing),
        "[ Rads ]"
    )

end)
