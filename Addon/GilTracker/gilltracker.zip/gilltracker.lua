addon.name      = 'giltracker';
addon.author    = 'Oneword With Ninja Ai';
addon.version   = '1.0';
addon.desc      = 'Tracks gil and shows changes since last reset';

require('common');
local chat = require('chat');
local imgui = require('imgui');

-- Settings
local giltracker = T{
    visible = true,
    opacity = 1.0,
    starting_gil = 0,
    current_gil = 0,
    is_open = T{ true },
    initialized = false,
};

--[[
* Gets current gil amount
]]--
local function get_current_gil()
    local inventory = AshitaCore:GetMemoryManager():GetInventory();
    if inventory then
        local item = inventory:GetContainerItem(0, 0);
        if item then
            return item.Count;
        end
    end
    return 0;
end

--[[
* Formats a number with commas
]]--
local function format_number(num)
    local formatted = tostring(num);
    local k;
    while true do
        formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2');
        if k == 0 then break end
    end
    return formatted;
end

--[[
* Gets color based on gil change
]]--
local function get_change_color(change)
    if change > 0 then
        return { 0.0, 1.0, 0.0, 1.0 }; -- Green
    elseif change < 0 then
        return { 1.0, 0.0, 0.0, 1.0 }; -- Red
    else
        return { 1.0, 1.0, 1.0, 1.0 }; -- White
    end
end

--[[
* event: load
* desc : Event called when the addon is being loaded.
]]--
ashita.events.register('load', 'giltracker_load', function()
    print(chat.header(addon.name):append(chat.message('Loaded! Use /giltracker or /gt for commands.')));
end);

--[[
* event: d3d_present
* desc : Event called when the Direct3D device is presenting a scene.
]]--
ashita.events.register('d3d_present', 'giltracker_present', function()
    -- Initialize gil on first valid read
    if not giltracker.initialized then
        local party = AshitaCore:GetMemoryManager():GetParty();
        if party and party:GetMemberIsActive(0) == 1 then
            local gil = get_current_gil();
            if gil > 0 then
                giltracker.current_gil = gil;
                giltracker.starting_gil = gil;
                giltracker.initialized = true;
            end
        end
        return;
    end
    
    -- Update current gil
    giltracker.current_gil = get_current_gil();
    
    -- Calculate change
    local gil_change = giltracker.current_gil - giltracker.starting_gil;
    local change_color = get_change_color(gil_change);
    
    -- Render ImGui window
    if giltracker.is_open[1] then
        imgui.SetNextWindowSize({ 250, 120 }, ImGuiCond_FirstUseEver);
        imgui.SetNextWindowBgAlpha(giltracker.opacity);
        
        if imgui.Begin('Gil Tracker', giltracker.is_open, ImGuiWindowFlags_NoCollapse) then
            -- Current Gil
            imgui.Text('Current Gil:');
            imgui.SameLine();
            imgui.TextColored({ 1.0, 1.0, 0.0, 1.0 }, format_number(giltracker.current_gil));
            
            imgui.Separator();
            
            -- Gil Change
            imgui.Text('Change:');
            imgui.SameLine();
            local change_text = format_number(gil_change);
            if gil_change > 0 then
                change_text = '+' .. change_text;
            end
            imgui.TextColored(change_color, change_text);
            
            imgui.Separator();
            
            -- Refresh Button
            if imgui.Button('Refresh', { 100, 25 }) then
                giltracker.starting_gil = giltracker.current_gil;
                print(chat.header(addon.name):append(chat.message('Gil tracker reset!')));
            end
            
            imgui.SameLine();
            
            -- Settings Button
            if imgui.Button('Settings', { 100, 25 }) then
                imgui.OpenPopup('Settings');
            end
            
            -- Settings Popup
            if imgui.BeginPopup('Settings') then
                imgui.Text('Window Opacity:');
                local opacity = T{ giltracker.opacity };
                if imgui.SliderFloat('##opacity', opacity, 0.1, 1.0, '%.1f') then
                    giltracker.opacity = opacity[1];
                end
                imgui.EndPopup();
            end
            
            imgui.End();
        end
    end
end);

--[[
* event: command
* desc : Event called when the addon is processing a command.
]]--
ashita.events.register('command', 'giltracker_command', function(e)
    local args = e.command:args();
    if #args == 0 or (args[1] ~= '/giltracker' and args[1] ~= '/gt') then
        return;
    end
    
    e.blocked = true;
    
    if #args == 1 then
        giltracker.is_open[1] = not giltracker.is_open[1];
        return;
    end
    
    local cmd = args[2]:lower();
    
    if cmd == 'show' then
        giltracker.is_open[1] = true;
        print(chat.header(addon.name):append(chat.message('Window shown.')));
    elseif cmd == 'hide' then
        giltracker.is_open[1] = false;
        print(chat.header(addon.name):append(chat.message('Window hidden.')));
    elseif cmd == 'reset' or cmd == 'refresh' then
        giltracker.starting_gil = giltracker.current_gil;
        print(chat.header(addon.name):append(chat.message('Gil tracker reset!')));
    elseif cmd == 'help' then
        print(chat.header(addon.name):append(chat.message('Commands:')));
        print(chat.message('  /giltracker or /gt - Toggle window'));
        print(chat.message('  /giltracker show - Show window'));
        print(chat.message('  /giltracker hide - Hide window'));
        print(chat.message('  /giltracker reset - Reset gil change counter'));
        print(chat.message('  /giltracker help - Show this help'));
    else
        print(chat.header(addon.name):append(chat.error('Unknown command. Use /giltracker help for commands.')));
    end
end);
