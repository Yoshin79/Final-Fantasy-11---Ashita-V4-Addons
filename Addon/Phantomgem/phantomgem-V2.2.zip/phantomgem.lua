--[[
Copyright © 2019, Wiener
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of PhantomGem nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL Sammeh BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
]]

addon.name = 'PhantomGem'
addon.author = 'Wiener, Ashita version by Jyouya, GUI addition by Oneword'
addon.version = '2.2'
addon.desc = 'Check and Buy phantom gems'

require('sugar');
local chat = require('chat');
local imgui = require('imgui');

-- GUI state
local ui = {
    is_open = { true },  -- Changed from false to true to open GUI on load
    filter = { '' },
    show_owned = { false },
    merits = 0
};

npcs       = {
    [231] = { name = 'Trisvain', menuId = 892, zone = 231 },
    [236] = { name = 'Raving Opossum', menuId = 429, zone = 236 },
    [240] = { name = 'Mimble-Pimble', menuId = 895, zone = 240 },
}

-- option index is 2 8 bit numbers.
-- The first number (2) indicates that a gem is being purchased
-- The second is the index of the gem, from 0 - 25
pGems      = {
    [0] = { ki = 2468, cost = 10, oi = 2, name = "Shadow Lord phantom gem" },
    [1] = { ki = 2470, cost = 10, oi = 258, name = "Stellar Fulcrum phantom gem" },
    [2] = { ki = 2469, cost = 10, oi = 514, name = "Celestial Nexus phantom gem" },
    [3] = { ki = 2471, cost = 15, oi = 770, name = "Phantom gem of apathy" },
    [4] = { ki = 2472, cost = 15, oi = 1026, name = "Phantom gem of arrogance" },
    [5] = { ki = 2473, cost = 15, oi = 1282, name = "Phantom gem of envy" },
    [6] = { ki = 2474, cost = 15, oi = 1538, name = "Phantom gem of cowardice" },
    [7] = { ki = 2475, cost = 15, oi = 1794, name = "Phantom gem of rage" },
    [8] = { ki = 2476, cost = 20, oi = 2050, name = "P. Perpetrator phantom gem" },
    [9] = { ki = 2545, cost = 10, oi = 2306, name = "Savage's phantom gem" },
    [10] = { ki = 2546, cost = 10, oi = 2562, name = "Warrior's Path phantom gem" },
    [11] = { ki = 2556, cost = 10, oi = 2818, name = "Puppet in Peril phantom gem" },
    [12] = { ki = 2557, cost = 10, oi = 3074, name = "Legacy phantom gem" },
    [13] = { ki = 2595, cost = 10, oi = 3330, name = "Head wind phantom gem" },
    [14] = { ki = 2619, cost = 10, oi = 3586, name = "Avatar phantom gem" },
    [15] = { ki = 2923, cost = 10, oi = 3842, name = "Moonlit Path phantom gem" },
    [16] = { ki = 2924, cost = 10, oi = 4098, name = "Waking the Beast phantom gem" },
    [17] = { ki = 2925, cost = 10, oi = 4354, name = "Waking Dream phantom gem" },
    [18] = { ki = 2987, cost = 10, oi = 4610, name = "Feared One phantom gem" },
    [19] = { ki = 2988, cost = 10, oi = 4866, name = "Dawn phantom gem" },
    [20] = { ki = 3185, cost = 10, oi = 5122, name = "Stygian Pact phantom gem" },
    [21] = { ki = 3186, cost = 10, oi = 5378, name = "Champion phantom gem" },
    [22] = { ki = 3187, cost = 10, oi = 5634, name = "Divine phantom gem" },
    [23] = { ki = 3188, cost = 10, oi = 5890, name = "Maiden phantom gem" },
    [24] = { ki = 3261, cost = 30, oi = 6146, name = "Shinryu phantom gem" },
    [25] = { ki = 3356, cost = 30, oi = 6402, name = "Cloud of Darkness phantom gem" }
}

shortcuts  = {
    ["shadow"] = 0,
    ["lord"] = 0,
    ["sl"] = 0,
    ["stellar"] = 1,
    ["fulcrum"] = 2,
    ["sf"] = 1,
    ["celestial"] = 2,
    ["nexus"] = 2,
    ["cn"] = 2,
    ['apathy'] = 3,
    ['aahm'] = 3,
    ['arrogance'] = 4,
    ['aaev'] = 4,
    ['envy'] = 5,
    ['aamr'] = 5,
    ['cowardice'] = 6,
    ['coward'] = 6,
    ['aatt'] = 6,
    ['rage'] = 7,
    ['aagk'] = 7,
    ['perp'] = 8,
    ['perpetrator'] = 8,
    ['dm'] = 8,
    ['savage'] = 9,
    ['ouryu'] = 9,
    ['warrior'] = 10,
    ['war'] = 10,
    ['tenzen'] = 10,
    ['puppet'] = 11,
    ['peril'] = 11,
    ['pip'] = 11,
    ['legacy'] = 12,
    ['gessho'] = 12,
    ['headwind'] = 13,
    ['shikaree'] = 13,
    ['avatar'] = 14,
    ['garuda'] = 14,
    ['ramuh'] = 14,
    ['titan'] = 14,
    ['ifrit'] = 14,
    ['leviathan'] = 14,
    ['shiva'] = 14,
    ['moonlit'] = 15,
    ['path'] = 15,
    ['mp'] = 15,
    ['fenrir'] = 15,
    ['beast'] = 16,
    ['wtb'] = 16,
    ['dream'] = 17,
    ['wd'] = 17,
    ['diabolos'] = 17,
    ['fearedone'] = 18,
    ['feared'] = 18,
    ['fo'] = 18,
    ['omega'] = 18,
    ['ultima'] = 18,
    ['dawn'] = 19,
    ['promathia'] = 19,
    ['stygian'] = 20,
    ['sp'] = 20,
    ['odin'] = 20,
    ['champion'] = 21,
    ['cait'] = 21,
    ['caitsith'] = 21,
    ['divine'] = 22,
    ['alexander'] = 22,
    ['alex'] = 22,
    ['maiden'] = 23,
    ['lilith'] = 23,
    ['wyrm'] = 24,
    ['shinryu'] = 24,
    ['orb'] = 25,
    ['radiance'] = 25,
    ['cod'] = 25
}


local function message(text)
    print(chat.header(addon.name):append(chat.message(text)));
end

local function kiName(id)
    return AshitaCore:GetResourceManager():GetString('keyitems.names', id);
end

-- Technically not needed since the npcs have static indices
local function getIndexByName(name)
    local entMgr = AshitaCore:GetMemoryManager():GetEntity();

    for i = 1, 1023 do
        if entMgr:GetName(i) == name then
            return i;
        end
    end
end

-- Helper functions for the GUI
function GetOwnedCount()
    local count = 0;
    for _, gem in pairs(pGems) do
        if HaveKI(gem.ki) then
            count = count + 1;
        end
    end
    return count;
end

function GetTotalCount()
    local count = 0;
    for _ in pairs(pGems) do
        count = count + 1;
    end
    return count;
end

function HaveKI(id)
    return AshitaCore:GetMemoryManager():GetPlayer():HasKeyItem(id);
end

function GetStatus()
    local targetIndex = AshitaCore:GetMemoryManager():GetParty():GetMemberTargetIndex(0);
    return AshitaCore:GetMemoryManager():GetEntity():GetStatus(targetIndex);
end

function FindNPC(npcName)
    local entMgr = AshitaCore:GetMemoryManager():GetEntity();

    local npcIdx = getIndexByName(npcName);

    if GetStatus() == 0 then
        if npcIdx and math.sqrt(entMgr:GetDistance(npcIdx)) < 6 then
            return entMgr:GetServerId(npcIdx), npcIdx
        else
            message('Phantom gem NPC too far away!');
        end
    end

    return nil, nil
end

local function buildActionPacket(packet)
    local p = struct.pack('BBHLHHLLLL',
        0x1A,
        0x0E,
        0,
        packet['Target'] or 0,
        packet['Target Index'] or 0,
        packet['Category'] or 0,
        0, 0, 0, 0
    );

    return p;
end

local function inject(id, packet)
    AshitaCore:GetPacketManager():AddOutgoingPacket(id, packet:totable());
end

function EngageDialogue(npc)
    local target, targetIndex = FindNPC(npc.name)
    if target and targetIndex then
        local packet = buildActionPacket({
            ["Target"] = target,
            ["Target Index"] = targetIndex,
            ["Category"] = 0,
            ["Param"] = 0,
            ["_unknown1"] = 0
        });
        inject(0x1A, packet)
    end
end

local function buildMenuPacket(packet)
    return struct.pack('BBHLLHHHH',
        0x5B,
        0x0A,
        0,
        packet['Target'] or 0,
        packet['Option Index'] or 0,
        packet['Target Index'] or 0,
        packet['Automated Message'] and 1 or 0,
        packet['Zone'] or 0,
        packet['Menu ID'] or 0
    );
end

function ResetDialogue(npc, forced)
    _gem = nil
    local target, targetIndex = FindNPC(npc.name)
    if target and targetIndex then
        local resetPacket = buildMenuPacket {
            ["Target"] = target,
            ["Option Index"] = 16384,
            ["_unknown1"] = 16384,
            ["Target Index"] = targetIndex,
            ["Automated Message"] = false,
            ["_unknown2"] = 0,
            ["Zone"] = npc.zone,
            ["Menu ID"] = npc.menuId
        }
        inject(0x5B, resetPacket)
        if forced then
            message('Reset sent.')
        end
    end
end

local _gem = nil
ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args();
    if (#args == 0 or args[1] ~= '/pg') then
        return;
    end

    e.blocked = true;

    if args[2] == "gui" then
        ui.is_open[1] = not ui.is_open[1];
        return;
    end

    local zone = AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0);
    local npc = npcs[zone]

    if (npc) then
        local cmd = args[2];

        if cmd == "reset" then
            ResetDialogue(npc, true)
        else
            _gem = nil
            local gemNumber = tonumber(cmd)
            if type(gemNumber) ~= 'number' then
                gemNumber = shortcuts[cmd:lower()]
            end

            if gemNumber and type(gemNumber) == 'number' then
                _gem = pGems[gemNumber]
                if HaveKI(_gem.ki) then
                    message("\'" .. kiName(_gem.ki) .. "\' already in possession!")
                    _gem = nil
                else
                    EngageDialogue(npc)
                end
            else
                message("Phantom gem was not found.")
            end
        end
    else
        message("Not in a zone with a phantom gem NPC.")
    end
end)

ashita.events.register('packet_in', 'pg_cb', function(e)
    if e.injected then return end

    if e.id == 0x034 then
        local zone = struct.unpack('H', e.data, 0x2A + 0x01);
        local menuId = struct.unpack('H', e.data, 0x2C + 0x01);
        local npc = npcs[zone]
        local merits = struct.unpack('I2', e.data, 17);
        
        -- Update merits for GUI
        ui.merits = merits;
        
        if not _gem or not npc or npc.menuId ~= menuId then return false end
        
        e.blocked = true;

        local availabilityMask = struct.unpack('L', e.data, 0x0C + 0x01);

        if (bit.band(availabilityMask, math.pow(2, (_gem.oi - 2) / 256)) == 0) then
            message(kiName(_gem.ki) .. ' not unlocked!');
            ResetDialogue(npc, false);
            _gem = nil
            return true;
        end

        if _gem.cost <= merits then
            local packet = {}
            packet["Target"] = struct.unpack('L', e.data, 0x04 + 0x01)
            packet["Option Index"] = _gem.oi
            packet["_unknown1"] = 0
            packet["Target Index"] = struct.unpack('H', e.data, 0x28 + 0x01);
            packet["Automated Message"] = false
            packet["_unknown2"] = 0
            packet["Zone"] = zone
            packet["Menu ID"] = menuId

            inject(0x5B, buildMenuPacket(packet))

            _gem = nil
            return true
        else
            message('Not enough merits to buy gem!')
            ResetDialogue(npc, false)
            _gem = nil
            return true
        end
    end
end);

-- GUI rendering
ashita.events.register('d3d_present', 'present_cb', function()
    if not ui.is_open[1] then
        return;
    end
    
    -- Update merit points from memory
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    if player then
        ui.merits = player:GetMeritPoints();
    end
    
    -- Apply styling
    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.1, 0.1, 0.2, 0.9 });
    imgui.PushStyleColor(ImGuiCol_TitleBg, { 0.2, 0.2, 0.4, 1.0 });
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, { 0.3, 0.3, 0.6, 1.0 });
    imgui.PushStyleColor(ImGuiCol_Button, { 0.2, 0.3, 0.6, 0.8 });
    imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.3, 0.4, 0.7, 0.9 });
    imgui.PushStyleColor(ImGuiCol_ButtonActive, { 0.4, 0.5, 0.8, 1.0 });
    imgui.PushStyleColor(ImGuiCol_Header, { 0.2, 0.3, 0.6, 0.8 });
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.3, 0.4, 0.7, 0.9 });
    imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.4, 0.5, 0.8, 1.0 });
    
    imgui.SetNextWindowSize({ 600, 400 }, ImGuiCond_FirstUseEver);
    
    if imgui.Begin('Phantom Gem Tracker', ui.is_open) then
        -- Check if we're in a valid zone
        local zone = AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0);
        local npc = npcs[zone];
        local inValidZone = npc ~= nil;
        
        -- Merit points display
        imgui.Text("Merit Points: " .. ui.merits);
        imgui.SameLine(200);
        
        -- Filter and options
        imgui.PushItemWidth(200);
        imgui.InputText("Filter", ui.filter, 128);
        imgui.PopItemWidth();
        imgui.SameLine();
        imgui.Checkbox("Show Owned", ui.show_owned);
        
        imgui.Separator();
        
        if not inValidZone then
            imgui.TextColored({ 1.0, 0.4, 0.4, 1.0 }, "Not in a zone with a phantom gem NPC!");
            imgui.Text("Valid zones: Northern San d'Oria, Port Bastok, Port Windurst");
        end
        
        -- Create a child window for the scrollable list
        if imgui.BeginChild("GemList", { 0, -30 }, true) then
            -- Group gems by cost
            local costGroups = { [10] = {}, [15] = {}, [20] = {}, [30] = {} };
            
            for i, gem in pairs(pGems) do
                local hasKI = HaveKI(gem.ki);
                
                -- Apply filters
                local filterText = ui.filter[1]:lower();
                local nameMatches = filterText == '' or gem.name:lower():find(filterText, 1, true);
                local showBasedOnOwnership = ui.show_owned[1] or not hasKI;
                
                if nameMatches and showBasedOnOwnership then
                    table.insert(costGroups[gem.cost], { index = i, gem = gem, hasKI = hasKI });
                end
            end
            
            -- Display gems by cost groups
            for _, cost in ipairs({10, 15, 20, 30}) do
                if #costGroups[cost] > 0 then
                    imgui.TextColored({ 0.7, 0.7, 1.0, 1.0 }, cost .. " Merit Phantom Gems:");
                    imgui.Separator();
                    
                    for _, entry in ipairs(costGroups[cost]) do
                        local gem = entry.gem;
                        local hasKI = entry.hasKI;
                        local canAfford = ui.merits >= gem.cost;
                        
                        -- Set colors based on ownership and affordability
                        if hasKI then
                            imgui.TextColored({ 0.5, 1.0, 0.5, 1.0 }, gem.name);
                        elseif not canAfford then
                            imgui.TextColored({ 1.0, 0.5, 0.5, 1.0 }, gem.name);
                        else
                            imgui.Text(gem.name);
                        end
                        
                        imgui.SameLine(400);
                        
                        -- Button to buy the gem
                        local buttonLabel = hasKI and "Owned" or "Buy";
                        local buttonDisabled = hasKI or not canAfford or not inValidZone;
                        
                        if buttonDisabled then
                            imgui.PushStyleColor(ImGuiCol_Button, { 0.3, 0.3, 0.3, 0.8 });
                            imgui.PushStyleColor(ImGuiCol_ButtonHovered, { 0.3, 0.3, 0.3, 0.8 });
                            imgui.PushStyleColor(ImGuiCol_ButtonActive, { 0.3, 0.3, 0.3, 0.8 });
                            imgui.PushStyleColor(ImGuiCol_Text, { 0.7, 0.7, 0.7, 1.0 });
                        end
                        
                        -- FIXED: Instead of using QueueCommand, directly call the command handler
                        if imgui.Button(buttonLabel .. "##" .. entry.index, { 80, 20 }) and not buttonDisabled then
                            -- Instead of using QueueCommand, directly engage with the NPC
                            _gem = pGems[entry.index];
                            if not HaveKI(_gem.ki) then
                                EngageDialogue(npc);
                            end
                        end
                        
                        if buttonDisabled then
                            imgui.PopStyleColor(4);
                        end
                        
                        -- Tooltip with more information
                        if imgui.IsItemHovered() then
                            imgui.BeginTooltip();
                            imgui.Text(gem.name);
                            imgui.Text("Cost: " .. gem.cost .. " merit points");
                            if hasKI then
                                imgui.TextColored({ 0.5, 1.0, 0.5, 1.0 }, "Already owned");
                            elseif not canAfford then
                                imgui.TextColored({ 1.0, 0.5, 0.5, 1.0 }, "Not enough merit points");
                            elseif not inValidZone then
                                imgui.TextColored({ 1.0, 0.5, 0.5, 1.0 }, "Not in a valid zone");
                            else
                                imgui.TextColored({ 0.5, 1.0, 0.5, 1.0 }, "Click to buy");
                            end
                            imgui.EndTooltip();
                        end
                    end
                    
                    imgui.Spacing();
                    imgui.Spacing();
                end
            end
            
            imgui.EndChild();
        end
        
        -- Bottom buttons
        if imgui.Button("Close", { 100, 20 }) then
            ui.is_open[1] = false;
        end
        
        imgui.SameLine();
        
        -- FIXED: Instead of using QueueCommand, directly call the function
        if imgui.Button("Reset Dialog", { 100, 20 }) and inValidZone then
            ResetDialogue(npc, true);
        end
        
        imgui.SameLine(imgui.GetWindowWidth() - 200);
        imgui.Text("Total Owned: " .. GetOwnedCount() .. "/" .. GetTotalCount());
    end
    
    imgui.PopStyleColor(9);
    imgui.End();
end);

-- Register load event
ashita.events.register('load', 'load_cb', function()
    message('Loaded! Use /pg gui to open the GUI or /pg <gemname> to buy directly.');
    -- GUI is already set to open by default with ui.is_open = { true }
end);
