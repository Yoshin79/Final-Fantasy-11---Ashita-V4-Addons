addon.name      = 'autows';
addon.author    = 'Oneword - Ninja Ai';
addon.version   = '2.1';
addon.desc      = 'Auto Weaponskill Merged with banggugyangu AutoRA';

require('common');
local imgui = require('imgui');
local chat = require('chat');
local bit = require('bit');

start_time = os.time()
timeout = 1

-- AutoWS variables
gEnabled = { true }
gThreshold = { 1000 }
gSelectedWeapon = nil
gSelectedWS = nil

-- AutoRA variables
gAutoRA = { false }
gRAFiring = false
gRAFinTime = 0
gPlayerServerId = 0

-- Window state
local ui = {
    is_open = { true }
}

local categorized_ws = {
    ['Sword'] = {'Fast Blade', 'Flat Blade', 'Burning Blade', 'Red Lotus Blade', 'Shining Blade', 'Seraph Blade', 'Circle Blade', 'Spirits Within', 'Vorpal Blade', 'Swift Blade', 'Savage Blade', 'Knights of Round', 'Expiacion', 'Chant du Cygne', 'Sanguine Blade', 'Requiescat', 'Resolution', 'Dimidiation', 'Savage Blade'},
    ['Great Sword'] = {'Hard Slash', 'Power Slash', 'Frostbite', 'Freezebite', 'Shockwave', 'Crescent Moon', 'Sickle Moon', 'Spinning Slash', 'Ground Strike', 'Herculean Slash', 'Resolution', 'Scourge', 'Torcleaver', 'Fell Cleave'},
    ['Dagger'] = {'Wasp Sting', 'Gust Slash', 'Viper Bite', 'Shadowstitch', 'Cyclone', 'Energy Drain', 'Energy Steal', 'Dancing Edge', 'Shark Bite', 'Evisceration', 'Aeolian Edge', 'Exenterator', 'Rudra\'s Storm', 'Mandalic Stab', 'Pyrrhic Kleos'},
    ['Axe'] = {'Raging Axe', 'Smash Axe', 'Axe Cyclone', 'Mistral Axe', 'Rampage', 'Calamity', 'Decimation', 'Bora Axe', 'Bora Axe II', 'Upheaval', 'Primal Rend', 'Cloudsplitter', 'Onslaught'},
    ['Great Axe'] = {'Shield Break', 'Iron Tempest', 'Sturmwind', 'Armor Break', 'Full Break', 'Steel Cyclone', 'Metatron Torment', 'King\'s Justice', 'Upheaval', 'Fell Cleave'},
    ['Scythe'] = {'Slice', 'Dark Harvest', 'Shadow of Death', 'Nightmare Scythe', 'Spinning Scythe', 'Vorpal Scythe', 'Guillotine', 'Cross Reaper', 'Spiral Hell', 'Insurgency', 'Quietus', 'Entropy'},
    ['Polearm'] = {'Double Thrust', 'Thunder Thrust', 'Raiden Thrust', 'Leg Sweep', 'Penta Thrust', 'Vorpal Thrust', 'Impulse Drive', 'Sonic Thrust', 'Stardiver', 'Camlann\'s Torment'},
    ['Katana'] = {'Blade: Rin', 'Blade: Retsu', 'Blade: Teki', 'Blade: To', 'Blade: Chi', 'Blade: Ei', 'Blade: Jin', 'Blade: Ten', 'Blade: Kamu', 'Blade: Metsu', 'Blade: Shun', 'Blade: Hi', 'Blade: Yu'},
    ['Great Katana'] = {'Tachi: Enpi', 'Tachi: Hobaku', 'Tachi: Goten', 'Tachi: Kagero', 'Tachi: Jinpu', 'Tachi: Koki', 'Tachi: Yukikaze', 'Tachi: Gekko', 'Tachi: Kasha', 'Tachi: Rana', 'Tachi: Ageha', 'Tachi: Fudo', 'Tachi: Shoha'},
    ['Club'] = {'Brainshaker', 'Skullbreaker', 'True Strike', 'Judgment', 'Hexa Strike', 'Black Halo', 'Flash Nova', 'Realmrazer', 'Mystic Boon', 'Dagan'},
    ['Staff'] = {'Heavy Swing', 'Rock Crusher', 'Earth Crusher', 'Sunburst', 'Seraph Strike', 'Shining Strike', 'Starburst', 'Retribution', 'Gate of Tartarus', 'Full Swing', 'Spirit Taker', 'Omniscience', 'Garland of Bliss', 'Shattersoul', 'Cataclysm'},
    ['Hand-to-Hand'] = {'Combo', 'Shoulder Tackle', 'One Inch Punch', 'Backhand Blow', 'Spinning Attack', 'Howling Fist', 'Dragon Kick', 'Asuran Fists', 'Ascetic\'s Fury', 'Victory Smite', 'Shijin Spiral', 'Final Heaven', 'Raging Fists'},
    ['Archery'] = {'Flaming Arrow', 'Piercing Arrow', 'Dulling Arrow', 'Sidewinder', 'Blast Arrow', 'Arching Arrow', 'Empyreal Arrow', 'Namas Arrow', 'Refulgent Arrow', 'Jishnu\'s Radiance'},
    ['Marksmanship'] = {'Hot Shot', 'Split Shot', 'Sniper Shot', 'Slug Shot', 'Blast Shot', 'Heavy Shot', 'Detonator', 'Last Stand', 'Coronach', 'Trueflight', 'Wildfire', 'Leaden Salute'}
}

function get_keys(tbl)
    local keys = {}
    for k, _ in pairs(tbl) do table.insert(keys, k) end
    table.sort(keys)
    return keys
end

-- Function to render the UI
local function render_ui()
    if not ui.is_open[1] then
        return
    end

    local flags = bit.bor(
        ImGuiWindowFlags_AlwaysAutoResize,
        ImGuiWindowFlags_NoSavedSettings
    )

    if imgui.Begin('AutoWS##autows', ui.is_open, flags) then
        imgui.Checkbox('Enabled', gEnabled)
        imgui.Checkbox('Auto Ranged', gAutoRA)
        imgui.SliderInt('TP Threshold', gThreshold, 1000, 3000)

        local weapon_types = get_keys(categorized_ws)
        local current_weapon_index = gSelectedWeapon and table.find(weapon_types, gSelectedWeapon) or 1
        local weapon_selection = { current_weapon_index - 1 }
        
        -- Weapon selection
        if imgui.Combo('Select Weapon##weapon_combo', weapon_selection, table.concat(weapon_types, '\0') .. '\0') then
            gSelectedWeapon = weapon_types[weapon_selection[1] + 1]
            -- Don't set gSelectedWS to nil here anymore
        end

        -- Weapon skill selection
        if gSelectedWeapon then
            local ws_list = categorized_ws[gSelectedWeapon]
            imgui.Text('Select Weapon Skill:')
            
            -- Initialize gSelectedWS if it's nil
            if gSelectedWS == nil and #ws_list > 0 then
                gSelectedWS = ws_list[1]
            end
            
            local current_ws_index = gSelectedWS and table.find(ws_list, gSelectedWS) or 1
            local ws_selection = { current_ws_index - 1 }
            
            if imgui.Combo('##ws_combo', ws_selection, table.concat(ws_list, '\0') .. '\0') then
                gSelectedWS = ws_list[ws_selection[1] + 1]
            end
            
            if gSelectedWS then
                imgui.Text('Current: ' .. gSelectedWS)
            end
        end
    end
    imgui.End()
end

-- Function to process auto WS/RA logic
local function process_auto_logic()
    local now = os.time()
    local duration = os.difftime(now - start_time)

    if duration > timeout then
        local tp = getTP()
        local engaged = isPlayerEngaged()
        local stunned = isStunned()

        if engaged and not stunned then
            -- AutoWS Logic
           if gEnabled[1] and gSelectedWS and tp >= gThreshold[1] then
                local cmd = string.format('/ws "%s" <t>', gSelectedWS)
                AshitaCore:GetChatManager():QueueCommand(1, cmd)
                gRAFiring = false
                timeout = 3
                start_time = now

            -- AutoRA Logic
            elseif gAutoRA[1] then
                local delay = gRAFinTime + 3
                if now > delay and not gRAFiring then
                    gRAFiring = true
                    AshitaCore:GetChatManager():QueueCommand(-1, '/shoot <t>')
                end
                if now >= delay + 5 and gRAFiring then
                    gRAFiring = false
                end
                timeout = 1
                start_time = now
            end
        else
            timeout = 1
            start_time = now
        end
    end
end

-- Main d3d_present callback
ashita.events.register('d3d_present', 'present_cb', function()
    -- Always process the auto logic, regardless of UI state
    process_auto_logic()
    
    -- Render the UI if it's open
    render_ui()
end)

-- Packet handling for ranged attacks
ashita.events.register('packet_in', 'packet_in_cb', function (e)
    if e.id == 0x28 then
        local user = struct.unpack('L', e.data, 0x05 + 1)
        local actionType = ashita.bits.unpack_be(e.data_raw, 10, 2, 4)

        if gPlayerServerId == 0 then
            gPlayerServerId = AshitaCore:GetMemoryManager():GetParty():GetMemberServerId(0)
        end

        if user == gPlayerServerId then
            if actionType == 2 or actionType == 8 or actionType == 12 then
                gRAFinTime = os.time()
                gRAFiring = false
            end
        end
    end
end)

function isPlayerEngaged()
    local index = AshitaCore:GetMemoryManager():GetParty():GetMemberTargetIndex(0)
    return AshitaCore:GetMemoryManager():GetEntity():GetStatus(index) == 1
end

function isStunned()
    return isBuffed(7) or isBuffed(10) or isBuffed(2) or isBuffed(16) or isBuffed(14) or isBuffed(28) or isBuffed(0)
end

function isBuffed(id)
    local p = AshitaCore:GetMemoryManager():GetPlayer()
    if not p then return false end
    for _, v in pairs(p:GetBuffs()) do
        if v == id then return true end
    end
    return false
end

function getTP()
    local party = AshitaCore:GetMemoryManager():GetParty()
    if not party or type(party.GetMemberTP) ~= 'function' then return 0 end
    return party:GetMemberTP(0)
end

-- Command handler for start/stop and window toggle
ashita.events.register('command', 'command_cb', function (e)
    local args = e.command:args()
    
    -- Handle /autora commands
    if (#args > 0 and args[1]:any('/autora')) then
        e.blocked = true

        if (#args >= 2) then
            if (args[2]:any('start')) then
                gAutoRA[1] = true
            elseif (args[2]:any('stop')) then
                gAutoRA[1] = false
            end
        end
        return;
    end
    
    -- Handle /autows commands
    if (#args > 0 and args[1]:any('/autows')) then
        e.blocked = true
        
        -- Toggle window visibility
        if (#args == 1) then
            ui.is_open[1] = not ui.is_open[1];
            return;
        end
    end
end)

-- Register load/unload events
ashita.events.register('load', 'load_cb', function()
    AshitaCore:GetChatManager():QueueCommand(-1, '/bind ^D /autora start')
    AshitaCore:GetChatManager():QueueCommand(-1, '/bind !D /autora stop')
    print(chat.header(addon.name):append(chat.message('AutoWS loaded! Type /autows to toggle the window.')));
end)

ashita.events.register('unload', 'unload_cb', function()
    AshitaCore:GetChatManager():QueueCommand(-1, '/unbind ^D')
    AshitaCore:GetChatManager():QueueCommand(-1, '/unbind !D')
end)
