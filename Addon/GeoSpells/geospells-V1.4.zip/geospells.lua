addon.name    = 'geospells'
addon.author  = 'Oneword - Ninja AI'
addon.version = '1.4'
addon.desc    = 'Track missing GEO spells'

require('common')
local imgui = require('imgui')
local bit = require('bit')

-- Style Configuration
local styles = {
    colors = {
        window_bg = { 0.15, 0.15, 0.15, 0.98 },
        header_bg = { 0.25, 0.25, 0.30, 1.0 },
        header_active = { 0.30, 0.30, 0.35, 1.0 },
        header_text = { 0.85, 0.85, 0.85, 1.0 },
        known_spell = { 0.40, 0.85, 0.40, 1.0 },
        unknown_spell = { 0.85, 0.40, 0.40, 1.0 },
        location_text = { 0.75, 0.75, 0.75, 1.0 },
        checkbox_text = { 0.90, 0.90, 0.90, 1.0 },
        section_text = { 1.0, 0.85, 0.0, 1.0 }  -- Golden yellow for section headers
    },
    spacing = 4.0,
    indent = 20.0,
    padding = { 10, 10 }
}

local GeoSpells = {
    -- Indi Spells (Starting at 768)
    {id = 768, name = "Indi-Regen", level = 15},
    {id = 769, name = "Indi-Poison", level = 1},
    {id = 770, name = "Indi-Refresh", level = 30},
    {id = 771, name = "Indi-Haste", level = 93},
    {id = 772, name = "Indi-STR", level = 48},
    {id = 773, name = "Indi-DEX", level = 45},
    {id = 774, name = "Indi-VIT", level = 42},
    {id = 775, name = "Indi-AGI", level = 39},
    {id = 776, name = "Indi-INT", level = 36},
    {id = 777, name = "Indi-MND", level = 33},
    {id = 778, name = "Indi-CHR", level = 30},
    {id = 779, name = "Indi-Fury", level = 34},
    {id = 780, name = "Indi-Barrier", level = 28},
    {id = 781, name = "Indi-Acumen", level = 46},
    {id = 782, name = "Indi-Fend", level = 40},
    {id = 783, name = "Indi-Precision", level = 10},
    {id = 784, name = "Indi-Voidance", level = 4},
    {id = 785, name = "Indi-Focus", level = 22},
    {id = 786, name = "Indi-Attunement", level = 16},
    {id = 787, name = "Indi-Wilt", level = 82},
    {id = 788, name = "Indi-Frailty", level = 76},
    {id = 789, name = "Indi-Fade", level = 94},
    {id = 790, name = "Indi-Malaise", level = 88},
    {id = 791, name = "Indi-Slip", level = 58},
    {id = 792, name = "Indi-Torpor", level = 52},
    {id = 793, name = "Indi-Vex", level = 70},
    {id = 794, name = "Indi-Languor", level = 64},
    {id = 795, name = "Indi-Slow", level = 48},
    {id = 796, name = "Indi-Paralysis", level = 68},
    {id = 797, name = "Indi-Gravity", level = 88},

    -- Geo Spells (Starting at 798)
    {id = 798, name = "Geo-Regen", level = 19},
    {id = 799, name = "Geo-Poison", level = 5},
    {id = 800, name = "Geo-Refresh", level = 34},
    {id = 801, name = "Geo-Haste", level = 97},
    {id = 802, name = "Geo-STR", level = 52},
    {id = 803, name = "Geo-DEX", level = 49},
    {id = 804, name = "Geo-VIT", level = 46},
    {id = 805, name = "Geo-AGI", level = 43},
    {id = 806, name = "Geo-INT", level = 40},
    {id = 807, name = "Geo-MND", level = 37},
    {id = 808, name = "Geo-CHR", level = 34},
    {id = 809, name = "Geo-Fury", level = 38},
    {id = 810, name = "Geo-Barrier", level = 32},
    {id = 811, name = "Geo-Acumen", level = 50},
    {id = 812, name = "Geo-Fend", level = 44},
    {id = 813, name = "Geo-Precision", level = 14},
    {id = 814, name = "Geo-Voidance", level = 8},
    {id = 815, name = "Geo-Focus", level = 26},
    {id = 816, name = "Geo-Attunement", level = 20},
    {id = 817, name = "Geo-Wilt", level = 86},
    {id = 818, name = "Geo-Frailty", level = 80},
    {id = 819, name = "Geo-Fade", level = 98},
    {id = 820, name = "Geo-Malaise", level = 92},
    {id = 821, name = "Geo-Slip", level = 62},
    {id = 822, name = "Geo-Torpor", level = 56},
    {id = 823, name = "Geo-Vex", level = 74},
    {id = 824, name = "Geo-Languor", level = 68},
    {id = 825, name = "Geo-Slow", level = 52},
    {id = 826, name = "Geo-Paralysis", level = 72},
    {id = 827, name = "Geo-Gravity", level = 92}
}

local SpellLocations = {
    -- Indi Spells (first 3 are automatic)
    [768] = "Learned automatically at level 1",
    [769] = "Learned automatically at level 4",
    [770] = "Learned automatically at level 10",
    -- Geo Spell Locations from FFXIclopedia
    [798] = "La Theine Plateau (K-5/6) - Use ramp at H-7 south side of valley",
    [799] = "East Ronfaure (I-7) - Near waterfall drop-off",
    [800] = "La Theine Plateau (H-10) - Near Waypoint",
    [801] = "Marjami Ravine (J-6) - NW of Station, near Ergon Locus",
    [802] = "Crawlers' Nest Map 2 (F-6) - Use Unity warp or Survival Guide",
    [803] = "Behemoth's Dominion (E-8) - Behind pillar on southern route",
    [804] = "Garlaige Citadel Map 2 (H-9) - Behind Fetid Flesh after first gate",
    [805] = "Castle Oztroja Map 7 (H-8) - From entrance up stairs J-8",
    [806] = "Beaucedine Glacier (H-9) - Next to lake from Outpost warp",
    [807] = "Rolanberry Fields (J-10) - Near small lake (Path starts @ NE L-8)",
    [808] = "Lower Delkfutt's Tower 2F (E-8) - Take left fork from entrance",
    [809] = "Sauromugue Champaign (K-6) - In crater, near Deadly Dodo spawn",
    [810] = "Batallia Downs (D-7) - Top of Mount entrance to Eldieme Necropolis",
    [811] = "Beaucedine Glacier (J-6) - Next to lake towards Fei'Yin",
    [812] = "Davoi (J-11) - Southern end of river",
    [813] = "Konschtat Highlands (F/G-6) - West of Crag of Dem, middle of 3 rocks",
    [814] = "Tahrongi Canyon (I-7) - Center of Mountain cluster, south of Crag of Mea",
    [815] = "Gusgen Mines (G-8) - West room filled with Funguar",
    [816] = "Qufim Island (I-9) - Near bone wall in tunnel from Port Jeuno",
    [817] = "Yahse Hunting Grounds (K-7) - North of Station, on beach",
    [818] = "Ceizak Battlegrounds (E-8/F-8) - North of Bivouac #3",
    [819] = "Morimar Basalt Fields (G-8) - North from Bivouac #3",
    [820] = "Morimar Basalt Fields (J-6) - North of Bivouac #1",
    [821] = "Eldieme Necropolis Map 2 (J-11) - Use entrance 3 from Batallia",
    [822] = "Xarcabard (F-7) - Cliff overlooking Uleguerand Range",
    [823] = "Upper Delkfutt's Tower F12 (G-7) - NW room (Use HP #1)",
    [824] = "Bostaunieux Oubliette Map 2 (I-11) - Old Sewer Syrup room",
    [825] = "Beadeaux (K-8) - NW corner, middle of four stone pillars",
    [826] = "Fei'Yin Map 2 (H-5) - Before tunnel to Cloister of Frost",
    [827] = "Foret de Hennetiel (I-7) - SW of Station, near water"
}

-- Add remaining Indi spell locations
for i = 771, 797 do
    if not SpellLocations[i] then
        SpellLocations[i] = "Purchase from Ishvad/Eukalline in Western Adoulin"
    end
end

local ui = {
    is_open = { true },
    show_all = { false },
    indi_collapsed = { false },
    geo_collapsed = { false }
}

local function HasSpell(spellId)
    local player = AshitaCore:GetMemoryManager():GetPlayer()
    if (player == nil) then
        return false
    end
    return player:HasSpell(spellId)
end

local function ApplyTheme()
    imgui.PushStyleColor(ImGuiCol_WindowBg, styles.colors.window_bg)
    imgui.PushStyleColor(ImGuiCol_Header, styles.colors.header_bg)
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, styles.colors.header_active)
    imgui.PushStyleColor(ImGuiCol_HeaderActive, styles.colors.header_active)
    imgui.PushStyleColor(ImGuiCol_Text, styles.colors.header_text)
    
    imgui.PushStyleVar(ImGuiStyleVar_WindowRounding, 5.0)
    imgui.PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0)
    imgui.PushStyleVar(ImGuiStyleVar_ItemSpacing, { styles.spacing, styles.spacing })
    imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, styles.padding)
    imgui.PushStyleVar(ImGuiStyleVar_IndentSpacing, 20.0)
end

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args()
    if args[1] ~= '/geospells' then
        return
    end
    ui.is_open[1] = not ui.is_open[1]
    e.blocked = true
end)

ashita.events.register('d3d_present', 'present_cb', function()
    if not ui.is_open[1] then
        return
    end

    imgui.SetNextWindowSizeConstraints({ 450, 300 }, { 1920, 1080 })
    
    local flags = bit.bor(
        ImGuiWindowFlags_NoSavedSettings
    )

    ApplyTheme()
    
    if imgui.Begin('GEO Spells Tracker##compact', ui.is_open, flags) then
        -- Options Section
        imgui.TextColored(styles.colors.section_text, 'Options')
        imgui.Separator()
        imgui.Indent(styles.indent)
        if imgui.Checkbox('Show All Spells##compact', ui.show_all) then end
        imgui.Unindent(styles.indent)
        
        imgui.Spacing()
        imgui.Spacing()
        
        -- Create scrolling region for spell sections
        if imgui.BeginChild('ScrollingRegion', { 0, -1 }, true) then
            -- Indi Spells Section
            if imgui.CollapsingHeader('Indi Spells##section', ui.indi_collapsed) then
                imgui.Indent(styles.indent)
                for i = 1, 30 do
                    local spell = GeoSpells[i]
                    local known = HasSpell(spell.id)
                    
                    if ui.show_all[1] or not known then
                        if known then
                            imgui.TextColored(styles.colors.known_spell, string.format('%s (Lv. %d)', spell.name, spell.level))
                        else
                            imgui.TextColored(styles.colors.unknown_spell, string.format('%s (Lv. %d)', spell.name, spell.level))
                            if SpellLocations[spell.id] then
                                imgui.SameLine()
                                imgui.TextColored(styles.colors.location_text, string.format(' - %s', SpellLocations[spell.id]))
                            end
                        end
                    end
                end
                imgui.Unindent(styles.indent)
            end

            imgui.Spacing()
            
            -- Geo Spells Section
            if imgui.CollapsingHeader('Geo Spells##section', ui.geo_collapsed) then
                imgui.Indent(styles.indent)
                for i = 31, 60 do
                    local spell = GeoSpells[i]
                    local known = HasSpell(spell.id)
                    
                    if ui.show_all[1] or not known then
                        if known then
                            imgui.TextColored(styles.colors.known_spell, string.format('%s (Lv. %d)', spell.name, spell.level))
                        else
                            imgui.TextColored(styles.colors.unknown_spell, string.format('%s (Lv. %d)', spell.name, spell.level))
                            if SpellLocations[spell.id] then
                                imgui.SameLine()
                                imgui.TextColored(styles.colors.location_text, string.format(' - %s', SpellLocations[spell.id]))
                            end
                        end
                    end
                end
                imgui.Unindent(styles.indent)
            end
            imgui.EndChild()
        end
    end
    
    -- Clean up styles
    imgui.PopStyleColor(5)
    imgui.PopStyleVar(5)
    
    imgui.End()
end)

ashita.events.register('load', 'load_cb', function()
    print(string.format('[%s] loaded! Use /geospells to toggle the tracker.', addon.name))
end)