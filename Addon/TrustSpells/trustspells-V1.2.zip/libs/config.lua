local config = {}

-- Add configuration options here if needed
config.defaults = {
    show_all = false,
    hide_uc = true
}

-- Load/save functions can be added here

return config
