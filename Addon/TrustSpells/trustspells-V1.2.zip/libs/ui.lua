local imgui = require('imgui')
local bit = require('bit')

local ui = {
    is_open = { true },
    show_all = { false },
    search_text = '',
    hide_uc = { true },
    last_search_time = 0,
    trust_lookup = {} -- ID-based lookup table
}

-- Function for custom theme
local function SetCustomTheme()
    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.1, 0.1, 0.1, 0.95 })
    imgui.PushStyleColor(ImGuiCol_Header, { 0.2, 0.2, 0.2, 0.55 })
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.3, 0.3, 0.3, 0.55 })
    imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.4, 0.4, 0.4, 0.55 })
    imgui.PushStyleColor(ImGuiCol_Text, { 0.9, 0.9, 0.9, 1.0 })
    imgui.PushStyleColor(ImGuiCol_CheckMark, { 0.0, 0.8, 0.0, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarBg, { 0.1, 0.1, 0.1, 0.95 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrab, { 0.3, 0.3, 0.3, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrabHovered, { 0.4, 0.4, 0.4, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrabActive, { 0.5, 0.5, 0.5, 1.0 })
end

-- Function to reset theme
local function ResetCustomTheme()
    imgui.PopStyleColor(10)
end

-- Helper function to count table elements
local function tableCount(t)
    local count = 0
    for _ in pairs(t) do
        count = count + 1
    end
    return count
end

-- Initialize trust lookup table
local function InitializeTrustLookup(trustSpells, hasSpellFunc)
    ui.trust_lookup = {}
    local count = 0
    
    -- Handle both array-style and hash-style trust data
    for trust_id, trust in pairs(trustSpells) do
        if type(trust_id) == 'number' and trust.name then
            ui.trust_lookup[trust_id] = {
                name = trust.name,
                category = trust.category,
                requirement = trust.requirement,
                hasSpell = hasSpellFunc(trust_id)
            }
            count = count + 1
        end
    end
    
    -- Initialization debug message removed
end

function ui.toggle()
    ui.is_open[1] = not ui.is_open[1]
end

function ui.render(trustSpells, hasSpellFunc)
    if not ui.is_open[1] then
        return
    end

    local current_time = os.time()
    
    -- Initialize lookup if not done yet
    if next(ui.trust_lookup) == nil then
        InitializeTrustLookup(trustSpells, hasSpellFunc)
    end

    imgui.SetNextWindowSize({ 600, 500 }, ImGuiCond_FirstUseEver)
    SetCustomTheme()

    local flags = bit.bor(
        ImGuiWindowFlags_NoSavedSettings,
        ImGuiWindowFlags_AlwaysVerticalScrollbar
    )

    if imgui.Begin('Trust Spells Tracker', ui.is_open, flags) then
        -- Top controls
        imgui.Checkbox('Show All Trusts', ui.show_all)
        imgui.SameLine()
        imgui.Checkbox('Hide Unity Concord (UC) Trusts', ui.hide_uc)
        imgui.Spacing()
        
        -- Current Trusts dropdown - show ONLY trusts you have obtained
        imgui.TextColored({ 1.0, 1.0, 0.0, 1.0 }, "Your Current Trusts:")
        imgui.Spacing()
        
        -- Create list of ONLY trusts you have obtained
        local obtained_trusts = {}
        for _, trust in pairs(trustSpells) do
            if type(trust) == 'table' and trust.name and hasSpellFunc(trust.id) then
                table.insert(obtained_trusts, trust.name)
            end
        end
        
        -- Sort alphabetically
        table.sort(obtained_trusts, function(a, b)
            return string.lower(a) < string.lower(b)
        end)
        
        -- Set display text
        local display_text = "Your Trusts (" .. #obtained_trusts .. " total)"
        if #obtained_trusts == 0 then
            display_text = "No trusts obtained yet"
        end
        
        -- Create dropdown showing ONLY your obtained trusts
        imgui.PushItemWidth(250)
        if imgui.BeginCombo("##obtained_dropdown", display_text) then
            if #obtained_trusts > 0 then
                for _, trust_name in ipairs(obtained_trusts) do
                    local is_selected = (trust_name == ui.search_text)
                    if imgui.Selectable(trust_name, is_selected) then
                        ui.search_text = trust_name
                        ui.last_search_time = current_time
                    end
                    if is_selected then
                        imgui.SetItemDefaultFocus()
                    end
                end
            else
                imgui.TextDisabled("Obtain more trusts to see them here")
            end
            imgui.EndCombo()
        end
        imgui.PopItemWidth()
        
        imgui.SameLine()
        if imgui.Button('Clear') then
            ui.search_text = ""
        end
        imgui.Spacing()
        imgui.Separator()
        imgui.Spacing()

        -- Show search results if searching
        if ui.search_text ~= "" then
            imgui.TextColored({ 0.0, 1.0, 1.0, 1.0 }, "Search Results:")
            imgui.Spacing()
            
            local searchTermLower = string.lower(ui.search_text)
            local foundCount = 0
            
            -- Search through trust lookup by ID and name
            for trust_id, trust_info in pairs(ui.trust_lookup) do
                -- Skip UC trusts if hide_uc is enabled
                if not (ui.hide_uc[1] and trust_info.name:find("(UC)")) then
                    -- Check if search matches ID or name
                    local id_match = tostring(trust_id):find(ui.search_text, 1, false)
                    local name_match = string.lower(trust_info.name):find(searchTermLower, 1, true)
                    
                    if id_match or name_match then
                        local showTrust = ui.show_all[1] or not trust_info.hasSpell
                        
                        if showTrust then
                            if trust_info.hasSpell then
                                imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, trust_info.name)
                            else
                                imgui.TextColored({ 1.0, 0.0, 0.0, 1.0 }, trust_info.name)
                                if trust_info.requirement ~= "" then
                                    imgui.SameLine()
                                    imgui.TextDisabled(trust_info.requirement)
                                end
                            end
                            
                            -- Add tooltip with trust info
                            if imgui.IsItemHovered() then
                                imgui.BeginTooltip()
                                imgui.Text("Name: " .. trust_info.name)
                                imgui.Text("ID: " .. trust_id)
                                imgui.Text("Category: " .. trust_info.category)
                                imgui.Text("Status: " .. (trust_info.hasSpell and "Obtained" or "Missing"))
                                if trust_info.requirement ~= "" then
                                    imgui.Text("Requirement: " .. trust_info.requirement)
                                end
                                imgui.EndTooltip()
                            end
                            
                            foundCount = foundCount + 1
                        end
                    end
                end
            end
            
            -- Chat messages removed
            
            if foundCount == 0 then
                imgui.TextColored({ 1.0, 0.5, 0.0, 1.0 }, "No trusts found matching: " .. ui.search_text)
            end
            
            imgui.Spacing()
            imgui.Separator()
            imgui.Spacing()
        end

        -- Count obtained trusts
        local obtained = 0
        local total = 0
        for _, trust in pairs(trustSpells) do
            if type(trust) == 'table' and trust.name then
                -- Skip UC trusts if hide_uc is enabled
                if not (ui.hide_uc[1] and trust.name:find("(UC)")) then
                    total = total + 1
                    if hasSpellFunc(trust.id) then
                        obtained = obtained + 1
                    end
                end
            end
        end

        -- Progress display
        imgui.TextColored({ 0.0, 0.8, 0.0, 1.0 }, string.format("Trust Obtained: %d / %d", obtained, total))
        if obtained >= 86 then
            imgui.SameLine()
            imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, "(Sufficient for RoE Objectives!)")
        end
        imgui.Spacing()
        imgui.Separator()
        imgui.Spacing()

        -- Show full list (only if not searching)
        if ui.search_text == "" then
            -- Group trusts by category
            local trustsByCategory = {}
            for _, trust in pairs(trustSpells) do
                if type(trust) == 'table' and trust.name then
                    -- Skip UC trusts if hide_uc is enabled
                    if not (ui.hide_uc[1] and trust.name:find("(UC)")) then
                        if not trustsByCategory[trust.category] then
                            trustsByCategory[trust.category] = {}
                        end
                        table.insert(trustsByCategory[trust.category], trust)
                    end
                end
            end

            -- Display each category
            for category, trusts in pairs(trustsByCategory) do
                local categoryHeader = string.format("%s (%d)", category, #trusts)
                if imgui.CollapsingHeader(categoryHeader) then
                    imgui.Indent(10)

                    for _, trust in ipairs(trusts) do
                        local known = hasSpellFunc(trust.id)
                        local showTrust = ui.show_all[1] or not known

                        if showTrust then
                            if known then
                                imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, trust.name)
                            else
                                imgui.TextColored({ 1.0, 0.0, 0.0, 1.0 }, trust.name)
                                if trust.requirement ~= "" then
                                    imgui.SameLine()
                                    imgui.TextDisabled(trust.requirement)
                                end
                            end

                            -- Add tooltip with trust ID
                            if imgui.IsItemHovered() then
                                imgui.BeginTooltip()
                                imgui.Text(string.format("Trust ID: %d", trust.id))
                                imgui.EndTooltip()
                            end
                        end
                    end

                    imgui.Unindent(10)
                end
            end
        else
            imgui.TextColored({ 0.5, 0.5, 0.5, 1.0 }, "Clear search to view full trust list")
        end
    end
    imgui.End()
    ResetCustomTheme()
end

return ui