addon.name    = 'trustspells'
addon.author  = 'Oneword - Ninja AI'
addon.version = '1.2'
addon.desc    = 'Track available Trust spells'

require('common')
local config = require('libs.config')
local ui = require('libs.ui')
local data = require('libs.data')

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args()
    if args[1] ~= '/trustspells' then
        return
    end
    ui.toggle()
    e.blocked = true
end)

ashita.events.register('d3d_present', 'present_cb', function()
    ui.render(data.TrustSpells, data.HasSpell)
end)

ashita.events.register('load', 'load_cb', function()
    print(string.format('[%s] loaded! Use /trustspells to toggle the tracker.', addon.name))
end)