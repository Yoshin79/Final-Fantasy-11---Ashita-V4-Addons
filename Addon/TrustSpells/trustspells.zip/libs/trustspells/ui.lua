local imgui = require('imgui')
local bit = require('bit')

local ui = {
    is_open = { true },
    show_all = { false },
    filter = { '' },
    filter_buffer = { new = string.char(0):rep(256) },
    hide_uc = { true } -- New option to hide UC trusts
}

-- Function for custom theme
local function SetCustomTheme()
    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.1, 0.1, 0.1, 0.95 })
    imgui.PushStyleColor(ImGuiCol_Header, { 0.2, 0.2, 0.2, 0.55 })
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.3, 0.3, 0.3, 0.55 })
    imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.4, 0.4, 0.4, 0.55 })
    imgui.PushStyleColor(ImGuiCol_Text, { 0.9, 0.9, 0.9, 1.0 })
    imgui.PushStyleColor(ImGuiCol_CheckMark, { 0.0, 0.8, 0.0, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarBg, { 0.1, 0.1, 0.1, 0.95 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrab, { 0.3, 0.3, 0.3, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrabHovered, { 0.4, 0.4, 0.4, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrabActive, { 0.5, 0.5, 0.5, 1.0 })
end

-- Function to reset theme
local function ResetCustomTheme()
    imgui.PopStyleColor(10) -- Match the number of PushStyleColor calls
end

function ui.toggle()
    ui.is_open[1] = not ui.is_open[1]
end

function ui.render(trustSpells, hasSpellFunc)
    if not ui.is_open[1] then
        return
    end

    imgui.SetNextWindowSize({ 600, 400 }, ImGuiCond_FirstUseEver)
    SetCustomTheme()
    
    local flags = bit.bor(
        ImGuiWindowFlags_NoSavedSettings,
        ImGuiWindowFlags_AlwaysVerticalScrollbar
    )
    
    if imgui.Begin('Trust Spells Tracker', ui.is_open, flags) then
        -- Top controls
        imgui.Checkbox('Show All Trusts', ui.show_all)
        imgui.SameLine()
        imgui.Checkbox('Hide Unity Concord (UC) Trusts', ui.hide_uc)
        imgui.SameLine()
        
        imgui.PushItemWidth(200)
        if imgui.InputText('Filter', ui.filter_buffer, 256) then
            ui.filter[1] = ui.filter_buffer.new
        end
        imgui.PopItemWidth()

        -- Count obtained trusts
        local obtained = 0
        local total = 0
        for _, trust in ipairs(trustSpells) do
            -- Skip UC trusts if hide_uc is enabled
            if not (ui.hide_uc[1] and trust.name:find("%(UC%)")) then
                total = total + 1
                if hasSpellFunc(trust.id) then
                    obtained = obtained + 1
                end
            end
        end
        
        -- Progress display
        imgui.Spacing()
        imgui.TextColored({ 0.0, 0.8, 0.0, 1.0 }, string.format("Trust Obtained: %d / %d", obtained, total))
        if obtained >= 86 then
            imgui.SameLine()
            imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, "(Sufficient for RoE Objectives!)")
        end
        imgui.Spacing()
        imgui.Separator()
        imgui.Spacing()

        -- Group trusts by category
        local trustsByCategory = {}
        for _, trust in ipairs(trustSpells) do
            -- Skip UC trusts if hide_uc is enabled
            if not (ui.hide_uc[1] and trust.name:find("%(UC%)")) then
                if not trustsByCategory[trust.category] then
                    trustsByCategory[trust.category] = {}
                end
                table.insert(trustsByCategory[trust.category], trust)
            end
        end

        -- Display each category
        for category, trusts in pairs(trustsByCategory) do
            local categoryHeader = string.format("%s (%d)", category, #trusts)
            if imgui.CollapsingHeader(categoryHeader) then
                imgui.Indent(10)
                
                for _, trust in ipairs(trusts) do
                    local known = hasSpellFunc(trust.id)
                    local showTrust = ui.show_all[1] or not known
                    local matchesFilter = ui.filter[1] == "" or string.lower(trust.name):find(string.lower(ui.filter[1]), 1, true)
                    
                    if showTrust and matchesFilter then
                        if known then
                            imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, trust.name)
                        else
                            imgui.TextColored({ 1.0, 0.0, 0.0, 1.0 }, trust.name)
                            if trust.requirement ~= "" then
                                imgui.SameLine()
                                imgui.TextDisabled(trust.requirement)
                            end
                        end

                        -- Add tooltip with trust ID
                        if imgui.IsItemHovered() then
                            imgui.BeginTooltip()
                            imgui.Text(string.format("Trust ID: %d", trust.id))
                            imgui.EndTooltip()
                        end
                    end
                end
                
                imgui.Unindent(10)
            end
        end
    end
    imgui.End()
    ResetCustomTheme()
end

return ui
