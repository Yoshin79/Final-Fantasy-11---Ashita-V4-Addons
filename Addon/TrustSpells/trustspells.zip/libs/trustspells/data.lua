local data = {}

-- Trust spell categories
data.Categories = {
    TANK = "Tank",
    HEALER = "Healer", 
    SUPPORT = "Support",
    MELEE = "Melee Fighter",
    RANGED = "Ranged Fighter",
    CASTER = "Offensive Caster",
    SPECIAL = "Special"
}

-- Function to check if player has the Trust spell
data.HasSpell = function(spellId)
    local player = AshitaCore:GetMemoryManager():GetPlayer()
    if (player == nil) then
        return false
    end
    return player:HasSpell(spellId)
end

-- Table of Trust spells with their IDs and information
data.TrustSpells = {
    -- Tanks
    {id = 902, name = "Curilla", category = data.Categories.TANK, requirement = "Complete Trust: San d'Oria, Rank 3+"},
    {id = 899, name = "Excenmille", category = data.Categories.TANK, requirement = "Complete Trust: San d'Oria"},
    {id = 905, name = "Trion", category = data.Categories.TANK, requirement = "Complete Trust: San d'Oria, Rank 6+"},
    {id = 910, name = "Valaineral", category = data.Categories.TANK, requirement = "Records of Eminence: Basic Tutorial"},
    {id = 969, name = "Amchuchu", category = data.Categories.TANK, requirement = "2000 Bayld from Ujlei Zelekko"},
    {id = 926, name = "Mnejing", category = data.Categories.TANK, requirement = "3000 Assault Points"},
    {id = 951, name = "Rahal", category = data.Categories.TANK, requirement = "1000 Conquest Points"},
    {id = 960, name = "Rughadjeen", category = data.Categories.TANK, requirement = "Login Campaign Points"},
    {id = 993, name = "AAEV", category = data.Categories.TANK, requirement = "RoE: Temper Your Arrogance"},
    {id = 984, name = "August", category = data.Categories.TANK, requirement = "Sinister Reign or RoE Way Over Capacity"},
    {id = 972, name = "Halver", category = data.Categories.TANK, requirement = "Complete RoV 1-7 The Path Untraveled"},
    {id = 918, name = "Gessho", category = data.Categories.TANK, requirement = "Complete Passing Glory"},

    -- Healers
    {id = 898, name = "Kupipi", category = data.Categories.HEALER, requirement = "Complete Trust: Windurst"},
    {id = 916, name = "Cherukiki", category = data.Categories.HEALER, requirement = "Complete One to be Feared"},
    {id = 955, name = "Apururu (UC)", category = data.Categories.HEALER, requirement = "Unity Concord - 5000 Accolades (Apururu)"},
    {id = 909, name = "Mihli Aliapoh", category = data.Categories.HEALER, requirement = "2000 Imperial Standing"},
    {id = 944, name = "Ferreous Coffin", category = data.Categories.HEALER, requirement = "500 Sparks of Eminence"},
    {id = 936, name = "Karaha-Baruha", category = data.Categories.HEALER, requirement = "Login Campaign Points"},
    {id = 980, name = "Yoran-Oran (UC)", category = data.Categories.HEALER, requirement = "Unity Concord - 5000 Accolades (Yoran-Oran)"},
    {id = 998, name = "Ygnas", category = data.Categories.HEALER, requirement = "Complete RoE The Arciela Directive"},
    {id = 1012, name = "Nashmeira II", category = data.Categories.HEALER, requirement = "Complete RoV Ever Forward"},
    {id = 923, name = "Nashmeira", category = data.Categories.HEALER, requirement = "Complete Eternal Mercenary"},
    {id = 1020, name = "Monberaux", category = data.Categories.HEALER, requirement = "Complete Monberaux Trust quest"},

    -- Support
    {id = 911, name = "Joachim", category = data.Categories.SUPPORT, requirement = "5000 Cruor"},
    {id = 952, name = "Koru-Moru", category = data.Categories.SUPPORT, requirement = "300 Field Manual Tabs"},
    {id = 967, name = "Qultada", category = data.Categories.SUPPORT, requirement = "500 Sparks of Eminence"},
    {id = 965, name = "Arciela", category = data.Categories.SUPPORT, requirement = "Complete The Light Within"},
    {id = 1017, name = "Arciela II", category = data.Categories.SUPPORT, requirement = "Complete RoV What He Left Behind"},
    {id = 981, name = "Sylvie (UC)", category = data.Categories.SUPPORT, requirement = "Unity Concord - 5000 Accolades (Sylvie)"},
    {id = 914, name = "Ulmia", category = data.Categories.SUPPORT, requirement = "Complete CoP Dawn"},
    {id = 953, name = "Pieuje (UC)", category = data.Categories.SUPPORT, requirement = "Unity Concord - 5000 Accolades (Pieuje)"},
    {id = 989, name = "King of Hearts", category = data.Categories.SUPPORT, requirement = "500 Sparks of Eminence during Alter Ego Extravaganza"},
    {id = 1021, name = "Babban Mheillea", category = data.Categories.SUPPORT, requirement = "Obtained from special event"},

    -- Offensive Casters
    {id = 904, name = "Ajido-Marujido", category = data.Categories.CASTER, requirement = "Complete Trust: Windurst, Rank 6+"},
    {id = 934, name = "D.Shantotto", category = data.Categories.CASTER, requirement = "Login Campaign Points"},
    {id = 919, name = "Gadalar", category = data.Categories.CASTER, requirement = "Complete Embers of His Past"},
    {id = 1019, name = "Shantotto II", category = data.Categories.CASTER, requirement = "Login Campaign Points"},
    {id = 987, name = "Ullegore", category = data.Categories.CASTER, requirement = "Login Campaign Points"},
    {id = 977, name = "Robel-Akbel", category = data.Categories.CASTER, requirement = "Login Campaign Points"},
    {id = 976, name = "Kayeel-Payeel", category = data.Categories.CASTER, requirement = "Allied Notes during Alter Ego Extravaganza"},
    {id = 961, name = "Kukki-Chebukki", category = data.Categories.CASTER, requirement = "1000 Conquest Points during Alter Ego Extravaganza"},
    {id = 974, name = "Leonoyne", category = data.Categories.CASTER, requirement = "Allied Notes during Alter Ego Extravaganza"},
    {id = 1015, name = "Mumor II", category = data.Categories.CASTER, requirement = "Fantastic Fraulein Mumor: Curtain Call event (August)"},
    {id = 925, name = "Ovjang", category = data.Categories.CASTER, requirement = "3000 Assault Points"},
    {id = 985, name = "Rosulatia", category = data.Categories.CASTER, requirement = "Sinister Reign or RoE Over Capacity"},
    {id = 898, name = "Shantotto", category = data.Categories.CASTER, requirement = "Complete all three nation Trust quests"},
    {id = 986, name = "Teodor", category = data.Categories.CASTER, requirement = "Login Campaign Points"},

    -- Ranged Fighters
    {id = 941, name = "Elivira", category = data.Categories.RANGED, requirement = "1000 Allied Notes during Alter Ego Extravaganza"},
    {id = 929, name = "Najelith", category = data.Categories.RANGED, requirement = "Login Campaign Points"},
    {id = 988, name = "Makki-Chebukki", category = data.Categories.RANGED, requirement = "1000 Conquest Points during Alter Ego Extravaganza"},
    {id = 962, name = "Margret", category = data.Categories.RANGED, requirement = "2000 Bayld"},
    {id = 940, name = "Semih Lafihna", category = data.Categories.RANGED, requirement = "Complete RoV The Path Untraveled"},
    {id = 1014, name = "Tenzen II", category = data.Categories.RANGED, requirement = "Complete RoV Crashing Waves"},

    -- Melee Fighters
    {id = 900, name = "Ayame", category = data.Categories.MELEE, requirement = "Complete Trust: Bastok"},
    {id = 901, name = "Nanaa Mihgo", category = data.Categories.MELEE, requirement = "Complete Trust: Windurst, Rank 3+"},
    {id = 906, name = "Zeid", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 1010, name = "Zeid II", category = data.Categories.MELEE, requirement = "Complete RoV Volto Oscuro"},
    {id = 959, name = "Abenzio", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 982, name = "Abquhbah", category = data.Categories.MELEE, requirement = "Complete President Salaheem and Ever Forward"},
    {id = 930, name = "Aldo", category = data.Categories.MELEE, requirement = "Adventurer Appreciation Campaign"},
    {id = 1007, name = "Aldo (UC)", category = data.Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Aldo)"},
    {id = 939, name = "Areuhat", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 996, name = "AAGK", category = data.Categories.MELEE, requirement = "RoE: Quell Your Rage"},
    {id = 994, name = "AAMR", category = data.Categories.MELEE, requirement = "RoE: Stifle Your Envy"},
    {id = 992, name = "AAHM", category = data.Categories.MELEE, requirement = "RoE: Eliminate Your Apathy"},
    {id = 995, name = "AATT", category = data.Categories.MELEE, requirement = "RoE: Overcome Your Cowardice"},
    {id = 983, name = "Balamor", category = data.Categories.MELEE, requirement = "Complete RoV Pretender to the Throne"},
    {id = 963, name = "Chacharoon", category = data.Categories.MELEE, requirement = "Complete Trial of the Chacharoon"},
    {id = 937, name = "Cid", category = data.Categories.MELEE, requirement = "500 Sparks of Eminence during Alter Ego Extravaganza"},
    {id = 991, name = "Darrcuiln", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 1004, name = "Excenmille (S)", category = data.Categories.MELEE, requirement = "Complete Face of the Future"},
    {id = 932, name = "Fablinix", category = data.Categories.MELEE, requirement = "Adventurer Appreciation Campaign"},
    {id = 957, name = "Flaviria (UC)", category = data.Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Flaviria)"},
    {id = 938, name = "Gilgamesh", category = data.Categories.MELEE, requirement = "500 Sparks of Eminence during Alter Ego Extravaganza"},
    {id = 917, name = "Iron Eater", category = data.Categories.MELEE, requirement = "Complete Trust: Bastok, obtain Naji, Ayame & Volker"},
    {id = 956, name = "Jakoh (UC)", category = data.Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Jakoh)"},
    {id = 948, name = "Klara", category = data.Categories.MELEE, requirement = "Complete Bonds of Mythril"},
    {id = 922, name = "Lehko Habhoka", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 964, name = "Lhe Lhangavo", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 943, name = "Lhu Mhakaracca", category = data.Categories.MELEE, requirement = "1000 Allied Notes during Alter Ego Extravaganza"},
    {id = 945, name = "Lilisette", category = data.Categories.MELEE, requirement = "Complete A Forbidden Reunion"},
    {id = 1013, name = "Lilisette II", category = data.Categories.MELEE, requirement = "Complete RoV Ganged Up On"},
    {id = 907, name = "Lion", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 1009, name = "Lion II", category = data.Categories.MELEE, requirement = "Complete RoV A Land After Time"},
    {id = 928, name = "Luzaf", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 933, name = "Maat", category = data.Categories.MELEE, requirement = "Complete Shattering Stars on 6+ jobs"},
    {id = 1006, name = "Maat (UC)", category = data.Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Maat)"},
    {id = 975, name = "Maximilian", category = data.Categories.MELEE, requirement = "1000 Allied Notes during Alter Ego Extravaganza"},
    {id = 966, name = "Mayakov", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 971, name = "Mildaurion", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 990, name = "Morimar", category = data.Categories.MELEE, requirement = "2000 Bayld during Alter Ego Extravaganza"},
    {id = 946, name = "Mumor", category = data.Categories.MELEE, requirement = "Fantastic Fraulein Mumor event (August)"},
    {id = 912, name = "Naja Salaheem", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 1008, name = "Naja (UC)", category = data.Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Naja)"},
    {id = 897, name = "Naji", category = data.Categories.MELEE, requirement = "Complete Trust: Bastok"},
    {id = 942, name = "Noillurie", category = data.Categories.MELEE, requirement = "1000 Allied Notes during Alter Ego Extravaganza"},
    {id = 913, name = "Prishe", category = data.Categories.MELEE, requirement = "Complete CoP Dawn"},
    {id = 1011, name = "Prishe II", category = data.Categories.MELEE, requirement = "Complete RoV Call to Serve"},
    {id = 920, name = "Rainemard", category = data.Categories.MELEE, requirement = "Trade cipher after obtaining Bundle of half-inscribed scrolls"},
    {id = 949, name = "Romaa Mihgo", category = data.Categories.MELEE, requirement = "Complete At Journey's End"},
    {id = 973, name = "Rongelouts", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 979, name = "Selh'teus", category = data.Categories.MELEE, requirement = "Complete RoV Call of the Void"},
    {id = 915, name = "Shikaree Z", category = data.Categories.MELEE, requirement = "Complete Three Paths with Windurst Trust permit"},
    {id = 908, name = "Tenzen", category = data.Categories.MELEE, requirement = "1000 Conquest Points during Alter Ego Extravaganza"},
    {id = 947, name = "Uka Totlihn", category = data.Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 903, name = "Volker", category = data.Categories.MELEE, requirement = "Complete Trust: Bastok, Rank 6+"},
    {id = 924, name = "Zazarg", category = data.Categories.MELEE, requirement = "Complete Fist of the People"},

    -- Special (Passive/Aura Trusts)
    {id = 970, name = "Brygid", category = data.Categories.SPECIAL, requirement = "Login Campaign Points"},
    {id = 1003, name = "Cornelia", category = data.Categories.SPECIAL, requirement = "Limited Time Event - Automatic if available"},
    {id = 978, name = "Kupofried", category = data.Categories.SPECIAL, requirement = "Adventurer Appreciation Campaign"},
    {id = 950, name = "Kuyin Hathdenna", category = data.Categories.SPECIAL, requirement = "Login Campaign Points"},
    {id = 931, name = "Moogle", category = data.Categories.SPECIAL, requirement = "Adventurer Appreciation Campaign"},
    {id = 927, name = "Sakura", category = data.Categories.SPECIAL, requirement = "300 Field Manual Tabs"},
    {id = 935, name = "Star Sibyl", category = data.Categories.SPECIAL, requirement = "Login Campaign Points"}
}

return data
