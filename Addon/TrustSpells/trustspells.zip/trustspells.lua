addon.name    = 'trustspells'
addon.author  = 'Oneword - Ninja AI'
addon.version = '1.0'
addon.desc    = 'Track available Trust spells'

require('common')
local imgui = require('imgui')
local bit = require('bit')

-- Trust spell categories
local Categories = {
    TANK = "Tank",
    HEALER = "Healer", 
    SUPPORT = "Support",
    MELEE = "Melee Fighter",
    RANGED = "Ranged Fighter",
    CASTER = "Offensive Caster",
    SPECIAL = "Special"
}

local ui = {
    is_open = { true },
    show_all = { false },
    filter = { '' },
    filter_buffer = { new = string.char(0):rep(256) }
}


-- Function for custom theme
local function SetCustomTheme()
    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.1, 0.1, 0.1, 0.95 })
    imgui.PushStyleColor(ImGuiCol_Header, { 0.2, 0.2, 0.2, 0.55 })
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.3, 0.3, 0.3, 0.55 })
    imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.4, 0.4, 0.4, 0.55 })
    imgui.PushStyleColor(ImGuiCol_Text, { 0.9, 0.9, 0.9, 1.0 })
    imgui.PushStyleColor(ImGuiCol_CheckMark, { 0.0, 0.8, 0.0, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarBg, { 0.1, 0.1, 0.1, 0.95 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrab, { 0.3, 0.3, 0.3, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrabHovered, { 0.4, 0.4, 0.4, 1.0 })
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrabActive, { 0.5, 0.5, 0.5, 1.0 })
end

-- Function to reset theme
local function ResetCustomTheme()
    imgui.PopStyleColor(10) -- Match the number of PushStyleColor calls
end

-- Function to check if player has the Trust spell
local function HasSpell(spellId)
    local player = AshitaCore:GetMemoryManager():GetPlayer()
    if (player == nil) then
        return false
    end
    return player:HasSpell(spellId)
end

-- Table of Trust spells with their IDs and information
local TrustSpells = {
    -- Tanks
    {id = 902, name = "Curilla", category = Categories.TANK, requirement = "Complete Trust: San d'Oria, Rank 3+"},
    {id = 899, name = "Excenmille", category = Categories.TANK, requirement = "Complete Trust: San d'Oria"},
    {id = 905, name = "Trion", category = Categories.TANK, requirement = "Complete Trust: San d'Oria, Rank 6+"},
    {id = 910, name = "Valaineral", category = Categories.TANK, requirement = "Records of Eminence: Basic Tutorial"},
    {id = 969, name = "Amchuchu", category = Categories.TANK, requirement = "2000 Bayld from Ujlei Zelekko"},
    {id = 926, name = "Mnejing", category = Categories.TANK, requirement = "3000 Assault Points"},
    {id = 951, name = "Rahal", category = Categories.TANK, requirement = "1000 Conquest Points"},
    {id = 960, name = "Rughadjeen", category = Categories.TANK, requirement = "Login Campaign Points"},
    {id = 993, name = "AAEV", category = Categories.TANK, requirement = "RoE: Temper Your Arrogance"},
    {id = 984, name = "August", category = Categories.TANK, requirement = "Sinister Reign or RoE Way Over Capacity"},
    {id = 972, name = "Halver", category = Categories.TANK, requirement = "Complete RoV 1-7 The Path Untraveled"},
    {id = 918, name = "Gessho", category = Categories.TANK, requirement = "Complete Passing Glory"},

    -- Healers
    {id = 898, name = "Kupipi", category = Categories.HEALER, requirement = "Complete Trust: Windurst"},
    {id = 916, name = "Cherukiki", category = Categories.HEALER, requirement = "Complete One to be Feared"},
    {id = 955, name = "Apururu (UC)", category = Categories.HEALER, requirement = "Unity Concord - 5000 Accolades (Apururu)"},
    {id = 909, name = "Mihli Aliapoh", category = Categories.HEALER, requirement = "2000 Imperial Standing"},
    {id = 944, name = "Ferreous Coffin", category = Categories.HEALER, requirement = "500 Sparks of Eminence"},
    {id = 936, name = "Karaha-Baruha", category = Categories.HEALER, requirement = "Login Campaign Points"},
    {id = 980, name = "Yoran-Oran (UC)", category = Categories.HEALER, requirement = "Unity Concord - 5000 Accolades (Yoran-Oran)"},
    {id = 998, name = "Ygnas", category = Categories.HEALER, requirement = "Complete RoE The Arciela Directive"},
    {id = 1012, name = "Nashmeira II", category = Categories.HEALER, requirement = "Complete RoV Ever Forward"},
    {id = 923, name = "Nashmeira", category = Categories.HEALER, requirement = "Complete Eternal Mercenary"},

    -- Support
    {id = 911, name = "Joachim", category = Categories.SUPPORT, requirement = "5000 Cruor"},
    {id = 952, name = "Koru-Moru", category = Categories.SUPPORT, requirement = "300 Field Manual Tabs"},
    {id = 967, name = "Qultada", category = Categories.SUPPORT, requirement = "500 Sparks of Eminence"},
    {id = 965, name = "Arciela", category = Categories.SUPPORT, requirement = "Complete The Light Within"},
    {id = 1017, name = "Arciela II", category = Categories.SUPPORT, requirement = "Complete RoV What He Left Behind"},
    {id = 981, name = "Sylvie (UC)", category = Categories.SUPPORT, requirement = "Unity Concord - 5000 Accolades (Sylvie)"},
    {id = 914, name = "Ulmia", category = Categories.SUPPORT, requirement = "Complete CoP Dawn"},
    {id = 953, name = "Pieuje (UC)", category = Categories.SUPPORT, requirement = "Unity Concord - 5000 Accolades (Pieuje)"},
    {id = 989, name = "King of Hearts", category = Categories.SUPPORT, requirement = "500 Sparks of Eminence during Alter Ego Extravaganza"},

    -- Offensive Casters
    {id = 904, name = "Ajido-Marujido", category = Categories.CASTER, requirement = "Complete Trust: Windurst, Rank 6+"},
    {id = 934, name = "D.Shantotto", category = Categories.CASTER, requirement = "Login Campaign Points"},
    {id = 919, name = "Gadalar", category = Categories.CASTER, requirement = "Complete Embers of His Past"},
    {id = 1019, name = "Shantotto II", category = Categories.CASTER, requirement = "Login Campaign Points"},
    {id = 987, name = "Ullegore", category = Categories.CASTER, requirement = "Login Campaign Points"},
    {id = 977, name = "Robel-Akbel", category = Categories.CASTER, requirement = "Login Campaign Points"},
    {id = 976, name = "Kayeel-Payeel", category = Categories.CASTER, requirement = "Allied Notes during Alter Ego Extravaganza"},
    {id = 961, name = "Kukki-Chebukki", category = Categories.CASTER, requirement = "1000 Conquest Points during Alter Ego Extravaganza"},
    {id = 974, name = "Leonoyne", category = Categories.CASTER, requirement = "Allied Notes during Alter Ego Extravaganza"},
    {id = 1015, name = "Mumor II", category = Categories.CASTER, requirement = "Fantastic Fraulein Mumor: Curtain Call event (August)"},
    {id = 925, name = "Ovjang", category = Categories.CASTER, requirement = "3000 Assault Points"},
    {id = 985, name = "Rosulatia", category = Categories.CASTER, requirement = "Sinister Reign or RoE Over Capacity"},
    {id = 898, name = "Shantotto", category = Categories.CASTER, requirement = "Complete all three nation Trust quests"},
    {id = 986, name = "Teodor", category = Categories.CASTER, requirement = "Login Campaign Points"},

    -- Ranged Fighters
    {id = 941, name = "Elivira", category = Categories.RANGED, requirement = "1000 Allied Notes during Alter Ego Extravaganza"},
    {id = 929, name = "Najelith", category = Categories.RANGED, requirement = "Login Campaign Points"},
    {id = 988, name = "Makki-Chebukki", category = Categories.RANGED, requirement = "1000 Conquest Points during Alter Ego Extravaganza"},
    {id = 962, name = "Margret", category = Categories.RANGED, requirement = "2000 Bayld"},
    {id = 940, name = "Semih Lafihna", category = Categories.RANGED, requirement = "Complete RoV The Path Untraveled"},
    {id = 1014, name = "Tenzen II", category = Categories.RANGED, requirement = "Complete RoV Crashing Waves"},

    -- Melee Fighters
    {id = 900, name = "Ayame", category = Categories.MELEE, requirement = "Complete Trust: Bastok"},
    {id = 901, name = "Nanaa Mihgo", category = Categories.MELEE, requirement = "Complete Trust: Windurst, Rank 3+"},
    {id = 906, name = "Zeid", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 1010, name = "Zeid II", category = Categories.MELEE, requirement = "Complete RoV Volto Oscuro"},
    {id = 959, name = "Abenzio", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 982, name = "Abquhbah", category = Categories.MELEE, requirement = "Complete President Salaheem and Ever Forward"},
    {id = 930, name = "Aldo", category = Categories.MELEE, requirement = "Adventurer Appreciation Campaign"},
    {id = 1007, name = "Aldo (UC)", category = Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Aldo)"},
    {id = 939, name = "Areuhat", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 996, name = "AAGK", category = Categories.MELEE, requirement = "RoE: Quell Your Rage"},
    {id = 994, name = "AAMR", category = Categories.MELEE, requirement = "RoE: Stifle Your Envy"},
    {id = 992, name = "AAHM", category = Categories.MELEE, requirement = "RoE: Eliminate Your Apathy"},
    {id = 995, name = "AATT", category = Categories.MELEE, requirement = "RoE: Overcome Your Cowardice"},
    {id = 983, name = "Balamor", category = Categories.MELEE, requirement = "Complete RoV Pretender to the Throne"},
    {id = 963, name = "Chacharoon", category = Categories.MELEE, requirement = "Complete Trial of the Chacharoon"},
    {id = 937, name = "Cid", category = Categories.MELEE, requirement = "500 Sparks of Eminence during Alter Ego Extravaganza"},
    {id = 991, name = "Darrcuiln", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 1004, name = "Excenmille (S)", category = Categories.MELEE, requirement = "Complete Face of the Future"},
    {id = 932, name = "Fablinix", category = Categories.MELEE, requirement = "Adventurer Appreciation Campaign"},
    {id = 957, name = "Flaviria (UC)", category = Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Flaviria)"},
    {id = 938, name = "Gilgamesh", category = Categories.MELEE, requirement = "500 Sparks of Eminence during Alter Ego Extravaganza"},
    {id = 917, name = "Iron Eater", category = Categories.MELEE, requirement = "Complete Trust: Bastok, obtain Naji, Ayame & Volker"},
    {id = 956, name = "Jakoh (UC)", category = Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Jakoh)"},
    {id = 948, name = "Klara", category = Categories.MELEE, requirement = "Complete Bonds of Mythril"},
    {id = 922, name = "Lehko Habhoka", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 964, name = "Lhe Lhangavo", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 943, name = "Lhu Mhakaracca", category = Categories.MELEE, requirement = "1000 Allied Notes during Alter Ego Extravaganza"},
    {id = 945, name = "Lilisette", category = Categories.MELEE, requirement = "Complete A Forbidden Reunion"},
    {id = 1013, name = "Lilisette II", category = Categories.MELEE, requirement = "Complete RoV Ganged Up On"},
    {id = 907, name = "Lion", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 1009, name = "Lion II", category = Categories.MELEE, requirement = "Complete RoV A Land After Time"},
    {id = 928, name = "Luzaf", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 933, name = "Maat", category = Categories.MELEE, requirement = "Complete Shattering Stars on 6+ jobs"},
    {id = 1006, name = "Maat (UC)", category = Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Maat)"},
    {id = 975, name = "Maximilian", category = Categories.MELEE, requirement = "1000 Allied Notes during Alter Ego Extravaganza"},
    {id = 966, name = "Mayakov", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 971, name = "Mildaurion", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 990, name = "Morimar", category = Categories.MELEE, requirement = "2000 Bayld during Alter Ego Extravaganza"},
    {id = 946, name = "Mumor", category = Categories.MELEE, requirement = "Fantastic Fraulein Mumor event (August)"},
    {id = 912, name = "Naja Salaheem", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 1008, name = "Naja (UC)", category = Categories.MELEE, requirement = "Unity Concord - 5000 Accolades (Naja)"},
    {id = 897, name = "Naji", category = Categories.MELEE, requirement = "Complete Trust: Bastok"},
    {id = 942, name = "Noillurie", category = Categories.MELEE, requirement = "1000 Allied Notes during Alter Ego Extravaganza"},
    {id = 913, name = "Prishe", category = Categories.MELEE, requirement = "Complete CoP Dawn"},
    {id = 1011, name = "Prishe II", category = Categories.MELEE, requirement = "Complete RoV Call to Serve"},
    {id = 920, name = "Rainemard", category = Categories.MELEE, requirement = "Trade cipher after obtaining Bundle of half-inscribed scrolls"},
    {id = 949, name = "Romaa Mihgo", category = Categories.MELEE, requirement = "Complete At Journey's End"},
    {id = 973, name = "Rongelouts", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 979, name = "Selh'teus", category = Categories.MELEE, requirement = "Complete RoV Call of the Void"},
    {id = 915, name = "Shikaree Z", category = Categories.MELEE, requirement = "Complete Three Paths with Windurst Trust permit"},
    {id = 908, name = "Tenzen", category = Categories.MELEE, requirement = "1000 Conquest Points during Alter Ego Extravaganza"},
    {id = 947, name = "Uka Totlihn", category = Categories.MELEE, requirement = "Login Campaign Points"},
    {id = 903, name = "Volker", category = Categories.MELEE, requirement = "Complete Trust: Bastok, Rank 6+"},
    {id = 924, name = "Zazarg", category = Categories.MELEE, requirement = "Complete Fist of the People"},

    -- Special (Passive/Aura Trusts)
    {id = 970, name = "Brygid", category = Categories.SPECIAL, requirement = "Login Campaign Points"},
    {id = 1003, name = "Cornelia", category = Categories.SPECIAL, requirement = "Limited Time Event - Automatic if available"},
    {id = 978, name = "Kupofried", category = Categories.SPECIAL, requirement = "Adventurer Appreciation Campaign"},
    {id = 950, name = "Kuyin Hathdenna", category = Categories.SPECIAL, requirement = "Login Campaign Points"},
    {id = 931, name = "Moogle", category = Categories.SPECIAL, requirement = "Adventurer Appreciation Campaign"},
    {id = 927, name = "Sakura", category = Categories.SPECIAL, requirement = "300 Field Manual Tabs"},
    {id = 935, name = "Star Sibyl", category = Categories.SPECIAL, requirement = "Login Campaign Points"}
}

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args()
    if args[1] ~= '/trustspells' then
        return
    end
    ui.is_open[1] = not ui.is_open[1]
    e.blocked = true
end)

ashita.events.register('d3d_present', 'present_cb', function()
    if not ui.is_open[1] then
        return
    end

    imgui.SetNextWindowSize({ 600, 400 }, ImGuiCond_FirstUseEver)
    SetCustomTheme() -- Apply custom theme
    
    local flags = bit.bor(
        ImGuiWindowFlags_NoSavedSettings,
        ImGuiWindowFlags_AlwaysVerticalScrollbar
    )
    
    if imgui.Begin('Trust Spells Tracker', ui.is_open, flags) then
        -- Top controls
        imgui.Checkbox('Show All Trusts', ui.show_all)
        imgui.SameLine()
        
        imgui.PushItemWidth(200)
        if imgui.InputText('Filter', ui.filter_buffer, 256) then
            ui.filter[1] = ui.filter_buffer.new
        end
        imgui.PopItemWidth()

        -- Count obtained trusts
        local obtained = 0
        local total = 0
        for _, trust in ipairs(TrustSpells) do
            total = total + 1
            if HasSpell(trust.id) then
                obtained = obtained + 1
            end
        end
        
        -- Progress display
        imgui.Spacing()
        imgui.TextColored({ 0.0, 0.8, 0.0, 1.0 }, string.format("Trust Obtained: %d / %d", obtained, total))
        if total >= 86 then
            imgui.SameLine()
            imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, "(Sufficient for RoE Objectives!)")
        end
        imgui.Spacing()
        imgui.Separator()
        imgui.Spacing()

        -- Group trusts by category
        local trustsByCategory = {}
        for _, trust in ipairs(TrustSpells) do
            if not trustsByCategory[trust.category] then
                trustsByCategory[trust.category] = {}
            end
            table.insert(trustsByCategory[trust.category], trust)
        end

        -- Display each category
        for category, trusts in pairs(trustsByCategory) do
            local categoryHeader = string.format("%s (%d)", category, #trusts)
            if imgui.CollapsingHeader(categoryHeader) then
                imgui.Indent(10)
                
                for _, trust in ipairs(trusts) do
                    local known = HasSpell(trust.id)
                    local showTrust = ui.show_all[1] or not known
                    local matchesFilter = ui.filter[1] == "" or string.lower(trust.name):find(string.lower(ui.filter[1]), 1, true)
                    
                    if showTrust and matchesFilter then
                        if known then
                            imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, trust.name)
                        else
                            imgui.TextColored({ 1.0, 0.0, 0.0, 1.0 }, trust.name)
                            if trust.requirement ~= "" then
                                imgui.SameLine()
                                imgui.TextDisabled(trust.requirement)
                            end
                        end

                        -- Add tooltip with trust ID
                        if imgui.IsItemHovered() then
                            imgui.BeginTooltip()
                            imgui.Text(string.format("Trust ID: %d", trust.id))
                            imgui.EndTooltip()
                        end
                    end
                end
                
                imgui.Unindent(10)
            end
        end
    end
    imgui.End()
    ResetCustomTheme() -- Reset theme
end)

ashita.events.register('load', 'load_cb', function()
    print(string.format('[%s] loaded! Use /trustspells to toggle the tracker.', addon.name))
end)
