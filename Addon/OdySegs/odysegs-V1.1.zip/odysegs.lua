-- Odysegs.lua
addon.name      = 'Odysegs';
addon.author    = 'Oneword with Ninja AI';
addon.version   = '1.1';
addon.desc      = 'Simple Odyssey Segments Tracker';

require('common');
local imgui = require('imgui');
local chat = require('chat');
local settings = require('settings');

-- Global variables
local g_show_window = { true };
local g_show_config = { false }; 
local g_last_amount = 0; -- Track the last amount received

-- Settings
local default_settings = T{
    segments = 0, -- Start at 0 as requested
    position = {
        x = 100,
        y = 100
    },
    color = {
        r = 1.0,
        g = 0.8,
        b = 0.2,
        a = 1.0
    },
    font_scale = 1.0,
    show_last_amount = true -- New setting to show last amount
};

local g_settings = settings.load(default_settings);

-- This function draws the UI window
local function render_ui()
    if not g_show_window[1] then return; end
    
    -- Set window position
    imgui.SetNextWindowPos({ g_settings.position.x, g_settings.position.y }, ImGuiCond_FirstUseEver);
    
    -- Set window flags
    local flags = bit.bor(
        ImGuiWindowFlags_NoTitleBar,
        ImGuiWindowFlags_AlwaysAutoResize,
        ImGuiWindowFlags_NoScrollbar,
        ImGuiWindowFlags_NoCollapse
    );
    
    -- Create the window
    if imgui.Begin('Odysegs', g_show_window, flags) then
        -- Set font scale
        imgui.SetWindowFontScale(g_settings.font_scale);
        
        -- Display the segments value
        imgui.TextColored({ g_settings.color.r, g_settings.color.g, g_settings.color.b, g_settings.color.a }, 
            'Odyssey Segments: ' .. g_settings.segments);
        
        -- Display the last amount if enabled
        if g_settings.show_last_amount and g_last_amount > 0 then
            imgui.TextColored({ g_settings.color.r, g_settings.color.g, g_settings.color.b, 0.7 }, 
                'Last received: +' .. g_last_amount);
        end
        
        -- Save window position when it's moved
        if not imgui.IsWindowHovered() and not imgui.IsMouseDown(ImGuiMouseButton_Left) then
            local pos_x, pos_y = imgui.GetWindowPos();
            if g_settings.position.x ~= pos_x or g_settings.position.y ~= pos_y then
                g_settings.position.x = pos_x;
                g_settings.position.y = pos_y;
                settings.save();
            end
        end
        
        imgui.End();
    end
end

-- This function draws the config window
local function render_config()
    if not g_show_config[1] then return; end
    
    if imgui.Begin('Odysegs Config', g_show_config, ImGuiWindowFlags_AlwaysAutoResize) then
        -- Segments value
        local segments = { g_settings.segments };
        if imgui.InputInt('Segments', segments) then
            g_settings.segments = segments[1];
            settings.save();
        end
        
        -- Show last amount checkbox
        if imgui.Checkbox('Show Last Received Amount', { g_settings.show_last_amount }) then
            g_settings.show_last_amount = not g_settings.show_last_amount;
            settings.save();
        end
        
        -- Font scale
        local font_scale = { g_settings.font_scale };
        if imgui.SliderFloat('Font Scale', font_scale, 0.5, 2.0, '%.1f') then
            g_settings.font_scale = font_scale[1];
            settings.save();
        end
        
        -- Color picker
        local color = { g_settings.color.r, g_settings.color.g, g_settings.color.b, g_settings.color.a };
        if imgui.ColorEdit4('Text Color', color) then
            g_settings.color.r = color[1];
            g_settings.color.g = color[2];
            g_settings.color.b = color[3];
            g_settings.color.a = color[4];
            settings.save();
        end
        
        imgui.End();
    end
end

-- Parse chat messages for Odyssey Segments updates
ashita.events.register('text_in', 'text_in_cb', function(e)
    -- Skip if the message is injected
    if e.injected then return; end
    
    -- Look for messages about receiving moogle segments
    -- Format: "You receive XX moogle segments for a total of YYYY."
    local amount, total = e.message:match("You receive (%d+) moogle segments for a total of (%d+)");
    if amount and total then
        amount = tonumber(amount);
        total = tonumber(total);
        if amount and total then
            g_last_amount = amount; -- Store the last received amount
            g_settings.segments = total; -- Set directly to the total
            settings.save();
            print(chat.header(addon.name):append(chat.message('Added ' .. amount .. ' segments. Total: ' .. g_settings.segments)));
        end
        return;
    end
    
    -- Also check for the original formats we expected
    local obtained = e.message:match("You obtain (%d+) Odyssey segment");
    if obtained then
        local amount = tonumber(obtained);
        if amount then
            g_last_amount = amount; -- Store the last received amount
            g_settings.segments = g_settings.segments + amount;
            settings.save();
            print(chat.header(addon.name):append(chat.message('Added ' .. amount .. ' segments. Total: ' .. g_settings.segments)));
        end
        return;
    end
    
    local spent = e.message:match("You spend (%d+) Odyssey segment");
    if spent then
        local amount = tonumber(spent);
        if amount then
            g_last_amount = -amount; -- Store as negative for spent amount
            g_settings.segments = g_settings.segments - amount;
            settings.save();
            print(chat.header(addon.name):append(chat.message('Spent ' .. amount .. ' segments. Total: ' .. g_settings.segments)));
        end
        return;
    end
    
    -- Also check for spending moogle segments
    local spent_moogle = e.message:match("You spend (%d+) moogle segments");
    if spent_moogle then
        local amount = tonumber(spent_moogle);
        if amount then
            g_last_amount = -amount; -- Store as negative for spent amount
            g_settings.segments = g_settings.segments - amount;
            settings.save();
            print(chat.header(addon.name):append(chat.message('Spent ' .. amount .. ' segments. Total: ' .. g_settings.segments)));
        end
        return;
    end
end);

-- Main loop
ashita.events.register('d3d_present', 'present_cb', function()
    render_ui();
    render_config();
end);

-- Command handler
ashita.events.register('command', 'command_cb', function(e)
    if not e or not e.command then return; end
    
    local args = e.command:args();
    if not args or #args == 0 then return; end
    
    if args[1] == '/odysegs' then
        e.blocked = true;
        
        if #args == 1 then
            -- Toggle window
            g_show_window[1] = not g_show_window[1];
        elseif #args == 2 and args[2] == 'config' then
            -- Toggle config window
            g_show_config[1] = not g_show_config[1];
        elseif #args == 2 and args[2] == 'help' then
            -- Show help
            print(chat.header(addon.name):append(chat.message('Commands:')));
            print(chat.header(addon.name):append(chat.message('/odysegs - Toggle the window')));
            print(chat.header(addon.name):append(chat.message('/odysegs config - Open the configuration window')));
            print(chat.header(addon.name):append(chat.message('/odysegs set <amount> - Set the segments to a specific amount')));
            print(chat.header(addon.name):append(chat.message('/odysegs add <amount> - Add segments')));
            print(chat.header(addon.name):append(chat.message('/odysegs sub <amount> - Subtract segments')));
        elseif #args == 3 and args[2] == 'set' and tonumber(args[3]) then
            -- Set segments
            g_settings.segments = tonumber(args[3]);
            settings.save();
            print(chat.header(addon.name):append(chat.message('Set segments to ' .. g_settings.segments)));
        elseif #args == 3 and args[2] == 'add' and tonumber(args[3]) then
            -- Add segments
            local amount = tonumber(args[3]);
            g_settings.segments = g_settings.segments + amount;
            g_last_amount = amount; -- Update last amount
            settings.save();
            print(chat.header(addon.name):append(chat.message('Added ' .. args[3] .. ' segments. Total: ' .. g_settings.segments)));
        elseif #args == 3 and args[2] == 'sub' and tonumber(args[3]) then
            -- Subtract segments
            local amount = tonumber(args[3]);
            g_settings.segments = g_settings.segments - amount;
            g_last_amount = -amount; -- Update last amount as negative
            settings.save();
            print(chat.header(addon.name):append(chat.message('Subtracted ' .. args[3] .. ' segments. Total: ' .. g_settings.segments)));
        end
    end
end);

-- Settings update callback
settings.register('settings', 'settings_update', function(s)
    if s ~= nil then
        g_settings = s;
    end
end);

-- Load message
ashita.events.register('load', 'load_cb', function()
    print(chat.header(addon.name):append(chat.message('Loaded! Type /odysegs to toggle window.')));
    print(chat.header(addon.name):append(chat.message('Type /odysegs config to open the configuration window.')));
    print(chat.header(addon.name):append(chat.message('Type /odysegs help for more commands.')));
end);
