-- settings.lua
local settings = {}

-- Default settings
settings.default = {
    show_notifications = true,
    show_gui = true,
    notification_color = true,
    track_skillups = true,
    track_history = true,
    max_history = 100,
    show_recipe_search = true,
    auto_update_skills = true,
}

-- Load settings from file
function settings.load()
    local settings_path = addon.path .. 'settings.json'
    local f = io.open(settings_path, 'r')
    if f then
        local data = f:read('*all')
        f:close()
        local success, loaded_settings = pcall(function()
            return ashita.settings.JSON:decode(data)
        end)
        if success and loaded_settings then
            -- Merge loaded settings with defaults
            for k, v in pairs(loaded_settings) do
                _G.craftassist.settings[k] = v
            end
            
            -- Load skills if present
            if loaded_settings.skills then
                for k, v in pairs(loaded_settings.skills) do
                    _G.craftassist.skills[k] = v
                end
            end
            
            -- Load history if present
            if loaded_settings.history then
                _G.craftassist.history = loaded_settings.history
            end
        end
    end
end

-- Save settings to file
function settings.save()
    if not _G.craftassist then return end
    
    local settings_path = addon.path .. 'settings.json'
    local save_data = {
        show_notifications = _G.craftassist.settings.show_notifications,
        show_gui = _G.craftassist.settings.show_gui,
        notification_color = _G.craftassist.settings.notification_color,
        track_skillups = _G.craftassist.settings.track_skillups,
        track_history = _G.craftassist.settings.track_history,
        max_history = _G.craftassist.settings.max_history,
        show_recipe_search = _G.craftassist.settings.show_recipe_search,
        auto_update_skills = _G.craftassist.settings.auto_update_skills,
        skills = _G.craftassist.skills,
        history = _G.craftassist.history,
    }
    
    pcall(function()
        local f = io.open(settings_path, 'w+')
        if f then
            f:write(ashita.settings.JSON:encode(save_data, nil, { pretty = true }))
            f:close()
        end
    end)
end

return settings