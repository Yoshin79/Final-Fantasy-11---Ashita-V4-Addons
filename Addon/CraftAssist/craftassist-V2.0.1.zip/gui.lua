-- gui.lua
local gui = {}
local imgui = require('imgui')
local chat = require('chat')

-- GUI state for auto-craft
gui.autocraft_state = {
    crystal_input = { '' },
    ingredient_inputs = { '', '', '', '', '', '', '', '' },
    count_input = { 1 },
    selected_recipe = nil,
}

-- Initialize GUI
function gui.initialize()
    _G.craftassist.modules.helpers.message('CraftAssist loaded! Type /craft or /ca to toggle GUI')
end

-- Draw skills section
function gui.draw_skills()
    if imgui.CollapsingHeader('Crafting Skills', ImGuiTreeNodeFlags_DefaultOpen) then
        imgui.PushStyleVar(ImGuiStyleVar_CellPadding, { 10, 2 })
        
        if imgui.BeginTable('craftassist.skills', 2, ImGuiTableFlags_SizingStretchProp) then
            -- Setup columns with proper widths
            imgui.TableSetupColumn('Left', ImGuiTableColumnFlags_WidthStretch, 1.0)
            imgui.TableSetupColumn('Right', ImGuiTableColumnFlags_WidthStretch, 1.0)
            
            -- Load constants for rank/uncap info
            local constants = require('constants')
            
            for id = 1, 8 do
                imgui.TableNextColumn()
                local skill_name = _G.craftassist.modules.helpers.skill_names[id]
                local skill_level = { _G.craftassist.skills[id] }
                local current_skill = skill_level[1]
                
                -- Display: Skill Name (fixed width) then Value with [-][+] buttons
                imgui.AlignTextToFramePadding()
                
                -- Display skill name with fixed width for alignment
                imgui.Text(skill_name)
                imgui.SameLine()
                
                -- Calculate spacing needed to align all value fields
                local text_width = imgui.CalcTextSize(skill_name)
                local target_width = 100 -- Fixed position for all value fields
                local spacing = target_width - text_width
                if spacing > 0 then
                    imgui.Dummy({ spacing, 0 })
                    imgui.SameLine()
                end
                
                -- Display the value with input field and +/- buttons
                imgui.PushItemWidth(100) -- Width for value + buttons
                if imgui.InputFloat(string.format('##skill_%d', id), skill_level, 0.1, 1.0, '%.1f') then
                    _G.craftassist.skills[id] = skill_level[1]
                end
                imgui.PopItemWidth()
                
                -- Show rank and uncap item info on same line
                imgui.SameLine()
                local rank_name = constants.get_rank_name(current_skill)
                local uncap_item = constants.get_uncap_item(skill_name, current_skill)
                
                if uncap_item then
                    imgui.TextColored({ 1.0, 0.8, 0.2, 1.0 }, string.format('[%s - Uncap: %s]', rank_name, uncap_item))
                    if imgui.IsItemHovered() then
                        imgui.SetTooltip(string.format('Turn in %s to uncap %s', uncap_item, skill_name))
                    end
                else
                    imgui.TextColored({ 0.7, 0.7, 0.7, 1.0 }, string.format('[%s]', rank_name))
                end
            end
            imgui.EndTable()
        end
        
        imgui.PopStyleVar()
        
        if imgui.Button('Refresh Skills') then
            local player = AshitaCore:GetMemoryManager():GetPlayer()
            if player then
                local skills_loaded = 0
                for id = 1, 8 do
                    local skill_data = player:GetCraftSkill(id)
                    if skill_data then
                        local skill_level = skill_data:GetSkill()
                        if skill_level > 0 then
                            _G.craftassist.skills[id] = skill_level
                            skills_loaded = skills_loaded + 1
                        end
                    end
                end
                
                if skills_loaded > 0 then
                    _G.craftassist.modules.helpers.success(string.format('Loaded %d skill levels from game!', skills_loaded))
                else
                    _G.craftassist.modules.helpers.error('No skills found')
                end
            else
                _G.craftassist.modules.helpers.error('Player not available')
            end
        end
        
        imgui.SameLine()
        
        if imgui.Button('Save Skills') then
            _G.craftassist.modules.settings.save()
            _G.craftassist.modules.helpers.success('Skills saved!')
        end
    end
end

-- Draw recipe search section
function gui.draw_recipe_search()
    if not _G.craftassist.settings.show_recipe_search then
        return
    end
    
    if imgui.CollapsingHeader('Recipe Search') then
        -- Search input
        if imgui.InputText('Search', _G.craftassist.gui.recipe_filter, 256) then
            local filter = _G.craftassist.gui.recipe_filter[1]:lower()
            if filter and filter ~= '' and #filter >= 2 then
                _G.craftassist.gui.search_results = _G.craftassist.modules.recipes.search(filter)
            else
                _G.craftassist.gui.search_results = {}
            end
        end
        
        imgui.SameLine()
        if imgui.Button('Clear') then
            _G.craftassist.gui.recipe_filter[1] = ''
            _G.craftassist.gui.search_results = {}
        end
        
        -- Display search results
        local results = _G.craftassist.gui.search_results
        if results and #results > 0 then
            local display_count = math.min(20, #results)
            imgui.Text(string.format('Showing %d of %d results', display_count, #results))
            
            imgui.BeginChild('recipe_results', { 0, 300 }, true)
            
            local res = AshitaCore:GetResourceManager()
            local inv = _G.craftassist.modules.helpers.get_inventory_totals()
            
            for i = 1, display_count do
                local result = results[i]
                local recipe = result.recipe
                local item = res:GetItemById(recipe.result)
                
                if item then
                    imgui.PushID(string.format('recipe_%d_%d', recipe.result, i))
                    
                    if imgui.TreeNode(string.format('%s x%d', item.LogNameSingular[1], recipe.count or 1)) then
                        -- Show skill requirements
                        if recipe.skills then
                            for skill_id, skill_level in ipairs(recipe.skills) do
                                if skill_level > 0 then
                                    local player_skill = _G.craftassist.skills[skill_id]
                                    local can_craft = (player_skill + 14) >= skill_level
                                    local color = can_craft and { 0, 1, 0, 1 } or { 1, 0, 0, 1 }
                                    
                                    imgui.TextColored(color, string.format('  %s: %d (You: %.1f)', 
                                        _G.craftassist.modules.helpers.skill_names[skill_id],
                                        skill_level,
                                        player_skill))
                                end
                            end
                        end
                        
                        -- Add to Auto-Craft button - right after skill requirements
                        if imgui.Button('Add to Auto-Craft', { 160, 25 }) then
                            -- Set crystal
                            if recipe.crystal then
                                gui.autocraft_state.crystal_input[1] = tostring(recipe.crystal)
                            end
                            
                            -- Initialize quantity inputs if not exists
                            if not gui.autocraft_state.ingredient_quantities then
                                gui.autocraft_state.ingredient_quantities = {}
                                for j = 1, 8 do
                                    gui.autocraft_state.ingredient_quantities[j] = { 1 }
                                end
                            end
                            
                            -- Clear all ingredient fields first
                            for j = 1, 8 do
                                gui.autocraft_state.ingredient_inputs[j] = ''
                                gui.autocraft_state.ingredient_quantities[j][1] = 1
                            end
                            
                            -- Set ingredients with quantities
                            if recipe.ingredients then
                                -- Count occurrences of each ingredient
                                local ingredient_counts = {}
                                for _, ing_id in ipairs(recipe.ingredients) do
                                    ingredient_counts[ing_id] = (ingredient_counts[ing_id] or 0) + 1
                                end
                                
                                -- Fill in unique ingredients with their quantities
                                local field_index = 1
                                for ing_id, count in pairs(ingredient_counts) do
                                    if field_index <= 8 then
                                        gui.autocraft_state.ingredient_inputs[field_index] = tostring(ing_id)
                                        gui.autocraft_state.ingredient_quantities[field_index][1] = count
                                        field_index = field_index + 1
                                    end
                                end
                            end
                            
                            -- Set the selected recipe for reference
                            gui.autocraft_state.selected_recipe = recipe
                            
                            _G.craftassist.modules.helpers.success('Recipe added to Auto-Craft section!')
                            _G.craftassist.modules.helpers.message('Check the Auto-Craft section - ingredients with quantities filled in!')
                        end
                        
                        -- Show crystal
                        if recipe.crystal then
                            local crystal_item = res:GetItemById(recipe.crystal)
                            if crystal_item then
                                local crystal_count = inv[recipe.crystal] or 0
                                imgui.Text(string.format('  Crystal: %s (ID: %d, Have: %d)', 
                                    crystal_item.LogNameSingular[1], recipe.crystal, crystal_count))
                            end
                        end
                        
                        -- Show ingredients
                        if recipe.ingredients then
                            imgui.Text('  Ingredients:')
                            for _, ing_id in ipairs(recipe.ingredients) do
                                local ing_item = res:GetItemById(ing_id)
                                if ing_item then
                                    local ing_count = inv[ing_id] or 0
                                    imgui.Text(string.format('    %s (ID: %d, Have: %d)', 
                                        ing_item.LogNameSingular[1], ing_id, ing_count))
                                end
                            end
                        end
                        
                        -- Add crafting buttons
                        imgui.Separator()
                        
                        -- Craft x1 button
                        if imgui.Button('Craft x1', { 80, 25 }) then
                            AshitaCore:GetChatManager():QueueCommand(1, '/lastsynth')
                            _G.craftassist.modules.helpers.message('Using /lastsynth - make sure this is your last craft!')
                        end
                        
                        imgui.SameLine()
                        
                        -- Auto-Craft button
                        local autocraft = _G.craftassist.modules.autocraft
                        local is_this_recipe_running = autocraft.state.enabled and 
                            gui.autocraft_state.selected_recipe and 
                            gui.autocraft_state.selected_recipe.result == recipe.result
                        
                        -- Check if ANY auto-craft is running (not just this recipe)
                        local is_any_autocraft_running = autocraft.state.enabled
                        
                        if not is_any_autocraft_running then
                            if imgui.Button('Auto-Craft', { 100, 25 }) then
                                -- Set this as the selected recipe
                                gui.autocraft_state.selected_recipe = recipe
                                
                                -- Set crystal and ingredients (using consolidation logic)
                                if recipe.crystal then
                                    gui.autocraft_state.crystal_input[1] = tostring(recipe.crystal)
                                end
                                
                                -- Initialize quantity inputs if not exists
                                if not gui.autocraft_state.ingredient_quantities then
                                    gui.autocraft_state.ingredient_quantities = {}
                                    for j = 1, 8 do
                                        gui.autocraft_state.ingredient_quantities[j] = { 1 }
                                    end
                                end
                                
                                -- Clear all ingredient fields first
                                for j = 1, 8 do
                                    gui.autocraft_state.ingredient_inputs[j] = ''
                                    gui.autocraft_state.ingredient_quantities[j][1] = 1
                                end
                                
                                -- Set ingredients with quantities (consolidated)
                                if recipe.ingredients then
                                    -- Count occurrences of each ingredient
                                    local ingredient_counts = {}
                                    for _, ing_id in ipairs(recipe.ingredients) do
                                        ingredient_counts[ing_id] = (ingredient_counts[ing_id] or 0) + 1
                                    end
                                    
                                    -- Fill in unique ingredients with their quantities
                                    local field_index = 1
                                    for ing_id, count in pairs(ingredient_counts) do
                                        if field_index <= 8 then
                                            gui.autocraft_state.ingredient_inputs[field_index] = tostring(ing_id)
                                            gui.autocraft_state.ingredient_quantities[field_index][1] = count
                                            field_index = field_index + 1
                                        end
                                    end
                                end
                                
                                -- Start auto-craft immediately since we have recipe data
                                local crystal_id = recipe.crystal
                                local ingredient_ids = recipe.ingredients or {}
                                _G.craftassist.modules.helpers.success('Starting auto-craft with recipe data!')
                                _G.craftassist.modules.helpers.message('IMPORTANT: Manually perform the first synth now!')
                                autocraft.start(crystal_id, ingredient_ids, 999999)
                            end
                            
                            imgui.SameLine()
                            
                            -- Auto Last button - starts auto-craft using /lastsynth without needing to select recipe
                            if imgui.Button('Auto Last', { 90, 25 }) then
                                -- Start auto-craft using /lastsynth (no validation)
                                autocraft.start_lastsynth()
                            end
                            
                            
                        else
                            -- Show Stop button when any auto-craft is running
                            if imgui.Button('Stop', { 100, 25 }) then
                                autocraft.stop()
                            end
                        end
                        
                        -- Note: Auto-craft will continue until materials run out or stopped manually
                        
                        imgui.TreePop()
                    end
                    
                    imgui.PopID()
                end
            end
            
            imgui.EndChild()
        elseif _G.craftassist.gui.recipe_filter[1] ~= '' then
            imgui.Text('No recipes found. Try a different search term.')
        end
    end
end

-- Draw history section
function gui.draw_history()
    if not _G.craftassist.settings.track_history then
        return
    end
    
    if imgui.CollapsingHeader('Craft History') then
        if imgui.Button('Clear History') then
            _G.craftassist.history = {}
        end
        
        if #_G.craftassist.history == 0 then
            imgui.Text('No craft history yet.')
            return
        end
        
        imgui.BeginChild('history', { 0, 300 }, true)
        
        if imgui.BeginTable('craftassist.history', 3, ImGuiTableFlags_ScrollY) then
            imgui.TableSetupScrollFreeze(0, 1)
            imgui.TableSetupColumn('Item', ImGuiTableColumnFlags_NoHide)
            imgui.TableSetupColumn('Result', ImGuiTableColumnFlags_NoHide)
            imgui.TableSetupColumn('Skillups', ImGuiTableColumnFlags_NoHide)
            imgui.TableHeadersRow()
            
            local res = AshitaCore:GetResourceManager()
            
            for i, synth in ipairs(_G.craftassist.history) do
                imgui.TableNextRow()
                
                -- Item name
                imgui.TableNextColumn()
                local item_name = 'Unknown'
                if synth.item and synth.item > 0 then
                    local item = res:GetItemById(synth.item)
                    if item then
                        item_name = item.Name[1]
                    end
                end
                
                if synth.count and synth.count > 1 then
                    imgui.Text(string.format('%s x%d', item_name, synth.count))
                else
                    imgui.Text(item_name)
                end
                
                -- Result
                imgui.TableNextColumn()
                local result_info = _G.craftassist.modules.helpers.get_result_quality(synth.result or 0)
                
                -- Color code based on result
                if result_info.short == 'HQ1' then
                    imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, result_info.short) -- Green
                elseif result_info.short == 'HQ2' then
                    imgui.TextColored({ 0.8, 0.0, 1.0, 1.0 }, result_info.short) -- Purple
                elseif result_info.short == 'HQ3' then
                    imgui.TextColored({ 1.0, 0.84, 0.0, 1.0 }, result_info.short) -- Gold
                else
                    imgui.Text(result_info.short) -- White (NQ, Break, etc.)
                end
                
                -- Skillups
                imgui.TableNextColumn()
                if synth.skillups and next(synth.skillups) then
                    local skillup_parts = {}
                    for skill_id, info in pairs(synth.skillups) do
                        if info.change and info.change ~= 0 then
                            table.insert(skillup_parts, string.format('%s %+.1f', 
                                _G.craftassist.modules.helpers.skill_abbr[skill_id], info.change))
                        end
                    end
                    if #skillup_parts > 0 then
                        imgui.Text(table.concat(skillup_parts, ' '))
                    end
                end
            end
            
            imgui.EndTable()
        end
        
        imgui.EndChild()
    end
end

-- Draw auto-craft section
function gui.draw_autocraft()
    if imgui.CollapsingHeader('Auto-Craft', ImGuiTreeNodeFlags_DefaultOpen) then
        local autocraft = _G.craftassist.modules.autocraft
        
        -- Status display
        if autocraft.state.enabled then
            if autocraft.state.current_count == 0 and not autocraft.state.first_synth_done then
                if gui.autocraft_state.selected_recipe then
                    imgui.TextColored({ 0, 1, 0, 1 }, 'Status: Auto-crafting with recipe data...')
                else
                    imgui.TextColored({ 1, 1, 0, 1 }, 'Status: Waiting for first synth...')
                    imgui.TextColored({ 1, 0.5, 0, 1 }, 'Perform the synth manually now!')
                end
            else
                imgui.TextColored({ 0, 1, 0, 1 }, string.format('Status: Running (%d/%d)', 
                    autocraft.state.current_count, autocraft.state.target_count))
            end
        else
            imgui.TextColored({ 1, 1, 1, 1 }, 'Status: Idle')
        end
        
        imgui.Separator()
        
        -- Show selected recipe info if available
        if gui.autocraft_state.selected_recipe then
            local res = AshitaCore:GetResourceManager()
            local recipe = gui.autocraft_state.selected_recipe
            local item = res:GetItemById(recipe.result)
            if item then
                imgui.TextColored({ 0, 1, 1, 1 }, string.format('Selected Recipe: %s x%d', 
                    item.LogNameSingular[1], recipe.count or 1))
                
                if imgui.Button('Clear Selection', { 120, 20 }) then
                    gui.autocraft_state.selected_recipe = nil
                    gui.autocraft_state.crystal_input[1] = ''
                    for j = 1, 8 do
                        gui.autocraft_state.ingredient_inputs[j] = ''
                    end
                end
                imgui.Separator()
            end
        end
        
        -- Crystal ID input
        imgui.Text('Crystal:')
        imgui.SameLine()
           local crystals = require('crystals')
           local current_crystal_id = tonumber(gui.autocraft_state.crystal_input[1]) or 0
           local current_crystal_name = crystals.get_name_by_id(current_crystal_id)
           if current_crystal_id == 0 then
           current_crystal_name = "Select Crystal..."
           end
           
           if imgui.BeginCombo('##crystal_combo', current_crystal_name) then
           for _, crystal in ipairs(crystals.data) do
           local is_selected = (current_crystal_id == crystal.id)
           if imgui.Selectable(crystal.name, is_selected) then
           gui.autocraft_state.crystal_input[1] = tostring(crystal.id)
           end
           end
           imgui.EndCombo()
           end
        
        -- Ingredient inputs
        imgui.Text('Ingredients:')
        
        -- Initialize quantity inputs if not exists
        if not gui.autocraft_state.ingredient_quantities then
            gui.autocraft_state.ingredient_quantities = {}
            for i = 1, 8 do
                gui.autocraft_state.ingredient_quantities[i] = { 1 }
            end
        end
        
        for i = 1, 8 do
            imgui.PushID(string.format('ing_%d', i))
            imgui.Text(string.format('%d:', i))
            imgui.SameLine()
            
            -- Item ID input (smaller width)
            imgui.PushItemWidth(80)
            if imgui.InputText('##ingredient', { gui.autocraft_state.ingredient_inputs[i] }, 32) then
                -- Input updated
            end
            imgui.PopItemWidth()
            
            -- Show ingredient name if ID is valid
            imgui.SameLine()
            local ing_id = tonumber(gui.autocraft_state.ingredient_inputs[i])
            if ing_id and ing_id > 0 then
                local res = AshitaCore:GetResourceManager()
                local ing_item = res:GetItemById(ing_id)
                if ing_item then
                    imgui.Text(string.format('(%s)', ing_item.LogNameSingular[1]))
                else
                    imgui.Text('(Unknown Item)')
                end
            else
                imgui.Text('(Enter Item ID)')
            end
            
            imgui.SameLine()
            imgui.Text(' x')
            imgui.SameLine()
            
            -- Quantity input (wider for better visibility)
            imgui.PushItemWidth(80)
            if imgui.InputInt('##qty', gui.autocraft_state.ingredient_quantities[i], 1, 1) then
                if gui.autocraft_state.ingredient_quantities[i][1] < 1 then
                    gui.autocraft_state.ingredient_quantities[i][1] = 1
                end
            end
            imgui.PopItemWidth()
            
            imgui.PopID()
        end
        
        imgui.TextColored({ 1, 1, 0, 1 }, 'Tip: Search for a recipe below and click "Use This Recipe"')
        
        -- Count input
        imgui.Text('Number of Synths:')
        imgui.SameLine()
        if imgui.InputInt('##count', gui.autocraft_state.count_input, 1, 10) then
            if gui.autocraft_state.count_input[1] < 1 then
                gui.autocraft_state.count_input[1] = 1
            end
        end
        
        -- Delay input
        local delay = { autocraft.state.synth_delay }
        if imgui.SliderFloat('Delay (seconds)', delay, 15.0, 30.0, '%.1f') then
            autocraft.state.synth_delay = delay[1]
        end
        if imgui.IsItemHovered() then
            imgui.SetTooltip('Delay between synths (22 seconds recommended for /lastsynth)')
        end
        
        imgui.Separator()
        
        -- Control buttons
        if not autocraft.state.enabled then
            if imgui.Button('Start Auto-Craft', { 150, 30 }) then
                -- Parse crystal ID
                local crystal_id = tonumber(gui.autocraft_state.crystal_input[1])
                if not crystal_id then
                    _G.craftassist.modules.helpers.error('Invalid crystal ID')
                else
                    -- Parse ingredient IDs
                    local ingredient_ids = {}
                    for i = 1, 8 do
                        local ing_str = gui.autocraft_state.ingredient_inputs[i]
                        if ing_str and ing_str ~= '' then
                            local ing_id = tonumber(ing_str)
                            if ing_id then
                                table.insert(ingredient_ids, ing_id)
                            end
                        end
                    end
                    
                    -- Check if we have a selected recipe (from "Add to Auto-Craft" button)
                    if gui.autocraft_state.selected_recipe then
                        -- We have recipe data, start auto-craft (requires manual first synth)
                        _G.craftassist.modules.helpers.success('Starting auto-craft with recipe data!')
                        _G.craftassist.modules.helpers.message('IMPORTANT: Manually perform the first synth now!')
                        _G.craftassist.modules.helpers.message('The addon will automatically repeat it using /lastsynth')
                        autocraft.start(crystal_id, ingredient_ids, gui.autocraft_state.count_input[1])
                    else
                        -- No recipe data, use normal approach (requires manual first craft)
                        autocraft.start(crystal_id, ingredient_ids, gui.autocraft_state.count_input[1])
                    end
                end
            end
        else
            if imgui.Button('Stop Auto-Craft', { 150, 30 }) then
                autocraft.stop()
            end
        end
        
        imgui.SameLine()
        
        if imgui.Button('Load from Recipe', { 150, 30 }) then
            imgui.OpenPopup('Load Recipe')
        end
        
        -- Recipe selection popup
        if imgui.BeginPopup('Load Recipe') then
            imgui.Text('Select a recipe from Recipe Search section')
            imgui.Text('This feature will be enhanced in future updates')
            if imgui.Button('Close') then
                imgui.CloseCurrentPopup()
            end
            imgui.EndPopup()
        end
        
        imgui.Separator()
        
        -- Help text
        imgui.TextColored({ 1, 1, 0, 1 }, 'HOW AUTO-CRAFT WORKS:')
        imgui.TextWrapped('EASY METHOD:')
        imgui.TextWrapped('1. Search for a recipe in Recipe Search section')
        imgui.TextWrapped('2. Click "Add to Auto-Craft" on the recipe')
        imgui.TextWrapped('3. Click "Start Auto-Craft" - starts immediately!')
        imgui.TextWrapped('')
        imgui.TextWrapped('MANUAL METHOD:')
        imgui.TextWrapped('1. Select crystal and enter ingredient IDs manually')
        imgui.TextWrapped('2. Click "Start Auto-Craft"')
        imgui.TextWrapped('3. Manually perform the first synth in-game')
        imgui.TextWrapped('4. Addon will automatically repeat using /lastsynth!')
        imgui.Separator()
        imgui.TextColored({ 0, 1, 1, 1 }, 'TIP: Use Recipe Search below to auto-fill everything!')
        
        if imgui.Button('Common Crystal IDs') then
            imgui.OpenPopup('Crystal ID Help')
        end
        
        if imgui.BeginPopup('Crystal ID Help') then
            imgui.Text('Common Crystals:')
            imgui.Separator()
            imgui.BulletText('Fire: 4096')
            imgui.BulletText('Ice: 4097')
            imgui.BulletText('Wind: 4098')
            imgui.BulletText('Earth: 4099')
            imgui.BulletText('Lightning: 4100')
            imgui.BulletText('Water: 4101')
            imgui.BulletText('Light: 4102')
            imgui.BulletText('Dark: 4103')
            imgui.Separator()
            imgui.Text('Finding Other Item IDs:')
            imgui.BulletText('Use Recipe Search below')
            imgui.BulletText('Check FFXIAH.com or FFXIDB.com')
            imgui.BulletText('Use /itemsearch in-game')
            if imgui.Button('Close') then
                imgui.CloseCurrentPopup()
            end
            imgui.EndPopup()
        end
    end
end

-- Draw settings section
function gui.draw_settings()
    if imgui.CollapsingHeader('Settings') then
        local show_notifications = { _G.craftassist.settings.show_notifications }
        if imgui.Checkbox('Show Notifications', show_notifications) then
            _G.craftassist.settings.show_notifications = show_notifications[1]
        end
        
        local notification_color = { _G.craftassist.settings.notification_color }
        if imgui.Checkbox('Colored Notifications', notification_color) then
            _G.craftassist.settings.notification_color = notification_color[1]
        end
        
        local track_skillups = { _G.craftassist.settings.track_skillups }
        if imgui.Checkbox('Track Skillups', track_skillups) then
            _G.craftassist.settings.track_skillups = track_skillups[1]
        end
        
        local track_history = { _G.craftassist.settings.track_history }
        if imgui.Checkbox('Track History', track_history) then
            _G.craftassist.settings.track_history = track_history[1]
        end
        
        local auto_update_skills = { _G.craftassist.settings.auto_update_skills }
        if imgui.Checkbox('Auto-Update Skills', auto_update_skills) then
            _G.craftassist.settings.auto_update_skills = auto_update_skills[1]
        end
        
        local show_recipe_search = { _G.craftassist.settings.show_recipe_search }
        if imgui.Checkbox('Show Recipe Search', show_recipe_search) then
            _G.craftassist.settings.show_recipe_search = show_recipe_search[1]
        end
        
        local max_history = { _G.craftassist.settings.max_history }
        if imgui.SliderInt('Max History', max_history, 10, 500) then
            _G.craftassist.settings.max_history = max_history[1]
        end
        
        if imgui.Button('Save Settings') then
            _G.craftassist.modules.settings.save()
            _G.craftassist.modules.helpers.success('Settings saved!')
        end
    end
end

-- Main render function
function gui.render()
    if not _G.craftassist.gui.is_open[1] then
        return
    end
    
    -- Update autocraft
    if _G.craftassist.modules.autocraft then
        _G.craftassist.modules.autocraft.update()
    end
    
    imgui.SetNextWindowSize({ 600, 800 }, ImGuiCond_FirstUseEver)
    
    if imgui.Begin('CraftAssist v' .. addon.version, _G.craftassist.gui.is_open, ImGuiWindowFlags_None) then
        gui.draw_autocraft()
        imgui.Separator()
        gui.draw_skills()
        imgui.Separator()
        gui.draw_recipe_search()
        imgui.Separator()
        gui.draw_history()
        imgui.Separator()
        gui.draw_settings()
    end
    imgui.End()
end

return gui