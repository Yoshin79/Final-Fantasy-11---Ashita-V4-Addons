-- helpers.lua
local helpers = {}
local chat = require('chat')

-- Skill names mapping
helpers.skill_names = {
    [1] = 'Woodworking',
    [2] = 'Smithing',
    [3] = 'Goldsmithing',
    [4] = 'Clothcraft',
    [5] = 'Leathercraft',
    [6] = 'Bonecraft',
    [7] = 'Alchemy',
    [8] = 'Cooking',
}

-- Skill abbreviations
helpers.skill_abbr = {
    [1] = 'CRP',
    [2] = 'BSM',
    [3] = 'GSM',
    [4] = 'WVR',
    [5] = 'LTW',
    [6] = 'BON',
    [7] = 'ALC',
    [8] = 'CUL',
}

-- Result quality mapping
helpers.result_quality = {
    [0] = { color = 1, text = 'Normal Quality', short = 'NQ' },
    [1] = { color = 39, text = 'Break', short = 'Fail' },
    [2] = { color = 5, text = 'High-Quality', short = 'HQ1' },
    [3] = { color = 5, text = 'High-Quality +1', short = 'HQ2' },
    [4] = { color = 5, text = 'High-Quality +2', short = 'HQ3' },
}

-- Get result quality info
function helpers.get_result_quality(res)
    return helpers.result_quality[res] or { color = 4, text = string.format('Unknown Quality (%d)', res), short = 'Unknown' }
end

-- Print message
function helpers.message(text)
    print(chat.header(addon.name):append(chat.message(text)))
end

-- Print error
function helpers.error(text)
    print(chat.header(addon.name):append(chat.error(text)))
end

-- Print success
function helpers.success(text)
    print(chat.header(addon.name):append(chat.success(text)))
end

-- Print help
function helpers.print_help()
    helpers.message('Available commands:')
    local cmds = {
        { '/craft or /ca', 'Toggle the GUI window' },
        { '/craft help', 'Show this help message' },
        { '/craft refresh', 'Reload skills from game (open crafting menu first)' },
        { '/craft history', 'Show craft history in chat' },
        { '/craft clear', 'Clear craft history' },
        { '/craft skills', 'Show current skill levels' },
        { '/craft notify', 'Toggle notifications' },
        { '/craft save', 'Save current settings' },
        { '/craft start <crystal> <ing1> [ing2...]', 'Start auto-craft with IDs' },
        { '/craft stop', 'Stop auto-craft' },
    }
    
    for _, cmd in ipairs(cmds) do
        helpers.message(string.format('  %s - %s', cmd[1], cmd[2]))
    end
end

-- Show skills in chat
function helpers.show_skills()
    helpers.message('Current Crafting Skills:')
    for id = 1, 8 do
        local skill_name = helpers.skill_names[id]
        local skill_level = _G.craftassist.skills[id]
        helpers.message(string.format('  %s: %.1f', skill_name, skill_level))
    end
end

-- Show history in chat
function helpers.show_history()
    if #_G.craftassist.history == 0 then
        helpers.message('No craft history available.')
        return
    end
    
    helpers.message('Recent Craft History:')
    local res = AshitaCore:GetResourceManager()
    local count = math.min(10, #_G.craftassist.history)
    
    for i = 1, count do
        local synth = _G.craftassist.history[i]
        local item_name = 'Unknown'
        if synth.item and synth.item > 0 then
            local item = res:GetItemById(synth.item)
            if item then
                item_name = item.Name[1]
            end
        end
        
        local result_info = helpers.get_result_quality(synth.result or 0)
        local skillup_text = ''
        
        if synth.skillups and next(synth.skillups) then
            local skillup_parts = {}
            for skill_id, change in pairs(synth.skillups) do
                if change ~= 0 then
                    table.insert(skillup_parts, string.format('%s %+.1f', helpers.skill_abbr[skill_id], change))
                end
            end
            if #skillup_parts > 0 then
                skillup_text = ' [' .. table.concat(skillup_parts, ', ') .. ']'
            end
        end
        
        helpers.message(string.format('  %s x%d - %s%s', item_name, synth.count or 1, result_info.short, skillup_text))
    end
end

-- Handle commands
function helpers.handle_command(e)
    local args = e.command:args()
    if #args == 0 or not args[1]:any('/craft', '/ca') then
        return
    end
    
    e.blocked = true
    
    -- No arguments - toggle GUI
    if #args == 1 then
        _G.craftassist.gui.is_open[1] = not _G.craftassist.gui.is_open[1]
        return
    end
    
    -- Handle subcommands
    local subcmd = args[2]:lower()
    
    if subcmd == 'help' then
        helpers.print_help()
    elseif subcmd == 'skills' then
        helpers.show_skills()
    elseif subcmd == 'history' then
        helpers.show_history()
    elseif subcmd == 'clear' then
        _G.craftassist.history = {}
        helpers.success('Craft history cleared.')
    elseif subcmd == 'notify' then
        _G.craftassist.settings.show_notifications = not _G.craftassist.settings.show_notifications
        helpers.message(string.format('Notifications %s', _G.craftassist.settings.show_notifications and 'enabled' or 'disabled'))
    elseif subcmd == 'save' then
        _G.craftassist.modules.settings.save()
        helpers.success('Settings saved.')
    elseif subcmd == 'start' then
        if #args < 4 then
            helpers.error('Usage: /craft start <crystal_id> <ingredient1> [ingredient2] ...')
            return
        end
        
        local crystal_id = tonumber(args[3])
        if not crystal_id then
            helpers.error('Invalid crystal ID')
            return
        end
        
        local ingredients = {}
        for i = 4, #args do
            local ing_id = tonumber(args[i])
            if ing_id then
                table.insert(ingredients, ing_id)
            end
        end
        
        if #ingredients == 0 then
            helpers.error('No valid ingredients provided')
            return
        end
        
        _G.craftassist.modules.autocraft.start(crystal_id, ingredients, 1)
    elseif subcmd == 'stop' then
        _G.craftassist.modules.autocraft.stop()
    elseif subcmd == 'refresh' or subcmd == 'reload' then
        local player = AshitaCore:GetMemoryManager():GetPlayer()
        if not player then 
            helpers.error('Player not available')
            return
        end
        
        helpers.message('=== Detailed Skill Debug ===')
        
        local skills_loaded = 0
        -- Game uses IDs 1-8 for the 8 crafts (0 is Fishing which we don't track)
        for id = 1, 8 do
            local skill_data = player:GetCraftSkill(id)
            if skill_data then
                local skill_level = skill_data:GetSkill()
                local skill_rank = skill_data:GetRank()
                local is_capped = skill_data:IsCapped()
                
                print(string.format('[DEBUG] Skill %d (%s): level=%s, rank=%s, capped=%s', 
                    id, 
                    helpers.skill_names[id] or 'Unknown',
                    tostring(skill_level),
                    tostring(skill_rank),
                    tostring(is_capped)))
                
                if skill_level and skill_level > 0 then
                    _G.craftassist.skills[id] = skill_level
                    skills_loaded = skills_loaded + 1
                    helpers.success(string.format('Loaded %s: %.1f', helpers.skill_names[id], skill_level))
                end
            else
                print(string.format('[DEBUG] Skill %d: skill_data is nil', id))
            end
        end
        
        helpers.message('=== End Debug ===')
        
        if skills_loaded > 0 then
            helpers.success(string.format('Total: Loaded %d skill levels from game!', skills_loaded))
        else
            helpers.error('No skills found - all returned 0 or nil')
        end
    else
        helpers.error('Unknown command. Use /craft help for available commands.')
    end
end

-- Get inventory totals
function helpers.get_inventory_totals()
    local inv = AshitaCore:GetMemoryManager():GetInventory()
    local cumulative = {}
    
    -- Scan main inventory
    for i = 1, inv:GetContainerCountMax(0) do
        local slot = inv:GetContainerItem(0, i)
        if slot and slot.Id > 0 then
            if cumulative[slot.Id] == nil then
                cumulative[slot.Id] = slot.Count
            else
                cumulative[slot.Id] = cumulative[slot.Id] + slot.Count
            end
        end
    end
    
    return cumulative
end

-- Handle chat messages for skill updates
function helpers.handle_chat_message(e)
    -- Check for skillup messages and synthesis canceled messages
    -- Format: "Cooking skill rises 0.1 points."
    -- Format: "Smithing skill rises 0.2 points."
    -- Format: "Synthesis canceled."
    
    local message = e.message_modified or e.message or e.message_string
    if not message then return end
    
    -- Strip color codes and special characters
    local clean_message = message:gsub('\x1E', ''):gsub('\x1F', ''):gsub('\x7F', ''):gsub('\x01', ''):gsub('\x02', '')
    
    -- Check for synthesis canceled message
    if clean_message:find('Synthesis canceled') then
        -- Stop auto-craft if running
        if _G.craftassist and _G.craftassist.modules and _G.craftassist.modules.autocraft then
            local autocraft = _G.craftassist.modules.autocraft
            if autocraft.state.enabled then
                autocraft.stop()
                helpers.error('Auto-craft stopped: Synthesis canceled (likely out of materials)')
                return
            end
        end
    end
    
    -- Check for skill level up message
    -- Matches: "Jfloss's cooking skill reaches level 38."
    local skill_name_level, level = clean_message:match("%w+'s (%w+) skill reaches level (%d+)%.?")
    if skill_name_level and level then
        local level_num = tonumber(level)
        if level_num then
            -- Map skill names to IDs (case-insensitive)
            local skill_map = {
                ['woodworking'] = 1,
                ['smithing'] = 2,
                ['goldsmithing'] = 3,
                ['clothcraft'] = 4,
                ['leathercraft'] = 5,
                ['bonecraft'] = 6,
                ['alchemy'] = 7,
                ['cooking'] = 8,
            }
            
            local skill_name_lower = skill_name_level:lower()
            local skill_id = skill_map[skill_name_lower]
            
            if skill_id and _G.craftassist and _G.craftassist.skills then
                local old_skill = _G.craftassist.skills[skill_id]
                _G.craftassist.skills[skill_id] = level_num
                
                helpers.message(string.format('%s reached level %d! (was %.1f)', 
                    skill_name_level, level_num, old_skill))
                return
            end
        end
    end
    
    -- Pattern to match skill rise messages with player name
    -- Matches: "Jfloss's cooking skill rises 0.1 points."
    local skill_name, points = clean_message:match("%w+'s (%w+) skill rises ([%d%.]+) points?%.?")
    
    if not skill_name or not points then
        -- Try pattern without player name
        -- Matches: "Cooking skill rises 0.1 points."
        skill_name, points = clean_message:match('(%w+) skill rises ([%d%.]+) points?%.?')
    end
    
    if not skill_name or not points then
        -- Try alternate pattern without period
        skill_name, points = clean_message:match('(%w+) skill rises ([%d%.]+) points?')
    end
    
    if skill_name and points then
        local points_num = tonumber(points)
        if not points_num then return end
        
        -- Map skill names to IDs (case-insensitive)
        local skill_map = {
            ['woodworking'] = 1,
            ['smithing'] = 2,
            ['goldsmithing'] = 3,
            ['clothcraft'] = 4,
            ['leathercraft'] = 5,
            ['bonecraft'] = 6,
            ['alchemy'] = 7,
            ['cooking'] = 8,
        }
        
        -- Convert skill name to lowercase for matching
        local skill_name_lower = skill_name:lower()
        local skill_id = skill_map[skill_name_lower]
        
        if skill_id and _G.craftassist and _G.craftassist.skills then
            -- Update the skill
            local old_skill = _G.craftassist.skills[skill_id]
            _G.craftassist.skills[skill_id] = old_skill + points_num
            
            -- Update history if there's a recent synth
            if #_G.craftassist.history > 0 then
                local latest = _G.craftassist.history[1]
                if not latest.skillups then
                    latest.skillups = {}
                end
                latest.skillups[skill_id] = {
                    allowed = true,
                    change = points_num,
                }
            end
            
            -- Print confirmation for skillups (using -> instead of → for compatibility)
            helpers.message(string.format('%s: %.1f -> %.1f (+%.1f)', 
                skill_name, old_skill, _G.craftassist.skills[skill_id], points_num))
        end
    end
end

return helpers