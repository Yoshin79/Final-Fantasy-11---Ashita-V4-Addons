-- constants.lua
local constants = {}

-- Rank names for skill levels
constants.rank_names = {
    { min = 0, max = 10, name = "Recruit" },
    { min = 11, max = 20, name = "Initiate" },
    { min = 21, max = 30, name = "Novice" },
    { min = 31, max = 40, name = "Apprentice" },
    { min = 41, max = 50, name = "Journeyman" },
    { min = 51, max = 60, name = "Craftsman" },
    { min = 61, max = 70, name = "Artisan" },
    { min = 71, max = 80, name = "Adept" },
    { min = 81, max = 90, name = "Veteran" },
    { min = 91, max = 100, name = "Expert" },
    { min = 101, max = 110, name = "Authority" },
}

-- Uncap items for each crafting skill based on level range
constants.uncap_items = {
    woodworking = {
        { range = {8, 10}, item = "Ash Lumber", rank = "Recruit" },
        { range = {18, 20}, item = "Elm Lumber", rank = "Initiate" },
        { range = {28, 30}, item = "Oak Lumber", rank = "Novice" },
        { range = {38, 40}, item = "Mahogany Lumber", rank = "Apprentice" },
        { range = {48, 50}, item = "Ebony Lumber", rank = "Journeyman" },
        { range = {58, 60}, item = "Lacquer Tree Lumber", rank = "Craftsman" },
        { range = {68, 70}, item = "Dogwood Lumber", rank = "Artisan" },
        { range = {78, 80}, item = "Rosewood Lumber", rank = "Adept" },
        { range = {88, 90}, item = "Shihei", rank = "Veteran" },
        { range = {98, 100}, item = "Lancewood Lumber", rank = "Expert" },
    },
    smithing = {
        { range = {8, 10}, item = "Xiphos", rank = "Recruit" },
        { range = {18, 20}, item = "Aspis", rank = "Initiate" },
        { range = {28, 30}, item = "Bilbo", rank = "Novice" },
        { range = {38, 40}, item = "War Pick", rank = "Apprentice" },
        { range = {48, 50}, item = "Mythril Pick", rank = "Journeyman" },
        { range = {58, 60}, item = "Darksteel Falchion", rank = "Craftsman" },
        { range = {68, 70}, item = "Bascinet", rank = "Artisan" },
        { range = {78, 80}, item = "Bastard Sword", rank = "Adept" },
        { range = {88, 90}, item = "Celata", rank = "Veteran" },
        { range = {98, 100}, item = "Gorkhali Kukri", rank = "Expert" },
    },
    goldsmithing = {
        { range = {8, 10}, item = "Copper Hairpin", rank = "Recruit" },
        { range = {18, 20}, item = "Brass Hairpin", rank = "Initiate" },
        { range = {28, 30}, item = "Silver Hairpin", rank = "Novice" },
        { range = {38, 40}, item = "Chain Gorget", rank = "Apprentice" },
        { range = {48, 50}, item = "Mythril Ring", rank = "Journeyman" },
        { range = {58, 60}, item = "Mythril Gorget", rank = "Craftsman" },
        { range = {68, 70}, item = "Mythril Breastplate", rank = "Artisan" },
        { range = {78, 80}, item = "Torque", rank = "Adept" },
        { range = {88, 90}, item = "Colichemarde", rank = "Veteran" },
        { range = {98, 100}, item = "Evader Earring", rank = "Expert" },
    },
    clothcraft = {
        { range = {8, 10}, item = "Cape", rank = "Recruit" },
        { range = {18, 20}, item = "Cotton Cape", rank = "Initiate" },
        { range = {28, 30}, item = "Heko Obi", rank = "Novice" },
        { range = {38, 40}, item = "Feather Collar", rank = "Apprentice" },
        { range = {48, 50}, item = "Wool Bracers", rank = "Journeyman" },
        { range = {58, 60}, item = "Red Cape", rank = "Craftsman" },
        { range = {68, 70}, item = "Wool Doublet", rank = "Artisan" },
        { range = {78, 80}, item = "Silk Cloak", rank = "Adept" },
        { range = {88, 90}, item = "Arhat's Hakama", rank = "Veteran" },
        { range = {98, 100}, item = "Swith Cape", rank = "Expert" },
    },
    leathercraft = {
        { range = {8, 10}, item = "Rabbit Mantle", rank = "Recruit" },
        { range = {18, 20}, item = "Lizard Cesti", rank = "Initiate" },
        { range = {28, 30}, item = "Dhalmel Mantle", rank = "Novice" },
        { range = {38, 40}, item = "Magic Belt", rank = "Apprentice" },
        { range = {48, 50}, item = "Cuir Bouilli", rank = "Journeyman" },
        { range = {58, 60}, item = "Raptor Jerkin", rank = "Craftsman" },
        { range = {68, 70}, item = "Battle Boots", rank = "Artisan" },
        { range = {78, 80}, item = "Tiger Gloves", rank = "Adept" },
        { range = {88, 90}, item = "Coeurl Mask", rank = "Veteran" },
        { range = {98, 100}, item = "Urja Trousers", rank = "Expert" },
    },
    bonecraft = {
        { range = {8, 10}, item = "Shell Ring", rank = "Recruit" },
        { range = {18, 20}, item = "Bone Ring", rank = "Initiate" },
        { range = {28, 30}, item = "Beetle Earring", rank = "Novice" },
        { range = {38, 40}, item = "Horn Ring", rank = "Apprentice" },
        { range = {48, 50}, item = "Carapace Gorget", rank = "Journeyman" },
        { range = {58, 60}, item = "Astragalos", rank = "Craftsman" },
        { range = {68, 70}, item = "Bone Patas", rank = "Artisan" },
        { range = {78, 80}, item = "Coral Hairpin", rank = "Adept" },
        { range = {88, 90}, item = "Coral Bangles", rank = "Veteran" },
        { range = {98, 100}, item = "Hajduk Ring", rank = "Expert" },
    },
    alchemy = {
        { range = {8, 10}, item = "Animal Glue", rank = "Recruit" },
        { range = {18, 20}, item = "Poison Potion", rank = "Initiate" },
        { range = {28, 30}, item = "Blinding Potion", rank = "Novice" },
        { range = {38, 40}, item = "Firesand", rank = "Apprentice" },
        { range = {48, 50}, item = "Fire Sword", rank = "Journeyman" },
        { range = {58, 60}, item = "Hi-Potion", rank = "Craftsman" },
        { range = {68, 70}, item = "Acid Kukri", rank = "Artisan" },
        { range = {78, 80}, item = "X-Potion", rank = "Adept" },
        { range = {88, 90}, item = "Bloody Sword", rank = "Veteran" },
        { range = {98, 100}, item = "Saida Ring", rank = "Expert" },
    },
    cooking = {
        { range = {8, 10}, item = "Salmon Sub Sandwich", rank = "Recruit" },
        { range = {18, 20}, item = "Pea Soup", rank = "Initiate" },
        { range = {28, 30}, item = "Vegetable Gruel", rank = "Novice" },
        { range = {38, 40}, item = "Meat Mithkabob", rank = "Apprentice" },
        { range = {48, 50}, item = "Apple Pie", rank = "Journeyman" },
        { range = {58, 60}, item = "Yagudo Drink", rank = "Craftsman" },
        { range = {68, 70}, item = "Raisin Bread", rank = "Artisan" },
        { range = {78, 80}, item = "Whitefish Stew", rank = "Adept" },
        { range = {88, 90}, item = "Seafood Stew", rank = "Veteran" },
        { range = {98, 100}, item = "Sprightly Soup", rank = "Expert" },
    },
}

-- Function to get rank name for a skill level
function constants.get_rank_name(skill_level)
    local level = math.floor(skill_level)
    for _, rank in ipairs(constants.rank_names) do
        if level >= rank.min and level <= rank.max then
            return rank.name
        end
    end
    return "Unknown"
end

-- Function to get uncap item for a skill
function constants.get_uncap_item(craft_name, skill_level)
    local uncap_data = constants.uncap_items[craft_name:lower()]
    if uncap_data then
        local level = math.floor(skill_level)
        for _, data in ipairs(uncap_data) do
            local min_level, max_level = data.range[1], data.range[2]
            -- Show uncap item if skill is in the range (e.g., 8-10, 18-20, etc.)
            if level >= min_level and level <= max_level then
                return data.item
            end
        end
    end
    return nil
end

return constants