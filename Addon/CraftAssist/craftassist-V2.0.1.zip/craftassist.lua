--[[
* Addons - Copyright (c) 2021 Ashita Development Team
* Contact: https://www.ashitaxi.com/
* Contact: https://discord.gg/Ashita
*
* This file is part of Ashita.
*
* Ashita is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Ashita is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with Ashita.  If not, see <https://www.gnu.org/licenses/>.
--]]

addon.name      = 'CraftAssist'
addon.author    = 'atom0s & RZN Crafty V3 along with mousseng xitools crafty updated and converted to standalone by Oneword and Ninja Ai'
addon.version   = '2.0.1'
addon.desc      = 'Comprehensive Crafting Assistant with Auto-Craft, Recipe Database, Skill Tracking, and History'

require('common')
local chat = require('chat')
local imgui = require('imgui')

-- Set up package path for our modules
package.path = package.path .. ';' .. addon.path .. '?.lua'

-- Load our modules
local settings = require('settings')
local gui = require('gui')
local packets = require('packets')
local recipes = require('recipes')
local helpers = require('helpers')
local autocraft = require('autocraft')

-- Create global state table
_G.craftassist = {
    settings = settings.default,
    gui = {
        is_open = { true },
        recipe_filter = { '' },
        search_results = {},
    },
    current_synth = nil,
    history = {},
    skills = {
        [1] = 0.0,  -- Woodworking
        [2] = 0.0,  -- Smithing
        [3] = 0.0,  -- Goldsmithing
        [4] = 0.0,  -- Clothcraft
        [5] = 0.0,  -- Leathercraft
        [6] = 0.0,  -- Bonecraft
        [7] = 0.0,  -- Alchemy
        [8] = 0.0,  -- Cooking
    },
}

-- Initialize modules
_G.craftassist.modules = {
    settings = settings,
    gui = gui,
    packets = packets,
    recipes = recipes,
    helpers = helpers,
    autocraft = autocraft,
}

-- Register event callbacks
-- Function to read actual skill levels from game memory
local function update_skills_from_game()
    local player = AshitaCore:GetMemoryManager():GetPlayer()
    if not player then 
        print('[CraftAssist DEBUG] Player not available yet')
        return 
    end
    
    print('[CraftAssist DEBUG] Reading skills from game...')
    
    -- Read each crafting skill from game memory
    local skills_loaded = 0
    for id = 0, 7 do -- Game uses 0-7 for skills
        local skill_data = player:GetCraftSkill(id)
        if skill_data then
            local skill_level = skill_data:GetSkill() -- Already returns actual level (38.0, not 380)
            
            print(string.format('[CraftAssist DEBUG] Skill %d: level=%.1f', id, skill_level))
            
            if skill_level > 0 then
                _G.craftassist.skills[id + 1] = skill_level -- We use 1-8
                skills_loaded = skills_loaded + 1
            end
        else
            print(string.format('[CraftAssist DEBUG] Skill %d: no data', id))
        end
    end
    
    if skills_loaded > 0 then
        helpers.message(string.format('Loaded %d skill levels from game!', skills_loaded))
    else
        helpers.message('No skills loaded - you may need to zone or check your skills in-game first')
    end
end

ashita.events.register('load', 'load_cb', function()
    -- Try to load saved settings first
    settings.load()
    
    -- Initialize GUI
    gui.initialize()
    
    print(chat.header(addon.name):append(chat.message('Loaded! Use /craft or /ca to toggle GUI')))
    print(chat.header(addon.name):append(chat.message('Skills will auto-update from game memory')))
end)

-- Removed auto-update - use "Refresh Skills" button or /craft refresh command instead

ashita.events.register('unload', 'unload_cb', function()
    -- Save settings on unload
    settings.save()
    
    -- Clear global state
    _G.craftassist = nil
end)

ashita.events.register('command', 'command_cb', helpers.handle_command)
ashita.events.register('d3d_present', 'present_cb', gui.render)
ashita.events.register('packet_in', 'packet_in_cb', packets.handle_incoming)
ashita.events.register('packet_out', 'packet_out_cb', packets.handle_outgoing)
ashita.events.register('text_in', 'text_in_cb', helpers.handle_chat_message)