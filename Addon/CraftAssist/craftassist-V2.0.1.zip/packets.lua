-- packets.lua
local packets = {}
local bit = require('bit')
local chat = require('chat')

-- Crystal mapping (NQ, HQ, and special crystals all map to base NQ crystal)
local crystal_map = {
    -- NQ crystals
    [4096] = 4096, [4097] = 4097, [4098] = 4098, [4099] = 4099,
    [4100] = 4100, [4101] = 4101, [4102] = 4102, [4103] = 4103,
    -- HQ crystals
    [4238] = 4096, [4239] = 4097, [4240] = 4098, [4241] = 4099,
    [4242] = 4100, [4243] = 4101, [4244] = 4102, [4245] = 4103,
    -- Special crystals
    [6506] = 4096, [6507] = 4097, [6508] = 4098, [6509] = 4099,
    [6510] = 4100, [6511] = 4101, [6512] = 4102, [6513] = 4103,
}

-- Parse outgoing synth start packet
function packets.parse_synth_start(data)
    local synth = {
        crystal = struct.unpack('H', data, 0x06 + 1),
        crystal_idx = struct.unpack('B', data, 0x08 + 1),
        ingredient_count = struct.unpack('B', data, 0x09 + 1),
        ingredients = {},
        ingredient_idx = {},
    }
    
    -- Read ingredients
    for i = 0, 7 do
        synth.ingredients[i] = struct.unpack('H', data, 0x0A + (i * 2) + 1)
    end
    
    -- Read ingredient indices
    for i = 0, 7 do
        synth.ingredient_idx[i] = struct.unpack('B', data, 0x1A + (i * 2) + 1)
    end
    
    return synth
end

-- Parse synth animation packet
function packets.parse_synth_animation(data)
    local anim = {
        player = struct.unpack('I4', data, 0x04 + 1),
        player_idx = struct.unpack('H', data, 0x08 + 1),
        effect = struct.unpack('H', data, 0x0A + 1),
        param = struct.unpack('B', data, 0x0C + 1),
        animation = struct.unpack('B', data, 0x0D + 1),
    }
    return anim
end

-- Parse synth result packet
function packets.parse_synth_result(data)
    local result = {
        result = struct.unpack('B', data, 0x04 + 1),
        quality = struct.unpack('b', data, 0x05 + 1),
        count = struct.unpack('B', data, 0x06 + 1),
        item = struct.unpack('H', data, 0x08 + 1),
        lost = {},
        skills = {},
    }
    
    -- Read lost items
    for i = 1, 8 do
        result.lost[i] = struct.unpack('H', data, 0x08 + (i * 2) + 1)
    end
    
    -- Read skill information
    for i = 1, 2 do
        local skill_byte = struct.unpack('B', data, 0x19 + i + 1)
        result.skills[i] = {
            skill_id = bit.band(skill_byte, 63),
            skillup_allowed = bit.band(skill_byte, 40) == 40,
            is_desynth = bit.band(skill_byte, 80) == 80,
        }
    end
    
    return result
end

-- Parse skillup packet
function packets.parse_skillup(data)
    local skillup = {
        message = struct.unpack('H', data, 0x0A + 1),
        param = struct.unpack('B', data, 0x0E + 1),
        target = struct.unpack('I', data, 0x04 + 1),
        value = struct.unpack('H', data, 0x18 + 1),
    }
    return skillup
end

-- Handle outgoing packets
function packets.handle_outgoing(e)
    -- Start Synth packet (0x096)
    if e.id == 0x096 and _G.craftassist.current_synth == nil then
        local synth_data = packets.parse_synth_start(e.data)
        
        -- Normalize crystal ID
        local crystal = crystal_map[synth_data.crystal] or synth_data.crystal
        
        -- Collect ingredients
        local ingredients = {}
        for i = 0, synth_data.ingredient_count - 1 do
            if synth_data.ingredients[i] and synth_data.ingredients[i] > 0 then
                table.insert(ingredients, synth_data.ingredients[i])
            end
        end
        
        -- Try to find matching recipe
        local recipe = _G.craftassist.modules.recipes.find_recipe(crystal, ingredients)
        
        -- Start tracking this synth
        _G.craftassist.current_synth = {
            start_time = os.time(),
            crystal = crystal,
            ingredients = ingredients,
            recipe = recipe,
            result = nil,
            item = recipe and recipe.result or 0,
            count = recipe and recipe.count or 0,
            lost = {},
            skillups = {},
        }
    end
    
    return false
end

-- Handle incoming packets
function packets.handle_incoming(e)
    -- Synth Animation packet (0x030)
    if e.id == 0x030 then
        local anim = packets.parse_synth_animation(e.data)
        local player = GetPlayerEntity()
        
        if player and anim.player == player.ServerId and _G.craftassist.current_synth then
            _G.craftassist.current_synth.result = anim.param
            
            -- Show notification if enabled
            if _G.craftassist.settings.show_notifications then
                local result_info = _G.craftassist.modules.helpers.get_result_quality(anim.param)
                local color_code = _G.craftassist.settings.notification_color and result_info.color or 1
                print(chat.header('CraftAssist'):append(chat.message(result_info.text)))
            end
        end
    end
    
    -- Synth Result packet (0x06F)
    if e.id == 0x06F then
        local result = packets.parse_synth_result(e.data)
        
        -- Handle synth cancellation
        if result.result == 3 or result.result == 4 or result.result == 6 or result.result == 7 then
            _G.craftassist.current_synth = nil
            
            -- If auto-craft is running, stop it due to error
            if _G.craftassist.modules.autocraft.state.enabled then
                _G.craftassist.modules.autocraft.stop()
                _G.craftassist.modules.helpers.error("Auto-craft stopped: Synth failed (likely out of materials)")
            end
            
            return false
        end
        
        if _G.craftassist.current_synth then
            -- Update with actual results
            if result.item ~= 29695 or _G.craftassist.current_synth.item == 0 then
                _G.craftassist.current_synth.item = result.item
                _G.craftassist.current_synth.count = result.count
            end
            
            -- Store lost items
            _G.craftassist.current_synth.lost = {}
            for _, item_id in ipairs(result.lost) do
                if item_id > 0 then
                    table.insert(_G.craftassist.current_synth.lost, item_id)
                end
            end
            
            -- Track skills that can gain skillups
            for _, skill_info in ipairs(result.skills) do
                if skill_info.skill_id > 0 then
                    local skill_id = skill_info.skill_id - 48
                    if skill_id >= 1 and skill_id <= 8 then
                        _G.craftassist.current_synth.skillups[skill_id] = {
                            allowed = skill_info.skillup_allowed,
                            change = 0,
                        }
                    end
                end
            end
            
            -- Show item created notification
            if _G.craftassist.settings.show_notifications and result.result == 0 then
                local res = AshitaCore:GetResourceManager()
                local item = res:GetItemById(result.item)
                if item then
                    print(chat.header('CraftAssist'):append(chat.message(string.format('Created: %s x%d', item.Name[1], result.count))))
                end
            end
            
            -- Add to history if tracking enabled
            if _G.craftassist.settings.track_history then
                table.insert(_G.craftassist.history, 1, _G.craftassist.current_synth)
                
                -- Trim history to max size
                while #_G.craftassist.history > _G.craftassist.settings.max_history do
                    table.remove(_G.craftassist.history)
                end
            end
            
            _G.craftassist.current_synth = nil
        end
    end
    
    -- Skillup packet (0x029)
    if e.id == 0x029 then
        local skillup = packets.parse_skillup(e.data)
        local player = GetPlayerEntity()
        
        if player and skillup.target == player.ServerId then
            local skill_id = skillup.param - 48
            
            -- Skillup message (38) or skill down message (310)
            if (skillup.message == 38 or skillup.message == 310) and skill_id >= 1 and skill_id <= 8 then
                local change = skillup.value / 10.0
                if skillup.message == 310 then
                    change = -change
                end
                
                -- Update current skill level if auto-update enabled
                if _G.craftassist.settings.auto_update_skills then
                    _G.craftassist.skills[skill_id] = _G.craftassist.skills[skill_id] + change
                end
                
                -- Update most recent synth in history
                if #_G.craftassist.history > 0 then
                    local latest = _G.craftassist.history[1]
                    if latest.skillups and latest.skillups[skill_id] then
                        latest.skillups[skill_id].change = change
                    end
                end
            end
        end
    end
    
    return false
end

return packets