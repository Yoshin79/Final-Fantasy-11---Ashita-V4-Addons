# CraftAssist - Comprehensive Crafting Assistant for Ashita v4

A full-featured crafting addon for Final Fantasy XI that provides real-time synth monitoring, recipe database, skill tracking, and craft history.

## Features

### Core Features
- **Auto-Craft System**: Automatically craft multiple items until complete or out of materials
- **Real-time Synth Monitoring**: Instant feedback on craft results (NQ, HQ, Break)
- **Colored Notifications**: Visual feedback with color-coded results
- **Skill Tracking**: Track all 8 crafting skills with automatic updates
- **Craft History**: Detailed history of all your synths with results and skillups
- **Recipe Database**: 13,936+ recipes searchable by name
- **Ingredient Checking**: See what materials you have vs. what's needed
- **Skill Requirements**: Check if you meet the skill requirements for recipes

### GUI Features
- **Auto-Craft Panel**: Set up and control automatic crafting with material checking
- **Skills Panel**: View and manually adjust your crafting skill levels
- **Recipe Search**: Search through thousands of recipes by item name
- **History View**: See your recent crafts with results and skillups
- **Settings Panel**: Customize notifications, tracking, and display options

### Command Line Features
- `/craft` or `/ca` - Toggle the GUI window
- `/craft help` - Show available commands
- `/craft skills` - Display current skill levels in chat
- `/craft history` - Show recent craft history in chat
- `/craft clear` - Clear craft history
- `/craft notify` - Toggle notifications on/off
- `/craft save` - Save current settings
- `/craft start <crystal> <ing1> [ing2...]` - Start auto-craft with item IDs
- `/craft stop` - Stop auto-craft

## Installation

1. Copy the entire `craftassist` folder to your Ashita `addons` directory:
   ```
   Ashita/addons/craftassist/
   ```

2. Load the addon in-game:
   ```
   /addon load craftassist
   ```

3. (Optional) Add to your auto-load script to load on startup

## Usage

### First Time Setup
1. Open the GUI with `/craft` or `/ca`
2. In the Skills section, enter your current crafting skill levels
3. Click "Save Skills" to save your levels
4. Configure your preferences in the Settings section

### Auto-Crafting

**EASY METHOD (Recommended):**
1. Open the GUI with `/craft`
2. Scroll down to "Recipe Search"
3. Search for the item you want to craft (e.g., "bronze ingot")
4. Expand the recipe you want
5. Click the **"Use This Recipe for Auto-Craft"** button
6. The crystal and ingredients are automatically filled in!
7. Set the number of synths you want
8. Click "Start Auto-Craft"

**MANUAL METHOD:**
1. Open the GUI with `/craft`
2. In the "Auto-Craft" section:
   - Enter the Crystal ID (e.g., 4096 for Fire Crystal)
   - Enter Ingredient IDs (one per line, up to 8)
   - Set the number of synths you want to perform
   - Adjust the delay between synths (default 2 seconds)
3. Click "Start Auto-Craft"

**How It Works:**
- The addon automatically checks if you have materials
- Performs the synth
- Waits for the result
- Repeats until complete or out of materials
- Click "Stop Auto-Craft" to stop at any time

**Finding Item IDs:**
- **Best way:** Use Recipe Search and click "Use This Recipe"
- Click "Common Crystal IDs" in the Auto-Craft section
- Use `/itemsearch` command in-game
- Check FFXIAH.com or FFXIDB.com

### During Crafting
- The addon automatically monitors all your synths
- Notifications appear in chat showing the result (NQ/HQ/Break)
- Skillups are automatically tracked and recorded
- All synths are added to your history

### Recipe Search
1. Open the GUI with `/craft`
2. Expand the "Recipe Search" section
3. Type at least 2 characters to search
4. Results show:
   - Skill requirements (green if you can craft, red if not)
   - Crystal needed
   - All ingredients required
   - Your current inventory count for each item

### Viewing History
- Open the GUI and expand "Craft History"
- See your recent synths with:
  - Item name and quantity
  - Result (NQ/HQ/Fail)
  - Skillups gained (if any)
  - Items lost on failure
- Use `/craft history` to see history in chat
- Click "Clear History" to reset

## Settings

### Available Settings
- **Show Notifications**: Display synth results in chat
- **Colored Notifications**: Use colored text for results
- **Track Skillups**: Record skillup information
- **Track History**: Save synth history
- **Auto-Update Skills**: Automatically update skill levels on skillup
- **Show Recipe Search**: Display recipe search panel
- **Max History**: Maximum number of synths to keep in history (10-500)

### Saving Settings
- Click "Save Settings" in the Settings panel
- Or use `/craft save` command
- Settings are automatically saved on addon unload

## Skill Abbreviations
- CRP - Woodworking
- BSM - Smithing
- GSM - Goldsmithing
- WVR - Clothcraft
- LTW - Leathercraft
- BON - Bonecraft
- ALC - Alchemy
- CUL - Cooking

## Result Types
- **NQ** - Normal Quality (white)
- **HQ1** - High Quality (green)
- **HQ2** - High Quality +1 (green)
- **HQ3** - High Quality +2 (green)
- **Fail** - Break/Failed synth (red)

## Technical Details

### Packet Monitoring
The addon monitors the following packets:
- **0x096** (Outbound): Start Synth - Detects when you begin a craft
- **0x030** (Inbound): Synth Animation - Provides immediate result
- **0x06F** (Inbound): Synth Result - Detailed results including items and skills
- **0x029** (Inbound): Basic - Skillup notifications

### Recipe Database
- 13,936+ recipes indexed by ingredients
- 3,923+ recipes indexed by skill
- Includes all crafts from all 8 crafting skills
- Supports crystal variations (NQ, HQ, special)

### Data Storage
- Settings stored in: `craftassist/settings.json`
- Includes skill levels, history, and preferences
- Automatically saved on unload

## Troubleshooting

### Addon won't load
- Ensure all files are in the correct directory
- Check that you're using Ashita v4
- Verify ImGui is available

### Skills not updating
- Enable "Auto-Update Skills" in settings
- Manually enter skills in the GUI if needed
- Use `/craft skills` to verify current levels

### Recipe search not working
- Ensure recipe database files are present in `data/` folder
- Search requires at least 2 characters
- Try different search terms

### History not saving
- Enable "Track History" in settings
- Check that settings file is writable
- Use `/craft save` to force save

## Credits

- Original craftmon addon by atom0s (Ashita v3)
- Crafty module from xitools (Ashita v4)
- Converted and enhanced for standalone use
- Recipe databases from FFXI community resources

## Version History

### v1.1.0 (2025)
- Added auto-craft functionality
- Automatic material checking
- Configurable synth count and delay
- Command line auto-craft support
- Enhanced GUI with auto-craft panel

### v1.0.0 (2025)
- Initial release for Ashita v4
- Combined features from craftmon and crafty
- Standalone addon with full GUI
- Complete recipe database
- Skill tracking and history
- Customizable settings

## License

This addon is provided as-is for use with Ashita v4. See Ashita license for details.