-- autocraft.lua
local autocraft = {}
local chat = require('chat')

-- Auto-craft state
autocraft.state = {
    enabled = false,
    crafting = false,
    target_count = 1,
    current_count = 0,
    last_synth_time = 0,
    synth_delay = 22.0,  -- 22 seconds delay for /lastsynth
    first_craft_delay = 4.0,  -- 4 seconds delay after first manual craft
    waiting_for_result = false,
    use_lastsynth = true,
    first_synth_done = false,
}

-- Check if player can craft
function autocraft.can_craft()
    local player = GetPlayerEntity()
    if not player then return false end
    
    -- Check if player is idle (status 0)
    if player.Status ~= 0 then
        return false
    end
    
    return true
end

-- Trigger a synth using /lastsynth command
function autocraft.trigger_synth_lastsynth()
    -- Use the /lastsynth command to repeat the last synth
    AshitaCore:GetChatManager():QueueCommand(1, '/lastsynth')
    
    autocraft.state.waiting_for_result = true
    autocraft.state.last_synth_time = os.clock()
    autocraft.state.first_synth_done = true
    
    return true
end

-- Start auto-crafting
function autocraft.start(crystal_id, ingredient_ids, count)
    if autocraft.state.enabled then
        _G.craftassist.modules.helpers.message("Auto-craft already running")
        return
    end
    
    -- Validate inputs
    if not crystal_id or crystal_id == 0 then
        _G.craftassist.modules.helpers.error("No crystal selected")
        return
    end
    
    if not ingredient_ids or #ingredient_ids == 0 then
        _G.craftassist.modules.helpers.error("No ingredients selected")
        return
    end
    
    -- Initialize state
    autocraft.state.enabled = true
    autocraft.state.crafting = false
    autocraft.state.target_count = 999999 -- Effectively unlimited - will stop when materials run out
    autocraft.state.current_count = 0
    autocraft.state.waiting_for_result = false
    autocraft.state.first_synth_done = false
    
    _G.craftassist.modules.helpers.success("Auto-craft started: Will continue until materials run out")
    _G.craftassist.modules.helpers.message("IMPORTANT: Manually perform the first synth now!")
    _G.craftassist.modules.helpers.message("The addon will automatically repeat it using /lastsynth")
    _G.craftassist.modules.helpers.message("Click 'Stop' button to stop auto-crafting")
end

-- Start auto-crafting using /lastsynth (no validation needed)
function autocraft.start_lastsynth()
    if autocraft.state.enabled then
        _G.craftassist.modules.helpers.message("Auto-craft already running")
        return
    end
    
    -- Initialize state without validation
    autocraft.state.enabled = true
    autocraft.state.crafting = false
    autocraft.state.target_count = 999999
    autocraft.state.current_count = 0
    autocraft.state.waiting_for_result = false
    autocraft.state.first_synth_done = true -- Skip the "first synth" requirement
    
    _G.craftassist.modules.helpers.success("Auto-craft started using /lastsynth")
    _G.craftassist.modules.helpers.message("Will continue until materials run out or you click Stop")
end

-- Stop auto-crafting
function autocraft.stop()
    if not autocraft.state.enabled then
        return
    end
    
    autocraft.state.enabled = false
    autocraft.state.crafting = false
    autocraft.state.waiting_for_result = false
    
    _G.craftassist.modules.helpers.message(string.format("Auto-craft stopped: %d/%d completed", 
        autocraft.state.current_count, autocraft.state.target_count))
end

-- Update function (called every frame)
function autocraft.update()
    if not autocraft.state.enabled then
        return
    end
    
    -- Wait for previous synth to complete
    if autocraft.state.waiting_for_result then
        -- Check if synth completed (current_synth is nil after result)
        if not _G.craftassist.current_synth then
            autocraft.state.waiting_for_result = false
            autocraft.state.current_count = autocraft.state.current_count + 1
            
            -- If this was the first manual synth, notify user and use shorter delay
            if autocraft.state.current_count == 1 and not autocraft.state.first_synth_done then
                _G.craftassist.modules.helpers.success("First synth detected! Auto-repeating in 4 seconds...")
                autocraft.state.first_synth_done = true
                -- Set last synth time to (now - delay difference) so we only wait 11 seconds
                autocraft.state.last_synth_time = os.clock() - (autocraft.state.synth_delay - autocraft.state.first_craft_delay)
            else
                -- Set last synth time to now so we wait the full delay
                autocraft.state.last_synth_time = os.clock()
            end
            
            -- Check if we should continue (materials available)
            -- The game will show an error message if materials are missing
            -- We'll continue until user stops or an error occurs
        end
        return
    end
    
    -- If first synth not done yet, wait for user to do it manually
    if not autocraft.state.first_synth_done and autocraft.state.current_count == 0 then
        -- Check if user has started a synth
        if _G.craftassist.current_synth then
            autocraft.state.waiting_for_result = true
        end
        return
    end
    
    -- Check if we can craft
    if not autocraft.can_craft() then
        return
    end
    
    -- Check delay between synths
    local time_since_last = os.clock() - autocraft.state.last_synth_time
    if time_since_last < autocraft.state.synth_delay then
        return
    end
    
    -- Trigger the synth using /lastsynth
    autocraft.trigger_synth_lastsynth()
end

return autocraft