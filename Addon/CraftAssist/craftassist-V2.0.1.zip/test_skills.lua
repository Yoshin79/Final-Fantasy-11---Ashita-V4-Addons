-- Simple test script to check if we can read skills
-- Load with: /addon load test_skills

addon.name = 'TestSkills'
addon.author = 'Test'
addon.version = '1.0'

require('common')

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args()
    if #args == 0 or args[1] ~= '/testskills' then
        return
    end
    
    e.blocked = true
    
    print('=== Testing Skill Reading ===')
    
    local player = AshitaCore:GetMemoryManager():GetPlayer()
    if not player then
        print('ERROR: Player is nil')
        return
    end
    
    print('Player object exists')
    
    -- Try to read cooking skill (ID 7)
    local skill_data = player:GetCraftSkill(7)
    if not skill_data then
        print('ERROR: GetCraftSkill(7) returned nil')
        return
    end
    
    print('Skill data object exists')
    
    local skill = skill_data:GetSkill()
    local rank = skill_data:GetRank()
    local capped = skill_data:IsCapped()
    
    print(string.format('Cooking Skill: %s', tostring(skill)))
    print(string.format('Rank: %s', tostring(rank)))
    print(string.format('Capped: %s', tostring(capped)))
    
    print('=== End Test ===')
end)

print('[TestSkills] Loaded! Use /testskills to test')