-- recipes.lua
local recipes = {}

-- This will hold the recipe databases
recipes.by_ingredients = nil
recipes.by_skill = nil

-- Load recipe databases
function recipes.load()
    -- Try to load recipe databases if they exist
    local success, recipes_by_ing = pcall(require, 'data.recipesByIngredients')
    if success then
        recipes.by_ingredients = recipes_by_ing
    end
    
    local success2, recipes_by_skill = pcall(require, 'data.recipesBySkill')
    if success2 then
        recipes.by_skill = recipes_by_skill
    end
end

-- Find recipe by crystal and ingredients
function recipes.find_recipe(crystal, ingredients)
    if not recipes.by_ingredients then
        recipes.load()
    end
    
    if not recipes.by_ingredients or not recipes.by_ingredients[crystal] then
        return nil
    end
    
    -- Sort ingredients to create hash
    local sorted = {}
    for _, ing in ipairs(ingredients) do
        table.insert(sorted, ing)
    end
    table.sort(sorted)
    
    local hash = table.concat(sorted, ',')
    
    -- Look up recipe
    local recipe = recipes.by_ingredients[crystal][hash]
    if recipe then
        return {
            result = recipe.itemId,
            count = recipe.count,
        }
    end
    
    return nil
end

-- Search recipes by name
function recipes.search(filter)
    if not recipes.by_skill then
        recipes.load()
    end
    
    if not recipes.by_skill then
        return {}
    end
    
    local results = {}
    local res = AshitaCore:GetResourceManager()
    local filter_lower = filter:lower()
    
    -- Search through all recipes
    for skill_id, recipe_list in ipairs(recipes.by_skill) do
        for _, recipe in ipairs(recipe_list) do
            local item = res:GetItemById(recipe.result)
            if item then
                local item_name = item.Name[1]:lower()
                local full_name = item.LogNameSingular[1]:lower()
                
                if item_name:match(filter_lower) or full_name:match(filter_lower) then
                    table.insert(results, {
                        skill_id = skill_id,
                        recipe = recipe,
                    })
                end
            end
        end
    end
    
    return results
end

-- Get recipe details
function recipes.get_recipe_info(recipe)
    if not recipe then return nil end
    
    local res = AshitaCore:GetResourceManager()
    local item = res:GetItemById(recipe.result)
    
    if not item then return nil end
    
    return {
        name = item.Name[1],
        full_name = item.LogNameSingular[1],
        count = recipe.count or 1,
        crystal = recipe.crystal,
        ingredients = recipe.ingredients or {},
        skills = recipe.skills or {},
        key_item = recipe.keyItem or 0,
    }
end

return recipes