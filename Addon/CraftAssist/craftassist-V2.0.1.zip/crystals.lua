-- crystals.lua - Crystal data for dropdown

local crystals = {}

-- Crystal data with IDs and names
crystals.data = {
    -- Normal Crystals
    { id = 4096, name = "Fire Crystal", category = "Normal" },
    { id = 4097, name = "Ice Crystal", category = "Normal" },
    { id = 4098, name = "Wind Crystal", category = "Normal" },
    { id = 4099, name = "Earth Crystal", category = "Normal" },
    { id = 4100, name = "Lightning Crystal", category = "Normal" },
    { id = 4101, name = "Water Crystal", category = "Normal" },
    { id = 4102, name = "Light Crystal", category = "Normal" },
    { id = 4103, name = "Dark Crystal", category = "Normal" },
    
    -- HQ Crystals
    { id = 4104, name = "Inferno Crystal", category = "HQ" },
    { id = 4105, name = "Glacier Crystal", category = "HQ" },
    { id = 4106, name = "Cyclone Crystal", category = "HQ" },
    { id = 4107, name = "Terra Crystal", category = "HQ" },
    { id = 4108, name = "Plasma Crystal", category = "HQ" },
    { id = 4109, name = "Torrent Crystal", category = "HQ" },
    { id = 4110, name = "Aurora Crystal", category = "HQ" },
    { id = 4111, name = "Twilight Crystal", category = "HQ" },
}

-- Get crystal name by ID
function crystals.get_name_by_id(id)
    for _, crystal in ipairs(crystals.data) do
        if crystal.id == id then
            return crystal.name
        end
    end
    return "Unknown Crystal"
end

-- Get crystal ID by name
function crystals.get_id_by_name(name)
    for _, crystal in ipairs(crystals.data) do
        if crystal.name == name then
            return crystal.id
        end
    end
    return 0
end

return crystals