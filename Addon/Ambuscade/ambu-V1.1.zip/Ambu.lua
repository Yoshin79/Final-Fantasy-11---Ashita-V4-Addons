--[[
* Addons - Copyright (c) 2021 Ashita Development Team
* Contact: https://www.ashitaxi.com/
* Contact: https://discord.gg/Ashita
*
* This file is part of Ashita.
*
* Ashita is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Ashita is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with Ashita.  If not, see <https://www.gnu.org/licenses/>.
--]]

addon.name      = 'Ambu';
addon.author    = 'Modified from TribRad';
addon.version   = '1.0';
addon.desc      = 'Displays Primer Vol 1 and Primer Vol 2 status for Ambuscade.';
addon.link      = 'https://ashitaxi.com/';

require('common');
local imgui = require('imgui');
local settings = require('settings');

-- Ambu Variables
local ambu = T{
    -- ImGui Variables
    is_open = T{ true, },
};

--[[
* Registers a callback for the settings to load.
*
* @param {table} s - The settings table to load.
--]]
settings.register('settings', 'settings_load', function (s)
    if (s ~= nil) then
        ambu.is_open[1] = s.is_open;
    end
end);

--[[
* Registers a callback for the settings to save.
*
* @return {table} The settings table to save.
--]]
settings.register('settings', 'settings_save', function ()
    local s = T{
        is_open = ambu.is_open[1],
    };
    return s;
end);

--[[
* event: d3d_present
* desc : Event called when the Direct3D device is presenting a scene.
--]]
ashita.events.register('d3d_present', 'present_cb', function ()
    -- Obtain the player entity..
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    if (player == nil) then
        return;
    end

    -- Display the Ambu window..
    imgui.SetNextWindowSize({ 125, 50, }, ImGuiCond_FirstUseEver);
    if (imgui.Begin('Ambu', ambu.is_open, bit.bor(ImGuiWindowFlags_NoDecoration, ImGuiWindowFlags_AlwaysAutoResize))) then
        -- Check for Primer Vol 1 (3052)
        local primerVol1 = player:HasKeyItem(3052);
        if (primerVol1) then
            imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, '[ Primer Vol 1 ]');
        else
            imgui.TextColored({ 1.0, 0.0, 0.0, 1.0 }, '[ Primer Vol 1 ]');
        end

        -- Check for Primer Vol 2 (3053)
        local primerVol2 = player:HasKeyItem(3053);
        if (primerVol2) then
            imgui.TextColored({ 0.0, 1.0, 0.0, 1.0 }, '[ Primer Vol 2 ]');
        else
            imgui.TextColored({ 1.0, 0.0, 0.0, 1.0 }, '[ Primer Vol 2 ]');
        end
    end
    imgui.End();
end);