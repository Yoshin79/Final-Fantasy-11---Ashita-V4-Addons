# Ambu Addon for Ashita v4

## Description
This addon displays the status of Primer Vol 1 and Primer Vol 2 key items for Final Fantasy XI Ambuscade content. The display shows:
- **Green text** when you have the key item
- **Red text** when you don't have the key item

## Key Items
- **Primer Vol 1**: ID 3052
- **Primer Vol 2**: ID 3053

## Installation

1. Copy `Ambu.lua` to your Ashita addons folder:
   ```
   /Ashita/addons/Ambu/Ambu.lua
   ```

2. Load the addon in-game using the command:
   ```
   /addon load Ambu
   ```

3. To automatically load on startup, add this line to your `scripts/default.txt`:
   ```
   /addon load Ambu
   ```

## Usage

The addon will automatically display a small window showing:
```
[ Primer Vol 1 ] [ Primer Vol 2 ]
```

- The window is movable and will remember its position
- Colors update automatically when you acquire or lose the key items
- The window is always visible while the addon is loaded

## Commands

- Load addon: `/addon load Ambu`
- Unload addon: `/addon unload Ambu`
- Reload addon: `/addon reload Ambu`

## Credits

Modified from the TribRad addon structure for Ashita v4.