addon.name    = 'bluhelper'
addon.author  = 'Oneword - Ninja Ai'
addon.version = '2.1'
addon.desc    = 'Track Blue Magic spells'

require('common')
local imgui = require('imgui')
local bit = require('bit')

-- Load spell database from separate file
local BlueMagicSpells = require('spells_db')

-- Style Configuration
local styles = {
    colors = {
        window_bg = { 0.08, 0.09, 0.15, 0.97 },    -- Darker blue background
        header = { 0.2, 0.3, 0.7, 1.0 },           -- More vibrant header
        title_text = { 1.0, 1.0, 1.0, 1.0 },       -- White title text
        text_normal = { 0.9, 0.9, 0.9, 1.0 },      -- Brighter normal text
        text_known = { 0.3, 1.0, 0.4, 1.0 },       -- Softer green
        text_unknown = { 1.0, 0.4, 0.4, 1.0 },     -- Softer red
        category = { 0.4, 0.7, 1.0, 1.0 },         -- Brighter category color
        location = { 0.8, 0.8, 0.8, 1.0 },         -- Brighter location text
        button = { 0.25, 0.35, 0.8, 0.8 },         -- Button color
        button_hovered = { 0.35, 0.45, 0.9, 0.9 }, -- Button hover color
        separator = { 0.4, 0.5, 0.8, 1.0 },        -- Separator color
        level_indicator = { 0.7, 0.7, 0.2, 1.0 },  -- Level indicator color
        child_bg = { 0.10, 0.11, 0.18, 0.5 }       -- Darker child background
    }
}

-- UI State
local ui = {
    is_open = { true },
    show_all = { false },
    filter_level = { 99 },
    search_text = { '' },
    sort_by = { "level" },  -- Options: "level", "name", "category"
    show_categories = {
        physical = { true },
        magical = { true },
        breath = { true },
        healing = { true },
        enhancing = { true }
    }
}

local function HasSpell(spellId)
    local player = AshitaCore:GetMemoryManager():GetPlayer()
    if (player == nil) then
        return false
    end
    return player:HasSpell(spellId)
end

local function ApplyStyle()
    imgui.PushStyleColor(ImGuiCol_WindowBg, styles.colors.window_bg)
    imgui.PushStyleColor(ImGuiCol_Header, styles.colors.header)
    imgui.PushStyleColor(ImGuiCol_Button, styles.colors.button)
    imgui.PushStyleColor(ImGuiCol_ButtonHovered, styles.colors.button_hovered)
    imgui.PushStyleColor(ImGuiCol_Separator, styles.colors.separator)
    imgui.PushStyleColor(ImGuiCol_TitleBg, styles.colors.header)
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, styles.colors.header)
    imgui.PushStyleColor(ImGuiCol_ChildBg, styles.colors.child_bg)
    imgui.PushStyleColor(ImGuiCol_ScrollbarBg, {0, 0, 0, 0}) -- Hide scrollbar background
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrab, {0, 0, 0, 0}) -- Hide scrollbar grab
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrabHovered, {0, 0, 0, 0}) -- Hide scrollbar grab when hovered
    imgui.PushStyleColor(ImGuiCol_ScrollbarGrabActive, {0, 0, 0, 0}) -- Hide scrollbar grab when active
    
    imgui.PushStyleVar(ImGuiStyleVar_WindowRounding, 8.0)
    imgui.PushStyleVar(ImGuiStyleVar_FrameRounding, 5.0)
    imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, { 12, 12 })
    imgui.PushStyleVar(ImGuiStyleVar_ItemSpacing, { 8, 2 }) -- Reduced vertical spacing between items
    imgui.PushStyleVar(ImGuiStyleVar_FramePadding, { 6, 4 })
    imgui.PushStyleVar(ImGuiStyleVar_ScrollbarSize, 1) -- Minimize scrollbar size
    imgui.PushStyleVar(ImGuiStyleVar_ScrollbarRounding, 0)
end

local function SortSpells(spells)
    local sortedSpells = {}
    for id, spell in pairs(spells) do
        table.insert(sortedSpells, {id = id, data = spell})
    end
    
    if ui.sort_by[1] == "level" then
        table.sort(sortedSpells, function(a, b)
            if a.data.level == b.data.level then
                return a.data.name < b.data.name
            end
            return a.data.level < b.data.level
        end)
    elseif ui.sort_by[1] == "name" then
        table.sort(sortedSpells, function(a, b)
            return a.data.name < b.data.name
        end)
    elseif ui.sort_by[1] == "category" then
        table.sort(sortedSpells, function(a, b)
            if a.data.category == b.data.category then
                if a.data.level == b.data.level then
                    return a.data.name < b.data.name
                end
                return a.data.level < b.data.level
            end
            return a.data.category < b.data.category
        end)
    end
    
    return sortedSpells
end

local function DrawSpellEntry(id, spell, known)
    -- Use AlignTextToFramePadding to vertically center text
    imgui.AlignTextToFramePadding()
    
    -- Start a group to keep everything on one line
    imgui.BeginGroup()
    
    -- Level indicator with colored circle
    imgui.TextColored(styles.colors.level_indicator, string.format("Lv.%d", spell.level))
    imgui.SameLine(80) -- Fixed spacing for level
    
    -- Spell name with known/unknown color
    local text_color = known and styles.colors.text_known or styles.colors.text_unknown
    imgui.TextColored(text_color, spell.name)
    imgui.SameLine(240) -- Fixed spacing for spell name
    
    -- Category icon/text
    local categoryText = "["..spell.category:sub(1,1):upper().."]"
    imgui.TextColored(styles.colors.category, categoryText)
    imgui.SameLine(280) -- Fixed spacing for category
    
    -- Monster source
    local monsterText = table.concat(spell.monsters, ", ")
    imgui.TextColored(styles.colors.location, monsterText)
    
    imgui.EndGroup()
    
    -- No extra spacing between entries now
end

local function CountSpells()
    local total_count = 0
    local known_count = 0
    local category_counts = {
        physical = {total = 0, known = 0},
        magical = {total = 0, known = 0},
        breath = {total = 0, known = 0},
        healing = {total = 0, known = 0},
        enhancing = {total = 0, known = 0}
    }
    
    for id, spell in pairs(BlueMagicSpells) do
        total_count = total_count + 1
        local known = HasSpell(id)
        if known then
            known_count = known_count + 1
        end
        
        if category_counts[spell.category] then
            category_counts[spell.category].total = category_counts[spell.category].total + 1
            if known then
                category_counts[spell.category].known = category_counts[spell.category].known + 1
            end
        end
    end
    
    return {
        total = total_count,
        known = known_count,
        categories = category_counts
    }
end

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args()
    if args[1] ~= '/bluhelper' then
        return
    end
    ui.is_open[1] = not ui.is_open[1]
    e.blocked = true
end)

ashita.events.register('d3d_present', 'present_cb', function()
    if not ui.is_open[1] then
        return
    end

    imgui.SetNextWindowSizeConstraints({ 650, 450 }, { 1920, 1080 }) -- Increased minimum width to 650
    
    ApplyStyle()
    
    if imgui.Begin('Blue Magic Spell Tracker', ui.is_open, ImGuiWindowFlags_NoScrollbar) then
        -- Get window width for centering calculations
        local windowWidth = imgui.GetWindowWidth()
        
        -- Custom title bar - CENTERED
        local titleText = "Blue Magic Spell Tracker"
        local titleWidth = imgui.CalcTextSize(titleText) * 1.2 -- Account for font scaling
        
        imgui.SetCursorPosX((windowWidth - titleWidth) / 2)
        imgui.PushStyleColor(ImGuiCol_Text, styles.colors.title_text)
        imgui.SetWindowFontScale(1.2)
        imgui.Text(titleText)
        imgui.SetWindowFontScale(1.0)
        imgui.PopStyleColor()
        imgui.Separator()
        
        -- Options Bar with LEFT-ALIGNED ELEMENTS
        if imgui.BeginChild('OptionsBar', { -1, 110 }, true) then
            -- First row - LEFT ALIGNED WITH BETTER SPACING
            imgui.PushStyleVar(ImGuiStyleVar_FramePadding, { 8, 4 })
            
            -- Show All button - LEFT ALIGNED
            if imgui.Button(ui.show_all[1] and "Show Missing" or "Show All", { 120, 25 }) then
                ui.show_all[1] = not ui.show_all[1]
            end
            
            -- Level Filter - FIXED SPACING AND LABEL
            imgui.SameLine(140)
            imgui.AlignTextToFramePadding() -- Align text vertically with controls
            imgui.Text("Level Filter")
            
            -- SIGNIFICANTLY INCREASED SPACING FOR LEVEL FILTER CONTROL
            imgui.SameLine(260)
            imgui.PushItemWidth(100)
            imgui.SliderInt("##LevelFilter", ui.filter_level, 1, 99)
            imgui.PopItemWidth()
            
            -- Sort By - FIXED SPACING AND LABEL
            imgui.SameLine(380)
            imgui.AlignTextToFramePadding() -- Align text vertically with controls
            imgui.Text("Sort By")
            
            -- SIGNIFICANTLY INCREASED SPACING FOR SORT BY CONTROL
            imgui.SameLine(460)
            imgui.PushItemWidth(150)
            if imgui.BeginCombo("##SortBy", ui.sort_by[1]) then
                if imgui.Selectable("Level", ui.sort_by[1] == "level") then ui.sort_by[1] = "level" end
                if imgui.Selectable("Name", ui.sort_by[1] == "name") then ui.sort_by[1] = "name" end
                if imgui.Selectable("Category", ui.sort_by[1] == "category") then ui.sort_by[1] = "category" end
                imgui.EndCombo()
            end
            imgui.PopItemWidth()
            imgui.PopStyleVar()
            
            -- Second row - SEARCH BAR SMALLER AND LEFT ALIGNED
            imgui.Spacing()
            imgui.AlignTextToFramePadding() -- Align text vertically with controls
            imgui.TextColored(styles.colors.category, "Search:")
            imgui.SameLine()
            
            -- Smaller search bar (300px instead of full width)
            imgui.PushItemWidth(300)
            imgui.InputText('##Search', ui.search_text, 256)
            imgui.PopItemWidth()
            
            -- Third row - Categories EVENLY SPACED FROM LEFT
            imgui.Spacing()
            local categories = {"Physical", "Magical", "Breath", "Healing", "Enhancing"}
            local category_keys = {"physical", "magical", "breath", "healing", "enhancing"}
            
            -- Calculate spacing for evenly distributed checkboxes
            local spacing = 120 -- Fixed spacing between checkboxes
            
            -- Left align categories with even spacing
            for i, category in ipairs(categories) do
                if i > 1 then imgui.SameLine() end
                imgui.SetCursorPosX((i-1) * spacing + 10) -- 10px initial padding
                imgui.Checkbox(category, ui.show_categories[category_keys[i]])
            end
            
            imgui.EndChild()
        end

        -- Add a separator between options and spell list
        imgui.Separator()
        
        -- Spell List with sorting and grouping - HIDE SCROLLBAR BUT ALLOW SCROLLING
        if imgui.BeginChild('SpellList', { 0, -30 }, true, ImGuiWindowFlags_NoScrollbar) then
            local sortedSpells = SortSpells(BlueMagicSpells)
            local currentLevel = -1
            local currentCategory = ""
            
            for _, spellData in ipairs(sortedSpells) do
                local id = spellData.id
                local spell = spellData.data
                
                if ui.show_categories[spell.category][1] and spell.level <= ui.filter_level[1] then
                    local known = HasSpell(id)
                    
                    -- Filter by search text if any
                    local search_text = ui.search_text[1]:lower()
                    if search_text == '' or spell.name:lower():find(search_text, 1, true) then
                        if ui.show_all[1] or not known then
                            -- Add a separator when level changes (but no header)
                            if ui.sort_by[1] == "level" and spell.level ~= currentLevel then
                                currentLevel = spell.level
                                if currentLevel > 1 then -- Don't add separator before the first level
                                    imgui.Separator()
                                    imgui.Spacing() -- Add a little space after separator
                                end
                            end
                            
                            -- Add a separator when category changes (but no header)
                            if ui.sort_by[1] == "category" and spell.category ~= currentCategory then
                                currentCategory = spell.category
                                if currentCategory ~= "" then -- Don't add separator before the first category
                                    imgui.Separator()
                                    imgui.Spacing() -- Add a little space after separator
                                end
                            end
                            
                            DrawSpellEntry(id, spell, known)
                        end
                    end
                end
            end
            
            imgui.EndChild()
        end
        
        -- Status bar at the bottom - CENTERED
        imgui.Separator()
        if imgui.BeginChild('StatusBar', {-1, 25}, false) then
            local counts = CountSpells()
            
            local statusText = string.format("Known: %d/%d (%.1f%%)", 
                counts.known, counts.total, (counts.known/counts.total)*100)
            local statusWidth = imgui.CalcTextSize(statusText)
            imgui.SetCursorPosX((windowWidth - statusWidth) / 2)
            
            imgui.Text(statusText)
            
            imgui.EndChild()
        end
    end
    
    imgui.PopStyleColor(12)  -- Updated to match pushed colors (added ChildBg)
    imgui.PopStyleVar(7)    
    
    imgui.End()
end)

ashita.events.register('load', 'load_cb', function()
    print(string.format('[%s] loaded! Use /bluhelper to toggle the tracker.', addon.name))
end)
