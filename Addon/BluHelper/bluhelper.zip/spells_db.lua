return {
    -- Level 1
    [524] = { name = "Sandspin", level = 1, category = "magical", monsters = { "Worm" } },
    [549] = { name = "Pollen", level = 1, category = "magical", monsters = { "Bee" } },
    [577] = { name = "Foot Kick", level = 1, category = "physical", monsters = { "Rabbit" } },

    -- Level 4
    [551] = { name = "Power Attack", level = 4, category = "physical", monsters = { "Beetle" } },
    [597] = { name = "Sprout Smack", level = 4, category = "physical", monsters = { "Sapling" } },
    [603] = { name = "Wild Oats", level = 4, category = "physical", monsters = { "Mandragora" } },

    -- Level 8
    [547] = { name = "Metallic Body", level = 8, category = "enhancing", monsters = { "Crab" } },
    [547] = { name = "Cocoon", level = 8, category = "enhancing", monsters = { "Crawler" } },
    [599] = { name = "Queasyshroom", level = 8, category = "magical", monsters = { "Funguar" } },

    -- Level 12
    [620] = { name = "Battle Dance", level = 12, category = "physical", monsters = { "Orc - Melee Type" } },
    [623] = { name = "Head Butt", level = 12, category = "physical", monsters = { "Quadav - Melee Type" } },
    [638] = { name = "Feather Storm", level = 12, category = "physical", monsters = { "Yagudo - Mage Type" } },

    -- Level 16
    [567] = { name = "Helldive", level = 16, category = "physical", monsters = { "Bird" } },
    [581] = { name = "Healing Breeze", level = 16, category = "healing", monsters = { "Dhalmel" } },
    [584] = { name = "Sheep Song", level = 16, category = "magical", monsters = { "Sheep" } },

    -- Level 18
    [619] = { name = "Bludgeon", level = 18, category = "physical", monsters = { "Cardian" } },
    [544] = { name = "Cursed Sphere", level = 18, category = "magical", monsters = { "Fly" } },
    [618] = { name = "Blastbomb", level = 18, category = "magical", monsters = { "Orcish Warmachine" } },

    -- Level 20
    [570] = { name = "Blood Drain", level = 20, category = "magical", monsters = { "Giant Bat" } },
    [587] = { name = "Claw Cyclone", level = 20, category = "physical", monsters = { "Tiger" } },

    -- Level 22
    [536] = { name = "Poison Breath", level = 22, category = "magical", monsters = { "Hound" } },

    -- Level 24
    [598] = { name = "Soporific", level = 24, category = "magical", monsters = { "Fly Trap" } },

    -- Level 26
    [519] = { name = "Screwdriver", level = 26, category = "physical", monsters = { "Pugil" } },

    -- Level 28
    [626] = { name = "Bomb Toss", level = 28, category = "magical", monsters = { "Goblin" } },

    -- Level 30
    [622] = { name = "Grand Slam", level = 30, category = "physical", monsters = { "Gigas" } },
    [578] = { name = "Wild Carrot", level = 30, category = "healing", monsters = { "Rabbit - CoP" } },
	
    -- Level 32
    [572] = { name = "Sound Blast", level = 32, category = "magical", monsters = { "Cockatrice" } },
    [582] = { name = "Chaotic Eye", level = 32, category = "magical", monsters = { "Coeurl" } },

    -- Level 34
    [522] = { name = "Death Ray", level = 34, category = "magical", monsters = { "Hecteyes" } },
    [527] = { name = "Smite of Rage", level = 34, category = "physical", monsters = { "Evil Weapon" } },

    -- Level 36
    [542] = { name = "Digest", level = 36, category = "magical", monsters = { "Slime" } },
    [596] = { name = "Pinecone Bomb", level = 36, category = "physical", monsters = { "Treant" } },

    -- Level 38
    [592] = { name = "Blank Gaze", level = 38, category = "magical", monsters = { "Opo-opo" } },
    [569] = { name = "Jet Stream", level = 38, category = "physical", monsters = { "Tri-bat" } },
    [594] = { name = "Uppercut", level = 38, category = "physical", monsters = { "Goobbue" } },

    -- Level 40
    [534] = { name = "Mysterious Light", level = 40, category = "magical", monsters = { "Magic Pot" } },
    [539] = { name = "Terror Touch", level = 40, category = "physical", monsters = { "Ghost" } },

    -- Level 42
    [521] = { name = "MP Drainkiss", level = 42, category = "magical", monsters = { "Leech" } },
    [542] = { name = "Venom Shell", level = 42, category = "magical", monsters = { "Uragnite" } },

    -- Level 44
    [532] = { name = "Blitzstrahl", level = 44, category = "magical", monsters = { "Doll" } },
    [537] = { name = "Stinking Gas", level = 44, category = "magical", monsters = { "Doomed" } },
    [543] = { name = "Mandibular Bite", level = 44, category = "physical", monsters = { "Antlion" } },

    -- Level 46
    [555] = { name = "Magnetite Cloud", level = 46, category = "magical", monsters = { "Antica" } },
    [605] = { name = "Geist Wall", level = 46, category = "magical", monsters = { "Eft" } },
    [606] = { name = "Awful Eye", level = 46, category = "magical", monsters = { "Bugard" } },

    -- Level 48
    [530] = { name = "Refueling", level = 48, category = "enhancing", monsters = { "Bomb Cluster" } },
    [541] = { name = "Blood Saber", level = 48, category = "magical", monsters = { "Skeleton" } },
    [545] = { name = "Sickle Slash", level = 48, category = "physical", monsters = { "Spider" } },
    [575] = { name = "Jettatura", level = 48, category = "magical", monsters = { "Hippogryph" } },

    -- Level 50
    [531] = { name = "Ice Break", level = 50, category = "magical", monsters = { "Golem" } },
    [533] = { name = "Self-Destruct", level = 50, category = "magical", monsters = { "Bomb" } },
    [561] = { name = "Frightful Roar", level = 50, category = "magical", monsters = { "Taurus" } },

    -- Level 52
    [535] = { name = "Cold Wave", level = 52, category = "magical", monsters = { "Snoll" } },
    [548] = { name = "Filamented Hold", level = 52, category = "magical", monsters = { "Diremite" } },

    -- Level 54
    [563] = { name = "Hecatomb Wave", level = 54, category = "magical", monsters = { "Demon" } },
    [565] = { name = "Radiant Breath", level = 54, category = "breath", monsters = { "Wyvern" } },

    -- Level 56
    [574] = { name = "Feather Barrier", level = 56, category = "enhancing", monsters = { "Giant Bird" } },

    -- Level 58
    [593] = { name = "Magic Fruit", level = 58, category = "healing", monsters = { "Opo-opo" } },
    [629] = { name = "Flying Hip Press", level = 58, category = "physical", monsters = { "Bugbear" } },
    [634] = { name = "Light of Penance", level = 58, category = "magical", monsters = { "Tonberry" } },

    -- Level 60
    [589] = { name = "Dimensional Death", level = 60, category = "physical", monsters = { "Shadow / Fomor" } },
    [652] = { name = "Spiral Spin", level = 60, category = "physical", monsters = { "Ladybug" } },
    [700] = { name = "Death Scissors", level = 60, category = "physical", monsters = { "Crab" } },

    -- Level 61
    [557] = { name = "Eyes On Me", level = 61, category = "magical", monsters = { "Ahriman" } },
    [604] = { name = "Bad Breath", level = 61, category = "magical", monsters = { "Morbol" } },
    [650] = { name = "Seedspray", level = 61, category = "physical", monsters = { "Rafflesia" } },
    [701] = { name = "Maelstrom", level = 61, category = "magical", monsters = { "Kraken" } },

    -- Level 62
    [595] = { name = "1000 Needles", level = 62, category = "magical", monsters = { "Sabotender / Cactuar" } },
    [564] = { name = "Body Slam", level = 62, category = "physical", monsters = { "Dragon" } },
    [702] = { name = "Memento Mori", level = 62, category = "magical", monsters = { "Naraka" } },

    -- Level 63
    [631] = { name = "Hydro Shot", level = 63, category = "physical", monsters = { "Sahagin" } },
    [628] = { name = "Frypan", level = 63, category = "physical", monsters = { "Moblin" } },
    [703] = { name = "Spinal Cleave", level = 63, category = "physical", monsters = { "Orcish Warmachine" } },
    [704] = { name = "Frenetic Rip", level = 63, category = "physical", monsters = { "Goobbue" } },

    -- Level 64
    [573] = { name = "Feather Tickle", level = 64, category = "magical", monsters = { "Colibri" } },
    [576] = { name = "Yawn", level = 64, category = "magical", monsters = { "Apkallu" } },
    [579] = { name = "Voracious Trunk", level = 64, category = "magical", monsters = { "Marid" } },

    -- Level 65
    [610] = { name = "Infrasonics", level = 65, category = "magical", monsters = { "Lizard" } },
    [647] = { name = "Zephyr Mantle", level = 65, category = "enhancing", monsters = { "Puk" } },

    -- Level 66
    [608] = { name = "Frost Breath", level = 66, category = "breath", monsters = { "Raptor - CoP" } },
    [621] = { name = "Sandspray", level = 66, category = "magical", monsters = { "Qiqirn" } },
    [651] = { name = "Corrosive Ooze", level = 66, category = "magical", monsters = { "Slug" } },

    -- Level 67
    [632] = { name = "Diamondhide", level = 67, category = "enhancing", monsters = { "Troll Hoplites" } },
    [633] = { name = "Enervation", level = 67, category = "magical", monsters = { "Troll Cannoneers" } },

    -- Level 68
    [637] = { name = "Firespit", level = 68, category = "magical", monsters = { "Mamool Ja - Mage Class" } },
    [636] = { name = "Warm-Up", level = 68, category = "enhancing", monsters = { "Mamool Ja - Bst, Blu, Drg, Nin, and Thf" } },

    -- Level 69
    [640] = { name = "Tail Slap", level = 69, category = "physical", monsters = { "Merrow" } },
    [641] = { name = "Hysteric Barrage", level = 69, category = "physical", monsters = { "Lamia" } },
    [648] = { name = "Regurgitation", level = 69, category = "magical", monsters = { "Peiste" } },

    -- Level 70
    [642] = { name = "Amplification", level = 70, category = "enhancing", monsters = { "Flan" } },
    [643] = { name = "Cannonball", level = 70, category = "physical", monsters = { "Wamouracampa" } },
    [653] = { name = "Asuran Claws", level = 70, category = "physical", monsters = { "Gnole" } },

    -- Level 71
    [588] = { name = "Lowing", level = 71, category = "magical", monsters = { "Buffalo" } },
    [591] = { name = "Heat Breath", level = 71, category = "breath", monsters = { "Manticore" } },
    [655] = { name = "Triumphant Roar", level = 71, category = "enhancing", monsters = { "Gargouille" } },

    -- Level 72
    [611] = { name = "Disseverment", level = 72, category = "physical", monsters = { "Aern" } },
    [654] = { name = "Sub-zero Smash", level = 72, category = "physical", monsters = { "Ruszor" } },
    [705] = { name = "Saline Coat", level = 72, category = "enhancing", monsters = { "Sea Monk" } },

    -- Level 73
    [616] = { name = "Temporal Shift", level = 73, category = "magical", monsters = { "Hpemde" } },
    [706] = { name = "Ram Charge", level = 73, category = "physical", monsters = { "Ram" } },
    [707] = { name = "Mind Blast", level = 73, category = "magical", monsters = { "Soulflayer" } },

    -- Level 74
    [612] = { name = "Actinic Burst", level = 74, category = "magical", monsters = { "Ghrah" } },
    [646] = { name = "Magic Hammer", level = 74, category = "magical", monsters = { "Magic Pot" } },
    [708] = { name = "Reactor Cool", level = 74, category = "magical", monsters = { "Chariot" } },

    -- Level 75
    [645] = { name = "Exuviation", level = 75, category = "healing", monsters = { "Wamoura" } },
    [615] = { name = "Plasma Charge", level = 75, category = "magical", monsters = { "Euvhi" } },
    [709] = { name = "Vertical Cleave", level = 75, category = "physical", monsters = { "Baldurno" } },

    -- Level 76
    [658] = { name = "Plenilune Embrace", level = 76, category = "healing", monsters = { "Gnole" } },

    -- Level 77
    [656] = { name = "Acrid Stream", level = 77, category = "magical", monsters = { "Clionid" } },
    [663] = { name = "Leafstorm", level = 77, category = "magical", monsters = { "Treant" } },

    -- Level 78
    [660] = { name = "Cimicine Discharge", level = 78, category = "magical", monsters = { "Gnat" } },
    [710] = { name = "Regeneration", level = 78, category = "healing", monsters = { "Limule" } },

    -- Level 79
    [661] = { name = "Animating Wail", level = 79, category = "magical", monsters = { "Qutrub" } },
    [662] = { name = "Battery Charge", level = 79, category = "magical", monsters = { "Magic Pot" } },

    -- Level 80
    [657] = { name = "Blazing Bound", level = 80, category = "magical", monsters = { "Limule" } },
    [659] = { name = "Demoralizing Roar", level = 80, category = "magical", monsters = { "Wivre" } },

    -- Level 81
    [665] = { name = "Final Sting", level = 81, category = "physical", monsters = { "Bee - lvl 30+" } },
    [666] = { name = "Goblin Rush", level = 81, category = "physical", monsters = { "Goblin - Non CoP" } },

    -- Level 82
    [667] = { name = "Vanity Dive", level = 82, category = "physical", monsters = { "Hippogryph" } },
    [668] = { name = "Magic Barrier", level = 82, category = "enhancing", monsters = { "Ahriman" } },

    -- Level 83
    [669] = { name = "Whirl of Rage", level = 83, category = "physical", monsters = { "Evil Weapon" } },
    [670] = { name = "Benthic Typhoon", level = 83, category = "physical", monsters = { "Murex" } },

    -- Level 84
    [671] = { name = "Auroral Drape", level = 84, category = "magical", monsters = { "Weeper" } },
    [672] = { name = "Osmosis", level = 84, category = "magical", monsters = { "Amoeban" } },

    -- Level 85
    [673] = { name = "Quad. Continuum", level = 85, category = "physical", monsters = { "Gorger" } },
    [674] = { name = "Fantod", level = 85, category = "enhancing", monsters = { "Hippogryph" } },

    -- Level 86
    [675] = { name = "Thermal Pulse", level = 86, category = "magical", monsters = { "Zdei" } },

    -- Level 87
    [677] = { name = "Empty Thrash", level = 87, category = "physical", monsters = { "Craver" } },
    [678] = { name = "Dream Flower", level = 87, category = "magical", monsters = { "Mandragora" } },

    -- Level 88
    [679] = { name = "Occultation", level = 88, category = "enhancing", monsters = { "Ahriman" } },
    [680] = { name = "Charged Whisker", level = 88, category = "magical", monsters = { "Coeurl" } },

    -- Level 89
    [681] = { name = "Winds of Promy.", level = 89, category = "magical", monsters = { "Xzomit" } },
    [682] = { name = "Delta Thrust", level = 89, category = "physical", monsters = { "Peiste" } },

    -- Level 90
    [683] = { name = "Everyone's Grudge", level = 90, category = "magical", monsters = { "Tonberry" } },
    [684] = { name = "Reaving Wind", level = 90, category = "magical", monsters = { "Amphiptere" } },

    -- Level 91
    [685] = { name = "Barrier Tusk", level = 91, category = "enhancing", monsters = { "Marid" } },
    [686] = { name = "Mortal Ray", level = 91, category = "magical", monsters = { "Basilisk" } },

    -- Level 92
    [687] = { name = "Water Bomb", level = 92, category = "magical", monsters = { "Acuex" } },
    [688] = { name = "Heavy Strike", level = 92, category = "physical", monsters = { "Golem" } },

    -- Level 93
    [689] = { name = "Dark Orb", level = 93, category = "magical", monsters = { "Gargouille" } },

    -- Level 94
    [690] = { name = "White Wind", level = 94, category = "healing", monsters = { "Unicorn" } },

    -- Level 95
    [692] = { name = "Sudden Lunge", level = 95, category = "physical", monsters = { "Ladybug" } },
    [736] = { name = "Thunderbolt", level = 95, category = "magical", monsters = { "Behemoth" } },
    [737] = { name = "Harden Shell", level = 95, category = "enhancing", monsters = { "Adamantoise" } },

    -- Level 96
    [693] = { name = "Quadrastrike", level = 96, category = "physical", monsters = { "Demon - WotG or CoP" } },
    [694] = { name = "Vapor Spray", level = 96, category = "magical", monsters = { "Ironclad" } },
    [738] = { name = "Absolute Terror", level = 96, category = "magical", monsters = { "Wyrm" } },

    -- Level 97
    [695] = { name = "Thunder Breath", level = 97, category = "breath", monsters = { "Dragon" } },
    [739] = { name = "Gates of Hades", level = 97, category = "magical", monsters = { "Cerberus" } },
    [740] = { name = "Tourbillion", level = 97, category = "physical", monsters = { "Khimaira" } },

    -- Level 98
    [696] = { name = "O. Counterstance", level = 98, category = "enhancing", monsters = { "Orcish Champion" } },
    [697] = { name = "Amorphic Spikes", level = 98, category = "physical", monsters = { "Flan" } },
    [741] = { name = "Pyric Bulwark", level = 98, category = "enhancing", monsters = { "Hydra" } },

    -- Level 99
    [698] = { name = "Wind Breath", level = 99, category = "breath", monsters = { "Dragon" } },
    [699] = { name = "Barbed Crescent", level = 99, category = "physical", monsters = { "Shadow / Fomor" } },
    [742] = { name = "Bilgestorm", level = 99, category = "physical", monsters = { "Dvergr" } },
    [743] = { name = "Bloodrake", level = 99, category = "physical", monsters = { "Vampyr" } },
    
    -- Additional Level 99 spells from FFXIclopedia
    [744] = { name = "Nature's Meditation", level = 99, category = "enhancing", monsters = { "Rafflesia" } },
    [745] = { name = "Tempestuous Upheaval", level = 99, category = "magical", monsters = { "Bahamut" } },
    [746] = { name = "Rending Deluge", level = 99, category = "magical", monsters = { "Leviathan" } },
    [747] = { name = "Embalming Earth", level = 99, category = "magical", monsters = { "Titan" } },
    [748] = { name = "Paralyzing Triad", level = 99, category = "magical", monsters = { "Cerberus" } },
    [749] = { name = "Foul Waters", level = 99, category = "magical", monsters = { "Orobon" } },
    [750] = { name = "Glutinous Dart", level = 99, category = "physical", monsters = { "Slug" } },
    [751] = { name = "Retinal Glare", level = 99, category = "magical", monsters = { "Gorgimera" } },
    [752] = { name = "Erratic Flutter", level = 99, category = "magical", monsters = { "Butterfly" } },
    [753] = { name = "Subduction", level = 99, category = "magical", monsters = { "Chapuli" } },
    [754] = { name = "Thrashing Assault", level = 99, category = "physical", monsters = { "Mantis" } },
    [755] = { name = "Diffusion Ray", level = 99, category = "magical", monsters = { "Amoeban" } },
    [756] = { name = "Rail Cannon", level = 99, category = "magical", monsters = { "Chariot" } },
    [757] = { name = "Restoral", level = 99, category = "healing", monsters = { "Wamouracampa" } },
    [758] = { name = "Sinker Drill", level = 99, category = "physical", monsters = { "Puroboros" } },
    [759] = { name = "Molting Plumage", level = 99, category = "magical", monsters = { "Apkallu" } },
    [760] = { name = "Nectarous Deluge", level = 99, category = "magical", monsters = { "Rafflesia" } },
    [761] = { name = "Sweeping Gouge", level = 99, category = "physical", monsters = { "Chapuli" } },
    [762] = { name = "Atramentous Libations", level = 99, category = "magical", monsters = { "Oblivion" } },
    [763] = { name = "Searing Tempest", level = 99, category = "magical", monsters = { "Ifrit" } },
    [764] = { name = "Blinding Fulgor", level = 99, category = "magical", monsters = { "Ramuh" } },
    [765] = { name = "Spectral Floe", level = 99, category = "magical", monsters = { "Shiva" } },
    [766] = { name = "Scouring Spate", level = 99, category = "magical", monsters = { "Leviathan" } },
    [767] = { name = "Anvil Lightning", level = 99, category = "magical", monsters = { "Ramuh" } },
    [768] = { name = "Silent Storm", level = 99, category = "magical", monsters = { "Garuda" } },
    [769] = { name = "Entomb", level = 99, category = "magical", monsters = { "Titan" } },
    [770] = { name = "Tenebral Crush", level = 99, category = "magical", monsters = { "Fenrir" } },
    [771] = { name = "Saurian Slide", level = 99, category = "physical", monsters = { "Raptor" } },
    [772] = { name = "Palling Salvo", level = 99, category = "magical", monsters = { "Fenrir" } },
    [773] = { name = "Droning Whirlwind", level = 99, category = "magical", monsters = { "Garuda" } },
    [774] = { name = "Carcharian Verve", level = 99, category = "magical", monsters = { "Orobon" } },
    [775] = { name = "Blistering Roar", level = 99, category = "magical", monsters = { "Bahamut" } },
    [776] = { name = "Uproot", level = 99, category = "magical", monsters = { "Mandragora" } },
    [777] = { name = "Crashing Thunder", level = 99, category = "magical", monsters = { "Ramuh" } },
    [778] = { name = "Polar Roar", level = 99, category = "magical", monsters = { "Shiva" } },
    [779] = { name = "Mighty Guard", level = 99, category = "enhancing", monsters = { "Adamantoise" } },
    [780] = { name = "Cruel Joke", level = 99, category = "magical", monsters = { "Tonberry" } },
    [781] = { name = "Cesspool", level = 99, category = "magical", monsters = { "Orobon" } }
}
