addon.name      = 'EnemyCastBar';
addon.author    = 'Shiyo';
addon.version   = '1.0.0.2';
addon.desc      = 'Shows enemy cast bars with ImGui config';
addon.link      = 'https://ashitaxi.com/';

require('common');
require ('enemycastbarlibs')
local fonts = require('fonts');
local settings = require('settings');
local imgui = require('imgui');
local bit = require('bit');

local textDuration = 0
local monsterIndex
local tpId
local tpString
local monsterId
local monsterName
local spellId
local tpName

-- ImGui config window state
local showConfig = { true }

local windowWidth = AshitaCore:GetConfigurationManager():GetFloat('boot', 'ffxi.registry', '0001', 1024);
local windowHeight = AshitaCore:GetConfigurationManager():GetFloat('boot', 'ffxi.registry', '0002', 768);

local default_settings = T{
	font = T{
           visible = true,
           font_family = 'Arial',
           font_height = 18,
           color = 0xFFFFFFFF,
           position_x = 785,
           position_y = 470,
		background = T{
               visible = true,
               color = 0x80000000,
		}
       }
};

local function CheckString(string)
    if (string ~= nil) then
        textDuration = os.time() + 5 -- Only display text for 5 seconds
    end
end

local enemycastbar = T{
	settings = settings.load(default_settings)
};

local UpdateSettings = function(settings)
    enemycastbar.settings = settings;
    if (enemycastbar.font ~= nil) then
        enemycastbar.font:apply(enemycastbar.settings.font)
    end
end

-- Color conversion utilities
local function ARGBToImGui(argb)
    local a = bit.band(bit.rshift(argb, 24), 0xFF) / 255
    local r = bit.band(bit.rshift(argb, 16), 0xFF) / 255
    local g = bit.band(bit.rshift(argb, 8), 0xFF) / 255
    local b = bit.band(argb, 0xFF) / 255
    return {r, g, b, a}
end

local function ImGuiToARGB(rgba)
    local a = math.floor(rgba[4] * 255)
    local r = math.floor(rgba[1] * 255)
    local g = math.floor(rgba[2] * 255)
    local b = math.floor(rgba[3] * 255)
    return bit.lshift(a, 24) + bit.lshift(r, 16) + bit.lshift(g, 8) + b
end

-- Font families as null-separated string for ImGui
local fontFamiliesString = 'Arial\0Consolas\0Courier New\0Lucida Console\0Microsoft Sans Serif\0Tahoma\0Times New Roman\0Verdana\0'
local fontFamilies = {'Arial', 'Consolas', 'Courier New', 'Lucida Console', 'Microsoft Sans Serif', 'Tahoma', 'Times New Roman', 'Verdana'}

local function GetFontFamilyIndex(fontFamily)
    for i, family in ipairs(fontFamilies) do
        if family == fontFamily then
            return i
        end
    end
    return 1
end

-- Function to render the UI
local function render_ui()
    if not showConfig[1] then
        return
    end

    local flags = bit.bor(
        ImGuiWindowFlags_AlwaysAutoResize,
        ImGuiWindowFlags_NoSavedSettings
    )

    if imgui.Begin('EnemyCastBar Configuration##enemycastbar', showConfig, flags) then
        -- Font Family Selection
        imgui.Text('Font Family:')
        local currentFontIndex = GetFontFamilyIndex(enemycastbar.settings.font.font_family)
        local font_selection = { currentFontIndex - 1 }
        
        if imgui.Combo('##font_family', font_selection, fontFamiliesString) then
            enemycastbar.settings.font.font_family = fontFamilies[font_selection[1] + 1]
            UpdateSettings(enemycastbar.settings)
            settings.save()
        end
        imgui.Separator()
        
        -- Font Height Slider
        imgui.Text('Font Size:')
        local fontHeight = { enemycastbar.settings.font.font_height }
        if imgui.SliderInt('##font_height', fontHeight, 8, 48) then
            enemycastbar.settings.font.font_height = fontHeight[1]
            UpdateSettings(enemycastbar.settings)
            settings.save()
        end
        imgui.Separator()
        
        -- Text Color Picker
        imgui.Text('Text Color:')
        local textColor = ARGBToImGui(enemycastbar.settings.font.color)
        local newTextColor = {textColor[1], textColor[2], textColor[3]}
        if imgui.ColorEdit3('##text_color', newTextColor) then
            newTextColor[4] = textColor[4] -- Keep original alpha
            enemycastbar.settings.font.color = ImGuiToARGB(newTextColor)
            UpdateSettings(enemycastbar.settings)
            settings.save()
        end
        imgui.SameLine()
        imgui.Text('Preview:')
        local previewColor = ARGBToImGui(enemycastbar.settings.font.color)
        imgui.ColorButton('##text_preview', previewColor, 0, { 50, 20 })
        imgui.Separator()
        
        -- Position Controls
        imgui.Text('Position:')
        local posX = { enemycastbar.settings.font.position_x }
        local posY = { enemycastbar.settings.font.position_y }
        
        if imgui.DragInt('X Position##pos_x', posX, 1, 0, windowWidth) then
            enemycastbar.settings.font.position_x = posX[1]
            UpdateSettings(enemycastbar.settings)
            settings.save()
        end
        
        if imgui.DragInt('Y Position##pos_y', posY, 1, 0, windowHeight) then
            enemycastbar.settings.font.position_y = posY[1]
            UpdateSettings(enemycastbar.settings)
            settings.save()
        end
        imgui.Separator()
        
        -- Background Controls
        local bgVisible = { enemycastbar.settings.font.background.visible }
        if imgui.Checkbox('Show Background', bgVisible) then
            enemycastbar.settings.font.background.visible = bgVisible[1]
            UpdateSettings(enemycastbar.settings)
            settings.save()
        end
        
        if enemycastbar.settings.font.background.visible then
            imgui.Text('Background Color:')
            local bgColor = ARGBToImGui(enemycastbar.settings.font.background.color)
            local newBgColor = {bgColor[1], bgColor[2], bgColor[3], bgColor[4]}
            if imgui.ColorEdit4('##bg_color', newBgColor) then
                enemycastbar.settings.font.background.color = ImGuiToARGB(newBgColor)
                UpdateSettings(enemycastbar.settings)
                settings.save()
            end
            imgui.SameLine()
            imgui.Text('Preview:')
            local bgPreviewColor = ARGBToImGui(enemycastbar.settings.font.background.color)
            imgui.ColorButton('##bg_preview', bgPreviewColor, 0, { 50, 20 })
        end
        imgui.Separator()
        
        -- Reset Button
        if imgui.Button('Reset to Defaults') then
            enemycastbar.settings = settings.load(default_settings)
            UpdateSettings(enemycastbar.settings)
            settings.save()
        end
        
        imgui.SameLine()
        
        -- Close Button
        if imgui.Button('Close') then
            showConfig[1] = false
        end
        
    end
    imgui.End()
end

ashita.events.register('load', 'load_cb', function ()
    enemycastbar.font = fonts.new(enemycastbar.settings.font);
    settings.register('settings', 'settingchange', UpdateSettings);
end);

ashita.events.register('command', 'command_cb', function (e)
    local command = e.command:lower()
    
    if (command == '/ecb') or (command == '/enemycastbar') then
        showConfig[1] = not showConfig[1]
        return true
    end
    
    return false
end);

ashita.events.register('d3d_present', 'present_cb', function ()
    -- Render the UI if it's open
    render_ui()

    local fontObject = enemycastbar.font;
    if (fontObject.position_x > windowWidth) then
        fontObject.position_x = 0;
    end
    if (fontObject.position_y > windowHeight) then
        fontObject.position_y = 0;
    end
    if (fontObject.position_x ~= enemycastbar.settings.font.position_x) or (fontObject.position_y ~= enemycastbar.settings.font.position_y) then
        enemycastbar.settings.font.position_x = fontObject.position_x;
        enemycastbar.settings.font.position_y = fontObject.position_y;
        settings.save()
    end

    if (os.time() > textDuration ) then
        -- Hide text, reset variables to nil
        enemycastbar.font.visible = false;
        monsterIndex = nil
        tpId = nil
        tpString = nil
        monsterName = nil
        spellId = nil
        return;
    end
	if monsterName then
        if tpString and (tpId ~= nil) then
            enemycastbar.font.text = ('%s%s'):fmt(monsterName, tpString);
            enemycastbar.font.visible = true;
        elseif monsterName and (spellId ~= nil) then
            enemycastbar.font.text = ('%s%s'):fmt(monsterName, spellString);
            enemycastbar.font.visible = true;
        else
            enemycastbar.font.visible = false;
            return;
        end
    end
end);

ashita.events.register('packet_in', 'packet_in_cb', function (e)
    local myTarget = AshitaCore:GetMemoryManager():GetTarget():GetTargetIndex(AshitaCore:GetMemoryManager():GetTarget():GetIsSubTargetActive())
    -- Packet: Action
    if (e.id == 0x028) then
        local actionPacket = ParseActionPacket(e);
        if (actionPacket.Type == 7) and IsMonster(actionPacket.UserIndex) and (myTarget == actionPacket.UserIndex) then -- Mobskill Start
            local actionMessage = actionPacket.Targets[1].Actions[1].Message
            monsterId = struct.unpack('L', e.data, 0x05 + 0x01);
            monsterIndex = bit.band(monsterId, 0x7FF);
            tpId = ashita.bits.unpack_be(e.data:totable(), 0, 213, 17);
            if (tpId < 256) then
                tpName = AshitaCore:GetResourceManager():GetAbilityById(tpId)
                tpString = ' readies ' .. tpName.Name[1]
            else
                local tempName = AshitaCore:GetResourceManager():GetString('monsters.abilities', tpId - 256);
                if (tempName ~= nil) then
                    tpName = tempName;
                    tpString = ' readies ' .. tpName
                end
            end
            monsterName = AshitaCore:GetMemoryManager():GetEntity():GetName(monsterIndex);
            textDuration = 0
            CheckString(tpString)
            if (actionMessage == 0) then -- Mob Skill interrupted
                -- print('Enemy mob ability interrupted!!');
                monsterId = struct.unpack('L', e.data, 0x05 + 0x01);
                monsterIndex = bit.band(monsterId, 0x7FF);
                textDuration = 0
                tpId = 0
                tpString = '\'s TP move interrupted!!!'
                monsterName = AshitaCore:GetMemoryManager():GetEntity():GetName(monsterIndex);
                CheckString(tpString)
            end
        end
        if (actionPacket.Type == 8) and IsMonster(actionPacket.UserIndex) and (myTarget == actionPacket.UserIndex) then  -- Magic start
            local actionMessage = actionPacket.Targets[1].Actions[1].Message
            monsterId = struct.unpack('L', e.data, 0x05 + 0x01);
            monsterIndex = bit.band(monsterId, 0x7FF);
            spellId = actionPacket.Targets[1].Actions[1].Param
            local spellResource = AshitaCore:GetResourceManager():GetSpellById(spellId);
            if spellResource then
                -- print(string.format('Enemy started casting %s.', spellResource.Name[1]));
                if (spellResource.Name[1] ~= nil) then
                    spellString = ' casting ' .. spellResource.Name[1]
                end
                monsterName = AshitaCore:GetMemoryManager():GetEntity():GetName(monsterIndex);
                textDuration = 0
                -- print(string.format('monsterName: %s', monsterName));
                CheckString(spellString)
            end
            if (actionMessage == 0) then -- Magic Interrupted
                -- print('Enemy spell interrupted!!');
                textDuration = 0
                spellString = '\'s spell interrupted!!!'
                monsterName = AshitaCore:GetMemoryManager():GetEntity():GetName(monsterIndex);
                CheckString(spellString)
           end
        end
    end
end);

ashita.events.register('unload', 'unload_cb', function ()
    if (enemycastbar.font ~= nil) then
        enemycastbar.font:destroy();
    end
    settings.save();
end);