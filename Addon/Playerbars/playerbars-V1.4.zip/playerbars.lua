addon.name      = 'playerbars'
addon.author    = 'Oneword - Ninja Ai'
addon.version   = '1.4'
addon.desc      = 'Displays player HP, MP, TP bars and target HP'
addon.link      = ''

require('common')
local settings = require('settings')

-- Default Settings
local default_settings = T{
    show_hp = true,
    show_mp = true,
    show_tp = true,
    show_target = true,
    show_config = false,
    position_x = 100,
    position_y = 100,
    hp_position_x = nil,
    hp_position_y = nil,
    mp_position_x = nil,
    mp_position_y = nil,
    tp_position_x = nil,
    tp_position_y = nil,
    target_position_x = nil,
    target_position_y = nil,
    bar_width = 200,
    bar_height = 20,
    target_bar_width = 300,  -- New setting for target bar width
    target_bar_height = 20,  -- New setting for target bar height
    spacing = 5,
    hp_color = 0xFF00FF00,  -- Green (ARGB)
    mp_color = 0xFFC369FF,  -- Purple (ARGB)
    tp_color = 0xFF00ABFF,  -- Orange (ARGB)
    target_color = 0xFFFF0000,  -- Red (ARGB)
    bg_color = 0x80000000,  -- Semi-transparent black
    font_family = 'Arial',
    font_size = 15,
    target_font_size = 15,  -- New setting for target font size
    show_max_values = false
}

-- Create a shared state table
local state = {
    settings = settings.load(default_settings)
}

-- Load modules with the shared state
package.path = package.path .. ';' .. addon.path .. '\\?.lua'
local config = require('config')
config.initialize(state)

local fonts = require('fonts')
fonts.initialize(state)

local display = require('display')
local commands = require('commands')

-- Register settings callback
settings.register('settings', 'settings_update', function (s)
    if (s ~= nil) then
        state.settings = s
    end

    -- Update the font objects
    fonts.apply_settings()
    
    -- Save the current settings
    settings.save()
end)

-- Initialize addon
ashita.events.register('load', 'load_cb', function ()
    print("[Playerbars] Addon loaded! Use /playerbars to toggle config window.")
end)

-- Clean up on unload
ashita.events.register('unload', 'unload_cb', function ()
    print("[Playerbars] Unloading addon...")
    
    -- Update settings with current positions before unloading
    fonts.save_positions()
    
    fonts.cleanup()
    print("[Playerbars] Addon unloaded.")
end)

-- Main update function
ashita.events.register('d3d_present', 'present_cb', function ()
    display.update(state)
end)

-- Command handler
ashita.events.register('command', 'command_cb', function (e)
    commands.process(e, state)
end)
