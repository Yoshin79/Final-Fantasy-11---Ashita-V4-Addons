-- config/colors.lua
local colors = {};

-- Define element colors
colors.element_colors = {
    ["Fire"] = { 1.0, 0.4, 0.4, 1.0 },
    ["Earth"] = { 0.8, 0.6, 0.2, 1.0 },
    ["Water"] = { 0.4, 0.6, 1.0, 1.0 },
    ["Wind"] = { 0.7, 1.0, 0.7, 1.0 },
    ["Ice"] = { 0.7, 0.9, 1.0, 1.0 },
    ["Lightning"] = { 0.8, 0.4, 1.0, 1.0 },
    ["Light"] = { 1.0, 1.0, 0.8, 1.0 },
    ["Dark"] = { 0.6, 0.4, 0.7, 1.0 }
};

-- Function to get day color
function colors.get_day_color(day_name)
    if day_name == "Firesday" then
        return colors.element_colors["Fire"];
    elseif day_name == "Earthsday" then
        return colors.element_colors["Earth"];
    elseif day_name == "Watersday" then
        return colors.element_colors["Water"];
    elseif day_name == "Windsday" then
        return colors.element_colors["Wind"];
    elseif day_name == "Iceday" then
        return colors.element_colors["Ice"];
    elseif day_name == "Lightningday" then
        return colors.element_colors["Lightning"];
    elseif day_name == "Lightsday" then
        return colors.element_colors["Light"];
    elseif day_name == "Darksday" then
        return colors.element_colors["Dark"];
    else
        return { 1.0, 1.0, 1.0, 1.0 }; -- Default white
    end
end

return colors;
