local target = {
    current = "No Target",
    index = 0,
    last_check = 0
};

function target.initialize()
    target.update();
end

function target.set(name)
    target.current = name;
    print(string.format("[%s] Target manually set to: %s", addon.name, name));
end

function target.update()
    local success = pcall(function()
        local target_index = AshitaCore:GetMemoryManager():GetTarget():GetTargetIndex(0);
        if target_index > 0 then
            local entity = GetEntity(target_index);
            if entity and entity.Name then
                target.current = entity.Name;
                target.index = target_index;
            else
                target.current = "No Target";
                target.index = 0;
            end
        else
            target.current = "No Target";
            target.index = 0;
        end
    end);
    
    if not success then
        print("[abyproc] Error updating target");
    end
end

function target.handle_command(e)
    if not e or not e.command then return false; end
    
    local cmd = e.command;
    if not cmd or cmd:sub(1, 8) ~= '/abyproc' then return false; end
    
    e.blocked = true;
    
    local args = {};
    for arg in cmd:gmatch("%S+") do
        args[#args + 1] = arg;
    end
    
    -- Command handling logic here...
    -- [Previous command handling code]
    
    return true;
end

return target;
