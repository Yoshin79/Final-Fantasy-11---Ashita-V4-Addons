local procs = {
    used_procs = {},
    staggered = false,
    stagger_time = 0
};

function procs.mark_used(proc_name)
    procs.used_procs[proc_name] = true;
    print(string.format("[%s] Marked proc as used: %s", addon.name, proc_name));
end

function procs.reset()
    procs.used_procs = {};
    procs.staggered = false;
end

function procs.is_used(proc_name)
    return procs.used_procs[proc_name] == true;
end

function procs.check_chat_message(e)
    if not e.message then return false; end
    
    local ws_pattern = "You use ([%w%s:]+)%.";
    local ws_match = e.message:match(ws_pattern);
    if ws_match then
        procs.mark_used(ws_match);
    end
    
    if e.message:find("staggers") or e.message:find("~Staggered~") then
        procs.staggered = true;
        procs.stagger_time = os.time();
        print(string.format("[%s] STAGGER DETECTED!", addon.name));
    end
    
    return false;
end

return procs;
