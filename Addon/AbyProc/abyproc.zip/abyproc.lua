-- abyproc.lua
addon = {};
addon.name = 'AbyProc';
addon.author = 'Oneword with the help of Replit Ai and Ninja Ai';
addon.version = '4.6.3';
addon.desc = 'Enhanced Abyssea Proc Tracking';
addon.link = 'Sick-Deploy-Destroy';

-- Load ImGui if available 
local imgui = nil;
pcall(function() imgui = require('imgui'); end);

-- Load all components
local settings = require('config.settings');
local colors = require('config.colors');
local time = require('core.time');
local target = require('core.target');
local procs = require('core.procs');
local ui = require('ui.main');

-- Initialize the addon
ashita.events.register('load', 'load_cb', function()
    -- Print welcome message
    print('====================================================');
    print(string.format('    %s v%s by %s', addon.name, addon.version, addon.author));
    print('====================================================');
    print('             Latest Version 4.6.3');
    print('====================================================');
    
    settings.load();
    target.initialize();
end);

-- Register event handlers
ashita.events.register('command', 'command_cb', target.handle_command);
ashita.events.register('text_in', 'text_in_cb', procs.check_chat_message);
ashita.events.register('d3d_present', 'present_cb', ui.render);
ashita.events.register('unload', 'unload_cb', function()
    settings.save();
    print('[abyproc] Addon unloaded');
end);

return addon;
