local imgui = require('imgui');
local colors = require('config.colors');

local red_procs = {};

function red_procs.render()
    imgui.PushStyleColor(ImGuiCol_Header, { 0.7, 0.2, 0.2, 1.0 });          -- RED header
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.8, 0.3, 0.3, 1.0 });   -- Lighter red
    imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.9, 0.4, 0.4, 1.0 });    -- Lightest red
    
    if imgui.CollapsingHeader('Red Procs (Weapon Skills)', ImGuiTreeNodeFlags_DefaultOpen) then
        imgui.PushStyleColor(ImGuiCol_ChildBg, { 0.18, 0.18, 0.25, 1.0 });
        if imgui.BeginChild('red_procs_section', { 0, 300 }, true) then
            imgui.Columns(2, 'red_procs_columns', false);
            
            -- LEFT COLUMN
            imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, "Great Katana:");
            imgui.Indent(10);
            imgui.TextColored(colors.element_colors["Wind"], "Tachi: Jinpu");
            imgui.TextColored(colors.element_colors["Light"], "Tachi: Koki");
            imgui.Unindent(10);
            
            imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, "Sword:");
            imgui.Indent(10);
            imgui.TextColored(colors.element_colors["Fire"], "Red Lotus Blade");
            imgui.TextColored(colors.element_colors["Light"], "Seraph Blade");
            imgui.Unindent(10);
            
            imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, "Dagger:");
            imgui.Indent(10);
            imgui.TextColored(colors.element_colors["Wind"], "Cyclone");
            imgui.TextColored(colors.element_colors["Dark"], "Energy Drain");
            imgui.Unindent(10);
            
            imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, "Staff:");
            imgui.Indent(10);
            imgui.TextColored(colors.element_colors["Light"], "Sunburst");
            imgui.TextColored(colors.element_colors["Earth"], "Earth Crusher");
            imgui.Unindent(10);
            
            imgui.NextColumn();
            
            -- RIGHT COLUMN
            imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, "Polearm:");
            imgui.Indent(10);
            imgui.TextColored(colors.element_colors["Lightning"], "Raiden Thrust");
            imgui.Unindent(10);
            
            imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, "Club:");
            imgui.Indent(10);
            imgui.TextColored(colors.element_colors["Light"], "Seraph Strike");
            imgui.Unindent(10);
            
            imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, "Katana:");
            imgui.Indent(10);
            imgui.TextColored(colors.element_colors["Dark"], "Blade: Ei");
            imgui.Unindent(10);
            
            imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, "Scythe:");
            imgui.Indent(10);
            imgui.TextColored(colors.element_colors["Dark"], "Shadow of Death");
            imgui.Unindent(10);
            
            imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, "Great Sword:");
            imgui.Indent(10);
            imgui.TextColored(colors.element_colors["Ice"], "Freezebite");
            imgui.Unindent(10);
            
            imgui.Columns(1);
            imgui.EndChild();
        end
        imgui.PopStyleColor();
    end
    
    imgui.PopStyleColor(3);
end

return red_procs;
