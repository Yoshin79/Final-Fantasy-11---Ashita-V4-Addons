-- ui/blue_procs.lua
local imgui = require('imgui');

local blue_procs = {};

-- Time block weapon skill mappings
local time_block_ws = {
    ["0:00 to 4:00"] = {
        left = {
            { weapon = "Hand-to-Hand", skills = { "Dragon Kick", "One Inch Punch" } },
            { weapon = "Great Sword", skills = { "Scourge", "Herculean Slash" } }
        },
        right = {
            { weapon = "Polearm", skills = { "Wheeling Thrust", "Impulse Drive" } }
        }
    },
    ["4:00 to 8:00"] = {
        left = {
            { weapon = "Hand-to-Hand", skills = { "Asuran Fists", "Shijin Spiral" } },
            { weapon = "Great Sword", skills = { "Resolution", "Ground Strike" } }
        },
        right = {
            { weapon = "Polearm", skills = { "Impulse Drive", "Penta Thrust" } }
        }
    },
    ["8:00 to 12:00"] = {
        left = {
            { weapon = "Hand-to-Hand", skills = { "Asuran Fists", "Shijin Spiral" } },
            { weapon = "Great Sword", skills = { "Resolution", "Ground Strike" } }
        },
        right = {
            { weapon = "Polearm", skills = { "Wheeling Thrust", "Impulse Drive" } }
        }
    },
    ["12:00 to 16:00"] = {
        left = {
            { weapon = "Hand-to-Hand", skills = { "Asuran Fists", "Shijin Spiral" } },
            { weapon = "Great Sword", skills = { "Ground Strike", "Resolution" } }
        },
        right = {
            { weapon = "Polearm", skills = { "Penta Thrust", "Wheeling Thrust" } }
        }
    },
    ["16:00 to 20:00"] = {
        left = {
            { weapon = "Great Katana", skills = { "Tachi: Rana", "Tachi: Shoha" } }
        },
        right = {
            { weapon = "Ranged", skills = { "Last Stand", "Empyrical Arrow" } }
        }
    },
    ["20:00 to 0:00"] = {
        left = {
            { weapon = "Sword", skills = { "Chant du Cygne", "Requiescat" } }
        },
        right = {
            { weapon = "Great Sword", skills = { "Resolution", "Torcleaver" } }
        }
    }
};

function blue_procs.render(time_block)
    imgui.PushStyleColor(ImGuiCol_Header, { 0.2, 0.4, 0.7, 1.0 });         -- BLUE header
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.3, 0.5, 0.8, 1.0 });  -- Lighter blue
    imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.4, 0.6, 0.9, 1.0 });   -- Lightest blue
    
    if imgui.CollapsingHeader('Blue Procs (Time-Based WS)', ImGuiTreeNodeFlags_DefaultOpen) then
        imgui.PushStyleColor(ImGuiCol_ChildBg, { 0.18, 0.18, 0.25, 1.0 });
        if imgui.BeginChild('blue_procs_section', { 0, 200 }, true) then
            imgui.TextColored({ 1.0, 1.0, 1.0, 1.0 }, "Current Time Block: " .. time_block);
            imgui.Separator();
            
            -- Get the weapon skills for current time block
            local block_ws = time_block_ws[time_block];
            if block_ws then
                imgui.Columns(2, 'blue_proc_columns', false);
                
                -- Left column
                if block_ws.left then
                    for _, weapon in ipairs(block_ws.left) do
                        imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, weapon.weapon .. ":");
                        imgui.Indent(10);
                        for _, skill in ipairs(weapon.skills) do
                            imgui.Text(skill);
                        end
                        imgui.Unindent(10);
                        imgui.Spacing();
                    end
                end
                
                imgui.NextColumn();
                
                -- Right column
                if block_ws.right then
                    for _, weapon in ipairs(block_ws.right) do
                        imgui.TextColored({ 0.6, 0.6, 0.9, 1.0 }, weapon.weapon .. ":");
                        imgui.Indent(10);
                        for _, skill in ipairs(weapon.skills) do
                            imgui.Text(skill);
                        end
                        imgui.Unindent(10);
                        imgui.Spacing();
                    end
                end
                
                imgui.Columns(1);
            end
            
            imgui.EndChild();
        end
        imgui.PopStyleColor();
    end
    
    imgui.PopStyleColor(3);
end

return blue_procs;
