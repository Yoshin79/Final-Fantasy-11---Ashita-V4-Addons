-- ui/main.lua
local imgui = require('imgui');
local settings = require('config.settings');
local colors = require('config.colors');
local time = require('core.time');
local target = require('core.target');
local red_procs = require('ui.red_procs');
local blue_procs = require('ui.blue_procs');
local yellow_procs = require('ui.yellow_procs');

local ui = {};

-- Add window state tracking, just like in the working geospells.lua example
ui.is_open = { true };

-- Add the render_header function
function ui.render_header(vana_time, time_block)
    imgui.TextColored(colors.get_day_color(vana_time.day_name), 
        string.format("Day: %s", vana_time.day_name));
    imgui.SameLine(300);
    imgui.TextColored({ 0.7, 0.9, 1.0, 1.0 }, 
        string.format("Time: %s (%s)", vana_time.formatted_time, time_block));
    imgui.TextColored({ 1.0, 0.9, 0.7, 1.0 }, 
        string.format("Target: %s", target.current));
end

-- Add the render_controls function
function ui.render_controls()
    imgui.PushStyleColor(ImGuiCol_Header, { 0.5, 0.5, 0.5, 1.0 });          -- GREY header
    imgui.PushStyleColor(ImGuiCol_HeaderHovered, { 0.6, 0.6, 0.6, 1.0 });   -- Lighter grey
    imgui.PushStyleColor(ImGuiCol_HeaderActive, { 0.7, 0.7, 0.7, 1.0 });    -- Lightest grey
    
    if imgui.CollapsingHeader('Controls', ImGuiTreeNodeFlags_DefaultOpen) then
        -- Timezone dropdown
        imgui.TextColored({ 1.0, 1.0, 1.0, 1.0 }, "Timezone:");
        if imgui.BeginCombo("##timezone", settings.timezone_options[settings.timezone]) then
            for offset, label in pairs(settings.timezone_options) do
                local is_selected = (settings.timezone == offset);
                if imgui.Selectable(label, is_selected) then
                    settings.timezone = offset;
                    settings.save();
                end
                if is_selected then
                    imgui.SetItemDefaultFocus();
                end
            end
            imgui.EndCombo();
        end
        
        imgui.Separator();
        
        -- Proc type checkboxes
        imgui.Columns(3, 'proc_checkboxes', false);
        
        if imgui.Checkbox("Red Procs", { settings.show_red }) then
            settings.show_red = not settings.show_red;
            settings.save();
        end
        
        imgui.NextColumn();
        
        if imgui.Checkbox("Blue Procs", { settings.show_blue }) then
            settings.show_blue = not settings.show_blue;
            settings.save();
        end
        
        imgui.NextColumn();
        
        if imgui.Checkbox("Yellow Procs", { settings.show_yellow }) then
            settings.show_yellow = not settings.show_yellow;
            settings.save();
        end
        
        imgui.Columns(1);
        
        imgui.Separator();
        
        -- Control buttons
        if imgui.Button("Reset Tracking") then
            target.reset_procs();
        end
        
        imgui.SameLine();
        
        if imgui.Button("Update Target") then
            target.update();
        end
        
        imgui.SameLine();
        
        if imgui.Button("Show in Chat") then
            -- Just for display
        end
    end
    
    imgui.PopStyleColor(3);
end

function ui.render()
    -- We will now use our internal ui.is_open flag instead of settings.show_ui
    if not ui.is_open[1] or not imgui then return; end
    
    -- Check if stagger has timed out (30 seconds)
    if target.staggered and os.time() - target.stagger_time > 30 then
        target.staggered = false;
    end
    
    -- Update target occasionally
    local current_time = os.time();
    if current_time - target.last_check >= 2 then
        target.last_check = current_time;
        pcall(target.update);
    end
    
    -- Safely get time and target info
    local vana_time = time.calculate_vana_time();
    local time_block = time.get_time_block(vana_time.total_minutes);
    
    -- Window setup
    imgui.SetNextWindowSize({ 425, 800 }, ImGuiCond_FirstUseEver);
    
    -- Window styling
    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.15, 0.15, 0.23, 1.0 });
    imgui.PushStyleColor(ImGuiCol_TitleBg, { 0.6, 0.2, 0.2, 1.0 });
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, { 0.8, 0.3, 0.3, 1.0 });
    imgui.PushStyleColor(ImGuiCol_Border, { 0.4, 0.4, 0.4, 1.0 });
    
    -- Use ui.is_open to track window state. This makes the X button work.
    if imgui.Begin(string.format('abyproc v%s', addon.version), ui.is_open) then
        -- Render header
        ui.render_header(vana_time, time_block);
        
        -- Render controls
        ui.render_controls();
        
        -- Render proc sections
        if settings.show_red then red_procs.render(); end
        if settings.show_blue then blue_procs.render(time_block); end
        if settings.show_yellow then yellow_procs.render(vana_time); end
        
        -- Footer
        imgui.TextColored({ 0.7, 0.7, 0.7, 1.0 }, 
            "Auto-updating based on Earth time. Updates every 2 seconds. Use /abyproc help for commands.");
        
        imgui.End();
    end
    
    imgui.PopStyleColor(4);
end

-- Add function to toggle window visibility
function ui.toggle_window()
    ui.is_open[1] = not ui.is_open[1];
    -- Also update the settings flag to keep the saved state consistent.
    settings.show_ui = ui.is_open[1];
    settings.save();
end

return ui;
