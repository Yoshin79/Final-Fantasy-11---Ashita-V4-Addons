-- Data module for DelveHelper

local data = {
    -- Plasm count
    plasm = 0,
    
    -- Zone data
    zones = {
        {
            name = "Morimar Basalt Fields",
            color = "Alizarin",
            element = "Fire",
            yggrete_id = 3962,
            planchette_id = 2298,
            yggrete_count = 0,
            has_planchette = false
        },
        {
            name = "Foret de Hennetiel",
            color = "Zaffre",
            element = "Water",
            yggrete_id = 3961,
            planchette_id = 2297,
            yggrete_count = 0,
            has_planchette = false
        },
        {
            name = "Ceizak Battlegrounds",
            color = "Celadon",
            element = "Earth",
            yggrete_id = 3960,
            planchette_id = 2296,
            yggrete_count = 0,
            has_planchette = false
        },
        {
            name = "Yorcia Weald",
            color = "Russet",
            element = "Wind",
            yggrete_id = 8756,
            planchette_id = 2530,
            yggrete_count = 0,
            has_planchette = false
        },
        {
            name = "Marjami Ravine",
            color = "Phlox",
            element = "Lightning",
            yggrete_id = 8755,
            planchette_id = 2529,
            yggrete_count = 0,
            has_planchette = false
        },
        {
            name = "Kamihr Drifts",
            color = "Aster",
            element = "Ice",
            yggrete_id = 8757,
            planchette_id = 2531,
            yggrete_count = 0,
            has_planchette = false
        }
    }
};

-- Initialize data
function data.initialize()
    -- Reset all counts
    data.plasm = 0;
    
    for _, zone in ipairs(data.zones) do
        zone.yggrete_count = 0;
        zone.has_planchette = false;
    end
end

-- Find zone by yggrete ID
function data.find_zone_by_yggrete(id)
    for _, zone in ipairs(data.zones) do
        if zone.yggrete_id == id then
            return zone;
        end
    end
    return nil;
end

-- Find zone by planchette ID
function data.find_zone_by_planchette(id)
    for _, zone in ipairs(data.zones) do
        if zone.planchette_id == id then
            return zone;
        end
    end
    return nil;
end

return data;
