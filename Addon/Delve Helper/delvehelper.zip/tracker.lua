-- Tracker module for DelveHelper

local chat = require('chat');
local data = require('data');

local tracker = {};

-- Scan inventory for Delve items
function tracker.scan_inventory()
    local inventory = AshitaCore:GetMemoryManager():GetInventory();
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    
    -- Reset yggrete counts
    for _, zone in ipairs(data.zones) do
        zone.yggrete_count = 0;
        zone.has_planchette = false;
    end
    
    -- Check inventory for Yggrete Rocks
    for container = 0, 1 do  -- 0 = inventory, 1 = satchel
        for i = 0, 80 do
            local item = inventory:GetContainerItem(container, i);
            if item and item.Id ~= 0 and item.Count > 0 then
                local zone = data.find_zone_by_yggrete(item.Id);
                if zone then
                    zone.yggrete_count = zone.yggrete_count + item.Count;
                end
            end
        end
    end
    
    -- Check key items for planchettes
    for _, zone in ipairs(data.zones) do
        if player:HasKeyItem(zone.planchette_id) then
            zone.has_planchette = true;
        end
    end
end

-- Register text handler for Mweya Plasm updates
ashita.events.register('text_in', 'text_in_cb', function(e)
    -- Check for Mweya Plasm
    if e.message:match("You receive (%d+) corpuscles? of [Mm]weya [Pp]lasm") then
        local plasm = tonumber(e.message:match("You receive (%d+) corpuscles? of [Mm]weya [Pp]lasm"));
        if plasm then
            data.plasm = data.plasm + plasm;
            print(chat.header(addon.name):append(chat.message('Added ' .. plasm .. ' Mweya Plasm. Total: ' .. data.plasm)));
        end
    end
    
    -- Alternative format
    if e.message:match("You obtain (%d+) corpuscles? of [Mm]weya [Pp]lasm") then
        local plasm = tonumber(e.message:match("You obtain (%d+) corpuscles? of [Mm]weya [Pp]lasm"));
        if plasm then
            data.plasm = data.plasm + plasm;
            print(chat.header(addon.name):append(chat.message('Added ' .. plasm .. ' Mweya Plasm. Total: ' .. data.plasm)));
        end
    end
end);

-- Add a command to manually set plasm amount
function tracker.set_plasm(amount)
    if amount and amount >= 0 then
        data.plasm = amount;
        print(chat.header(addon.name):append(chat.message('Set Mweya Plasm to ' .. amount)));
        return true;
    end
    return false;
end

return tracker;
