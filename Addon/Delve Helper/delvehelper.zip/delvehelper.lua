-- Copyright (c) 2025
-- DelveHelper addon for Ashita v4

addon.name      = 'DelveHelper';
addon.author    = 'Oneword - Ninja Ai';
addon.version   = '1.0';
addon.desc      = 'Simple tracker for Delve items and plasm';
addon.link      = ''
require('common');
local chat = require('chat');
local imgui = require('imgui');
local settings = require('settings');

-- Load our modules
local data = require('data');
local tracker = require('tracker');

-- Configuration
local default_config = T{
    show_window = true,
    window_x = 100,
    window_y = 100,
    window_w = 300,
    window_h = 220,
    font_scale = 1.0,
    collapsed = false
};

-- Settings container
local settings_container = T{
    settings = default_config
};

-- Current configuration
local cfg = settings.load(settings_container);
if cfg then
    cfg = cfg.settings;
else
    cfg = default_config;
end

-- Save settings
local function save_settings()
    settings.save();
end

-- UI rendering
local function render_ui()
    -- Skip if window is hidden
    if not cfg.show_window then
        return;
    end
    
    -- Set window position and initial size
    imgui.SetNextWindowPos({ cfg.window_x, cfg.window_y }, ImGuiCond_FirstUseEver);
    imgui.SetNextWindowSize({ 300, 220 }, ImGuiCond_FirstUseEver);
    
    -- Set window flags to include collapsible and resizable
    local windowFlags = bit.bor(
        ImGuiWindowFlags_NoSavedSettings
    );
    
    -- Set more compact window style
    imgui.PushStyleVar(ImGuiStyleVar_WindowPadding, { 8, 8 });
    imgui.PushStyleVar(ImGuiStyleVar_ItemSpacing, { 4, 2 });
    imgui.PushStyleVar(ImGuiStyleVar_FramePadding, { 4, 2 });
    
    -- Set window title color
    imgui.PushStyleColor(ImGuiCol_TitleBg, { 0.7, 0.2, 0.2, 1.0 });
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, { 0.8, 0.2, 0.2, 1.0 });
    imgui.PushStyleColor(ImGuiCol_TitleBgCollapsed, { 0.7, 0.2, 0.2, 0.8 });
    
    -- Begin the window with a collapsible header
    local collapsed = { cfg.collapsed or false };
    if imgui.Begin('Delve Helper##delvehelper', { cfg.show_window }, windowFlags) then
        -- Check if window is collapsed
        if imgui.IsWindowCollapsed() ~= collapsed[1] then
            collapsed[1] = imgui.IsWindowCollapsed();
            cfg.collapsed = collapsed[1];
            save_settings();
        end
        
        -- Save window position and size
        local x, y = imgui.GetWindowPos();
        local w, h = imgui.GetWindowSize();
        cfg.window_x = x;
        cfg.window_y = y;
        cfg.window_w = w;
        cfg.window_h = h;
        
        -- Apply font scaling
        imgui.SetWindowFontScale(cfg.font_scale);
        
        -- Plasm display
        imgui.TextColored({ 1.0, 0.5, 0.0, 1.0 }, 'Mweya Plasm: ');
        imgui.SameLine();
        imgui.Text(tostring(data.plasm));
        
        -- Calculate table width to fill the window
        local tableWidth = imgui.GetWindowWidth() - 16; -- Window width minus padding
        
        -- Create a table for zones with compact layout
        local tableFlags = bit.bor(
            ImGuiTableFlags_Borders, 
            ImGuiTableFlags_RowBg,
            ImGuiTableFlags_NoSavedSettings
        );
        
        -- Define the blue color for headers
        local headerColor = { 0.0, 0.7, 1.0, 1.0 };
        
        if imgui.BeginTable('DelveZones', 3, tableFlags, { tableWidth, 0 }) then
            -- Set column widths with updated header names
            imgui.TableSetupColumn('Delve Zones', ImGuiTableColumnFlags_WidthStretch);
            imgui.TableSetupColumn('Yggrete', ImGuiTableColumnFlags_WidthFixed, 100 * cfg.font_scale);
            imgui.TableSetupColumn('Keys', ImGuiTableColumnFlags_WidthFixed, 50 * cfg.font_scale);
            
            -- Custom header row with blue color for all headers
            imgui.TableNextRow(ImGuiTableRowFlags_Headers);
            
            -- Delve Zones header with blue color
            imgui.TableSetColumnIndex(0);
            imgui.PushStyleColor(ImGuiCol_Text, headerColor);
            imgui.TableHeader('Delve Zones');
            
            -- Yggrete header with blue color
            imgui.TableSetColumnIndex(1);
            imgui.TableHeader('Yggrete');
            
            -- Keys header with blue color
            imgui.TableSetColumnIndex(2);
            imgui.TableHeader('Keys');
            
            -- Pop the color style after all headers
            imgui.PopStyleColor();
            
            -- Find the longest color name for alignment
            local maxColorLength = 0;
            for _, zone in ipairs(data.zones) do
                maxColorLength = math.max(maxColorLength, string.len(zone.color));
            end
            
            -- Rows for each zone
            for _, zone in ipairs(data.zones) do
                imgui.TableNextRow();
                
                -- Zone name
                imgui.TableSetColumnIndex(0);
                imgui.TextColored({ 0.9, 0.9, 0.9, 1.0 }, zone.name);
                
                -- Color name + Yggrete count with proper alignment
                imgui.TableSetColumnIndex(1);
                
                -- Create a formatted string with proper spacing
                local paddedColor = zone.color;
                while string.len(paddedColor) < maxColorLength do
                    paddedColor = paddedColor .. " ";
                end
                
                imgui.Text(paddedColor .. " " .. tostring(zone.yggrete_count));
                
                -- Planchette status (centered)
                imgui.TableSetColumnIndex(2);
                local status = zone.has_planchette and 'Yes' or 'No';
                local color = zone.has_planchette and { 0.0, 1.0, 0.0, 1.0 } or { 1.0, 0.0, 0.0, 1.0 };
                local statusWidth = imgui.CalcTextSize(status);
                local cellWidth = imgui.GetColumnWidth();
                imgui.SetCursorPosX(imgui.GetCursorPosX() + (cellWidth - statusWidth) * 0.5);
                imgui.TextColored(color, status);
            end
            
            imgui.EndTable();
        end
        
        -- Font scale slider with minimal spacing
        imgui.Text('UI Scale:');
        imgui.SameLine();
        local scale = { cfg.font_scale };
        if imgui.SliderFloat('##FontScale', scale, 0.5, 2.0, "%.3f", ImGuiSliderFlags_AlwaysClamp) then
            cfg.font_scale = scale[1];
            save_settings();
        end
    end
    imgui.End();
    
    -- Pop style vars and colors
    imgui.PopStyleVar(3);
    imgui.PopStyleColor(3);
end

-- Command handler
local function handle_command(cmd, args)
    if args[1] == '/delve' then
        -- Toggle window
        if #args == 1 then
            cfg.show_window = not cfg.show_window;
            save_settings();
            print(chat.header(addon.name):append(chat.message('Window ' .. (cfg.show_window and 'shown' or 'hidden'))));
            return true;
        end
        
        -- Help command
        if args[2] == 'help' then
            print(chat.header(addon.name):append(chat.message('Available commands:')));
            print(chat.header(addon.name):append(chat.message('/delve - Toggle the main window')));
            print(chat.header(addon.name):append(chat.message('/delve help - Show this help message')));
            print(chat.header(addon.name):append(chat.message('/delve scale <number> - Set UI scale (e.g., /delve scale 1.5)')));
            print(chat.header(addon.name):append(chat.message('/delve plasm <number> - Set Mweya Plasm amount (e.g., /delve plasm 175250)')));
            return true;
        end
        
        -- Scale command
        if args[2] == 'scale' and args[3] then
            local scale = tonumber(args[3]);
            if scale and scale > 0 then
                cfg.font_scale = scale;
                save_settings();
                print(chat.header(addon.name):append(chat.message('UI scale set to ' .. scale)));
            else
                print(chat.header(addon.name):append(chat.message('Invalid scale value. Please use a number greater than 0')));
            end
            return true;
        end
        
        -- Plasm command
        if args[2] == 'plasm' and args[3] then
            local amount = tonumber(args[3]);
            if tracker.set_plasm(amount) then
                return true;
            else
                print(chat.header(addon.name):append(chat.message('Invalid plasm amount. Please use a number greater than or equal to 0')));
            end
            return true;
        end
        
        return true;
    end
    
    return false;
end

-- Register event callbacks
ashita.events.register('load', 'load_cb', function()
    -- Initialize data
    data.initialize();
    
    -- Initial scan
    tracker.scan_inventory();
    
    print(chat.header(addon.name):append(chat.message('Delve Helper loaded!')));
    print(chat.header(addon.name):append(chat.message('Type /delve help for commands')));
end);

ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args();
    if #args > 0 and handle_command(e.command, args) then
        e.blocked = true;
    end
end);

ashita.events.register('d3d_present', 'd3d_present_cb', function()
    render_ui();
end);

ashita.events.register('packet_in', 'packet_in_cb', function(e)
    -- Inventory update packets
    if e.id == 0x01D or e.id == 0x01E or e.id == 0x01F or e.id == 0x020 then
        tracker.scan_inventory();
    end
end);

ashita.events.register('unload', 'unload_cb', function()
    save_settings();
    print(chat.header(addon.name):append(chat.message('Delve Helper unloaded!')));
end);
