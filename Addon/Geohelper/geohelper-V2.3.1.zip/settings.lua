return {
    ["show_display"] = true,
    ["colors"] =     {
        ["geo_high"] = 4278255360,
        ["indi"] = 4289388031,
        ["geo_low"] = 4294901760,
        ["background"] = 2147483750,
        ["geo_mid"] = 4294967040,
    },
    ["positions"] =     {
        ["geo"] =         {
            ["y"] = 734,
            ["x"] = 761,
        },
        ["indi"] =         {
            ["y"] = 758,
            ["x"] = 763,
        },
        ["entrust"] =         {
            ["y"] = 140,
            ["x"] = 100,
        },
    },
    ["font"] =     {
        ["family"] = "Arial",
        ["size"] = 15,
    },
}