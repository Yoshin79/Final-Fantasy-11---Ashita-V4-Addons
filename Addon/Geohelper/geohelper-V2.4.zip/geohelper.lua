addon.name = 'geohelper'
addon.author = 'Oneword - Ninja Ai'
addon.version = '2.4'
addon.desc = 'Tracks active GEO spells, INDI, and Entrust-INDI timers with frameless display'

require('common')
local imgui = require('imgui')

-- Active effects tracking with updated INDI duration
local active_spells = {
    indi = { name = nil, target = nil, cast_time = nil, duration = 262 },  -- 4m22s
    geo = { name = nil, target = nil, cast_time = nil },
    entrust_indi = { name = nil, target = nil, cast_time = nil, duration = 262 }  -- 4m22s
}

-- Settings
local config = {
    show_config = false,
    show_display = true,
    position = { x = 100, y = 100 },
    colors = {
        geo_high = 0xFF00FF00,  -- Green (AARRGGBB)
        geo_mid = 0xFFFFFF00,   -- Yellow
        geo_low = 0xFFFF0000,   -- Red
        indi = 0xFFAADDFF,      -- Brighter, more visible light blue
        background = 0x80000066  -- Semi-transparent dark blue
    },
    font = {
        family = 'Arial',
        size = 11
    }
}

-- Font objects
local fonts = {
    geo = nil,
    indi = nil,
    entrust = nil
}

-- Helper function for formatting time
local function format_time(seconds)
    if not seconds then return '--:--' end
    if seconds <= 0 then return 'Ready' end
    local minutes = math.floor(seconds / 60)
    local secs = math.floor(seconds % 60)
    return string.format('%02d:%02d', minutes, secs)
end

-- Initialize fonts
local function initialize_fonts()
    -- Create GEO font
    fonts.geo = AshitaCore:GetFontManager():Create('__geohelper_geo')
    fonts.geo:SetPositionX(config.position.x)
    fonts.geo:SetPositionY(config.position.y)
    fonts.geo:SetColor(config.colors.geo_high)
    fonts.geo:SetFontFamily(config.font.family)
    fonts.geo:SetFontHeight(config.font.size)
    fonts.geo:GetBackground():SetVisible(true)
    fonts.geo:GetBackground():SetColor(config.colors.background)
    fonts.geo:SetVisible(false)
    fonts.geo:SetLocked(false)
    
    -- Create INDI font
    fonts.indi = AshitaCore:GetFontManager():Create('__geohelper_indi')
    fonts.indi:SetPositionX(config.position.x)
    fonts.indi:SetPositionY(config.position.y + config.font.size + 4)
    fonts.indi:SetColor(config.colors.indi)
    fonts.indi:SetFontFamily(config.font.family)
    fonts.indi:SetFontHeight(config.font.size)
    fonts.indi:GetBackground():SetVisible(true)
    fonts.indi:GetBackground():SetColor(config.colors.background)
    fonts.indi:SetVisible(false)
    fonts.indi:SetLocked(false)
    
    -- Create Entrust INDI font
    fonts.entrust = AshitaCore:GetFontManager():Create('__geohelper_entrust')
    fonts.entrust:SetPositionX(config.position.x)
    fonts.entrust:SetPositionY(config.position.y + (config.font.size + 4) * 2)
    fonts.entrust:SetColor(config.colors.indi)
    fonts.entrust:SetFontFamily(config.font.family)
    fonts.entrust:SetFontHeight(config.font.size)
    fonts.entrust:GetBackground():SetVisible(true)
    fonts.entrust:GetBackground():SetColor(config.colors.background)
    fonts.entrust:SetVisible(false)
    fonts.entrust:SetLocked(false)
end

-- Clean up fonts
local function cleanup_fonts()
    if fonts.geo then
        AshitaCore:GetFontManager():Delete('__geohelper_geo')
    end
    if fonts.indi then
        AshitaCore:GetFontManager():Delete('__geohelper_indi')
    end
    if fonts.entrust then
        AshitaCore:GetFontManager():Delete('__geohelper_entrust')
    end
end

-- Command Handler
ashita.events.register('command', 'command_cb', function(e)
    local args = e.command:args()
    if args[1] ~= '/geohelper' then return end
    e.blocked = true
    
    if #args == 1 then
        -- Toggle config window when just /geohelper is used
        config.show_config = not config.show_config
    elseif args[2] == 'config' then
        -- Keep this for backward compatibility
        config.show_config = not config.show_config
    elseif args[2] == 'display' then
        -- Add a specific command for toggling display
        config.show_display = not config.show_display
        
        -- Update font visibility
        if fonts.geo then fonts.geo:SetVisible(config.show_display and active_spells.geo.name ~= nil) end
        if fonts.indi then fonts.indi:SetVisible(config.show_display and active_spells.indi.name ~= nil) end
        if fonts.entrust then fonts.entrust:SetVisible(config.show_display and active_spells.entrust_indi.name ~= nil) end
    end
end)

-- Chat Handler (with robust error handling)
ashita.events.register('text_in', 'text_in_cb', function(e)
    local now = os.clock()
    
    -- INDI spell cast detection
    local indi_pattern = '(%w+) starts casting (Indi%-%w+) on ([%w%s%-]+)%.'
    local caster, spell_name, target = e.message:match(indi_pattern)
    
    if caster and spell_name and target then
        -- Clean up the names
        spell_name = spell_name:gsub('Indi%-', '')
        target = target:gsub('the ', '')
        
        -- Check if this is a self-cast (regular INDI) or cast on someone else (Entrust INDI)
        local is_self_cast = (target == caster)
        
        -- Handle the spell based on target
        if is_self_cast then
            -- Regular INDI (self-cast)
            active_spells.indi = {
                name = spell_name,
                target = target,
                cast_time = now,
                duration = 262  -- 4m22s
            }
        else
            -- Entrust INDI (cast on someone else)
            active_spells.entrust_indi = {
                name = spell_name,
                target = target,
                cast_time = now,
                duration = 262  -- 4m22s
            }
        end
    end

    -- GEO spell cast detection
    local geo_pattern = '(%w+) starts casting (Geo%-%w+) on ([%w%s%-]+)%.'
    local caster, spell_name, target = e.message:match(geo_pattern)
    if caster and spell_name and target then
        active_spells.geo = {
            name = spell_name:gsub('Geo%-', ''),
            target = target:gsub('the ', ''),
            cast_time = now
        }
    end

    -- Spell wear off messages
    if e.message:match('Indi%-effect wears off') then
        if active_spells.indi.target and e.message:match(active_spells.indi.target) then
            active_spells.indi = { name = nil, target = nil, cast_time = nil, duration = 262 }
        end
        if active_spells.entrust_indi.target and e.message:match(active_spells.entrust_indi.target) then
            active_spells.entrust_indi = { name = nil, target = nil, cast_time = nil, duration = 262 }
        end
    end
end)

-- Update display
local function update_display()
    local now = os.clock()
    
    -- Update GEO display
    if active_spells.geo.name then
        local petID = AshitaCore:GetMemoryManager():GetEntity():GetPetTargetIndex(AshitaCore:GetMemoryManager():GetParty():GetMemberTargetIndex(0))
        if petID ~= 0 and petID ~= nil then
            local petHP = AshitaCore:GetMemoryManager():GetEntity():GetHPPercent(petID)
            if petHP > 0 then
                -- Set text with consistent formatting (percentage at end)
                local text = string.format('GEO-%s [%s]: %d%%', active_spells.geo.name, active_spells.geo.target, petHP)
                fonts.geo:SetText(text)
                
                -- Set color based on HP
                local color
                if petHP >= 60 then
                    color = config.colors.geo_high -- Green
                elseif petHP >= 30 then
                    color = config.colors.geo_mid -- Yellow
                else
                    color = config.colors.geo_low -- Red
                end
                fonts.geo:SetColor(color)
                
                -- Show the font
                fonts.geo:SetVisible(config.show_display)
            else
                active_spells.geo.name = nil
                active_spells.geo.target = nil
                fonts.geo:SetVisible(false)
            end
        else
            fonts.geo:SetVisible(false)
        end
    else
        fonts.geo:SetVisible(false)
    end
    
    -- Update INDI display
    if active_spells.indi.name then
        local remaining = active_spells.indi.duration - (now - active_spells.indi.cast_time)
        if remaining > 0 then
            -- Set text
            local text = string.format('INDI-%s [%s]: %s', active_spells.indi.name, active_spells.indi.target, format_time(remaining))
            fonts.indi:SetText(text)
            fonts.indi:SetColor(config.colors.indi) -- Light blue
            
            -- Show the font
            fonts.indi:SetVisible(config.show_display)
        else
            active_spells.indi = { name = nil, target = nil, cast_time = nil, duration = 262 }
            fonts.indi:SetVisible(false)
        end
    else
        fonts.indi:SetVisible(false)
    end
    
    -- Update Entrust INDI display
    if active_spells.entrust_indi.name then
        local remaining = active_spells.entrust_indi.duration - (now - active_spells.entrust_indi.cast_time)
        if remaining > 0 then
            -- Set text
            local text = string.format('INDI-%s [%s]: %s', active_spells.entrust_indi.name, active_spells.entrust_indi.target, format_time(remaining))
            fonts.entrust:SetText(text)
            fonts.entrust:SetColor(config.colors.indi) -- Light blue
            
            -- Show the font
            fonts.entrust:SetVisible(config.show_display)
        else
            active_spells.entrust_indi = { name = nil, target = nil, cast_time = nil, duration = 262 }
            fonts.entrust:SetVisible(false)
        end
    else
        fonts.entrust:SetVisible(false)
    end
    
    -- Check if fonts have been moved
    if fonts.geo then
        local pos_x = fonts.geo:GetPositionX()
        local pos_y = fonts.geo:GetPositionY()
        
        if pos_x ~= config.position.x or pos_y ~= config.position.y then
            -- Update stored position
            config.position.x = pos_x
            config.position.y = pos_y
            
            -- Update other fonts to follow
            if fonts.indi then
                fonts.indi:SetPositionX(pos_x)
                fonts.indi:SetPositionY(pos_y + config.font.size + 4)
            end
            
            if fonts.entrust then
                fonts.entrust:SetPositionX(pos_x)
                fonts.entrust:SetPositionY(pos_y + (config.font.size + 4) * 2)
            end
        end
    end
end

-- Render Function (for config window only)
ashita.events.register('d3d_present', 'present_cb', function()
    local player = AshitaCore:GetMemoryManager():GetPlayer()
    if not player or player:GetMainJob() ~= 21 then return end

    -- Update display
    update_display()
    
    -- Config window
    if config.show_config then
        -- Create a boolean reference for the window state
        local is_open = { config.show_config }
        
        -- Pass the reference to Begin to make the X button work
        if imgui.Begin('GeoHelper Config', is_open, ImGuiWindowFlags_AlwaysAutoResize) then
            -- Toggle for showing display
            local show_changed, show_value = imgui.Checkbox('Show Display', { config.show_display })
            if show_changed then 
                config.show_display = show_value[1]
                
                -- Update font visibility
                if fonts.geo then fonts.geo:SetVisible(config.show_display and active_spells.geo.name ~= nil) end
                if fonts.indi then fonts.indi:SetVisible(config.show_display and active_spells.indi.name ~= nil) end
                if fonts.entrust then fonts.entrust:SetVisible(config.show_display and active_spells.entrust_indi.name ~= nil) end
            end
            
            -- Font settings
            if imgui.CollapsingHeader('Font Settings') then
                -- Font family dropdown
                if imgui.BeginCombo('Font Family', config.font.family) then
                    local families = { 'Arial', 'Consolas', 'Courier New', 'Georgia', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana' }
                    for _, family in ipairs(families) do
                        if imgui.Selectable(family, family == config.font.family) then
                            config.font.family = family
                            
                            -- Update fonts
                            if fonts.geo then fonts.geo:SetFontFamily(family) end
                            if fonts.indi then fonts.indi:SetFontFamily(family) end
                            if fonts.entrust then fonts.entrust:SetFontFamily(family) end
                        end
                    end
                    imgui.EndCombo()
                end
                
                -- Font size
                imgui.Text('Font Size: ' .. config.font.size)
                imgui.SameLine()
                
                if imgui.Button('-') then
                    if config.font.size > 8 then
                        config.font.size = config.font.size - 1
                        
                        -- Update fonts
                        if fonts.geo then fonts.geo:SetFontHeight(config.font.size) end
                        if fonts.indi then 
                            fonts.indi:SetFontHeight(config.font.size)
                            fonts.indi:SetPositionY(fonts.geo:GetPositionY() + config.font.size + 4)
                        end
                        if fonts.entrust then 
                            fonts.entrust:SetFontHeight(config.font.size)
                            fonts.entrust:SetPositionY(fonts.geo:GetPositionY() + (config.font.size + 4) * 2)
                        end
                    end
                end
                
                imgui.SameLine()
                
                if imgui.Button('+') then
                    if config.font.size < 20 then
                        config.font.size = config.font.size + 1
                        
                        -- Update fonts
                        if fonts.geo then fonts.geo:SetFontHeight(config.font.size) end
                        if fonts.indi then 
                            fonts.indi:SetFontHeight(config.font.size)
                            fonts.indi:SetPositionY(fonts.geo:GetPositionY() + config.font.size + 4)
                        end
                        if fonts.entrust then 
                            fonts.entrust:SetFontHeight(config.font.size)
                            fonts.entrust:SetPositionY(fonts.geo:GetPositionY() + (config.font.size + 4) * 2)
                        end
                    end
                end
            end
            
            -- Color settings
            if imgui.CollapsingHeader('Color Settings') then
                -- Background transparency
                imgui.Text('Background Transparency:')
                local bg_alpha = bit.band(bit.rshift(config.colors.background, 24), 0xFF)
                local bg_alpha_percent = { bg_alpha / 255 * 100 }
                
                if imgui.SliderFloat('##BgAlpha', bg_alpha_percent, 0, 100, '%.0f%%') then
                    local new_alpha = math.floor(bg_alpha_percent[1] / 100 * 255)
                    config.colors.background = bit.bor(bit.band(config.colors.background, 0x00FFFFFF), bit.lshift(new_alpha, 24))
                    
                    -- Update fonts
                    if fonts.geo then fonts.geo:GetBackground():SetColor(config.colors.background) end
                    if fonts.indi then fonts.indi:GetBackground():SetColor(config.colors.background) end
                    if fonts.entrust then fonts.entrust:GetBackground():SetColor(config.colors.background) end
                end
            end
            
            imgui.End()
        end
        
        -- Update the config.show_config based on the window state
        if not is_open[1] then
            config.show_config = false
        end
    end
end)

-- Initialize addon
ashita.events.register('load', 'load_cb', function()
    initialize_fonts()
    print(string.format('\31\200[\31\05%s\31\200]\30\01 v%s Loaded! Use \30\02/geohelper\30\01 to toggle config window, \30\02/geohelper display\30\01 to toggle display.', addon.name, addon.version))
end)

-- Clean up on unload
ashita.events.register('unload', 'unload_cb', function()
    cleanup_fonts()
end)
