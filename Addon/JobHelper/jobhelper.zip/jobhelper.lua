addon.name      = 'jobhelper';
addon.author    = 'Oneword - Ninja Ai - Infro from https://ffxiclopedia.fandom.com/wiki';
addon.version   = '1.3';
addon.desc      = 'Helper addon to assist with unlocking jobs.';

require('common');
local imgui = require('imgui');

-- Color schemes
local colors = {
    title = { 0.7, 0.3, 1.0, 1.0 },      -- Purple
    header = { 0.4, 0.8, 1.0, 1.0 },      -- Light Blue
    requirement = { 1.0, 0.8, 0.2, 1.0 }, -- Gold
    step = { 0.9, 0.9, 0.9, 1.0 },        -- Off White
    location = { 0.3, 1.0, 0.5, 1.0 },    -- Green
    bullet = { 1.0, 0.5, 0.0, 1.0 },      -- Orange
    separator = { 0.5, 0.5, 1.0, 0.5 },   -- Semi-transparent Blue
    warning = { 1.0, 0.4, 0.4, 1.0 },     -- Red
    note = { 1.0, 0.7, 0.2, 1.0 }         -- Golden yellow
};

-- JobHelper variables
local jobhelper = {
    is_open = { false },
    settings = {
        position_x = 100,
        position_y = 100,
    },
    selected_job = nil,
    jobs = {
        GEO = {
            name = "Geomancer",
            requirements = {
                "Main job level 30+",
                "Petrified Log",
                "Fistful of homeland soil"
            },
            steps = {
                { text = "1. Speak to Sylvie in ", location = "Western Adoulin (I-5)" },
                { text = "2. Obtain Petrified Log" },
                { text = "3. Get homeland soil from your nations crag:" },
                { text = "   • San d'Oria - ", location = "Crag of Holla" },
                { text = "   • Windurst - ", location = "Crag of Mea" },
                { text = "   • Bastok - ", location = "Crag of Dem" },
                { text = "   Note: Check for \"Ergon Locus ???\" under the telepoint stairs" },
                { text = "4. Trade items to Sylvie" },
                { text = "5. Visit Ergon Locus in ", location = "Ceizak Battlegrounds (K-10)" },
                { text = "6. Use /heal and wait for message (up to 8 minutes)" }
            }
        },

        BST = {
            name = "Beastmaster",
            requirements = {
                "Level 30+",
                "Complete quest 'Save My Son'"
            },
            steps = {
                { text = "1. Talk to Brutus in ", location = "Upper Jeuno Chocobo Stables (G-7)" },
                { text = "Note: If 'Chocobo on the Loose!' triggers:" },
                { text = "  • Talk to Brutus" },
                { text = "  • Talk to the boy near the steps caring for the chocobo" },
                { text = "  • Talk to Brutus again" },
                { text = "You may need to talk to Brutus multiple times for cutscene" },
                { text = "Zone to receive job" },
                { text = "Optional: Click Dietmund's door in ", location = "Lower Jeuno (G-11)", note = " for cutscene" }
            }
        },

        SMN = {
            name = "Summoner",
            requirements = {
                "Main job level 30+",
                "Carbuncle's Ruby (Rare/Ex)",
                "Access to outdoor areas"
            },
            steps = {
                { text = "1. Obtain Carbuncle's Ruby" },
                { text = "   • Drops from Leech-type mobs (Bloodsucker, Bouncing Ball)" },
                { text = "   • Recommended areas: ", location = "Bostaunieux Oubliette or Toraimarai Canal" },
                { text = "   • TH increases drop rate" },
                { text = "2. Go to House of the Hero in ", location = "Windurst Walls (G-3)" },
                { text = "3. Collect seven colors by experiencing different weather types:" }
            },
            weather_requirements = {
                { color = "Red", element = "Fire", weather = "Heat Wave", areas = "Valkurm Dunes, Cape Teriggan, Eastern Altepa Desert" },
                { color = "Orange", element = "None", weather = "Clear Skies", areas = "West/East Sarutabaruta, Valkurm Dunes" },
                { color = "Yellow", element = "Earth", weather = "Dust Storms", areas = "Tahrongi Canyon, Konschtat Highlands" },
                { color = "Green", element = "Wind", weather = "High Winds", areas = "Tahrongi Canyon, La Theine Plateau" },
                { color = "Blue", element = "Water", weather = "Rain", areas = "La Theine Plateau, Jugner Forest" },
                { color = "Indigo", element = "Ice", weather = "Snow", areas = "Beaucedine Glacier, Xarcabard" },
                { color = "Violet", element = "Lightning", weather = "Thunderstorms", areas = "Konschtat Highlands, Jugner Forest" }
            },
            warnings = {
                "Cannot use Wings of the Goddess zones",
                "Must be outdoor, enemy-populated areas",
                "Cannot use Scholar weather effects",
                "Qufim Island and Behemoth's Dominion do NOT work"
            }
        },

        PUP = {
            name = "Puppetmaster",
            requirements = {
                "Main job level 30+",
                "Access to Aht Urhgan areas",
                "Ability to reach Arrapago Reef"
            },
            steps = {
                { text = "1. Talk to Shamarhaan near fountain in ", location = "Bastok Markets (F-9)" },
                { text = "2. Talk to Iruki-Waraki (top floor) in ", location = "Aht Urhgan Whitegate (K-9)" },
                { text = "3. Talk to Ghatsad in Automaton Workshop (top floor) in ", location = "Aht Urhgan Whitegate (I-7)" },
                { text = "4. Travel to Arrapago Reef:" },
                { text = "   Option A - From Nashmau:" },
                { text = "   • Take ferry from Port Ephramad to Nashmau" },
                { text = "   • Exit Nashmau North to ", location = "Caedarva Mire (H-6)" },
                { text = "   • Zone into Arrapago Reef at ", location = "Caedarva Mire (I-6)" },
                { text = "   Option B - Using Survival Guide:" },
                { text = "   • Use Aht Urhgan Whitegate Survival Guide to teleport to Arrapago Reef entrance" },
                { text = "   Option C - Using Runic Portal:" },
                { text = "   • Use Runic Portal to Azouph Isle Staging Point" },
                { text = "   • Head to tunnel at ", location = "(I-6)" },
                { text = "5. Find ??? under stairs on south/first boat in ", location = "Arrapago Reef Map 1 (H-10)" },
                { text = "6. Return to Ghatsad in ", location = "Aht Urhgan Whitegate (I-7)" },
                { text = "7. Wait until next game day, talk to Ghatsad again" },
                { text = "8. Return to Iruki-Waraki in ", location = "Aht Urhgan Whitegate (K-9)" }
            },
            warnings = {
                "Dangerous mobs in Caedarva Mire:",
                "• Imps (True Sight aggro)",
                "• Chigoes (Hidden nameplates until aggro)",
                "• Treants (Sound aggro)",
                "Cannot be invisible when examining ???",
                "Mobs will aggro level 99 characters"
            }
        },

        NIN = {
            name = "Ninja",
            requirements = {
                "Level 30+",
                "Access to Norg via:",
                "• Kazham Airship Pass OR",
                "• RoV Mission: The Beginning"
            },
            steps = {
                { text = "1. Talk to Kaede in ", location = "Port Bastok (J-5)", detail = "northernmost house" },
                { text = "2. Talk to Kagetora in ", location = "Port Bastok (F-6)", detail = "Warehouse 2, upper floor, western warehouse" },
                { text = "3. Talk to Ensetsu in ", location = "Port Bastok (J-5)" },
                { text = "4. Get Strangely Shaped Coral:" },
                { text = "   • Go to ", location = "Korroloka Tunnel Map 5 (L-8)" },
                { text = "   • Find ??? that spawns three Korroloka Leeches" },
                { text = "   • Kill leeches and click ??? for coral" },
                { text = "5. Return to Ensetsu in ", location = "Port Bastok (J-5)" },
                { text = "6. Travel to Norg:" },
                { text = "   Port Jeuno → Kazham → Yuhtunga Jungle → Sea Serpent Grotto → Norg" },
                { text = "7. Talk to Ryoma on the docks in ", location = "Norg (H-8)" },
                { text = "8. Return to Ensetsu in ", location = "Port Bastok (J-5)" }
            },
            warnings = {
                "Leech Fight Warnings:",
                "• Leeches immediately attack player who checks ???",
                "• Thread Leeches nearby will link",
                "• Ghosts spawn in the area",
                "Sea Serpent Grotto Warnings:",
                "• Need Sneak (blood aggro at level 30)",
                "• Multiple aggressive mobs en route to Norg"
            }
        },

        SAM = {
            name = "Samurai",
            requirements = {
                "Level 30+",
                "Access to Norg",
                "Access to Sanctuary of Zi'tah",
                "Access to Konschtat Highlands",
                "Hatchet (tool)"
            },
            steps = {
                { text = "1. Talk to Jaucribaix in ", location = "Norg (K-8)", detail = "upper level, end of hallway" },
                { text = "2. Talk to Aeka in ", location = "Norg (I-8)", detail = "receive Oriental Steel" },
                { text = "3. Talk to Ranemaud in ", location = "Norg (I-7)", detail = "receive Sacred Sprig" },
                { text = "4. Sacred Branch - First Item:" },
                { text = "   • Go to ", location = "Sanctuary of Zi'tah (K-10)" },
                { text = "   • Follow east path to unmapped area at ", location = "(L-10)" },
                { text = "   • Climb rocks at base of large tree" },
                { text = "   • Trade/Use Hatchet at ??? to spawn Guardian Treant" },
                { text = "   • Defeat Guardian Treant" },
                { text = "   • Trade Sacred Sprig to ??? for Sacred Branch" },
                { text = "5. Bomb Steel - Second Item:" },
                { text = "   • Go to cave in ", location = "Konschtat Highlands (D-8)" },
                { text = "   • Trade Oriental Steel to ??? to spawn Forger" },
                { text = "   • Defeat Forger for Bomb Steel" },
                { text = "6. Return to Jaucribaix in ", location = "Norg (K-8)" },
                { text = "7. Wait 3 game days (about 3 real hours)" },
                { text = "8. Talk to Jaucribaix for final cutscene" }
            },
            warnings = {
                "Guardian Treant has 10 minute respawn timer",
                "If you fail Forger fight, need new Oriental Steel",
                "Multiple Forger spawns need 1-2 minute wait between",
                "Keep Mumeito for future AF quest"
            }
        },

        RNG = {
            name = "Ranger",
            requirements = {
                "Main job level 30+",
                "Access to Sauromugue Champaign",
                "Form of Warp recommended"
            },
            steps = {
                { text = "1. Talk to Perih Vashai in ", location = "Windurst Woods (K-7)" },
                { text = "2. Optional: Talk to guards Muhk Johldy and Kapeh Myohrye for more info" },
                { text = "3. Go to Sauromugue Champaign:" },
                { text = "   • Go to ", location = "(L-8)", detail = "climb up the cliff" },
                { text = "   • Head south to ", location = "(L-10)" },
                { text = "4. Enter cave and find Tiger Bones:" },
                { text = "   • Click Tiger Bones to spawn Old Sabertooth" },
                { text = "   • Wait for Old Sabertooth to die naturally (~3 minutes)" },
                { text = "   • Click Tiger Bones again for Old tiger's fang" },
                { text = "5. Return to Perih Vashai in ", location = "Windurst Woods (K-7)" }
            },
            warnings = {
                "3 Sabertooth Tigers guard cave entrance",
                "Do NOT kill Old Sabertooth - must die naturally",
                "If killed accidentally, wait 5 minutes to respawn"
            },
            notes = {
                "Tigers won't aggro level 40+ characters",
                "Can use mount or Invisible to avoid tigers",
                "Stay behind Tiger Bones to avoid Old Sabertooth aggro",
                "Can get fang if someone else spawned Sabertooth",
                "Just need to see death message for key item"
            }
        },

        BLU = {
            name = "Blue Mage",
            requirements = {
                "Main job level 30+",
                "1000 gil for divination",
                "Access to Aht Urhgan areas"
            },
            steps = {
                { text = "1. Talk to Waoud in ", location = "Aht Urhgan Whitegate (J-10)", detail = "2nd Floor" },
                { text = "2. Answer divination questions correctly:" },
                { text = "   • What is destiny? → One forges for oneself" },
                { text = "   • Does accomplishment require sacrifice? → Absolutely" },
                { text = "   • Forbidden scroll choice? → Burn the scroll" },
                { text = "   • Save 10,000 lives? → Without hesitation" },
                { text = "   • Life choice? → A chaotic life" },
                { text = "   • Life as beast vs death? → Embrace life as a beast" },
                { text = "   • Companion turns against you? → Cut him down" },
                { text = "   • End loved one's suffering? → Grant the request" },
                { text = "   • Friend dying in battle? → End his pain" },
                { text = "   • Orders vs justice? → Follow your sense of justice" },
                { text = "3. Obtain requested item (one of three):" },
                { text = "   • Dangruf Stone - From geysers (cannot be bought/traded)" },
                { text = "   • Valkurm Sunsand - From beach (can be bought at AH)" },
                { text = "   • Siren's Tear - From river (can be traded/bazaared)" }
            },
            warnings = {
                "Failed divination costs 1000 gil",
                "Must wait until next game day to retry divination",
                "Must have requested item for pool cutscene",
                "Answering 'no' three times resets quest"
            }
        },

        COR = {
            name = "Corsair",
            requirements = {
                "Main job level 30+",
                "Access to Aht Urhgan areas",
                "One of the following:",
                "• Lamian Fang Key",
                "• THF with Thief's Tools",
                "• Access to Ilrusi Atoll Staging Point"
            },
            steps = {
                { text = "1. Talk to Ratihb in ", location = "Aht Urhgan Whitegate (J-12)", detail = "Shararat Teahouse, second floor" },
                { text = "2. Talk to Mafwahb at ", location = "Aht Urhgan Whitegate (L-9)", detail = "near Imperial Whitegate" },
                { text = "3. Travel to Arrapago Reef (choose a route):" },
                { text = "   Route A - Via Nashmau:" },
                { text = "   • Take ferry from Port Ephramad to Nashmau" },
                { text = "   • Exit Nashmau North to ", location = "Caedarva Mire (H-6)" },
                { text = "   • Zone into Arrapago Reef at ", location = "Caedarva Mire (I-6)" },
                { text = "4. In Arrapago Reef (Map 1):" },
                { text = "   • Travel north to ship" },
                { text = "   • Cross plank, go down eastern shore" },
                { text = "   • Open Iron Gate at ", location = "(J-10)", detail = "requires key" },
                { text = "   • Open second gate at ", location = "(I-9)" },
                { text = "   • Find ??? on ship at ", location = "(H-10)" }
            },
            warnings = {
                "Dangerous mobs in areas:",
                "• Caedarva Mire: Imps (True Sight), Chigoes, Treants (Sound)",
                "• Arrapago Reef: Lamiae (Sight), Draugars (Sound)",
                "Must have free inventory slot for Corsair Die",
                "Cannot have Corsair Die already in inventory"
            }
        },

        RUN = {
            name = "Rune Fencer",
            requirements = {
                "Main job level 30+",
                "Adoulinian charter permit",
                "Access to Yahse Hunting Grounds"
            },
            steps = {
                { text = "1. Talk to Octavien in ", location = "Eastern Adoulin (I-8)", detail = "Use Sverdhried Hillock Waypoint" },
                { text = "2. Get Yahse Wildflower Petal:" },
                { text = "   • Go to ", location = "Yahse Hunting Grounds (K-7)" },
                { text = "   • Take boat from Eastern Adoulin ", location = "(G-5)" },
                { text = "   • Use 'The Wharf to Yahse' Waypoint" },
                { text = "   • Examine the Yahse Wildflower" },
                { text = "3. Return to Octavien:" },
                { text = "   • Use Sverdhried Hillock Waypoint" },
                { text = "   • During cutscene, select 'Use Rune Enchantment...?'" },
                { text = "   • Keep selecting until quest completes (1-100 times)" }
            },
            warnings = {
                "Umbril appear at night (20:00-4:00)",
                "Umbril are aggressive to sight and magic",
                "Keep Sowilo Claymore for future AF quest"
            }
        },

        DNC = {
            name = "Dancer",
            requirements = {
                "Main job level 30+",
                "Wings of the Goddess expansion",
                "Pure White Feather (from Cavernous Maws mission)",
                "Access to Jugner Forest (S)"
            },
            steps = {
                { text = "1. Talk to Laila in ", location = "Upper Jeuno (G-7)" },
                { text = "   • Choose 'I surely do' then 'Never!'" },
                { text = "2. Talk to Rhea Myuliah next to Laila" },
                { text = "3. Go to Lion Springs Tavern in ", location = "Southern San d'Oria (K-6)" },
                { text = "   • Talk to Valderotaux" },
                { text = "   • Any dialogue choices work" },
                { text = "4. Return to Rhea Myuliah in ", location = "Upper Jeuno (G-7)" },
                { text = "5. Get Stardust Pebble:" },
                { text = "   • Go to ", location = "Jugner Forest (S) (I-5)" },
                { text = "   • Click Glowing Pebbles" },
                { text = "6. Return to Laila in ", location = "Upper Jeuno (G-7)" }
            },
            notes = {
                "Can use Batallia Downs (S) Survival Guide",
                "If Rhea answers instead of Laila, continue quest",
                "Home Point #3 in Southern San d'Oria is near tavern"
            }
        },

        DRG = {
            name = "Dragoon",
            requirements = {
                "Main job level 30+",
                "Rise of the Zilart expansion",
                "Access to Chateau d'Oraguille:",
                "• San d'Oria: Rank 2+",
                "• Others: Started 2-3 Mission",
                "Pickaxe",
                "Sneak/Invisible recommended"
            },
            steps = {
                { text = "1. Talk to Ceraulian/Arminibit in ", location = "Port San d'Oria Cargo Room A (I-9)" },
                { text = "2. Talk to Novalmauge in Bostaunieux Oubliette:", detail = "patrols (F-8) to (G-8)" },
                { text = "3. Talk to Morjean in ", location = "Northern San d'Oria Cathedral (L-7)", detail = "left room" },
                { text = "4. Get Wyvern Egg:" },
                { text = "   • Buy Pickaxe (Ostalie in Southern San d'Oria)" },
                { text = "   • Go to Maze of Shakhrami ", location = "Tahrongi Canyon (K-5)" },
                { text = "   • Find excavation point on first map" },
                { text = "   • Trade Pickaxe to point for egg" },
                { text = "5. Return to Morjean for cutscene" },
                { text = "6. Go to Meriphataud Mountains:" },
                { text = "   • Find ??? at ", location = "(K-8)", detail = "eastern edge of Drogaroga's Spine" },
                { text = "   • Trade Wyvern Egg to ???" }
            },
            warnings = {
                "Cannot complete with active Souls in Shadow quest",
                "Check Tahrongi side excavation points first",
                "Level 80+ mobs on Maze second map"
            }
        },

        PLD = {
            name = "Paladin",
            requirements = {
                "Main job level 30+",
                "Complete quest series in order:",
                "• A Squire's Test (Level 7+)",
                "• A Squire's Test II (Level 10+)",
                "• A Knight's Test (Level 30+)",
                "Sneak and Invisible recommended"
            },
            quest_series = {
                squire_test_1 = {
                    level = "7+",
                    items_needed = { "Revival Tree Root" },
                    steps = {
                        { text = "1. Talk to Balasiel in ", location = "Southern San d'Oria (F-7)" },
                        { text = "2. Trade Revival Tree Root to Balasiel" }
                    },
                    notes = {
                        "Can buy Revival Tree Root from AH (Materials -> Alchemy)",
                        "Can get root from any undead, not just King Ranperre's Tomb"
                    }
                },
                squire_test_2 = {
                    level = "10+",
                    items_needed = { "Sneak", "Invisible", "Form of Warp recommended" },
                    steps = {
                        { text = "1. Talk to Balasiel again" },
                        { text = "2. Go to Ordelle's Caves:", location = "La Theine Plateau (F-6)" },
                        { text = "3. Navigate to stalactite room (Map 2 G-7)" },
                        { text = "4. Touch ??? in pool, then quickly touch second ??? Obtained Key Item Stalactite dew" },
                        { text = "5. Return to Balasiel - Obtained key item Squire certificate" }
                    }
                },
                knights_test = {
                    level = "30+",
                    items_needed = { "Sneak", "Invisible" },
                    steps = {
                        { text = "1. Talk to Balasiel for Book of Tasks" },
                        { text = "2. Get Book of the West from Baunise at ", location = "Southern San d'Oria (H-9)" },
                        { text = "3. Get Book of the East from Cahaurme at ", location = "Southern San d'Oria (J-9)" },
                        { text = "4. Go to Davoi for Knight's Soul:" },
                        { text = "   • Go to broken bridge at ", location = "(I-8)" },
                        { text = "   • Drop into water" },
                        { text = "   • Follow water west to ", location = "(D-8)" },
                        { text = "   • Exit at ", location = "(D-9)" },
                        { text = "   • Go southeast through camp" },
                        { text = "   • Head south to Disused Well at ", location = "(E-10)" },
                        { text = "5. Return to Balasiel" }
                    }
                }
            }
        }
    } -- End of jobs table
}; -- End of jobhelper table

--[[
* Renders a separator
--]]
local function fancy_separator()
    imgui.Separator();
    imgui.Spacing();
end

--[[
* Renders weather requirements for SMN unlock
--]]
local function render_weather_requirements(weather_data)
    imgui.TextColored(colors.header, 'Weather Requirements:');
    imgui.Indent(10);
    
    for _, weather in ipairs(weather_data) do
        -- Color and weather type
        imgui.TextColored(colors.requirement, weather.color);
        imgui.SameLine();
        imgui.TextColored(colors.step, string.format(" (%s) - %s", weather.element, weather.weather));
        
        -- Areas
        imgui.TextColored(colors.location, "    Areas: " .. weather.areas);
    end
    
    imgui.Unindent(10);
    fancy_separator();
end

--[[
* Renders the quest series for jobs like PLD
--]]
local function render_quest_series(quest_series)
    -- Define the correct order of quests
    local quest_order = {
        "squire_test_1",
        "squire_test_2",
        "knights_test"
    };

    -- Iterate through quests in the defined order
    for _, quest_name in ipairs(quest_order) do
        local quest_data = quest_series[quest_name];
        if quest_data then
            imgui.TextColored(colors.header, quest_name .. " (Level " .. quest_data.level .. ")");
            
            if quest_data.items_needed then
                imgui.TextColored(colors.requirement, "Items Needed:");
                imgui.Indent(10);
                for _, item in ipairs(quest_data.items_needed) do
                    imgui.TextColored(colors.step, "• " .. item);
                end
                imgui.Unindent(10);
                imgui.Spacing();
            end

            for _, step in ipairs(quest_data.steps) do
                imgui.TextColored(colors.step, step.text);
                if step.location then
                    imgui.SameLine();
                    imgui.TextColored(colors.location, step.location);
                    if step.detail then
                        imgui.SameLine();
                        imgui.TextColored(colors.step, step.detail);
                    end
                end
            end

            if quest_data.notes then
                imgui.Spacing();
                imgui.TextColored(colors.note, "Notes:");
                imgui.Indent(10);
                for _, note in ipairs(quest_data.notes) do
                    imgui.TextColored(colors.step, "• " .. note);
                end
                imgui.Unindent(10);
            end

            fancy_separator();
        end
    end
end

--[[
* Renders the job guide
--]]
local function render_job_guide(job_data)
    -- Title with shadow
    local title_pos = { imgui.GetCursorScreenPos() };
    imgui.SetCursorScreenPos({ title_pos[1] + 1, title_pos[2] + 1 });
    imgui.TextColored({ 0.0, 0.0, 0.0, 0.5 }, job_data.name .. ' Unlock Guide');
    imgui.SetCursorScreenPos(title_pos);
    imgui.TextColored(colors.title, job_data.name .. ' Unlock Guide');
    
    fancy_separator();
    
    -- Requirements
    imgui.TextColored(colors.header, 'Requirements:');
    imgui.Indent(10);
    for _, req in ipairs(job_data.requirements) do
        imgui.TextColored(colors.requirement, '□ ' .. req);
    end
    imgui.Unindent(10);
    fancy_separator();
    
    -- Quest series (if applicable)
    if job_data.quest_series then
        render_quest_series(job_data.quest_series);
    else
        -- Standard steps
        imgui.TextColored(colors.header, 'Quest Steps:');
        imgui.PushTextWrapPos(imgui.GetWindowWidth() - 20);
        imgui.Indent(10);
        
        for _, step in ipairs(job_data.steps) do
            imgui.TextColored(colors.step, step.text);
            if step.location then
                imgui.SameLine();
                imgui.TextColored(colors.location, step.location);
                if step.detail then
                    imgui.SameLine();
                    imgui.TextColored(colors.step, step.detail);
                end
            end
        end
        
        imgui.Unindent(10);
        imgui.PopTextWrapPos();
        fancy_separator();
    end

    -- Weather Requirements (SMN only)
    if job_data.weather_requirements then
        render_weather_requirements(job_data.weather_requirements);
    end

    -- Warnings
    if job_data.warnings then
        imgui.TextColored(colors.header, 'Warnings:');
        imgui.Indent(10);
        for _, warning in ipairs(job_data.warnings) do
            imgui.TextColored(colors.warning, '! ' .. warning);
        end
        imgui.Unindent(10);
        fancy_separator();
    end

    -- Notes
    if job_data.notes then
        imgui.TextColored(colors.header, 'Notes:');
        imgui.Indent(10);
        for _, note in ipairs(job_data.notes) do
            imgui.TextColored(colors.note, '• ' .. note);
        end
        imgui.Unindent(10);
        fancy_separator();
    end
end

--[[
* Renders the UI.
--]]
local function render_ui()
    if (not jobhelper.is_open[1]) then
        return;
    end

    -- Set window style
    imgui.PushStyleColor(ImGuiCol_WindowBg, { 0.1, 0.1, 0.15, 0.95 });
    imgui.PushStyleColor(ImGuiCol_TitleBg, { 0.2, 0.2, 0.3, 1.0 });
    imgui.PushStyleColor(ImGuiCol_TitleBgActive, { 0.3, 0.3, 0.4, 1.0 });
    imgui.PushStyleColor(ImGuiCol_Border, { 0.5, 0.5, 0.8, 0.5 });
    imgui.PushStyleColor(ImGuiCol_Separator, { 0.5, 0.5, 0.8, 0.5 });
    
    -- Increased maximum window size constraints
    imgui.SetNextWindowSizeConstraints(
        { 400, 300 },     -- minimum size
        { 1920, 1080 }     -- maximum size (increased from 800x600)
    );
    
    -- Set initial window size if not already set
    if not jobhelper.initialized then
        imgui.SetNextWindowSize({ 800, 600 });
        jobhelper.initialized = true;
    end
    
    if (imgui.Begin('JobHelper', jobhelper.is_open)) then
        -- Rest of your render code...

        -- Job selection buttons with better layout
        local button_width = 100;  -- Set fixed button width
        local window_width = imgui.GetWindowWidth();
        local buttons_per_row = math.floor((window_width - 20) / (button_width + 5));
        local button_count = 0;

        for job_key, job_data in pairs(jobhelper.jobs) do
            if button_count > 0 and button_count % buttons_per_row ~= 0 then
                imgui.SameLine();
            end
            
            imgui.SetNextItemWidth(button_width);
            if imgui.Button(job_data.name, { button_width, 0 }) then
                jobhelper.selected_job = job_key;
            end
            
            button_count = button_count + 1;
        end

        imgui.NewLine();
        fancy_separator();
        
        -- Render selected job guide
        if jobhelper.selected_job then
            render_job_guide(jobhelper.jobs[jobhelper.selected_job]);
        else
            imgui.TextColored(colors.header, 'Select a job above to view unlock guide');
        end

        -- Store the window position
        local pos = { imgui.GetWindowPos() };
        jobhelper.settings.position_x = pos[1];
        jobhelper.settings.position_y = pos[2];
    end
    imgui.End();
    
    -- Pop window style colors
    imgui.PopStyleColor(5);
end


--[[
* Registers events when the addon is loaded.
--]]
ashita.events.register('d3d_present', 'present_cb', render_ui);

--[[
* Handles addon commands.
--]]
ashita.events.register('command', 'command_cb', function (e)
    -- Get the command arguments..
    local args = e.command:args();
    if (#args == 0) then
        return;
    end

    -- Handle: /jobhelper
    if (args[1] == '/jobhelper') then
        -- Block the command from being processed by the game..
        e.blocked = true;

        -- Toggle the UI visibility..
        jobhelper.is_open[1] = not jobhelper.is_open[1];
        
        -- Set the window position when opening
        if jobhelper.is_open[1] then
            imgui.SetNextWindowPos({ jobhelper.settings.position_x, jobhelper.settings.position_y }, ImGuiCond_FirstUseEver);
        end
    end
end);


--[[
* event: load
* desc : Event called when the addon is being loaded.
--]]
ashita.events.register('load', 'load_cb', function()
    -- Add any initialization here if needed
end);

--[[
* event: unload
* desc : Event called when the addon is being unloaded.
--]]
ashita.events.register('unload', 'unload_cb', function()
    -- Add any cleanup code here if needed
end);

--[[
* Returns the addon object.
--]]
return jobhelper;

