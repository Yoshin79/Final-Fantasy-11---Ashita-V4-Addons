-- autoroll.lua - Auto roll functionality for CorsairRolls addon

local data = require('data');

local autoroll = {};

-- Configuration for auto rolls
autoroll.config = {
    enabled = false, -- Disabled by default
    roll1 = {
        name = "Corsairs Roll",
        enabled = false,
        last_action_time = 0,
        active = false,
        snake_eye_used = false,  -- Track if Snake Eye was used
        busted = false           -- Track if roll is busted
    },
    roll2 = {
        name = "Samurai Roll",
        enabled = false,
        last_action_time = 0,
        active = false,
        snake_eye_used = false,  -- Track if Snake Eye was used
        busted = false           -- Track if roll is busted
    },
    action_delay = 6, -- Delay in seconds between actions
    phantom_roll_recast = 42, -- Changed to 42 seconds
    use_fold_on_bust = true,  -- Use Fold when a roll busts
    use_random_deal = true    -- Use Random Deal when Fold is on cooldown
};

-- Initialize auto roll
function autoroll.initialize()
    -- Load saved auto roll settings if they exist
    local settings = data.get_settings();
    if settings.autoroll then
        -- Copy saved settings but ensure enabled is false on startup
        autoroll.config.roll1 = settings.autoroll.roll1 or autoroll.config.roll1;
        autoroll.config.roll2 = settings.autoroll.roll2 or autoroll.config.roll2;
        autoroll.config.action_delay = settings.autoroll.action_delay or autoroll.config.action_delay;
        autoroll.config.phantom_roll_recast = settings.autoroll.phantom_roll_recast or autoroll.config.phantom_roll_recast;
        autoroll.config.use_fold_on_bust = settings.autoroll.use_fold_on_bust;
        autoroll.config.use_random_deal = settings.autoroll.use_random_deal;
        
        -- Force enabled to false on startup
        autoroll.config.enabled = false;
        autoroll.config.roll1.active = false;
        autoroll.config.roll2.active = false;
        autoroll.config.roll1.snake_eye_used = false;
        autoroll.config.roll2.snake_eye_used = false;
        autoroll.config.roll1.busted = false;
        autoroll.config.roll2.busted = false;
        
        -- Ensure all required fields exist
        if not autoroll.config.roll1.active then
            autoroll.config.roll1.active = false;
        end
        if not autoroll.config.roll2.active then
            autoroll.config.roll2.active = false;
        end
        if not autoroll.config.phantom_roll_recast then
            autoroll.config.phantom_roll_recast = 42; -- Changed to 42 seconds
        end
        if not autoroll.config.roll1.snake_eye_used then
            autoroll.config.roll1.snake_eye_used = false;
        end
        if not autoroll.config.roll2.snake_eye_used then
            autoroll.config.roll2.snake_eye_used = false;
        end
        if not autoroll.config.roll1.busted then
            autoroll.config.roll1.busted = false;
        end
        if not autoroll.config.roll2.busted then
            autoroll.config.roll2.busted = false;
        end
        if autoroll.config.use_fold_on_bust == nil then
            autoroll.config.use_fold_on_bust = true;
        end
        if autoroll.config.use_random_deal == nil then
            autoroll.config.use_random_deal = true;
        end
    else
        -- Save default config
        settings.autoroll = autoroll.config;
        data.save();
    end
    
    -- Clear any active rolls on startup
    settings.active_rolls = T{};
    data.save();
    
    print("Auto Roll: Initialized and disabled by default. Use /cor autoroll toggle to enable.");
end

-- Format roll name for command use (handle apostrophes)
function autoroll.format_roll_name(roll_name)
    -- Map of roll names that need apostrophes
    local apostrophe_rolls = {
        ["Corsairs Roll"] = "Corsair's Roll",
        ["Companions Roll"] = "Companion's Roll",
        ["Hunters Roll"] = "Hunter's Roll",
        ["Tacticians Roll"] = "Tactician's Roll",
        ["Allies Roll"] = "Allies' Roll",
        ["Misers Roll"] = "Miser's Roll",
        ["Avengers Roll"] = "Avenger's Roll"
    };
    
    -- Return the properly formatted name if it exists in our map
    if apostrophe_rolls[roll_name] then
        return apostrophe_rolls[roll_name];
    end
    
    -- Otherwise return the original name
    return roll_name;
end

-- Normalize roll name for comparison (remove apostrophes)
function autoroll.normalize_roll_name(roll_name)
    -- Remove apostrophes for consistent comparison
    return roll_name:gsub("'", "");
end

-- Check if an ability is ready
function autoroll.is_ability_ready(ability_name)
    -- Use Ashita API to check recast timers
    local recast = AshitaCore:GetMemoryManager():GetRecast();
    local player = AshitaCore:GetMemoryManager():GetPlayer();
    
    -- Loop through recast timers to find the ability
    for i = 0, 31 do
        local id = recast:GetAbilityTimerId(i);
        local timer = recast:GetAbilityTimer(i);
        
        -- Check if this is the ability we're looking for
        if id ~= 0 and timer > 0 then
            local ability = AshitaCore:GetResourceManager():GetAbilityByTimerId(id);
            if ability and ability.Name[player:GetMainJob()] == ability_name then
                return false, math.ceil(timer / 60); -- Return false and remaining time in seconds
            end
        end
    end
    
    return true, 0; -- Ability is ready
end

-- Process rolls and decide what action to take
function autoroll.process()
    if not autoroll.config.enabled then
        return;
    end
    
    local settings = data.get_settings();
    local current_time = os.time();
    local roll_data = data.get_roll_data();
    
    -- Update active status of rolls based on settings.active_rolls
    autoroll.update_active_status(settings.active_rolls);
    
    -- Process roll 1
    if autoroll.config.roll1.enabled then
        -- Check if roll 1 is busted
        if autoroll.config.roll1.busted then
            -- Try to recover from bust using Fold
            if autoroll.config.use_fold_on_bust then
                local fold_ready, fold_time = autoroll.is_ability_ready("Fold");
                if fold_ready and (current_time - autoroll.config.roll1.last_action_time) >= autoroll.config.action_delay then
                    autoroll.use_ability("/ja \"Fold\" <me>");
                    autoroll.config.roll1.last_action_time = current_time;
                    autoroll.config.roll1.busted = false; -- Fold removes bust
                    
                    if data.is_debug() then
                        print("Auto Roll: Used Fold to remove bust from Roll 1");
                    end
                    return; -- Wait for next cycle after using Fold
                elseif autoroll.config.use_random_deal then
                    -- If Fold is on cooldown, try Random Deal
                    local random_deal_ready, random_deal_time = autoroll.is_ability_ready("Random Deal");
                    if random_deal_ready and (current_time - autoroll.config.roll1.last_action_time) >= autoroll.config.action_delay then
                        autoroll.use_ability("/ja \"Random Deal\" <me>");
                        autoroll.config.roll1.last_action_time = current_time;
                        
                        if data.is_debug() then
                            print("Auto Roll: Used Random Deal to try to reset Fold");
                        end
                        return; -- Wait for next cycle after using Random Deal
                    end
                end
            end
            
            -- If we can't use Fold or Random Deal, just wait for bust to wear off
            if data.is_debug() then
                print("Auto Roll: Roll 1 is busted, waiting for effect to wear off");
            end
            return;
        end
        
        local roll1 = nil;
        
        -- Find the current roll 1 in active rolls
        for _, roll in ipairs(settings.active_rolls) do
            -- Normalize roll names for comparison
            if autoroll.normalize_roll_name(roll.name) == autoroll.normalize_roll_name(autoroll.config.roll1.name) then
                roll1 = roll;
                break;
            end
        end
        
        -- If we don't have roll 1 active and Phantom Roll is ready, use it
        if not roll1 then
            -- Reset snake_eye_used flag when starting a new roll
            autoroll.config.roll1.snake_eye_used = false;
            
            local ready, time = autoroll.is_ability_ready("Phantom Roll");
            if ready and (current_time - autoroll.config.roll1.last_action_time) >= autoroll.config.action_delay then
                -- Format the roll name properly for the command
                local formatted_name = autoroll.format_roll_name(autoroll.config.roll1.name);
                autoroll.use_ability("/ja \"" .. formatted_name .. "\" <me>");
                autoroll.config.roll1.last_action_time = current_time;
            end
        else
            -- We have roll 1, check if we need to Double-Up or use Snake Eye
            local roll_info = nil;
            
            -- Find roll info by normalized name
            for name, info in pairs(roll_data) do
                if autoroll.normalize_roll_name(name) == autoroll.normalize_roll_name(roll1.name) then
                    roll_info = info;
                    break;
                end
            end
            
            if roll_info then
                local lucky_value = roll_info.lucky or 0;
                local unlucky_value = roll_info.unlucky or 0;
                
                -- Debug info
                if data.is_debug() then
                    print("Auto Roll: Roll 1 value = " .. roll1.value .. ", lucky = " .. lucky_value .. ", unlucky = " .. unlucky_value);
                    print("Auto Roll: Snake Eye used = " .. tostring(autoroll.config.roll1.snake_eye_used));
                end
                
                -- If we rolled the lucky number, we're done
                if roll1.value == lucky_value or roll1.value == 11 then
                    -- Lucky roll, do nothing
                    if data.is_debug() then
                        print("Auto Roll: Roll 1 is lucky (" .. roll1.value .. "), no action needed");
                    end
                    -- Reset snake_eye_used flag
                    autoroll.config.roll1.snake_eye_used = false;
                elseif roll1.value == 10 and not autoroll.config.roll1.snake_eye_used then
                    -- Special case: If roll is 10, use Snake Eye to get to 11
                    local ready, time = autoroll.is_ability_ready("Snake Eye");
                    if ready and (current_time - autoroll.config.roll1.last_action_time) >= autoroll.config.action_delay then
                        autoroll.use_ability("/ja \"Snake Eye\" <me>");
                        autoroll.config.roll1.last_action_time = current_time;
                        autoroll.config.roll1.snake_eye_used = true;
                        
                        if data.is_debug() then
                            print("Auto Roll: Used Snake Eye for Roll 1 at value 10 to get to 11");
                        end
                    else
                        -- If Snake Eye is not ready or we've already used it, try Double-Up
                        local ready, time = autoroll.is_ability_ready("Double-Up");
                        if ready and (current_time - autoroll.config.roll1.last_action_time) >= autoroll.config.action_delay then
                            autoroll.use_ability("/ja \"Double-Up\" <me>");
                            autoroll.config.roll1.last_action_time = current_time;
                            
                            if data.is_debug() then
                                print("Auto Roll: Used Double-Up for Roll 1 after Snake Eye attempt");
                            end
                        end
                    end
                elseif roll1.value < 7 then
                    -- If we're one below lucky and Snake Eye is ready and we haven't used it yet
                    if lucky_value and roll1.value == lucky_value - 1 and not autoroll.config.roll1.snake_eye_used then
                        local ready, time = autoroll.is_ability_ready("Snake Eye");
                        if ready and (current_time - autoroll.config.roll1.last_action_time) >= autoroll.config.action_delay then
                            autoroll.use_ability("/ja \"Snake Eye\" <me>");
                            autoroll.config.roll1.last_action_time = current_time;
                            autoroll.config.roll1.snake_eye_used = true;
                            
                            if data.is_debug() then
                                print("Auto Roll: Used Snake Eye for Roll 1");
                            end
                        else
                            -- If Snake Eye is not ready or we've already used it, try Double-Up
                            local ready, time = autoroll.is_ability_ready("Double-Up");
                            if ready and (current_time - autoroll.config.roll1.last_action_time) >= autoroll.config.action_delay then
                                autoroll.use_ability("/ja \"Double-Up\" <me>");
                                autoroll.config.roll1.last_action_time = current_time;
                                
                                if data.is_debug() then
                                    print("Auto Roll: Used Double-Up for Roll 1 after Snake Eye attempt");
                                end
                            end
                        end
                    else
                        -- Otherwise Double-Up if it's ready
                        local ready, time = autoroll.is_ability_ready("Double-Up");
                        if ready and (current_time - autoroll.config.roll1.last_action_time) >= autoroll.config.action_delay then
                            autoroll.use_ability("/ja \"Double-Up\" <me>");
                            autoroll.config.roll1.last_action_time = current_time;
                            
                            if data.is_debug() then
                                print("Auto Roll: Used Double-Up for Roll 1");
                            end
                        end
                    end
                else
                    -- Roll is 7 or higher, check if it's unlucky
                    if unlucky_value and roll1.value == unlucky_value then
                        -- If unlucky and Double-Up is ready, try to improve it
                        local ready, time = autoroll.is_ability_ready("Double-Up");
                        if ready and (current_time - autoroll.config.roll1.last_action_time) >= autoroll.config.action_delay then
                            autoroll.use_ability("/ja \"Double-Up\" <me>");
                            autoroll.config.roll1.last_action_time = current_time;
                            
                            if data.is_debug() then
                                print("Auto Roll: Used Double-Up to improve unlucky Roll 1");
                            end
                        end
                    else
                        -- Roll is 7 or higher and not unlucky, we're satisfied
                        if data.is_debug() then
                            print("Auto Roll: Roll 1 is " .. roll1.value .. ", which is good enough");
                        end
                        -- Reset snake_eye_used flag
                        autoroll.config.roll1.snake_eye_used = false;
                    end
                end
            end
        end
    end
    
    -- Process roll 2 only if roll 1 is active and Phantom Roll is ready again
    -- or if roll 1 is not enabled
    if autoroll.config.roll2.enabled and 
       (not autoroll.config.roll1.enabled or autoroll.config.roll1.active) then
        
        -- Check if roll 2 is busted
        if autoroll.config.roll2.busted then
            -- Try to recover from bust using Fold
            if autoroll.config.use_fold_on_bust then
                local fold_ready, fold_time = autoroll.is_ability_ready("Fold");
                if fold_ready and (current_time - autoroll.config.roll2.last_action_time) >= autoroll.config.action_delay then
                    autoroll.use_ability("/ja \"Fold\" <me>");
                    autoroll.config.roll2.last_action_time = current_time;
                    autoroll.config.roll2.busted = false; -- Fold removes bust
                    
                    if data.is_debug() then
                        print("Auto Roll: Used Fold to remove bust from Roll 2");
                    end
                    return; -- Wait for next cycle after using Fold
                elseif autoroll.config.use_random_deal then
                    -- If Fold is on cooldown, try Random Deal
                    local random_deal_ready, random_deal_time = autoroll.is_ability_ready("Random Deal");
                    if random_deal_ready and (current_time - autoroll.config.roll2.last_action_time) >= autoroll.config.action_delay then
                        autoroll.use_ability("/ja \"Random Deal\" <me>");
                        autoroll.config.roll2.last_action_time = current_time;
                        
                        if data.is_debug() then
                            print("Auto Roll: Used Random Deal to try to reset Fold");
                        end
                        return; -- Wait for next cycle after using Random Deal
                    end
                end
            end
            
            -- If we can't use Fold or Random Deal, just wait for bust to wear off
            if data.is_debug() then
                print("Auto Roll: Roll 2 is busted, waiting for effect to wear off");
            end
            return;
        end
        
        -- Check if enough time has passed since roll 1 was used
        if autoroll.config.roll1.enabled and autoroll.config.roll1.last_action_time and
           (current_time - autoroll.config.roll1.last_action_time) < autoroll.config.phantom_roll_recast then
            -- Not enough time has passed, wait for Phantom Roll to be ready
            if data.is_debug() then
                local time_left = autoroll.config.phantom_roll_recast - (current_time - autoroll.config.roll1.last_action_time);
                print("Auto Roll: Waiting for Phantom Roll to be ready for Roll 2. Time left: " .. time_left .. "s");
            end
            return;
        end
        
        local roll2 = nil;
        
        -- Find the current roll 2 in active rolls
        for _, roll in ipairs(settings.active_rolls) do
            -- Normalize roll names for comparison
            if autoroll.normalize_roll_name(roll.name) == autoroll.normalize_roll_name(autoroll.config.roll2.name) then
                roll2 = roll;
                break;
            end
        end
        
        -- If we don't have roll 2 active and Phantom Roll is ready, use it
        if not roll2 then
            -- Reset snake_eye_used flag when starting a new roll
            autoroll.config.roll2.snake_eye_used = false;
            
            local ready, time = autoroll.is_ability_ready("Phantom Roll");
            if ready and (current_time - autoroll.config.roll2.last_action_time) >= autoroll.config.action_delay then
                -- Format the roll name properly for the command
                local formatted_name = autoroll.format_roll_name(autoroll.config.roll2.name);
                autoroll.use_ability("/ja \"" .. formatted_name .. "\" <me>");
                autoroll.config.roll2.last_action_time = current_time;
                
                if data.is_debug() then
                    print("Auto Roll: Used " .. formatted_name .. " for Roll 2");
                end
            end
        else
            -- We have roll 2, check if we need to Double-Up or use Snake Eye
            local roll_info = nil;
            
            -- Find roll info by normalized name
            for name, info in pairs(roll_data) do
                if autoroll.normalize_roll_name(name) == autoroll.normalize_roll_name(roll2.name) then
                    roll_info = info;
                    break;
                end
            end
            
            if roll_info then
                local lucky_value = roll_info.lucky or 0;
                local unlucky_value = roll_info.unlucky or 0;
                
                -- Debug info to help diagnose the issue
                if data.is_debug() then
                    print("Auto Roll: Roll 2 value = " .. roll2.value .. ", lucky = " .. lucky_value .. ", unlucky = " .. unlucky_value);
                    print("Auto Roll: Snake Eye used = " .. tostring(autoroll.config.roll2.snake_eye_used));
                end
                
                -- If we rolled the lucky number, we're done
                if roll2.value == lucky_value or roll2.value == 11 then
                    -- Lucky roll, do nothing
                    if data.is_debug() then
                        print("Auto Roll: Roll 2 is lucky (" .. roll2.value .. "), no action needed");
                    end
                    -- Reset snake_eye_used flag
                    autoroll.config.roll2.snake_eye_used = false;
                elseif roll2.value == 10 and not autoroll.config.roll2.snake_eye_used then
                    -- Special case: If roll is 10, use Snake Eye to get to 11
                    local ready, time = autoroll.is_ability_ready("Snake Eye");
                    if ready and (current_time - autoroll.config.roll2.last_action_time) >= autoroll.config.action_delay then
                        autoroll.use_ability("/ja \"Snake Eye\" <me>");
                        autoroll.config.roll2.last_action_time = current_time;
                        autoroll.config.roll2.snake_eye_used = true;
                        
                        if data.is_debug() then
                            print("Auto Roll: Used Snake Eye for Roll 2 at value 10 to get to 11");
                        end
                    else
                        -- If Snake Eye is not ready or we've already used it, try Double-Up
                        local ready, time = autoroll.is_ability_ready("Double-Up");
                        if ready and (current_time - autoroll.config.roll2.last_action_time) >= autoroll.config.action_delay then
                            autoroll.use_ability("/ja \"Double-Up\" <me>");
                            autoroll.config.roll2.last_action_time = current_time;
                            
                            if data.is_debug() then
                                print("Auto Roll: Used Double-Up for Roll 2 after Snake Eye attempt");
                            end
                        end
                    end
                elseif roll2.value < 7 then
                    -- If we're one below lucky and Snake Eye is ready and we haven't used it yet
                    if lucky_value and roll2.value == lucky_value - 1 and not autoroll.config.roll2.snake_eye_used then
                        local ready, time = autoroll.is_ability_ready("Snake Eye");
                        if ready and (current_time - autoroll.config.roll2.last_action_time) >= autoroll.config.action_delay then
                            autoroll.use_ability("/ja \"Snake Eye\" <me>");
                            autoroll.config.roll2.last_action_time = current_time;
                            autoroll.config.roll2.snake_eye_used = true;
                            
                            if data.is_debug() then
                                print("Auto Roll: Used Snake Eye for Roll 2");
                            end
                        else
                            -- If Snake Eye is not ready or we've already used it, try Double-Up
                            local ready, time = autoroll.is_ability_ready("Double-Up");
                            if ready and (current_time - autoroll.config.roll2.last_action_time) >= autoroll.config.action_delay then
                                autoroll.use_ability("/ja \"Double-Up\" <me>");
                                autoroll.config.roll2.last_action_time = current_time;
                                
                                if data.is_debug() then
                                    print("Auto Roll: Used Double-Up for Roll 2 after Snake Eye attempt");
                                end
                            end
                        end
                    else
                        -- Otherwise Double-Up if it's ready
                        local ready, time = autoroll.is_ability_ready("Double-Up");
                        if ready and (current_time - autoroll.config.roll2.last_action_time) >= autoroll.config.action_delay then
                            autoroll.use_ability("/ja \"Double-Up\" <me>");
                            autoroll.config.roll2.last_action_time = current_time;
                            
                            if data.is_debug() then
                                print("Auto Roll: Used Double-Up for Roll 2");
                            end
                        end
                    end
                else
                    -- Roll is 7 or higher, check if it's unlucky
                    if unlucky_value and roll2.value == unlucky_value then
                        -- If unlucky and Double-Up is ready, try to improve it
                        local ready, time = autoroll.is_ability_ready("Double-Up");
                        if ready and (current_time - autoroll.config.roll2.last_action_time) >= autoroll.config.action_delay then
                            autoroll.use_ability("/ja \"Double-Up\" <me>");
                            autoroll.config.roll2.last_action_time = current_time;
                            
                            if data.is_debug() then
                                print("Auto Roll: Used Double-Up to improve unlucky Roll 2");
                            end
                        end
                    else
                        -- Roll is 7 or higher and not unlucky, we're satisfied
                        if data.is_debug() then
                            print("Auto Roll: Roll 2 is " .. roll2.value .. ", which is good enough");
                        end
                        -- Reset snake_eye_used flag
                        autoroll.config.roll2.snake_eye_used = false;
                    end
                end
            else
                -- No roll info found, this is likely the issue
                if data.is_debug() then
                    print("Auto Roll: No roll info found for " .. roll2.name);
                end
            end
        end
    end
    
    -- Save the updated config
    settings.autoroll = autoroll.config;
    data.save();
end

-- Update active status of rolls
function autoroll.update_active_status(active_rolls)
    -- Previous active status
    local prev_roll1_active = autoroll.config.roll1.active;
    local prev_roll2_active = autoroll.config.roll2.active;
    
    -- Reset active status
    autoroll.config.roll1.active = false;
    autoroll.config.roll2.active = false;
    
    -- Check if rolls are active
    for _, roll in ipairs(active_rolls) do
        -- Normalize roll names for comparison
        if autoroll.normalize_roll_name(roll.name) == autoroll.normalize_roll_name(autoroll.config.roll1.name) then
            autoroll.config.roll1.active = true;
        elseif autoroll.normalize_roll_name(roll.name) == autoroll.normalize_roll_name(autoroll.config.roll2.name) then
            autoroll.config.roll2.active = true;
        end
    end
    
    -- If a roll was active but is no longer active, reset its state
    if prev_roll1_active and not autoroll.config.roll1.active then
        autoroll.config.roll1.snake_eye_used = false;
        if data.is_debug() then
            print("Auto Roll: Roll 1 is no longer active, resetting state");
        end
    end
    
    if prev_roll2_active and not autoroll.config.roll2.active then
        autoroll.config.roll2.snake_eye_used = false;
        if data.is_debug() then
            print("Auto Roll: Roll 2 is no longer active, resetting state");
        end
    end
    
    -- Debug info
    if data.is_debug() then
        print("Auto Roll: Roll 1 active = " .. tostring(autoroll.config.roll1.active));
        print("Auto Roll: Roll 2 active = " .. tostring(autoroll.config.roll2.active));
    end
end

-- Track bust status
function autoroll.set_bust_status(roll_name, is_busted)
    if autoroll.normalize_roll_name(roll_name) == autoroll.normalize_roll_name(autoroll.config.roll1.name) then
        autoroll.config.roll1.busted = is_busted;
        if data.is_debug() then
            print("Auto Roll: Roll 1 bust status set to " .. tostring(is_busted));
        end
    elseif autoroll.normalize_roll_name(roll_name) == autoroll.normalize_roll_name(autoroll.config.roll2.name) then
        autoroll.config.roll2.busted = is_busted;
        if data.is_debug() then
            print("Auto Roll: Roll 2 bust status set to " .. tostring(is_busted));
        end
    end
end

-- Reset roll state when a roll effect is lost
function autoroll.reset_roll_state(roll_name)
    if autoroll.normalize_roll_name(roll_name) == autoroll.normalize_roll_name(autoroll.config.roll1.name) then
        autoroll.config.roll1.snake_eye_used = false;
        if data.is_debug() then
            print("Auto Roll: Reset Roll 1 state due to effect loss");
        end
    elseif autoroll.normalize_roll_name(roll_name) == autoroll.normalize_roll_name(autoroll.config.roll2.name) then
        autoroll.config.roll2.snake_eye_used = false;
        if data.is_debug() then
            print("Auto Roll: Reset Roll 2 state due to effect loss");
        end
    end
end

-- Execute an ability command
function autoroll.use_ability(command)
    AshitaCore:GetChatManager():QueueCommand(1, command);
    if data.is_debug() then
        print("Auto Roll: " .. command);
    end
end

-- Toggle auto roll feature
function autoroll.toggle()
    autoroll.config.enabled = not autoroll.config.enabled;
    print("Auto Roll: " .. (autoroll.config.enabled and "Enabled" or "Disabled"));
    
    local settings = data.get_settings();
    settings.autoroll = autoroll.config;
    data.save();
end

-- Toggle specific roll
function autoroll.toggle_roll(roll_num)
    if roll_num == 1 then
        autoroll.config.roll1.enabled = not autoroll.config.roll1.enabled;
        print("Auto Roll 1 (" .. autoroll.config.roll1.name .. "): " .. 
              (autoroll.config.roll1.enabled and "Enabled" or "Disabled"));
    elseif roll_num == 2 then
        autoroll.config.roll2.enabled = not autoroll.config.roll2.enabled;
        print("Auto Roll 2 (" .. autoroll.config.roll2.name .. "): " .. 
              (autoroll.config.roll2.enabled and "Enabled" or "Disabled"));
    end
    
    local settings = data.get_settings();
    settings.autoroll = autoroll.config;
    data.save();
end



-- Set roll type
function autoroll.set_roll(roll_num, roll_name)
    if roll_num == 1 then
        autoroll.config.roll1.name = roll_name;
        print("Auto Roll 1 set to: " .. roll_name);
    elseif roll_num == 2 then
        autoroll.config.roll2.name = roll_name;
        print("Auto Roll 2 set to: " .. roll_name);
    end
    
    local settings = data.get_settings();
    settings.autoroll = autoroll.config;
    data.save();
end

-- Toggle use of Fold on bust
function autoroll.toggle_fold_on_bust()
    autoroll.config.use_fold_on_bust = not autoroll.config.use_fold_on_bust;
    print("Auto Roll: Use Fold on bust " .. (autoroll.config.use_fold_on_bust and "Enabled" or "Disabled"));
    
    local settings = data.get_settings();
    settings.autoroll = autoroll.config;
    data.save();
end

-- Toggle use of Random Deal
function autoroll.toggle_random_deal()
    autoroll.config.use_random_deal = not autoroll.config.use_random_deal;
    print("Auto Roll: Use Random Deal " .. (autoroll.config.use_random_deal and "Enabled" or "Disabled"));
    
    local settings = data.get_settings();
    settings.autoroll = autoroll.config;
    data.save();
end

return autoroll;
