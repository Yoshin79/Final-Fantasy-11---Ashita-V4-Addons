-- config.lua - ImGui configuration panel for CorsairRolls addon

local imgui = require('imgui');
local data = require('data');
local display = require('display');
local tracker = require('tracker');
local autoroll = require('autoroll');

local config = {};

-- Initialize configuration
function config.initialize()
    -- Nothing to initialize
end

-- Helper function to convert color from 0xAARRGGBB to ImGui format {r, g, b, a}
local function color_to_imgui(color)
    local a = bit.band(bit.rshift(color, 24), 0xFF) / 255;
    local r = bit.band(bit.rshift(color, 16), 0xFF) / 255;
    local g = bit.band(bit.rshift(color, 8), 0xFF) / 255;
    local b = bit.band(color, 0xFF) / 255;
    return { r, g, b, a };
end

-- Helper function to convert color from ImGui format {r, g, b, a} to 0xAARRGGBB
local function imgui_to_color(color_array)
    local a = math.floor(color_array[4] * 255);
    local r = math.floor(color_array[1] * 255);
    local g = math.floor(color_array[2] * 255);
    local b = math.floor(color_array[3] * 255);
    return bit.lshift(a, 24) + bit.lshift(r, 16) + bit.lshift(g, 8) + b;
end

-- Toggle configuration window visibility
function config.toggle()
    local settings = data.get_settings();
    settings.config_visible = not settings.config_visible;
    data.save();
end

-- Render the configuration window
function config.render()
    local settings = data.get_settings();
    
    if not settings.config_visible then
        return;
    end
    
    -- Create a boolean reference for the window state
    local is_open = { settings.config_visible };
    
    -- Begin the configuration window with the is_open reference
    imgui.SetNextWindowSize({ 400, 300 }, ImGuiCond_FirstUseEver);
    if imgui.Begin('Corsair Rolls Configuration', is_open) then
        -- Visibility toggle
        local visible = settings.visible;
        if imgui.Checkbox('Display Rolls', { visible }) then
            display.toggle_visibility();
        end
        
        imgui.Separator();
        
        -- Font settings
        if imgui.CollapsingHeader('Font Settings') then
            -- Font family dropdown
            if imgui.BeginCombo('Font Family', settings.font.family) then
                for _, family in ipairs(data.get_font_families()) do
                    if imgui.Selectable(family, family == settings.font.family) then
                        display.update_font_settings(family, nil);
                    end
                end
                imgui.EndCombo();
            end
            
            -- Font size buttons
            imgui.Text('Font Size: ' .. settings.font.size);
            
            imgui.SameLine();
            
            if imgui.Button('-') then
                if settings.font.size > 8 then
                    display.update_font_settings(nil, settings.font.size - 1);
                end
            end
            
            imgui.SameLine();
            
            if imgui.Button('+') then
                if settings.font.size < 20 then
                    display.update_font_settings(nil, settings.font.size + 1);
                end
            end
        end
        
        imgui.Separator();
        
        -- Color settings
        if imgui.CollapsingHeader('Color Settings') then
            -- Text color
            local text_color = color_to_imgui(settings.colors.text);
            if imgui.ColorEdit4('Normal Text Color', text_color) then
                settings.colors.text = imgui_to_color(text_color);
                data.save();
            end
            
            -- Lucky color
            local lucky_color = color_to_imgui(settings.colors.lucky);
            if imgui.ColorEdit4('Lucky Roll Color', lucky_color) then
                settings.colors.lucky = imgui_to_color(lucky_color);
                data.save();
            end
            
            -- Unlucky color
            local unlucky_color = color_to_imgui(settings.colors.unlucky);
            if imgui.ColorEdit4('Unlucky Roll Color', unlucky_color) then
                settings.colors.unlucky = imgui_to_color(unlucky_color);
                data.save();
            end
            
            -- Background color
            local bg_color = color_to_imgui(settings.colors.background);
            if imgui.ColorEdit4('Background Color', bg_color) then
                display.update_background_color(imgui_to_color(bg_color));
            end
        end
        
        imgui.Separator();
        
        -- Test rolls section
        if imgui.CollapsingHeader('Test Rolls') then
            if imgui.Button('Test Lucky Roll') then
                -- Add a test lucky roll
                local test_roll = "Hunters Roll";
                local lucky_value = data.get_roll_data()[test_roll].lucky;
                
                -- If we already have 2 rolls, remove the oldest one
                if #settings.active_rolls >= 2 then
                    table.remove(settings.active_rolls, 1);
                end
                
                -- Add the test roll
                table.insert(settings.active_rolls, {
                    name = test_roll,
                    value = lucky_value
                });
                
                data.save();
            end
            
            imgui.SameLine();
            
            if imgui.Button('Test Unlucky Roll') then
                -- Add a test unlucky roll
                local test_roll = "Tacticians Roll";
                local unlucky_value = data.get_roll_data()[test_roll].unlucky;
                
                -- If we already have 2 rolls, remove the oldest one
                if #settings.active_rolls >= 2 then
                    table.remove(settings.active_rolls, 1);
                end
                
                -- Add the test roll
                table.insert(settings.active_rolls, {
                    name = test_roll,
                    value = unlucky_value
                });
                
                data.save();
            end
            
            if imgui.Button('Clear Rolls') then
                tracker.clear_rolls();
            end
        end
        
        imgui.Separator();
        
        -- Auto Roll settings
        if imgui.CollapsingHeader('Auto Roll Settings') then
            -- Enable/disable auto roll
            local auto_enabled = settings.autoroll.enabled;
            if imgui.Checkbox('Enable Auto Roll', { auto_enabled }) then
                autoroll.toggle();
            end
            
            imgui.Separator();
            
            -- Roll 1 settings
            local roll1_enabled = settings.autoroll.roll1.enabled;
            if imgui.Checkbox('Enable Roll 1', { roll1_enabled }) then
                autoroll.toggle_roll(1);
            end
            
            imgui.SameLine();
            
            -- Roll 1 dropdown
            if imgui.BeginCombo('Roll 1 Type', settings.autoroll.roll1.name) then
                for roll_name, _ in pairs(data.get_roll_data()) do
                    if imgui.Selectable(roll_name, roll_name == settings.autoroll.roll1.name) then
                        autoroll.set_roll(1, roll_name);
                    end
                end
                imgui.EndCombo();
            end
            
            -- Roll 2 settings
            local roll2_enabled = settings.autoroll.roll2.enabled;
            if imgui.Checkbox('Enable Roll 2', { roll2_enabled }) then
                autoroll.toggle_roll(2);
            end
            
            imgui.SameLine();
            
            -- Roll 2 dropdown
            if imgui.BeginCombo('Roll 2 Type', settings.autoroll.roll2.name) then
                for roll_name, _ in pairs(data.get_roll_data()) do
                    if imgui.Selectable(roll_name, roll_name == settings.autoroll.roll2.name) then
                        autoroll.set_roll(2, roll_name);
                    end
                end
                imgui.EndCombo();
            end
            
            -- Action delay setting
            local action_delay = settings.autoroll.action_delay;
            imgui.Text('Action Delay (seconds): ');
            imgui.SameLine();
            if imgui.InputInt('##ActionDelay', { action_delay }) then
                if action_delay < 1 then action_delay = 1; end
                if action_delay > 30 then action_delay = 30; end
                settings.autoroll.action_delay = action_delay;
                data.save();
            end
            
            -- Use Fold on bust checkbox
            local use_fold = settings.autoroll.use_fold_on_bust;
            if imgui.Checkbox('Use Fold on Bust', { use_fold }) then
                autoroll.toggle_fold_on_bust();
            end
            
            -- Use Random Deal checkbox
            local use_random_deal = settings.autoroll.use_random_deal;
            if imgui.Checkbox('Use Random Deal when Fold is on cooldown', { use_random_deal }) then
                autoroll.toggle_random_deal();
            end
            
            -- Display bust status
            if settings.autoroll.roll1.busted then
                imgui.TextColored({ 1, 0.3, 0.3, 1 }, "Roll 1 is busted!");
            end
            
            if settings.autoroll.roll2.busted then
                imgui.TextColored({ 1, 0.3, 0.3, 1 }, "Roll 2 is busted!");
            end
        end
        
        imgui.Separator();
        
        -- Debug section
        if imgui.CollapsingHeader('Debug Options') then
            local debug_enabled = data.is_debug();
            if imgui.Checkbox('Enable Debug Messages', { debug_enabled }) then
                data.toggle_debug();
            end
        end
        
        imgui.Separator();
        
        -- Save and close buttons
        if imgui.Button('Save Settings') then
            data.save();
            print("Corsair Rolls settings saved.");
        end
        
        imgui.SameLine();
        
        if imgui.Button('Close Configuration') then
            settings.config_visible = false;
            data.save();
        end
        
        imgui.SameLine();
        
        if imgui.Button('Reset to Defaults') then
            -- Reset to defaults but keep position
            local pos_x = settings.position.x;
            local pos_y = settings.position.y;
            
            -- Preserve positions of individual rolls if they exist
            local positions = settings.positions;
            
            -- Reload default settings
            data.initialize();
            settings = data.get_settings();
            
            -- Restore position
            settings.position.x = pos_x;
            settings.position.y = pos_y;
            
            -- Restore individual roll positions if they existed
            if positions then
                settings.positions = positions;
            end
            
            -- Reinitialize display with new settings
            display.initialize();
            
            data.save();
        end
        
        imgui.End();
    end
    
    -- Update the config_visible state based on the window state
    if not is_open[1] and settings.config_visible then
        settings.config_visible = false;
        data.save();
    end
end

return config;
