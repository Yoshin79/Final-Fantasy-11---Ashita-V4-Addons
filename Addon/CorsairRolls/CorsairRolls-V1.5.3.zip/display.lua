-- display.lua - Display and font handling for CorsairRolls addon

local data = require('data');

local display = {};
local roll_fonts = {};
local last_pos = {};

-- Initialize display
function display.initialize()
    local settings = data.get_settings();
    roll_fonts = {};
    last_pos = {};
    
    -- Create the font objects for rolls (up to 2 active rolls)
    for i = 1, 2 do
        local font = AshitaCore:GetFontManager():Create('__corsair_roll_' .. i);
        
        -- Initialize positions - use stored positions if available, otherwise use defaults
        if not settings.positions then
            settings.positions = {};
        end
        
        if not settings.positions[i] then
            settings.positions[i] = {
                x = settings.position.x,
                y = settings.position.y + ((i - 1) * (settings.font.size + 4))
            };
        end
        
        font:SetPositionX(settings.positions[i].x);
        font:SetPositionY(settings.positions[i].y);
        font:SetColor(settings.colors.text);
        font:SetFontFamily(settings.font.family);
        font:SetFontHeight(settings.font.size);
        font:GetBackground():SetVisible(true);
        font:GetBackground():SetColor(settings.colors.background);
        font:SetVisible(false); -- Initially hidden until rolls are active
        font:SetLocked(false);   -- Allow the font to be dragged
        
        roll_fonts[i] = font;
        last_pos[i] = {
            x = settings.positions[i].x,
            y = settings.positions[i].y
        };
    end
    
    -- Save the settings to ensure positions are stored
    data.save();
end

-- Normalize roll name to handle apostrophes consistently
local function normalize_roll_name(name)
    -- Remove apostrophes for consistent lookup
    local normalized = name:gsub("'", "");
    
    -- Map common variations to standard names
    if normalized == "Companions Roll" then
        return "Companions Roll";
    end
    
    return normalized;
end

-- Check if a value is a lucky number for a roll
local function is_lucky_number(roll_name, value)
    -- Debug the roll name
    if data.is_debug() then
        print("DEBUG: Checking if " .. value .. " is lucky for " .. roll_name);
    end
    
    -- 11 is always lucky for any roll
    if value == 11 then
        if data.is_debug() then
            print("DEBUG: 11 is always lucky!");
        end
        return true;
    end
    
    -- Normalize the roll name
    local normalized_name = normalize_roll_name(roll_name);
    
    -- Check against the standard lucky number in roll_data
    local roll_data_entry = data.get_roll_data()[normalized_name];
    if not roll_data_entry and data.is_debug() then
        print("DEBUG: No roll data found for " .. normalized_name);
        -- Try to find a close match
        for name, _ in pairs(data.get_roll_data()) do
            print("DEBUG: Available roll: " .. name);
        end
        return false;
    end
    
    if roll_data_entry and value == roll_data_entry.lucky then
        if data.is_debug() then
            print("DEBUG: " .. value .. " matches lucky number for " .. normalized_name);
        end
        return true;
    end
    
    return false;
end

-- Check if a value is an unlucky number for a roll
local function is_unlucky_number(roll_name, value)
    -- Normalize the roll name
    local normalized_name = normalize_roll_name(roll_name);
    
    local roll_data_entry = data.get_roll_data()[normalized_name];
    if not roll_data_entry and data.is_debug() then
        print("DEBUG: No roll data found for " .. normalized_name .. " when checking unlucky");
        return false;
    end
    
    if roll_data_entry and value == roll_data_entry.unlucky then
        if data.is_debug() then
            print("DEBUG: " .. value .. " matches unlucky number for " .. normalized_name);
        end
        return true;
    end
    
    return false;
end

-- Update the display
function display.update()
    local settings = data.get_settings();
    
    -- Update roll displays
    for i = 1, 2 do
        local font = roll_fonts[i];
        local roll = settings.active_rolls[i];
        
        if font and roll then
            -- Set text and make visible
            local roll_text = string.format('%s = %d', roll.name, roll.value);
            font:SetText(roll_text);
            font:SetVisible(settings.visible);
            
            -- Set color based on lucky/unlucky
            if is_lucky_number(roll.name, roll.value) then
                font:SetColor(settings.colors.lucky);
                if data.is_debug() then
                    print("DEBUG: " .. roll.name .. " value " .. roll.value .. " is lucky!");
                end
            elseif is_unlucky_number(roll.name, roll.value) then
                font:SetColor(settings.colors.unlucky);
                if data.is_debug() then
                    print("DEBUG: " .. roll.name .. " value " .. roll.value .. " is unlucky!");
                end
            else
                font:SetColor(settings.colors.text);
                if data.is_debug() then
                    print("DEBUG: " .. roll.name .. " value " .. roll.value .. " is normal.");
                end
            end
            
            -- Check if this font has been moved
            local pos_x = font:GetPositionX();
            local pos_y = font:GetPositionY();
            
            -- Only update if position has changed
            if pos_x ~= last_pos[i].x or pos_y ~= last_pos[i].y then
                -- Update settings with new position
                if not settings.positions then
                    settings.positions = {};
                end
                
                settings.positions[i] = {
                    x = pos_x,
                    y = pos_y
                };
                
                -- Update last known position
                last_pos[i].x = pos_x;
                last_pos[i].y = pos_y;
                
                -- Save settings
                data.save();
                
                if data.is_debug() then
                    print("DEBUG: Roll " .. i .. " position updated to X:" .. pos_x .. " Y:" .. pos_y);
                end
            end
        elseif font then
            -- No roll data for this slot, hide it
            font:SetVisible(false);
        end
    end
end

-- Clean up display resources
function display.cleanup()
    for i = 1, 2 do
        if roll_fonts[i] ~= nil then
            AshitaCore:GetFontManager():Delete('__corsair_roll_' .. i);
        end
    end
end

-- Toggle visibility
function display.toggle_visibility()
    local settings = data.get_settings();
    settings.visible = not settings.visible;
    
    for i = 1, 2 do
        if roll_fonts[i] and settings.active_rolls[i] then
            roll_fonts[i]:SetVisible(settings.visible);
        end
    end
    
    data.save();
end

-- Set lucky color
function display.set_lucky_color(hex)
    local color = tonumber('0xFF' .. hex, 16);
    if color then
        data.get_settings().colors.lucky = color;
        data.save();
        print("Lucky roll color set to #" .. hex);
    else
        print("Invalid color format. Use hex format like 00FF00 for green.");
    end
end

-- Set unlucky color
function display.set_unlucky_color(hex)
    local color = tonumber('0xFF' .. hex, 16);
    if color then
        data.get_settings().colors.unlucky = color;
        data.save();
        print("Unlucky roll color set to #" .. hex);
    else
        print("Invalid color format. Use hex format like FF8000 for orange.");
    end
end

-- Update font settings
function display.update_font_settings(family, size)
    local settings = data.get_settings();
    
    if family then
        settings.font.family = family;
    end
    
    if size then
        settings.font.size = size;
    end
    
    for i = 1, 2 do
        if roll_fonts[i] then
            if family then
                roll_fonts[i]:SetFontFamily(settings.font.family);
            end
            
            if size then
                roll_fonts[i]:SetFontHeight(settings.font.size);
            end
        end
    end
    
    data.save();
end

-- Update background color
function display.update_background_color(color)
    local settings = data.get_settings();
    settings.colors.background = color;
    
    for i = 1, 2 do
        if roll_fonts[i] then
            roll_fonts[i]:GetBackground():SetColor(color);
        end
    end
    
    data.save();
end

-- Set position manually
function display.set_position(index, x, y)
    if roll_fonts[index] then
        roll_fonts[index]:SetPositionX(x);
        roll_fonts[index]:SetPositionY(y);
        
        -- Update settings
        local settings = data.get_settings();
        if not settings.positions then
            settings.positions = {};
        end
        
        settings.positions[index] = {
            x = x,
            y = y
        };
        
        -- Update last known position
        last_pos[index] = {
            x = x,
            y = y
        };
        
        data.save();
    end
end

return display;
