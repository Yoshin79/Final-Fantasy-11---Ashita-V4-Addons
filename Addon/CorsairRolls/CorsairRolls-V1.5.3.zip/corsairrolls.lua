-- corsairrolls.lua for Ashita v4
addon.name      = 'corsairrolls';
addon.author    = 'Oneword - Ninja Ai';
addon.version   = '1.5.3';
addon.desc      = 'Tracks Corsair rolls lucky/unlucky numbers';

require('common');
local settings = require('settings');

-- Load modules in the correct order to avoid circular dependencies
local data = require('data');
local display = require('display');
local autoroll = require('autoroll');
local tracker = require('tracker');
local config = require('config');

-- Track current zone to detect zone changes (for packet detection only)
local current_zone = 0;

-- Initialize the addon
ashita.events.register('load', 'corsair_load', function()
    -- Initialize modules
    data.initialize();
    display.initialize();
    autoroll.initialize();
    config.initialize();
    
    print("CorsairRolls addon loaded. Use /cor to access commands.");
end);

-- Process incoming chat messages
ashita.events.register('text_in', 'corsair_text_in', function(e)
    return tracker.process_message(e.message);
end);

-- Update the display
ashita.events.register('d3d_present', 'corsair_present', function()
    display.update();
    config.render();
    autoroll.process();
end);

-- Handle addon unloading
ashita.events.register('unload', 'corsair_unload', function()
    display.cleanup();
    data.save();
end);

-- Handle zone changes - clear rolls when entering a new area
-- We'll use multiple methods to ensure zone changes are detected
ashita.events.register('packet_in', 'corsair_packet_in', function(e)
    -- Packet 0x0A is the zone change packet
    if e.id == 0x0A then
        local new_zone = struct.unpack('H', e.data, 0x30 + 1);
        
        -- If we're changing zones (and not just loading in for the first time)
        if current_zone ~= 0 and new_zone ~= current_zone then
            print("CorsairRolls: Zone change detected - clearing all rolls");
            
            -- Clear all rolls when zoning
            tracker.clear_rolls();
            
            -- Clear bust status
            local autoroll_module = package.loaded['autoroll'];
            if autoroll_module then
                autoroll_module.set_bust_status(autoroll_module.config.roll1.name, false);
                autoroll_module.set_bust_status(autoroll_module.config.roll2.name, false);
            end
        end
        
        -- Update current zone
        current_zone = new_zone;
    end
    
    return false;
end);



-- Command handler for configuration
ashita.events.register('command', 'corsair_command', function(e)
    -- Parse the command
    local args = e.command:args();
    if (#args == 0 or args[1] ~= '/cor') then
        return false;
    end

    -- Handle the command
    if (#args == 1) then
        -- Toggle configuration window
        config.toggle();
    elseif (args[2] == 'toggle') then
        -- Toggle visibility
        display.toggle_visibility();
    elseif (args[2] == 'clear') then
        -- Clear all rolls
        tracker.clear_rolls();
    elseif (args[2] == 'test') then
        -- Add test rolls
        tracker.add_test_rolls();
    elseif (args[2] == 'debug') then
        -- Toggle debug mode
        data.toggle_debug();
    elseif (args[2] == 'autoroll') then
        if (args[3] == 'toggle') then
            -- Toggle auto roll
            autoroll.toggle();
        elseif (args[3] == 'roll1' and args[4] == 'toggle') then
            -- Toggle roll 1
            autoroll.toggle_roll(1);
        elseif (args[3] == 'roll2' and args[4] == 'toggle') then
            -- Toggle roll 2
            autoroll.toggle_roll(2);
        elseif (args[3] == 'roll1' and args[4] == 'set' and args[5]) then
            -- Set roll 1 type
            autoroll.set_roll(1, args[5] .. " Roll");
        elseif (args[3] == 'roll2' and args[4] == 'set' and args[5]) then
            -- Set roll 2 type
            autoroll.set_roll(2, args[5] .. " Roll");
        elseif (args[3] == 'fold' and args[4] == 'toggle') then
            -- Toggle use of Fold on bust
            autoroll.toggle_fold_on_bust();
        elseif (args[3] == 'randomdeal' and args[4] == 'toggle') then
            -- Toggle use of Random Deal
            autoroll.toggle_random_deal();
        else
            -- Show auto roll help
            print("Auto Roll commands:");
            print("/cor autoroll toggle - Toggle auto roll");
            print("/cor autoroll roll1 toggle - Toggle roll 1");
            print("/cor autoroll roll2 toggle - Toggle roll 2");
            print("/cor autoroll roll1 set [name] - Set roll 1 type (e.g. Corsairs)");
            print("/cor autoroll roll2 set [name] - Set roll 2 type (e.g. Samurai)");
            print("/cor autoroll fold toggle - Toggle use of Fold on bust");
            print("/cor autoroll randomdeal toggle - Toggle use of Random Deal");
        end
    elseif (args[2] == 'color' and args[3] == 'lucky' and args[4]) then
        -- Set lucky color
        display.set_lucky_color(args[4]);
    elseif (args[2] == 'color' and args[3] == 'unlucky' and args[4]) then
        -- Set unlucky color
        display.set_unlucky_color(args[4]);
    else
        -- Show help
        print("CorsairRolls commands:");
        print("/cor - Toggle configuration window");
        print("/cor toggle - Toggle visibility");
        print("/cor clear - Clear all rolls");
        print("/cor test - Add test rolls");
        print("/cor debug - Toggle debug mode");
        print("/cor autoroll - Auto roll commands");
        print("/cor color lucky [hex] - Set lucky roll color (e.g. 00FF00 for green)");
        print("/cor color unlucky [hex] - Set unlucky roll color (e.g. FF8000 for orange)");
    end

    return true;
end);