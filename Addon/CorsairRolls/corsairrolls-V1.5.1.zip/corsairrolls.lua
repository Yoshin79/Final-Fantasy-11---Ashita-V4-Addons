-- corsairrolls.lua for Ashita v4
addon.name      = 'corsairrolls';
addon.author    = 'Oneword - Ninja Ai';
addon.version   = '1.5.1';
addon.desc      = 'Tracks Corsair rolls  lucky/unlucky numbers';

require('common');
local settings = require('settings');

-- Load modules
local data = require('data');
local display = require('display');
local tracker = require('tracker');
local config = require('config');

-- Initialize the addon
ashita.events.register('load', 'corsair_load', function()
    -- Initialize modules
    data.initialize();
    display.initialize();
    config.initialize();
    
    print("CorsairRolls addon loaded. Use /cor to access commands.");
end);

-- Process incoming chat messages
ashita.events.register('text_in', 'corsair_text_in', function(e)
    return tracker.process_message(e.message);
end);

-- Update the display
ashita.events.register('d3d_present', 'corsair_present', function()
    display.update();
    config.render();
end);

-- Handle addon unloading
ashita.events.register('unload', 'corsair_unload', function()
    display.cleanup();
    data.save();
end);

-- Command handler for configuration
ashita.events.register('command', 'corsair_command', function(e)
    -- Parse the command
    local args = e.command:args();
    if (#args == 0 or args[1] ~= '/cor') then
        return false;
    end

    -- Handle the command
    if (#args == 1) then
        -- Toggle configuration window
        config.toggle();
    elseif (args[2] == 'toggle') then
        -- Toggle visibility
        display.toggle_visibility();
    elseif (args[2] == 'clear') then
        -- Clear all rolls
        tracker.clear_rolls();
    elseif (args[2] == 'test') then
        -- Add test rolls
        tracker.add_test_rolls();
    elseif (args[2] == 'debug') then
        -- Toggle debug mode
        data.toggle_debug();
    elseif (args[2] == 'color' and args[3] == 'lucky' and args[4]) then
        -- Set lucky color
        display.set_lucky_color(args[4]);
    elseif (args[2] == 'color' and args[3] == 'unlucky' and args[4]) then
        -- Set unlucky color
        display.set_unlucky_color(args[4]);
    else
        -- Show help
        print("CorsairRolls commands:");
        print("/cor - Toggle configuration window");
        print("/cor toggle - Toggle visibility");
        print("/cor clear - Clear all rolls");
        print("/cor test - Add test rolls");
        print("/cor debug - Toggle debug mode");
        print("/cor color lucky [hex] - Set lucky roll color (e.g. 00FF00 for green)");
        print("/cor color unlucky [hex] - Set unlucky roll color (e.g. FF8000 for orange)");
    end

    return true;
end);
