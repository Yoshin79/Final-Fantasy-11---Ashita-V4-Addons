-- display.lua - Display and font handling for CorsairRolls addon

local data = require('data');

local display = {};
local roll_fonts = {};
local is_dragging = false;
local last_pos_x = 0;
local last_pos_y = 0;

-- Initialize display
function display.initialize()
    local settings = data.get_settings();
    roll_fonts = {};
    
    -- Create the font objects for rolls (up to 2 active rolls)
    for i = 1, 2 do
        local font = AshitaCore:GetFontManager():Create('__corsair_roll_' .. i);
        font:SetPositionX(settings.position.x);
        font:SetPositionY(settings.position.y + ((i - 1) * (settings.font.size + 4)));
        font:SetColor(settings.colors.text);
        font:SetFontFamily(settings.font.family);
        font:SetFontHeight(settings.font.size);
        font:GetBackground():SetVisible(true);
        font:GetBackground():SetColor(settings.colors.background);
        font:SetVisible(false); -- Initially hidden until rolls are active
        font:SetLocked(false);   -- Allow the font to be dragged
        
        roll_fonts[i] = font;
    end
    
    -- Initialize last position
    last_pos_x = settings.position.x;
    last_pos_y = settings.position.y;
end

-- Normalize roll name to handle apostrophes consistently
local function normalize_roll_name(name)
    -- Remove apostrophes for consistent lookup
    local normalized = name:gsub("'", "");
    
    -- Map common variations to standard names
    if normalized == "Companions Roll" then
        return "Companions Roll";
    end
    
    return normalized;
end

-- Check if a value is a lucky number for a roll
local function is_lucky_number(roll_name, value)
    -- Debug the roll name
    if data.is_debug() then
        print("DEBUG: Checking if " .. value .. " is lucky for " .. roll_name);
    end
    
    -- 11 is always lucky for any roll
    if value == 11 then
        if data.is_debug() then
            print("DEBUG: 11 is always lucky!");
        end
        return true;
    end
    
    -- Normalize the roll name
    local normalized_name = normalize_roll_name(roll_name);
    
    -- Check against the standard lucky number in roll_data
    local roll_data_entry = data.get_roll_data()[normalized_name];
    if not roll_data_entry and data.is_debug() then
        print("DEBUG: No roll data found for " .. normalized_name);
        -- Try to find a close match
        for name, _ in pairs(data.get_roll_data()) do
            print("DEBUG: Available roll: " .. name);
        end
        return false;
    end
    
    if roll_data_entry and value == roll_data_entry.lucky then
        if data.is_debug() then
            print("DEBUG: " .. value .. " matches lucky number for " .. normalized_name);
        end
        return true;
    end
    
    return false;
end

-- Check if a value is an unlucky number for a roll
local function is_unlucky_number(roll_name, value)
    -- Normalize the roll name
    local normalized_name = normalize_roll_name(roll_name);
    
    local roll_data_entry = data.get_roll_data()[normalized_name];
    if not roll_data_entry and data.is_debug() then
        print("DEBUG: No roll data found for " .. normalized_name .. " when checking unlucky");
        return false;
    end
    
    if roll_data_entry and value == roll_data_entry.unlucky then
        if data.is_debug() then
            print("DEBUG: " .. value .. " matches unlucky number for " .. normalized_name);
        end
        return true;
    end
    
    return false;
end

-- Update the display
function display.update()
    local settings = data.get_settings();
    
    -- Update roll displays
    for i = 1, 2 do
        local font = roll_fonts[i];
        local roll = settings.active_rolls[i];
        
        if font and roll then
            -- Set text and make visible
            local roll_text = string.format('%s = %d', roll.name, roll.value);
            font:SetText(roll_text);
            font:SetVisible(settings.visible);
            
            -- Set color based on lucky/unlucky
            if is_lucky_number(roll.name, roll.value) then
                font:SetColor(settings.colors.lucky);
                if data.is_debug() then
                    print("DEBUG: " .. roll.name .. " value " .. roll.value .. " is lucky!");
                end
            elseif is_unlucky_number(roll.name, roll.value) then
                font:SetColor(settings.colors.unlucky);
                if data.is_debug() then
                    print("DEBUG: " .. roll.name .. " value " .. roll.value .. " is unlucky!");
                end
            else
                font:SetColor(settings.colors.text);
                if data.is_debug() then
                    print("DEBUG: " .. roll.name .. " value " .. roll.value .. " is normal.");
                end
            end
            
            -- Update position based on first font (for secondary rolls)
            if i > 1 then
                font:SetPositionX(roll_fonts[1]:GetPositionX());
                font:SetPositionY(roll_fonts[1]:GetPositionY() + ((i - 1) * (settings.font.size + 4)));
            end
        elseif font then
            -- No roll data for this slot, hide it
            font:SetVisible(false);
        end
    end
    
    -- Check if the first font has been moved
    if roll_fonts[1] then
        local pos_x = roll_fonts[1]:GetPositionX();
        local pos_y = roll_fonts[1]:GetPositionY();
        
        -- Only update if position has changed
        if pos_x ~= last_pos_x or pos_y ~= last_pos_y then
            -- Update settings with new position
            settings.position.x = pos_x;
            settings.position.y = pos_y;
            
            -- Update last known position
            last_pos_x = pos_x;
            last_pos_y = pos_y;
            
            -- Save settings
            data.save();
            
            if data.is_debug() then
                print("DEBUG: Position updated to X:" .. pos_x .. " Y:" .. pos_y);
            end
        end
    end
end

-- Clean up display resources
function display.cleanup()
    for i = 1, 2 do
        if roll_fonts[i] ~= nil then
            AshitaCore:GetFontManager():Delete('__corsair_roll_' .. i);
        end
    end
end

-- Toggle visibility
function display.toggle_visibility()
    local settings = data.get_settings();
    settings.visible = not settings.visible;
    
    for i = 1, 2 do
        if roll_fonts[i] and settings.active_rolls[i] then
            roll_fonts[i]:SetVisible(settings.visible);
        end
    end
    
    data.save();
end

-- Set lucky color
function display.set_lucky_color(hex)
    local color = tonumber('0xFF' .. hex, 16);
    if color then
        data.get_settings().colors.lucky = color;
        data.save();
        print("Lucky roll color set to #" .. hex);
    else
        print("Invalid color format. Use hex format like 00FF00 for green.");
    end
end

-- Set unlucky color
function display.set_unlucky_color(hex)
    local color = tonumber('0xFF' .. hex, 16);
    if color then
        data.get_settings().colors.unlucky = color;
        data.save();
        print("Unlucky roll color set to #" .. hex);
    else
        print("Invalid color format. Use hex format like FF8000 for orange.");
    end
end

-- Update font settings
function display.update_font_settings(family, size)
    local settings = data.get_settings();
    
    if family then
        settings.font.family = family;
    end
    
    if size then
        settings.font.size = size;
    end
    
    for i = 1, 2 do
        if roll_fonts[i] then
            if family then
                roll_fonts[i]:SetFontFamily(settings.font.family);
            end
            
            if size then
                roll_fonts[i]:SetFontHeight(settings.font.size);
                
                -- Only adjust position of secondary rolls
                if i > 1 then
                    roll_fonts[i]:SetPositionY(roll_fonts[1]:GetPositionY() + ((i - 1) * (settings.font.size + 4)));
                end
            end
        end
    end
    
    data.save();
end

-- Update background color
function display.update_background_color(color)
    local settings = data.get_settings();
    settings.colors.background = color;
    
    for i = 1, 2 do
        if roll_fonts[i] then
            roll_fonts[i]:GetBackground():SetColor(color);
        end
    end
    
    data.save();
end

-- Set position manually
function display.set_position(x, y)
    if roll_fonts[1] then
        roll_fonts[1]:SetPositionX(x);
        roll_fonts[1]:SetPositionY(y);
        
        -- Update settings
        local settings = data.get_settings();
        settings.position.x = x;
        settings.position.y = y;
        
        -- Update last known position
        last_pos_x = x;
        last_pos_y = y;
        
        -- Update secondary rolls
        for i = 2, #roll_fonts do
            if roll_fonts[i] then
                roll_fonts[i]:SetPositionX(x);
                roll_fonts[i]:SetPositionY(y + ((i - 1) * (settings.font.size + 4)));
            end
        end
        
        data.save();
    end
end

return display;
