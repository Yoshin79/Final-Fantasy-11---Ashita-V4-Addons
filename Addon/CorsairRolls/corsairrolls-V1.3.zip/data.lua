-- data.lua - Roll data and configuration for CorsairRolls addon

local settings = require('settings');

local data = {};

-- Roll data: name, lucky, unlucky
data.roll_data = {
    ["Fighters Roll"] = {lucky = 5, unlucky = 9},
    ["Monks Roll"] = {lucky = 3, unlucky = 7},
    ["Healers Roll"] = {lucky = 3, unlucky = 7},
    ["Wizards Roll"] = {lucky = 5, unlucky = 9},
    ["Warlocks Roll"] = {lucky = 4, unlucky = 8},
    ["Rogues Roll"] = {lucky = 5, unlucky = 9},
    ["Gallants Roll"] = {lucky = 3, unlucky = 7},
    ["Chaos Roll"] = {lucky = 4, unlucky = 8},
    ["Beast Roll"] = {lucky = 4, unlucky = 8},
    ["Choral Roll"] = {lucky = 2, unlucky = 6},
    ["Hunters Roll"] = {lucky = 4, unlucky = 8},
    ["Samurai Roll"] = {lucky = 2, unlucky = 6},
    ["Ninja Roll"] = {lucky = 4, unlucky = 8},
    ["Drachen Roll"] = {lucky = 4, unlucky = 8},
    ["Evokers Roll"] = {lucky = 5, unlucky = 9},
    ["Maguss Roll"] = {lucky = 2, unlucky = 6},
    ["Corsairs Roll"] = {lucky = 5, unlucky = 9},
    ["Puppet Roll"] = {lucky = 3, unlucky = 7},
    ["Dancers Roll"] = {lucky = 3, unlucky = 7},
    ["Scholars Roll"] = {lucky = 2, unlucky = 6},
    ["Bolters Roll"] = {lucky = 3, unlucky = 9},
    ["Casters Roll"] = {lucky = 2, unlucky = 7},
    ["Coursers Roll"] = {lucky = 3, unlucky = 9},
    ["Blitzers Roll"] = {lucky = 4, unlucky = 9},
    ["Tacticians Roll"] = {lucky = 5, unlucky = 8},
    ["Allies Roll"] = {lucky = 3, unlucky = 10},
    ["Misers Roll"] = {lucky = 5, unlucky = 7},
    ["Companions Roll"] = {lucky = 2, unlucky = 10},
    ["Avengers Roll"] = {lucky = 4, unlucky = 8},
    ["Naturalists Roll"] = {lucky = 3, unlucky = 7},
    ["Runeists Roll"] = {lucky = 4, unlucky = 8}
};

-- Default configuration
local default_config = T{
    position = T{ x = 100, y = 100 },
    visible = true,
    colors = T{
        text = 0xFFFFFFFF,       -- White text
        background = 0xE0000066, -- Semi-transparent dark blue
        lucky = 0xFF00FF00,      -- Green for lucky rolls
        unlucky = 0xFFFF8000,    -- Orange for unlucky rolls
    },
    font = T{
        family = 'Arial',
        size = 11
    },
    active_rolls = T{},          -- Will store active rolls
    config_visible = false       -- Configuration window visibility
};

-- Available font families
data.font_families = T{
    'Arial',
    'Consolas',
    'Courier New',
    'Georgia',
    'Tahoma',
    'Times New Roman',
    'Trebuchet MS',
    'Verdana'
};

-- Initialize data
function data.initialize()
    data.settings = settings.load(default_config);
    data.debug = false;
end

-- Save settings
function data.save()
    settings.save();
end

-- Toggle debug mode
function data.toggle_debug()
    data.debug = not data.debug;
    print("Debug mode " .. (data.debug and "enabled" or "disabled"));
end

-- Get settings
function data.get_settings()
    return data.settings;
end

-- Get roll data
function data.get_roll_data()
    return data.roll_data;
end

-- Get font families
function data.get_font_families()
    return data.font_families;
end

-- Is debug enabled
function data.is_debug()
    return data.debug;
end

return data;
