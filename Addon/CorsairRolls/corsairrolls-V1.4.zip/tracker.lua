-- tracker.lua - Roll tracking logic for CorsairRolls addon

local data = require('data');

local tracker = {};

-- Process incoming chat messages
function tracker.process_message(message)
    if data.is_debug() then
        print("DEBUG: " .. message);
    end
    
    -- Pattern to match roll messages
    -- Example: "Cariblou uses Samurai Roll. The total comes to 8!"
    local roll_pattern = "([%w%s']+) uses ([%w%s']+) Roll%. The total comes to (%d+)!";
    local player, roll_name, roll_value = string.match(message, roll_pattern);
    
    if player and roll_name and roll_value then
        roll_value = tonumber(roll_value);
        local full_roll_name = roll_name .. " Roll";
        
        if data.is_debug() then
            print("Roll detected: " .. player .. " used " .. full_roll_name .. " with value " .. roll_value);
        end
        
        tracker.update_roll(full_roll_name, roll_value);
    end
    
    -- Pattern to match bust messages
    -- Example: "Bust!"
    if string.match(message, "Bust!") then
        if data.is_debug() then
            print("Bust detected");
        end
        
        -- If we have a roll that was just mentioned, remove it
        local settings = data.get_settings();
        if #settings.active_rolls > 0 then
            table.remove(settings.active_rolls, #settings.active_rolls);
            data.save();
        end
    end
    
    -- Pattern to match Fold ability
    -- Example: "Cariblou uses Fold."
    local fold_pattern = "([%w%s']+) uses Fold%.";
    local fold_player = string.match(message, fold_pattern);
    
    if fold_player then
        if data.is_debug() then
            print("Fold detected: " .. fold_player .. " used Fold");
        end
        
        -- Remove the last roll
        local settings = data.get_settings();
        if #settings.active_rolls > 0 then
            table.remove(settings.active_rolls, #settings.active_rolls);
            data.save();
        end
    end
    
    -- Pattern to match double-up messages
    -- Example: "The total for Samurai Roll increases to 11!"
    local doubleup_pattern = "The total for ([%w%s']+) Roll increases to (%d+)!";
    local du_roll, du_value = string.match(message, doubleup_pattern);
    
    if du_roll and du_value then
        du_value = tonumber(du_value);
        local full_du_roll = du_roll .. " Roll";
        
        if data.is_debug() then
            print("Double-up detected: " .. full_du_roll .. " increased to " .. du_value);
        end
        
        tracker.update_roll(full_du_roll, du_value);
    end
    
    -- Pattern to match roll effect loss
    -- Example: "Cariblou loses the effect of Samurai Roll."
    local effect_loss_pattern = "([%w%s']+) loses the effect of ([%w%s']+) Roll%.";
    local loss_player, loss_roll = string.match(message, effect_loss_pattern);
    
    if loss_player and loss_roll then
        local full_loss_roll = loss_roll .. " Roll";
        
        if data.is_debug() then
            print("Roll effect lost: " .. loss_player .. " lost " .. full_loss_roll);
        end
        
        tracker.remove_roll(full_loss_roll);
    end
    
    -- Pattern to match Snake Eye ability
    -- Example: "Cariblou uses Snake Eye."
    local snake_eye_pattern = "([%w%s']+) uses Snake Eye%.";
    local snake_eye_player = string.match(message, snake_eye_pattern);
    
    if snake_eye_player then
        if data.is_debug() then
            print("Snake Eye detected: " .. snake_eye_player .. " used Snake Eye");
        end
        
        -- We don't need to do anything special here, just log it for debugging
    end
    
    return false;
end

-- Update a roll
function tracker.update_roll(roll_name, roll_value)
    local settings = data.get_settings();
    
    -- Check if this roll is already active
    local found = false;
    for i, roll in ipairs(settings.active_rolls) do
        if roll.name == roll_name then
            roll.value = roll_value;
            found = true;
            break;
        end
    end
    
    -- If not found, add it as a new roll
    if not found then
        -- If we already have 2 rolls, remove the oldest one
        if #settings.active_rolls >= 2 then
            table.remove(settings.active_rolls, 1);
        end
        
        -- Add the new roll
        table.insert(settings.active_rolls, {
            name = roll_name,
            value = roll_value
        });
    end
    
    -- Save settings
    data.save();
end

-- Remove a roll
function tracker.remove_roll(roll_name)
    local settings = data.get_settings();
    
    for i, roll in ipairs(settings.active_rolls) do
        if roll.name == roll_name then
            table.remove(settings.active_rolls, i);
            break;
        end
    end
    
    data.save();
end

-- Clear all rolls
function tracker.clear_rolls()
    data.get_settings().active_rolls = T{};
    data.save();
end

-- Add test rolls
function tracker.add_test_rolls()
    data.get_settings().active_rolls = T{
        { name = "Hunters Roll", value = 4 },
        { name = "Tacticians Roll", value = 8 }
    };
    data.save();
end

return tracker;
